import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/home/HeroSection.vue");const _sfc_main = {  }
import { createElementVNode as _createElementVNode, createTextVNode as _createTextVNode, resolveComponent as _resolveComponent, withCtx as _withCtx, createVNode as _createVNode, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/node_modules/.vite/deps/vue.js?v=7f2dea69"

const _hoisted_1 = { class: "px-10 sm:px-20 pt-28" }

function _sfc_render(_ctx, _cache) {
  const _component_RouterLink = _resolveComponent("RouterLink")

  return (_openBlock(), _createElementBlock("section", null, [
    _createElementVNode("div", _hoisted_1, [
      _cache[1] || (_cache[1] = _createElementVNode("h1", { class: "font-['Playfair-Display'] text-5xl text-text-default font-bold max-w-2xl pb-2" }, " Descubre nuestra auténtica carta italiana. ", -1 /* CACHED */)),
      _cache[2] || (_cache[2] = _createElementVNode("p", { class: "text-lg text-text-brand max-w-md pb-14" }, " Recetas de herencia preparadas con ingredientes frescos y la pasión de siempre. ", -1 /* CACHED */)),
      _createVNode(_component_RouterLink, {
        to: "/cart",
        class: "text-lg text-text-on-special bg-bg-brand-darker py-5 px-14 sm:px-20 rounded-lg transition-colors hover:bg-bg-brand"
      }, {
        default: _withCtx(() => [...(_cache[0] || (_cache[0] = [
          _createTextVNode(" Revisar pedido → ", -1 /* CACHED */)
        ]))]),
        _: 1 /* STABLE */
      })
    ])
  ]))
}



_sfc_main.__hmrId = "c0a1d4d8"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"C:/Users/simooone/Desktop/cosas/factoria f5/trabajos/project-p5-digital-academy-team3-restaurant-frontend/src/components/home/HeroSection.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQzovVXNlcnMvc2ltb29vbmUvRGVza3RvcC9jb3Nhcy9mYWN0b3JpYSBmNS90cmFiYWpvcy9wcm9qZWN0LXA1LWRpZ2l0YWwtYWNhZGVteS10ZWFtMy1yZXN0YXVyYW50LWZyb250ZW5kL3NyYy9jb21wb25lbnRzL2hvbWUvSGVyb1NlY3Rpb24udnVlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkhlcm9TZWN0aW9uLnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8c2NyaXB0IHNldHVwPlxyXG48L3NjcmlwdD5cclxuXHJcbjx0ZW1wbGF0ZT5cclxuICAgIDxzZWN0aW9uPlxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCIgcHgtMTAgc206cHgtMjAgcHQtMjhcIj5cclxuICAgICAgICAgICAgPGgxIGNsYXNzPVwiZm9udC1bJ1BsYXlmYWlyLURpc3BsYXknXSB0ZXh0LTV4bCB0ZXh0LXRleHQtZGVmYXVsdCBmb250LWJvbGQgbWF4LXctMnhsIHBiLTJcIj5cclxuICAgICAgICAgICAgICAgIERlc2N1YnJlIG51ZXN0cmEgYXV0w6ludGljYSBjYXJ0YSBpdGFsaWFuYS5cclxuICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAgPHAgY2xhc3M9XCJ0ZXh0LWxnIHRleHQtdGV4dC1icmFuZCBtYXgtdy1tZCBwYi0xNFwiPlxyXG4gICAgICAgICAgICAgICAgUmVjZXRhcyBkZSBoZXJlbmNpYSBwcmVwYXJhZGFzIGNvbiBpbmdyZWRpZW50ZXMgZnJlc2NvcyB5IGxhIHBhc2nDs24gZGUgc2llbXByZS5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8Um91dGVyTGluayB0bz1cIi9jYXJ0XCIgY2xhc3M9XCJ0ZXh0LWxnIHRleHQtdGV4dC1vbi1zcGVjaWFsIGJnLWJnLWJyYW5kLWRhcmtlciBweS01IHB4LTE0IHNtOnB4LTIwIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1jb2xvcnMgaG92ZXI6YmctYmctYnJhbmRcIj5cclxuICAgICAgICAgICAgICAgIFJldmlzYXIgcGVkaWRvIOKGklxyXG4gICAgICAgICAgICA8L1JvdXRlckxpbms+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICA8L3NlY3Rpb24+XHJcbjwvdGVtcGxhdGU+Il0sIm1hcHBpbmdzIjoiOzs7cUJBS2EsS0FBSyxFQUFDLHNCQUF1Qjs7Ozs7d0JBRHRDLG9CQVlVO0lBWE4sb0JBVU0sT0FWTixVQVVNO2dDQVRGLG9CQUVLLFFBRkQsS0FBSyxFQUFDLCtFQUErRSxJQUFDLDhDQUUxRjtnQ0FDQSxvQkFFSSxPQUZELEtBQUssRUFBQyx3Q0FBd0MsSUFBQyxtRkFFbEQ7TUFDQSxhQUVhO1FBRkQsRUFBRSxFQUFDLE9BQU87UUFBQyxLQUFLLEVBQUMsb0hBQW9IOzswQkFBQyxDQUVsSjsyQkFGa0osb0JBRWxKIiwiaWdub3JlTGlzdCI6W119