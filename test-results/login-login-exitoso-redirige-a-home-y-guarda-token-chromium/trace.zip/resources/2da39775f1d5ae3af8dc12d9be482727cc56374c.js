import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/home/ProductCard.vue");import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false, "VITE_API_URL": "http://localhost:8080"};import { ref } from "/node_modules/.vite/deps/vue.js?v=7f2dea69";
import addToCartIcon from "/src/assets/addtocart.svg?import"
import { useCart } from "/src/composables/useCart.js"


const _sfc_main = {
  __name: 'ProductCard',
  props: {
    id: {
        type: Number,
        required: true,
    },
    name: {
        type: String,
        required: true,
    },
    description: {
        type: String,
        required: true,
    },
    category: {
        type: String,
        required: true,
    },
    price: {
        type: Number,
        required: true,
    },
    imageUrl: {
        type: String,
        required: true,
    }
},
  setup(__props, { expose: __expose }) {
  __expose();

const { addToCart } = useCart()

const props = __props

function getFullImageUrl(relativePath) {
  return import.meta.env.VITE_API_URL + relativePath
}

const quantity = ref(1)

// function addToCart() {
//     emit('add-to-cart', { id: props.id, quantity: quantity.value })
//     quantity.value = 1
// }

function handleAddToCart() {
    addToCart({ id: props.id, name: props.name, price: props.price, image: getFullImageUrl(props.imageUrl)}, quantity.value)
    quantity.value = 1
}

function increase() {
    quantity.value++;
}

function decrease() {
    if (quantity.value > 1) quantity.value--;
}


const __returned__ = { addToCart, props, getFullImageUrl, quantity, handleAddToCart, increase, decrease, ref, get addToCartIcon() { return addToCartIcon }, get useCart() { return useCart } }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { createElementVNode as _createElementVNode, toDisplayString as _toDisplayString, createTextVNode as _createTextVNode, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/node_modules/.vite/deps/vue.js?v=7f2dea69"

const _hoisted_1 = { class: "bg-bg-container rounded-xl shadow-sm overflow-hidden" }
const _hoisted_2 = ["src", "alt"]
const _hoisted_3 = { class: "p-4 space-y-3" }
const _hoisted_4 = { class: "font-['Playfair-Display'] text-xl text-text-default font-bold" }
const _hoisted_5 = { class: "text-sm line-clamp-2 text-text-muted" }
const _hoisted_6 = { class: "flex justify-between items-center" }
const _hoisted_7 = { class: "flex items-center h-8 justify-center bg-bg-container-high rounded-2xl overflow-hidden" }
const _hoisted_8 = {
  class: "min-w-7 text-center flex-1",
  "data-testid": "quantity"
}
const _hoisted_9 = { class: "font-['Playfair-Display'] text-xl text-text-special font-bold" }
const _hoisted_10 = ["src"]

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createElementBlock("article", _hoisted_1, [
    _createElementVNode("img", {
      src: $setup.getFullImageUrl($props.imageUrl),
      alt: $props.name,
      class: "w-full object-cover aspect-video"
    }, null, 8 /* PROPS */, _hoisted_2),
    _createElementVNode("div", _hoisted_3, [
      _createElementVNode("h3", _hoisted_4, _toDisplayString($props.name), 1 /* TEXT */),
      _createElementVNode("p", _hoisted_5, _toDisplayString($props.description), 1 /* TEXT */),
      _createElementVNode("div", _hoisted_6, [
        _createElementVNode("div", _hoisted_7, [
          _createElementVNode("button", {
            class: "flex items-center justify-center flex-1 px-4 py-2 transition-colors hover:bg-bg-brand-darker hover:text-text-on-brand active:bg-bg-brand",
            type: "button",
            "data-testid": "decrease",
            onClick: $setup.decrease
          }, " - "),
          _createElementVNode("span", _hoisted_8, _toDisplayString($setup.quantity), 1 /* TEXT */),
          _createElementVNode("button", {
            class: "flex items-center justify-center flex-1 px-4 py-2 transition-colors hover:bg-bg-brand-darker hover:text-text-on-brand active:bg-bg-brand",
            type: "button",
            "data-testid": "increase",
            onClick: $setup.increase
          }, " + ")
        ]),
        _createElementVNode("p", _hoisted_9, _toDisplayString($props.price) + " € ", 1 /* TEXT */)
      ]),
      _createElementVNode("button", {
        class: "w-full bg-bg-brand-darker text-text-on-brand inline-flex items-center justify-center gap-2 rounded-xl p-2 transition-colors hover:bg-bg-brand active:bg-bg-brand-hover",
        type: "button",
        "data-testid": "add-to-cart",
        onClick: $setup.handleAddToCart
      }, [
        _createElementVNode("img", {
          src: $setup.addToCartIcon,
          alt: ""
        }, null, 8 /* PROPS */, _hoisted_10),
        _cache[0] || (_cache[0] = _createTextVNode(" Añadir a la cesta ", -1 /* CACHED */))
      ])
    ])
  ]))
}



_sfc_main.__hmrId = "fa33e794"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"C:/Users/simooone/Desktop/cosas/factoria f5/trabajos/project-p5-digital-academy-team3-restaurant-frontend/src/components/home/ProductCard.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUHJvZHVjdENhcmQudnVlIl0sInNvdXJjZXNDb250ZW50IjpbIjxzY3JpcHQgc2V0dXA+XHJcbmltcG9ydCB7IHJlZiB9IGZyb20gJ3Z1ZSc7XHJcbmltcG9ydCBhZGRUb0NhcnRJY29uIGZyb20gJy4uLy4uL2Fzc2V0cy9hZGR0b2NhcnQuc3ZnJ1xyXG5pbXBvcnQgeyB1c2VDYXJ0IH0gZnJvbSAnLi4vLi4vY29tcG9zYWJsZXMvdXNlQ2FydC5qcydcclxuXHJcbmNvbnN0IHsgYWRkVG9DYXJ0IH0gPSB1c2VDYXJ0KClcclxuXHJcbmNvbnN0IHByb3BzID0gZGVmaW5lUHJvcHMoe1xyXG4gICAgaWQ6IHtcclxuICAgICAgICB0eXBlOiBOdW1iZXIsXHJcbiAgICAgICAgcmVxdWlyZWQ6IHRydWUsXHJcbiAgICB9LFxyXG4gICAgbmFtZToge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICByZXF1aXJlZDogdHJ1ZSxcclxuICAgIH0sXHJcbiAgICBkZXNjcmlwdGlvbjoge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICByZXF1aXJlZDogdHJ1ZSxcclxuICAgIH0sXHJcbiAgICBjYXRlZ29yeToge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICByZXF1aXJlZDogdHJ1ZSxcclxuICAgIH0sXHJcbiAgICBwcmljZToge1xyXG4gICAgICAgIHR5cGU6IE51bWJlcixcclxuICAgICAgICByZXF1aXJlZDogdHJ1ZSxcclxuICAgIH0sXHJcbiAgICBpbWFnZVVybDoge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICByZXF1aXJlZDogdHJ1ZSxcclxuICAgIH1cclxufSlcclxuXHJcbmZ1bmN0aW9uIGdldEZ1bGxJbWFnZVVybChyZWxhdGl2ZVBhdGgpIHtcclxuICByZXR1cm4gaW1wb3J0Lm1ldGEuZW52LlZJVEVfQVBJX1VSTCArIHJlbGF0aXZlUGF0aFxyXG59XHJcblxyXG5jb25zdCBxdWFudGl0eSA9IHJlZigxKVxyXG5cclxuLy8gZnVuY3Rpb24gYWRkVG9DYXJ0KCkge1xyXG4vLyAgICAgZW1pdCgnYWRkLXRvLWNhcnQnLCB7IGlkOiBwcm9wcy5pZCwgcXVhbnRpdHk6IHF1YW50aXR5LnZhbHVlIH0pXHJcbi8vICAgICBxdWFudGl0eS52YWx1ZSA9IDFcclxuLy8gfVxyXG5cclxuZnVuY3Rpb24gaGFuZGxlQWRkVG9DYXJ0KCkge1xyXG4gICAgYWRkVG9DYXJ0KHsgaWQ6IHByb3BzLmlkLCBuYW1lOiBwcm9wcy5uYW1lLCBwcmljZTogcHJvcHMucHJpY2UsIGltYWdlOiBnZXRGdWxsSW1hZ2VVcmwocHJvcHMuaW1hZ2VVcmwpfSwgcXVhbnRpdHkudmFsdWUpXHJcbiAgICBxdWFudGl0eS52YWx1ZSA9IDFcclxufVxyXG5cclxuZnVuY3Rpb24gaW5jcmVhc2UoKSB7XHJcbiAgICBxdWFudGl0eS52YWx1ZSsrO1xyXG59XHJcblxyXG5mdW5jdGlvbiBkZWNyZWFzZSgpIHtcclxuICAgIGlmIChxdWFudGl0eS52YWx1ZSA+IDEpIHF1YW50aXR5LnZhbHVlLS07XHJcbn1cclxuXHJcbjwvc2NyaXB0PlxyXG5cclxuPHRlbXBsYXRlPlxyXG4gICAgPGFydGljbGUgY2xhc3M9XCJiZy1iZy1jb250YWluZXIgcm91bmRlZC14bCBzaGFkb3ctc20gb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbiAgICAgICAgPGltZyA6c3JjPVwiZ2V0RnVsbEltYWdlVXJsKGltYWdlVXJsKVwiIDphbHQ9XCJuYW1lXCIgY2xhc3M9XCJ3LWZ1bGwgb2JqZWN0LWNvdmVyIGFzcGVjdC12aWRlb1wiPlxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJwLTQgc3BhY2UteS0zXCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzcz1cImZvbnQtWydQbGF5ZmFpci1EaXNwbGF5J10gdGV4dC14bCB0ZXh0LXRleHQtZGVmYXVsdCBmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICAgIHt7IG5hbWUgfX1cclxuICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgPHAgY2xhc3M9XCJ0ZXh0LXNtIGxpbmUtY2xhbXAtMiB0ZXh0LXRleHQtbXV0ZWRcIj5cclxuICAgICAgICAgICAgICAgIHt7IGRlc2NyaXB0aW9uIH19XHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGgtOCBqdXN0aWZ5LWNlbnRlciBiZy1iZy1jb250YWluZXItaGlnaCByb3VuZGVkLTJ4bCBvdmVyZmxvdy1oaWRkZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZmxleC0xIHB4LTQgcHktMiB0cmFuc2l0aW9uLWNvbG9ycyBob3ZlcjpiZy1iZy1icmFuZC1kYXJrZXIgaG92ZXI6dGV4dC10ZXh0LW9uLWJyYW5kIGFjdGl2ZTpiZy1iZy1icmFuZFwiIHR5cGU9XCJidXR0b25cIiBkYXRhLXRlc3RpZD1cImRlY3JlYXNlXCIgQGNsaWNrPVwiZGVjcmVhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgLVxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwibWluLXctNyB0ZXh0LWNlbnRlciBmbGV4LTFcIiBkYXRhLXRlc3RpZD1cInF1YW50aXR5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt7IHF1YW50aXR5IH19XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBmbGV4LTEgcHgtNCBweS0yIHRyYW5zaXRpb24tY29sb3JzIGhvdmVyOmJnLWJnLWJyYW5kLWRhcmtlciBob3Zlcjp0ZXh0LXRleHQtb24tYnJhbmQgYWN0aXZlOmJnLWJnLWJyYW5kXCIgdHlwZT1cImJ1dHRvblwiIGRhdGEtdGVzdGlkPVwiaW5jcmVhc2VcIiBAY2xpY2s9XCJpbmNyZWFzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICArXHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzPVwiZm9udC1bJ1BsYXlmYWlyLURpc3BsYXknXSB0ZXh0LXhsIHRleHQtdGV4dC1zcGVjaWFsIGZvbnQtYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHt7IHByaWNlIH19IOKCrFxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGJ1dHRvbiBjbGFzcz1cInctZnVsbCBiZy1iZy1icmFuZC1kYXJrZXIgdGV4dC10ZXh0LW9uLWJyYW5kIGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiByb3VuZGVkLXhsIHAtMiB0cmFuc2l0aW9uLWNvbG9ycyBob3ZlcjpiZy1iZy1icmFuZCBhY3RpdmU6YmctYmctYnJhbmQtaG92ZXJcIiB0eXBlPVwiYnV0dG9uXCIgZGF0YS10ZXN0aWQ9XCJhZGQtdG8tY2FydFwiIEBjbGljaz1cImhhbmRsZUFkZFRvQ2FydFwiPlxyXG4gICAgICAgICAgICAgICAgPGltZyA6c3JjPVwiYWRkVG9DYXJ0SWNvblwiIGFsdD1cIlwiPlxyXG4gICAgICAgICAgICAgICAgQcOxYWRpciBhIGxhIGNlc3RhXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgPC9hcnRpY2xlPlxyXG48L3RlbXBsYXRlPiJdLCJtYXBwaW5ncyI6IkFBQ0EsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3REOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUpjO0FBS2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvQjtBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQXlCWjtBQUNGO0FBQ0EsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BELENBQUM7QUFDRDtBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QjtBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0RSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSjtBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1SCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RCLENBQUM7QUFDRDtBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JCLENBQUM7QUFDRDtBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzdDLENBQUM7QUFDRDs7Ozs7Ozs7OztxQkFJYSxLQUFLLEVBQUMsc0RBQXNEOztxQkFFNUQsS0FBSyxFQUFDLGVBQWU7cUJBQ2xCLEtBQUssRUFBQywrREFBK0Q7cUJBR3RFLEtBQUssRUFBQyxzQ0FBc0M7cUJBRzFDLEtBQUssRUFBQyxtQ0FBbUM7cUJBQ3JDLEtBQUssRUFBQyx1RkFBdUY7O0VBSXhGLEtBQUssRUFBQyw0QkFBNEI7RUFBQyxhQUFXLEVBQUMsVUFBVTs7cUJBT2hFLEtBQUssRUFBQywrREFBK0Q7Ozs7d0JBckJwRixvQkE4QlUsV0E5QlYsVUE4QlU7SUE3Qk4sb0JBQTJGO01BQXJGLEdBQUcsRUFBRSxzQkFBZSxDQUFDLGVBQVE7TUFBSSxHQUFHLEVBQUUsV0FBSTtNQUFFLEtBQUssRUFBQyxrQ0FBa0M7O0lBQzFGLG9CQTJCTSxPQTNCTixVQTJCTTtNQTFCRixvQkFFSyxNQUZMLFVBRUssbUJBREUsV0FBSTtNQUVYLG9CQUVJLEtBRkosVUFFSSxtQkFERyxrQkFBVztNQUVsQixvQkFlTSxPQWZOLFVBZU07UUFkRixvQkFVTSxPQVZOLFVBVU07VUFURixvQkFFUztZQUZELEtBQUssRUFBQywwSUFBMEk7WUFBQyxJQUFJLEVBQUMsUUFBUTtZQUFDLGFBQVcsRUFBQyxVQUFVO1lBQUUsT0FBSyxFQUFFLGVBQVE7YUFBRSxLQUVoTjtVQUNBLG9CQUVPLFFBRlAsVUFFTyxtQkFEQSxlQUFRO1VBRWYsb0JBRVM7WUFGRCxLQUFLLEVBQUMsMElBQTBJO1lBQUMsSUFBSSxFQUFDLFFBQVE7WUFBQyxhQUFXLEVBQUMsVUFBVTtZQUFFLE9BQUssRUFBRSxlQUFRO2FBQUUsS0FFaE47O1FBRUosb0JBRUksS0FGSixVQUVJLG1CQURHLFlBQUssSUFBRyxLQUNmOztNQUVKLG9CQUdTO1FBSEQsS0FBSyxFQUFDLHdLQUF3SztRQUFDLElBQUksRUFBQyxRQUFRO1FBQUMsYUFBVyxFQUFDLGFBQWE7UUFBRSxPQUFLLEVBQUUsc0JBQWU7O1FBQ2xQLG9CQUFpQztVQUEzQixHQUFHLEVBQUUsb0JBQWE7VUFBRSxHQUFHLEVBQUMsRUFBRTs7bURBQUMscUJBRXJDIiwiaWdub3JlTGlzdCI6W119