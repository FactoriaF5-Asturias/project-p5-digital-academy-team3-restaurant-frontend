import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/home/ContactSection.vue");import locationIcon from "/src/assets/location.svg?import"
import clockIcon from "/src/assets/clock.svg?import"
import phoneIcon from "/src/assets/phone.svg?import"

const _sfc_main = {
  __name: 'ContactSection',
  setup(__props, { expose: __expose }) {
  __expose();


const __returned__ = { get locationIcon() { return locationIcon }, get clockIcon() { return clockIcon }, get phoneIcon() { return phoneIcon } }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { createElementVNode as _createElementVNode, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/node_modules/.vite/deps/vue.js?v=7f2dea69"

const _hoisted_1 = { class: "contact-section" }
const _hoisted_2 = { class: "contact-section__content" }
const _hoisted_3 = { class: "contact-section__info" }
const _hoisted_4 = { class: "contact-section__list" }
const _hoisted_5 = { class: "contact-section__item" }
const _hoisted_6 = ["src"]
const _hoisted_7 = { class: "contact-section__item" }
const _hoisted_8 = ["src"]
const _hoisted_9 = { class: "contact-section__item" }
const _hoisted_10 = ["src"]

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createElementBlock("section", _hoisted_1, [
    _createElementVNode("div", _hoisted_2, [
      _createElementVNode("div", _hoisted_3, [
        _cache[3] || (_cache[3] = _createElementVNode("h2", { class: "contact-section__title" }, " Encuéntranos ", -1 /* CACHED */)),
        _createElementVNode("div", _hoisted_4, [
          _createElementVNode("div", _hoisted_5, [
            _createElementVNode("img", {
              src: $setup.locationIcon,
              alt: "",
              class: "contact-section__icon"
            }, null, 8 /* PROPS */, _hoisted_6),
            _cache[0] || (_cache[0] = _createElementVNode("div", null, [
              _createElementVNode("h3", { class: "contact-section__subtitle" }, "Dirección"),
              _createElementVNode("p", { class: "contact-section__text" }, "Calle Roma 123, Barrio Gótico"),
              _createElementVNode("p", { class: "contact-section__text" }, "08002, Barcelona")
            ], -1 /* CACHED */))
          ]),
          _createElementVNode("div", _hoisted_7, [
            _createElementVNode("img", {
              src: $setup.clockIcon,
              alt: "",
              class: "contact-section__icon"
            }, null, 8 /* PROPS */, _hoisted_8),
            _cache[1] || (_cache[1] = _createElementVNode("div", null, [
              _createElementVNode("h3", { class: "contact-section__subtitle" }, "Horario"),
              _createElementVNode("p", { class: "contact-section__text" }, "Lun - Jue: 13:00 - 23:00"),
              _createElementVNode("p", { class: "contact-section__text" }, "Vie - Sáb: 13:00 - 00:00"),
              _createElementVNode("p", { class: "contact-section__text contact-section__text--brand" }, "Domingo: 12:30 - 22:30")
            ], -1 /* CACHED */))
          ]),
          _createElementVNode("div", _hoisted_9, [
            _createElementVNode("img", {
              src: $setup.phoneIcon,
              alt: "",
              class: "contact-section__icon"
            }, null, 8 /* PROPS */, _hoisted_10),
            _cache[2] || (_cache[2] = _createElementVNode("div", null, [
              _createElementVNode("h3", { class: "contact-section__subtitle" }, "Contacto"),
              _createElementVNode("p", { class: "contact-section__text" }, "+34 93 123 45 67"),
              _createElementVNode("p", { class: "contact-section__text" }, "hola@giacobello.es")
            ], -1 /* CACHED */))
          ])
        ])
      ]),
      _cache[4] || (_cache[4] = _createElementVNode("div", { class: "contact-section__map" }, [
        _createElementVNode("iframe", {
          class: "contact-section__map-frame",
          title: "Mapa de Bella Vita en Barcelona",
          src: "https://www.google.com/maps?q=Calle%20Roma%20123%2C%20Barcelona&z=15&output=embed",
          loading: "lazy"
        })
      ], -1 /* CACHED */))
    ])
  ]))
}


import "/src/components/home/ContactSection.vue?vue&type=style&index=0&scoped=2751b897&lang.css"

_sfc_main.__hmrId = "2751b897"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__scopeId',"data-v-2751b897"],['__file',"C:/Users/simooone/Desktop/cosas/factoria f5/trabajos/project-p5-digital-academy-team3-restaurant-frontend/src/components/home/ContactSection.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQ29udGFjdFNlY3Rpb24udnVlIl0sInNvdXJjZXNDb250ZW50IjpbIjxzY3JpcHQgc2V0dXA+XHJcbmltcG9ydCBsb2NhdGlvbkljb24gZnJvbSAnLi4vLi4vYXNzZXRzL2xvY2F0aW9uLnN2ZydcclxuaW1wb3J0IGNsb2NrSWNvbiBmcm9tICcuLi8uLi9hc3NldHMvY2xvY2suc3ZnJ1xyXG5pbXBvcnQgcGhvbmVJY29uIGZyb20gJy4uLy4uL2Fzc2V0cy9waG9uZS5zdmcnXHJcbjwvc2NyaXB0PlxyXG48dGVtcGxhdGU+XHJcbiAgICA8c2VjdGlvbiBjbGFzcz1cImNvbnRhY3Qtc2VjdGlvblwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJjb250YWN0LXNlY3Rpb25fX2NvbnRlbnRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbnRhY3Qtc2VjdGlvbl9faW5mb1wiPlxyXG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzPVwiY29udGFjdC1zZWN0aW9uX190aXRsZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIEVuY3XDqW50cmFub3NcclxuICAgICAgICAgICAgICAgIDwvaDI+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbnRhY3Qtc2VjdGlvbl9fbGlzdFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb250YWN0LXNlY3Rpb25fX2l0ZW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOnNyYz1cImxvY2F0aW9uSWNvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbHQ9XCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJjb250YWN0LXNlY3Rpb25fX2ljb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzcz1cImNvbnRhY3Qtc2VjdGlvbl9fc3VidGl0bGVcIj5EaXJlY2Npw7NuPC9oMz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzPVwiY29udGFjdC1zZWN0aW9uX190ZXh0XCI+Q2FsbGUgUm9tYSAxMjMsIEJhcnJpbyBHw7N0aWNvPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3M9XCJjb250YWN0LXNlY3Rpb25fX3RleHRcIj4wODAwMiwgQmFyY2Vsb25hPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbnRhY3Qtc2VjdGlvbl9faXRlbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6c3JjPVwiY2xvY2tJY29uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsdD1cIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImNvbnRhY3Qtc2VjdGlvbl9faWNvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzPVwiY29udGFjdC1zZWN0aW9uX19zdWJ0aXRsZVwiPkhvcmFyaW88L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3M9XCJjb250YWN0LXNlY3Rpb25fX3RleHRcIj5MdW4gLSBKdWU6IDEzOjAwIC0gMjM6MDA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzcz1cImNvbnRhY3Qtc2VjdGlvbl9fdGV4dFwiPlZpZSAtIFPDoWI6IDEzOjAwIC0gMDA6MDA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzcz1cImNvbnRhY3Qtc2VjdGlvbl9fdGV4dCBjb250YWN0LXNlY3Rpb25fX3RleHQtLWJyYW5kXCI+RG9taW5nbzogMTI6MzAgLSAyMjozMDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb250YWN0LXNlY3Rpb25fX2l0ZW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOnNyYz1cInBob25lSWNvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbHQ9XCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJjb250YWN0LXNlY3Rpb25fX2ljb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzcz1cImNvbnRhY3Qtc2VjdGlvbl9fc3VidGl0bGVcIj5Db250YWN0bzwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzcz1cImNvbnRhY3Qtc2VjdGlvbl9fdGV4dFwiPiszNCA5MyAxMjMgNDUgNjc8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzcz1cImNvbnRhY3Qtc2VjdGlvbl9fdGV4dFwiPmhvbGFAZ2lhY29iZWxsby5lczwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29udGFjdC1zZWN0aW9uX19tYXBcIj5cclxuICAgICAgICAgICAgICAgIDxpZnJhbWVcclxuICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImNvbnRhY3Qtc2VjdGlvbl9fbWFwLWZyYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIk1hcGEgZGUgQmVsbGEgVml0YSBlbiBCYXJjZWxvbmFcIlxyXG4gICAgICAgICAgICAgICAgICAgIHNyYz1cImh0dHBzOi8vd3d3Lmdvb2dsZS5jb20vbWFwcz9xPUNhbGxlJTIwUm9tYSUyMDEyMyUyQyUyMEJhcmNlbG9uYSZ6PTE1Jm91dHB1dD1lbWJlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbG9hZGluZz1cImxhenlcIlxyXG4gICAgICAgICAgICAgICAgPjwvaWZyYW1lPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgIDwvc2VjdGlvbj5cclxuPC90ZW1wbGF0ZT5cclxuPHN0eWxlIHNjb3BlZD5cclxuQHJlZmVyZW5jZSBcIi4uLy4uL21haW4uY3NzXCI7XHJcbi5jb250YWN0LXNlY3Rpb24ge1xyXG4gICAgQGFwcGx5XHJcbiAgICAgICAgYmctYmctY29udGFpbmVyXHJcbiAgICAgICAgcHktMjA7XHJcbn1cclxuXHJcbi5jb250YWN0LXNlY3Rpb25fX2NvbnRlbnQge1xyXG4gICAgQGFwcGx5XHJcbiAgICAgICAgZ3JpZFxyXG4gICAgICAgIGdyaWQtY29scy0xXHJcbiAgICAgICAgbWQ6Z3JpZC1jb2xzLVs0MjBweF8xZnJdXHJcbiAgICAgICAgaXRlbXMtY2VudGVyXHJcbiAgICAgICAgZ2FwLTEyXHJcbiAgICAgICAgcHgtMTBcclxuICAgICAgICBtZDpweC0yMDtcclxufVxyXG5cclxuLmNvbnRhY3Qtc2VjdGlvbl9faW5mbyB7XHJcbiAgICBAYXBwbHlcclxuICAgICAgICBmbGV4XHJcbiAgICAgICAgZmxleC1jb2xcclxuICAgICAgICBnYXAtMTQ7XHJcbn1cclxuXHJcbi5jb250YWN0LXNlY3Rpb25fX3RpdGxlIHtcclxuICAgIEBhcHBseVxyXG4gICAgICAgIGZvbnQtc2VyaWZcclxuICAgICAgICB0ZXh0LTN4bFxyXG4gICAgICAgIGZvbnQtYm9sZFxyXG4gICAgICAgIHRleHQtdGV4dC1icmFuZDtcclxufVxyXG5cclxuLmNvbnRhY3Qtc2VjdGlvbl9fbGlzdCB7XHJcbiAgICBAYXBwbHlcclxuICAgICAgICBmbGV4XHJcbiAgICAgICAgZmxleC1jb2xcclxuICAgICAgICBnYXAtNjtcclxufVxyXG5cclxuLmNvbnRhY3Qtc2VjdGlvbl9faXRlbSB7XHJcbiAgICBAYXBwbHlcclxuICAgICAgICBmbGV4XHJcbiAgICAgICAgaXRlbXMtc3RhcnRcclxuICAgICAgICBnYXAtNDtcclxufVxyXG5cclxuLmNvbnRhY3Qtc2VjdGlvbl9faWNvbiB7XHJcbiAgICBAYXBwbHlcclxuICAgICAgICBoLTVcclxuICAgICAgICB3LTVcclxuICAgICAgICBzaHJpbmstMDtcclxufVxyXG5cclxuLmNvbnRhY3Qtc2VjdGlvbl9fc3VidGl0bGUge1xyXG4gICAgQGFwcGx5XHJcbiAgICAgICAgbWItMlxyXG4gICAgICAgIHRleHQtc21cclxuICAgICAgICBmb250LWJvbGRcclxuICAgICAgICB1cHBlcmNhc2VcclxuICAgICAgICB0cmFja2luZy13aWRlXHJcbiAgICAgICAgdGV4dC10ZXh0LWRlZmF1bHQ7XHJcbn1cclxuXHJcbi5jb250YWN0LXNlY3Rpb25fX3RleHQge1xyXG4gICAgQGFwcGx5XHJcbiAgICAgICAgdGV4dC1iYXNlXHJcbiAgICAgICAgbGVhZGluZy1yZWxheGVkXHJcbiAgICAgICAgdGV4dC10ZXh0LW11dGVkO1xyXG59XHJcblxyXG4uY29udGFjdC1zZWN0aW9uX190ZXh0LS1icmFuZCB7XHJcbiAgICBAYXBwbHlcclxuICAgICAgICBmb250LW1lZGl1bVxyXG4gICAgICAgIHRleHQtdGV4dC1icmFuZDtcclxufVxyXG5cclxuLmNvbnRhY3Qtc2VjdGlvbl9fbWFwIHtcclxuICAgIEBhcHBseVxyXG4gICAgICAgIG10LTRcclxuICAgICAgICBtZDptdC0yM1xyXG4gICAgICAgIG92ZXJmbG93LWhpZGRlblxyXG4gICAgICAgIHJvdW5kZWQtM3hsXHJcbiAgICAgICAgYm9yZGVyXHJcbiAgICAgICAgYm9yZGVyLWJvcmRlci1kZWZhdWx0XHJcbiAgICAgICAgc2hhZG93LXhsO1xyXG59XHJcblxyXG4uY29udGFjdC1zZWN0aW9uX19tYXAtZnJhbWUge1xyXG4gICAgQGFwcGx5XHJcbiAgICAgICAgdy1mdWxsXHJcbiAgICAgICAgYm9yZGVyLTA7XHJcbiAgICAgICAgaGVpZ2h0OiAzMjBweDtcclxufVxyXG48L3N0eWxlPiJdLCJtYXBwaW5ncyI6IkFBQ0EsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Ozs7OztBQUhoQzs7Ozs7Ozs7OztxQkFNRCxLQUFLLEVBQUMsaUJBQWlCO3FCQUN2QixLQUFLLEVBQUMsMEJBQTBCO3FCQUM1QixLQUFLLEVBQUMsdUJBQXVCO3FCQUt6QixLQUFLLEVBQUMsdUJBQXVCO3FCQUN6QixLQUFLLEVBQUMsdUJBQXVCOztxQkFjN0IsS0FBSyxFQUFDLHVCQUF1Qjs7cUJBZTdCLEtBQUssRUFBQyx1QkFBdUI7Ozs7d0JBckNsRCxvQkE4RFUsV0E5RFYsVUE4RFU7SUE3RE4sb0JBNERNLE9BNUROLFVBNERNO01BM0RGLG9CQWlETSxPQWpETixVQWlETTtrQ0FoREYsb0JBRUssUUFGRCxLQUFLLEVBQUMsd0JBQXdCLElBQUMsZ0JBRW5DO1FBRUEsb0JBMkNNLE9BM0NOLFVBMkNNO1VBMUNGLG9CQVlNLE9BWk4sVUFZTTtZQVhGLG9CQUlFO2NBSEcsR0FBRyxFQUFFLG1CQUFZO2NBQ2xCLEdBQUcsRUFBQyxFQUFFO2NBQ04sS0FBSyxFQUFDLHVCQUF1Qjs7c0NBR2pDLG9CQUlNO2NBSEYsb0JBQW9ELFFBQWhELEtBQUssRUFBQywyQkFBMkIsSUFBQyxXQUFTO2NBQy9DLG9CQUFrRSxPQUEvRCxLQUFLLEVBQUMsdUJBQXVCLElBQUMsK0JBQTZCO2NBQzlELG9CQUFxRCxPQUFsRCxLQUFLLEVBQUMsdUJBQXVCLElBQUMsa0JBQWdCOzs7VUFJekQsb0JBYU0sT0FiTixVQWFNO1lBWkYsb0JBSUU7Y0FIRyxHQUFHLEVBQUUsZ0JBQVM7Y0FDZixHQUFHLEVBQUMsRUFBRTtjQUNOLEtBQUssRUFBQyx1QkFBdUI7O3NDQUdqQyxvQkFLTTtjQUpGLG9CQUFrRCxRQUE5QyxLQUFLLEVBQUMsMkJBQTJCLElBQUMsU0FBTztjQUM3QyxvQkFBNkQsT0FBMUQsS0FBSyxFQUFDLHVCQUF1QixJQUFDLDBCQUF3QjtjQUN6RCxvQkFBNkQsT0FBMUQsS0FBSyxFQUFDLHVCQUF1QixJQUFDLDBCQUF3QjtjQUN6RCxvQkFBd0YsT0FBckYsS0FBSyxFQUFDLG9EQUFvRCxJQUFDLHdCQUFzQjs7O1VBSTVGLG9CQVlNLE9BWk4sVUFZTTtZQVhGLG9CQUlFO2NBSEcsR0FBRyxFQUFFLGdCQUFTO2NBQ2YsR0FBRyxFQUFDLEVBQUU7Y0FDTixLQUFLLEVBQUMsdUJBQXVCOztzQ0FHakMsb0JBSU07Y0FIRixvQkFBbUQsUUFBL0MsS0FBSyxFQUFDLDJCQUEyQixJQUFDLFVBQVE7Y0FDOUMsb0JBQXFELE9BQWxELEtBQUssRUFBQyx1QkFBdUIsSUFBQyxrQkFBZ0I7Y0FDakQsb0JBQXVELE9BQXBELEtBQUssRUFBQyx1QkFBdUIsSUFBQyxvQkFBa0I7Ozs7O2dDQU1uRSxvQkFPTSxTQVBELEtBQUssRUFBQyxzQkFBc0I7UUFDN0Isb0JBS1U7VUFKTixLQUFLLEVBQUMsNEJBQTRCO1VBQ2xDLEtBQUssRUFBQyxpQ0FBaUM7VUFDdkMsR0FBRyxFQUFDLG1GQUFtRjtVQUN2RixPQUFPLEVBQUMsTUFBTSIsImlnbm9yZUxpc3QiOltdfQ==