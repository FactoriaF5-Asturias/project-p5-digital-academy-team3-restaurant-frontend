import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/home/MenuCategoryFilter.vue");import { useModel as _useModel } from "/node_modules/.vite/deps/vue.js?v=7f2dea69"

const _sfc_main = {
  __name: 'MenuCategoryFilter',
  props: {
    "modelValue": {},
    "modelModifiers": {},
  },
  emits: ["update:modelValue"],
  setup(__props, { expose: __expose }) {
  __expose();

const model = _useModel(__props, "modelValue")

const categories = [
    { label: 'Todos', value: 'all' },
    { label: 'Especialidades', value: 'Especialidades' },
    { label: 'Postres', value: 'Postres' },
    { label: 'Bebidas', value: 'Bebidas' },
    // { label: 'Ofertas', value: 'ofertas' },
]

const __returned__ = { model, categories }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { renderList as _renderList, Fragment as _Fragment, openBlock as _openBlock, createElementBlock as _createElementBlock, toDisplayString as _toDisplayString, normalizeClass as _normalizeClass, createElementVNode as _createElementVNode } from "/node_modules/.vite/deps/vue.js?v=7f2dea69"

const _hoisted_1 = { class: "menu-category-filter" }
const _hoisted_2 = ["onClick"]

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createElementBlock("div", _hoisted_1, [
    (_openBlock(), _createElementBlock(_Fragment, null, _renderList($setup.categories, (category) => {
      return _createElementVNode("button", {
        key: category.value,
        type: "button",
        class: _normalizeClass(["menu-category-filter__button", { 'menu-category-filter__button--active': $setup.model === category.value }]),
        onClick: $event => ($setup.model = category.value)
      }, _toDisplayString(category.label), 11 /* TEXT, CLASS, PROPS */, _hoisted_2)
    }), 64 /* STABLE_FRAGMENT */))
  ]))
}


import "/src/components/home/MenuCategoryFilter.vue?vue&type=style&index=0&scoped=aa8f9f11&lang.css"

_sfc_main.__hmrId = "aa8f9f11"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__scopeId',"data-v-aa8f9f11"],['__file',"C:/Users/simooone/Desktop/cosas/factoria f5/trabajos/project-p5-digital-academy-team3-restaurant-frontend/src/components/home/MenuCategoryFilter.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTWVudUNhdGVnb3J5RmlsdGVyLnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8c2NyaXB0IHNldHVwPlxyXG5jb25zdCBtb2RlbCA9IGRlZmluZU1vZGVsKClcclxuXHJcbmNvbnN0IGNhdGVnb3JpZXMgPSBbXHJcbiAgICB7IGxhYmVsOiAnVG9kb3MnLCB2YWx1ZTogJ2FsbCcgfSxcclxuICAgIHsgbGFiZWw6ICdFc3BlY2lhbGlkYWRlcycsIHZhbHVlOiAnRXNwZWNpYWxpZGFkZXMnIH0sXHJcbiAgICB7IGxhYmVsOiAnUG9zdHJlcycsIHZhbHVlOiAnUG9zdHJlcycgfSxcclxuICAgIHsgbGFiZWw6ICdCZWJpZGFzJywgdmFsdWU6ICdCZWJpZGFzJyB9LFxyXG4gICAgLy8geyBsYWJlbDogJ09mZXJ0YXMnLCB2YWx1ZTogJ29mZXJ0YXMnIH0sXHJcbl1cclxuPC9zY3JpcHQ+XHJcbjx0ZW1wbGF0ZT5cclxuICAgIDxkaXYgY2xhc3M9XCJtZW51LWNhdGVnb3J5LWZpbHRlclwiPlxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgdi1mb3I9XCJjYXRlZ29yeSBpbiBjYXRlZ29yaWVzXCJcclxuICAgICAgICAgICAgOmtleT1cImNhdGVnb3J5LnZhbHVlXCJcclxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgIGNsYXNzPVwibWVudS1jYXRlZ29yeS1maWx0ZXJfX2J1dHRvblwiXHJcbiAgICAgICAgICAgIDpjbGFzcz1cInsgJ21lbnUtY2F0ZWdvcnktZmlsdGVyX19idXR0b24tLWFjdGl2ZSc6IG1vZGVsID09PSBjYXRlZ29yeS52YWx1ZSB9XCJcclxuICAgICAgICAgICAgQGNsaWNrPVwibW9kZWwgPSBjYXRlZ29yeS52YWx1ZVwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgICB7eyBjYXRlZ29yeS5sYWJlbCB9fVxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgPC9kaXY+XHJcbjwvdGVtcGxhdGU+XHJcbjxzdHlsZSBzY29wZWQ+XHJcbkByZWZlcmVuY2UgXCIuLi8uLi9tYWluLmNzc1wiO1xyXG5cclxuLm1lbnUtY2F0ZWdvcnktZmlsdGVyIHtcclxuICAgIEBhcHBseVxyXG4gICAgICAgIGZsZXhcclxuICAgICAgICBnYXAtM1xyXG4gICAgICAgIG92ZXJmbG93LXgtYXV0b1xyXG4gICAgICAgIFtzY3JvbGxiYXItd2lkdGg6bm9uZV1cclxuICAgICAgICBbJjo6LXdlYmtpdC1zY3JvbGxiYXJdOmhpZGRlbjtcclxufVxyXG5cclxuLm1lbnUtY2F0ZWdvcnktZmlsdGVyX19idXR0b24ge1xyXG4gICAgQGFwcGx5XHJcbiAgICAgICAgcm91bmRlZC1mdWxsXHJcbiAgICAgICAgYmctYmctc3VyZmFjZVxyXG4gICAgICAgIHNoYWRvdy1zbVxyXG4gICAgICAgIHB4LTZcclxuICAgICAgICBweS0yXHJcbiAgICAgICAgdGV4dC1zbVxyXG4gICAgICAgIGZvbnQtc2VtaWJvbGRcclxuICAgICAgICB0ZXh0LXRleHQtbXV0ZWRcclxuICAgICAgICB0cmFuc2l0aW9uLWNvbG9yc1xyXG4gICAgICAgIGhvdmVyOmJnLWJnLWJyYW5kXHJcbiAgICAgICAgaG92ZXI6dGV4dC10ZXh0LW9uLWJyYW5kXHJcbiAgICAgICAgc2hyaW5rLTA7XHJcbn1cclxuXHJcbi5tZW51LWNhdGVnb3J5LWZpbHRlcl9fYnV0dG9uLS1hY3RpdmUge1xyXG4gICAgQGFwcGx5XHJcbiAgICAgICAgYmctYmctYnJhbmQtZGFya2VyXHJcbiAgICAgICAgdGV4dC10ZXh0LW9uLWJyYW5kO1xyXG59XHJcbjwvc3R5bGU+Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUFjO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVcsc0JBQUMsQ0FBQztBQUMzQjtBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlDLENBQUM7Ozs7Ozs7Ozs7cUJBR1EsS0FBSyxFQUFDLHNCQUFzQjs7Ozt3QkFBakMsb0JBV00sT0FYTixVQVdNO21CQVZGLG9CQVNTLDZCQVJjLGlCQUFVLEdBQXRCLFFBQVE7YUFEbkIsb0JBU1M7UUFQSixHQUFHLEVBQUUsUUFBUSxDQUFDLEtBQUs7UUFDcEIsSUFBSSxFQUFDLFFBQVE7UUFDYixLQUFLLG1CQUFDLDhCQUE4Qiw0Q0FDYyxZQUFLLEtBQUssUUFBUSxDQUFDLEtBQUs7UUFDekUsT0FBSyxhQUFFLFlBQUssR0FBRyxRQUFRLENBQUMsS0FBSzswQkFFM0IsUUFBUSxDQUFDLEtBQUsiLCJpZ25vcmVMaXN0IjpbXX0=