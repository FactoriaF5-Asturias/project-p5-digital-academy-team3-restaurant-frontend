import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/home/MenuSearch.vue");import { useModel as _useModel, mergeModels as _mergeModels } from "/node_modules/.vite/deps/vue.js?v=7f2dea69"
import searchIcon from "/src/assets/search.svg?import"


const _sfc_main = {
  __name: 'MenuSearch',
  props: /*@__PURE__*/_mergeModels({
    placeholder: {
        type: String,
        default: 'Buscar plato, ingrediente...',
    },
    ariaLabel: {
        type: String,
        default: 'Buscar plato o ingrediente',
    }
}, {
    "modelValue": {},
    "modelModifiers": {},
  }),
  emits: ["update:modelValue"],
  setup(__props, { expose: __expose }) {
  __expose();



const model = _useModel(__props, "modelValue")

const __returned__ = { model, get searchIcon() { return searchIcon } }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { createElementVNode as _createElementVNode, vModelText as _vModelText, withDirectives as _withDirectives, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/node_modules/.vite/deps/vue.js?v=7f2dea69"

const _hoisted_1 = { class: "menu-search" }
const _hoisted_2 = ["src"]
const _hoisted_3 = ["placeholder", "aria-label"]

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createElementBlock("label", _hoisted_1, [
    _createElementVNode("img", {
      src: $setup.searchIcon,
      alt: "",
      class: "menu-search__icon"
    }, null, 8 /* PROPS */, _hoisted_2),
    _withDirectives(_createElementVNode("input", {
      "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => (($setup.model) = $event)),
      class: "menu-search__input",
      type: "search",
      placeholder: $props.placeholder,
      "aria-label": $props.ariaLabel
    }, null, 8 /* PROPS */, _hoisted_3), [
      [_vModelText, $setup.model]
    ])
  ]))
}


import "/src/components/home/MenuSearch.vue?vue&type=style&index=0&scoped=cac19771&lang.css"

_sfc_main.__hmrId = "cac19771"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__scopeId',"data-v-cac19771"],['__file',"C:/Users/simooone/Desktop/cosas/factoria f5/trabajos/project-p5-digital-academy-team3-restaurant-frontend/src/components/home/MenuSearch.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTWVudVNlYXJjaC52dWUiXSwic291cmNlc0NvbnRlbnQiOlsiPHNjcmlwdCBzZXR1cD5cclxuaW1wb3J0IHNlYXJjaEljb24gZnJvbSAnLi4vLi4vYXNzZXRzL3NlYXJjaC5zdmcnXHJcblxyXG5kZWZpbmVQcm9wcyh7XHJcbiAgICBwbGFjZWhvbGRlcjoge1xyXG4gICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICBkZWZhdWx0OiAnQnVzY2FyIHBsYXRvLCBpbmdyZWRpZW50ZS4uLicsXHJcbiAgICB9LFxyXG4gICAgYXJpYUxhYmVsOiB7XHJcbiAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIGRlZmF1bHQ6ICdCdXNjYXIgcGxhdG8gbyBpbmdyZWRpZW50ZScsXHJcbiAgICB9XHJcbn0pXHJcblxyXG5jb25zdCBtb2RlbCA9IGRlZmluZU1vZGVsKClcclxuPC9zY3JpcHQ+XHJcbjx0ZW1wbGF0ZT5cclxuICAgIDxsYWJlbCBjbGFzcz1cIm1lbnUtc2VhcmNoXCI+XHJcbiAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICA6c3JjPVwic2VhcmNoSWNvblwiXHJcbiAgICAgICAgICAgIGFsdD1cIlwiXHJcbiAgICAgICAgICAgIGNsYXNzPVwibWVudS1zZWFyY2hfX2ljb25cIlxyXG4gICAgICAgIC8+XHJcbiAgICBcclxuICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgdi1tb2RlbD1cIm1vZGVsXCJcclxuICAgICAgICAgICAgY2xhc3M9XCJtZW51LXNlYXJjaF9faW5wdXRcIlxyXG4gICAgICAgICAgICB0eXBlPVwic2VhcmNoXCJcclxuICAgICAgICAgICAgOnBsYWNlaG9sZGVyPVwicGxhY2Vob2xkZXJcIlxyXG4gICAgICAgICAgICA6YXJpYS1sYWJlbD1cImFyaWFMYWJlbFwiXHJcbiAgICAgICAgLz5cclxuICAgIDwvbGFiZWw+XHJcbjwvdGVtcGxhdGU+XHJcbjxzdHlsZSBzY29wZWQ+XHJcbkByZWZlcmVuY2UgXCIuLi8uLi9tYWluLmNzc1wiO1xyXG5cclxuLm1lbnUtc2VhcmNoIHtcclxuICAgIEBhcHBseVxyXG4gICAgICAgIGZsZXhcclxuICAgICAgICBoLTEyXHJcbiAgICAgICAgdy1mdWxsIG1kOnctOTZcclxuICAgICAgICBpdGVtcy1jZW50ZXJcclxuICAgICAgICBnYXAtNFxyXG4gICAgICAgIHJvdW5kZWQteGxcclxuICAgICAgICBiZy1iZy1zdXJmYWNlXHJcbiAgICAgICAgcHgtNlxyXG4gICAgICAgIHNoYWRvdy1zbTtcclxufVxyXG5cclxuLm1lbnUtc2VhcmNoX19pY29uIHtcclxuICAgIEBhcHBseVxyXG4gICAgICAgIGgtNVxyXG4gICAgICAgIHctNVxyXG4gICAgICAgIHNocmluay0wO1xyXG59XHJcblxyXG4ubWVudS1zZWFyY2hfX2lucHV0IHtcclxuICAgIEBhcHBseVxyXG4gICAgICAgIHctZnVsbFxyXG4gICAgICAgIGJnLXRyYW5zcGFyZW50XHJcbiAgICAgICAgdGV4dC1zbVxyXG4gICAgICAgIHRleHQtdGV4dC1kZWZhdWx0XHJcbiAgICAgICAgb3V0bGluZS1ub25lXHJcbiAgICAgICAgcGxhY2Vob2xkZXI6dGV4dC10ZXh0LW11dGVkO1xyXG59XHJcbjwvc3R5bGU+Il0sIm1hcHBpbmdzIjoiO0FBQ0EsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRmM7QUFZWjtBQUNGO0FBQ0EsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVcsc0JBQUMsQ0FBQzs7Ozs7Ozs7OztxQkFHaEIsS0FBSyxFQUFDLGFBQWE7Ozs7O3dCQUExQixvQkFjUSxTQWRSLFVBY1E7SUFiSixvQkFJRTtNQUhHLEdBQUcsRUFBRSxpQkFBVTtNQUNoQixHQUFHLEVBQUMsRUFBRTtNQUNOLEtBQUssRUFBQyxtQkFBbUI7O29CQUc3QixvQkFNRTttRUFMVyxZQUFLO01BQ2QsS0FBSyxFQUFDLG9CQUFvQjtNQUMxQixJQUFJLEVBQUMsUUFBUTtNQUNaLFdBQVcsRUFBRSxrQkFBVztNQUN4QixZQUFVLEVBQUUsZ0JBQVM7O29CQUpiLFlBQUsiLCJpZ25vcmVMaXN0IjpbXX0=