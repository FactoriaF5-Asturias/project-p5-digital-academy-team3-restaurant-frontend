import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/MainHeader.vue");import { computed } from "/node_modules/.vite/deps/vue.js?v=7f2dea69";

    import restaurantLogo from "/src/assets/bella_vita_logo.png?import"
    import cartIcon from "/src/assets/cart.svg?import"
    import profileIcon from "/src/assets/profile.svg?import"
    import { useCart } from "/src/composables/useCart.js"
    import { useAuth } from "/src/composables/useAuth.js";
    import { useRouter } from "/node_modules/.vite/deps/vue-router.js?v=7f2dea69";

    
const _sfc_main = {
  __name: 'MainHeader',
  setup(__props, { expose: __expose }) {
  __expose();

    const { items } = useCart()

    const counter = computed(() =>
        items.value.reduce((total, items) => total + items.quantity, 0)
    )

    const { user, isAuthenticated, logout } = useAuth()
    const router = useRouter()

    const profileRoute = computed(() => {
        if (user.value?.roles?.includes('ADMIN')) return '/admin'
        if (user.value?.roles?.includes('KITCHEN')) return '/kitchen'
        return '/'
    })

    function handleLogout() {
        logout()
        router.push('/')
    }

const __returned__ = { items, counter, user, isAuthenticated, logout, router, profileRoute, handleLogout, computed, get restaurantLogo() { return restaurantLogo }, get cartIcon() { return cartIcon }, get profileIcon() { return profileIcon }, get useCart() { return useCart }, get useAuth() { return useAuth }, get useRouter() { return useRouter } }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { createElementVNode as _createElementVNode, resolveComponent as _resolveComponent, withCtx as _withCtx, createVNode as _createVNode, openBlock as _openBlock, createElementBlock as _createElementBlock, createCommentVNode as _createCommentVNode, createTextVNode as _createTextVNode, toDisplayString as _toDisplayString } from "/node_modules/.vite/deps/vue.js?v=7f2dea69"

const _hoisted_1 = { class: "sticky top-0 z-50" }
const _hoisted_2 = { class: "flex justify-between items-center px-7 sm:px-20 py-5 bg-bg-container text-text-brand shadow-sm" }
const _hoisted_3 = ["src"]
const _hoisted_4 = { class: "flex items-center gap-4" }
const _hoisted_5 = { class: "flex items-center" }
const _hoisted_6 = {
  key: 0,
  class: "pr-3"
}
const _hoisted_7 = {
  key: 1,
  class: "pl-3"
}
const _hoisted_8 = { class: "flex items-center gap-4 md:gap-6" }
const _hoisted_9 = ["src"]
const _hoisted_10 = {
  "data-testid": "cart-counter",
  class: "absolute -top-1 -right-1 w-5 h-5 rounded-full text-xs font-semibold bg-bg-brand text-text-on-brand flex items-center justify-center"
}
const _hoisted_11 = { key: 0 }
const _hoisted_12 = ["src"]

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_RouterLink = _resolveComponent("RouterLink")

  return (_openBlock(), _createElementBlock("div", _hoisted_1, [
    _createElementVNode("header", _hoisted_2, [
      _createElementVNode("div", null, [
        _createVNode(_component_RouterLink, {
          class: "flex items-center gap-2 hover:underline underline-offset-2 active:text-text-brand-darker",
          to: "/",
          "aria-label": "Ir a página principal"
        }, {
          default: _withCtx(() => [
            _createElementVNode("img", {
              class: "h-10",
              src: $setup.restaurantLogo,
              alt: ""
            }, null, 8 /* PROPS */, _hoisted_3),
            _cache[0] || (_cache[0] = _createElementVNode("span", { class: "font-['Playfair-Display'] text-xl md:text-3xl font-bold" }, "Giacobello", -1 /* CACHED */))
          ]),
          _: 1 /* STABLE */
        })
      ]),
      _createElementVNode("nav", _hoisted_4, [
        _createElementVNode("ul", _hoisted_5, [
          ($setup.isAuthenticated)
            ? (_openBlock(), _createElementBlock("li", _hoisted_6, [
                _createElementVNode("button", {
                  type: "button",
                  class: "hover:underline underline-offset-2 active:text-text-brand-darker",
                  onClick: $setup.handleLogout
                }, " Logout ")
              ]))
            : (_openBlock(), _createElementBlock("li", _hoisted_7, [
                _createVNode(_component_RouterLink, {
                  to: "/login",
                  class: "hover:underline underline-offset-2 active:text-text-brand-darker"
                }, {
                  default: _withCtx(() => [...(_cache[1] || (_cache[1] = [
                    _createTextVNode(" Login ", -1 /* CACHED */)
                  ]))]),
                  _: 1 /* STABLE */
                })
              ]))
        ]),
        _createElementVNode("ul", _hoisted_8, [
          _createElementVNode("li", null, [
            _createVNode(_component_RouterLink, {
              class: "relative rounded-full h-9 w-9 flex items-center justify-center bg-bg-container-high transition-opacity hover:opacity-70",
              to: "/cart",
              "aria-label": "Ir al carrito"
            }, {
              default: _withCtx(() => [
                _createElementVNode("img", {
                  class: "h-5",
                  src: $setup.cartIcon,
                  alt: ""
                }, null, 8 /* PROPS */, _hoisted_9),
                _createElementVNode("span", _hoisted_10, _toDisplayString($setup.counter), 1 /* TEXT */)
              ]),
              _: 1 /* STABLE */
            })
          ]),
          ($setup.isAuthenticated)
            ? (_openBlock(), _createElementBlock("li", _hoisted_11, [
                _createVNode(_component_RouterLink, {
                  class: "relative rounded-full h-9 w-9 flex items-center justify-center bg-bg-brand transition-opacity hover:opacity-70",
                  to: $setup.profileRoute,
                  "aria-label": "Ir al perfil"
                }, {
                  default: _withCtx(() => [
                    _createElementVNode("img", {
                      class: "h-4",
                      src: $setup.profileIcon,
                      alt: ""
                    }, null, 8 /* PROPS */, _hoisted_12)
                  ]),
                  _: 1 /* STABLE */
                }, 8 /* PROPS */, ["to"])
              ]))
            : _createCommentVNode("v-if", true)
        ])
      ])
    ])
  ]))
}



_sfc_main.__hmrId = "7727d381"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"C:/Users/simooone/Desktop/cosas/factoria f5/trabajos/project-p5-digital-academy-team3-restaurant-frontend/src/components/common/MainHeader.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTWFpbkhlYWRlci52dWUiXSwic291cmNlc0NvbnRlbnQiOlsiPHNjcmlwdCBzZXR1cD5cclxuICAgIGltcG9ydCB7IGNvbXB1dGVkIH0gZnJvbSAndnVlJztcclxuXHJcbiAgICBpbXBvcnQgcmVzdGF1cmFudExvZ28gZnJvbSAnLi4vLi4vYXNzZXRzL2JlbGxhX3ZpdGFfbG9nby5wbmcnXHJcbiAgICBpbXBvcnQgY2FydEljb24gZnJvbSAnLi4vLi4vYXNzZXRzL2NhcnQuc3ZnJ1xyXG4gICAgaW1wb3J0IHByb2ZpbGVJY29uIGZyb20gJy4uLy4uL2Fzc2V0cy9wcm9maWxlLnN2ZydcclxuICAgIGltcG9ydCB7IHVzZUNhcnQgfSBmcm9tICcuLi8uLi9jb21wb3NhYmxlcy91c2VDYXJ0LmpzJ1xyXG4gICAgaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uLy4uL2NvbXBvc2FibGVzL3VzZUF1dGguanMnO1xyXG4gICAgaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSAndnVlLXJvdXRlcic7XHJcblxyXG4gICAgY29uc3QgeyBpdGVtcyB9ID0gdXNlQ2FydCgpXHJcblxyXG4gICAgY29uc3QgY291bnRlciA9IGNvbXB1dGVkKCgpID0+XHJcbiAgICAgICAgaXRlbXMudmFsdWUucmVkdWNlKCh0b3RhbCwgaXRlbXMpID0+IHRvdGFsICsgaXRlbXMucXVhbnRpdHksIDApXHJcbiAgICApXHJcblxyXG4gICAgY29uc3QgeyB1c2VyLCBpc0F1dGhlbnRpY2F0ZWQsIGxvZ291dCB9ID0gdXNlQXV0aCgpXHJcbiAgICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKVxyXG5cclxuICAgIGNvbnN0IHByb2ZpbGVSb3V0ZSA9IGNvbXB1dGVkKCgpID0+IHtcclxuICAgICAgICBpZiAodXNlci52YWx1ZT8ucm9sZXM/LmluY2x1ZGVzKCdBRE1JTicpKSByZXR1cm4gJy9hZG1pbidcclxuICAgICAgICBpZiAodXNlci52YWx1ZT8ucm9sZXM/LmluY2x1ZGVzKCdLSVRDSEVOJykpIHJldHVybiAnL2tpdGNoZW4nXHJcbiAgICAgICAgcmV0dXJuICcvJ1xyXG4gICAgfSlcclxuXHJcbiAgICBmdW5jdGlvbiBoYW5kbGVMb2dvdXQoKSB7XHJcbiAgICAgICAgbG9nb3V0KClcclxuICAgICAgICByb3V0ZXIucHVzaCgnLycpXHJcbiAgICB9XHJcbjwvc2NyaXB0PlxyXG5cclxuPHRlbXBsYXRlPlxyXG4gICAgPGRpdiBjbGFzcz1cInN0aWNreSB0b3AtMCB6LTUwXCI+XHJcbiAgICAgICAgPGhlYWRlciBjbGFzcz1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBweC03IHNtOnB4LTIwIHB5LTUgYmctYmctY29udGFpbmVyIHRleHQtdGV4dC1icmFuZCBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxSb3V0ZXJMaW5rIGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgaG92ZXI6dW5kZXJsaW5lIHVuZGVybGluZS1vZmZzZXQtMiBhY3RpdmU6dGV4dC10ZXh0LWJyYW5kLWRhcmtlclwiIHRvPVwiL1wiIGFyaWEtbGFiZWw9XCJJciBhIHDDoWdpbmEgcHJpbmNpcGFsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGltZyBjbGFzcz1cImgtMTBcIiA6c3JjPVwicmVzdGF1cmFudExvZ29cIiBhbHQ9XCJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImZvbnQtWydQbGF5ZmFpci1EaXNwbGF5J10gdGV4dC14bCBtZDp0ZXh0LTN4bCBmb250LWJvbGRcIj5HaWFjb2JlbGxvPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9Sb3V0ZXJMaW5rPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPG5hdiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICA8dWwgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsaSB2LWlmPVwiaXNBdXRoZW50aWNhdGVkXCIgY2xhc3M9XCJwci0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzPVwiaG92ZXI6dW5kZXJsaW5lIHVuZGVybGluZS1vZmZzZXQtMiBhY3RpdmU6dGV4dC10ZXh0LWJyYW5kLWRhcmtlclwiIEBjbGljaz1cImhhbmRsZUxvZ291dFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgTG9nb3V0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxpIHYtZWxzZSBjbGFzcz1cInBsLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFJvdXRlckxpbmsgdG89XCIvbG9naW5cIiBjbGFzcz1cImhvdmVyOnVuZGVybGluZSB1bmRlcmxpbmUtb2Zmc2V0LTIgYWN0aXZlOnRleHQtdGV4dC1icmFuZC1kYXJrZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIExvZ2luXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvUm91dGVyTGluaz5cclxuICAgICAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgICAgICAgIDx1bCBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00IG1kOmdhcC02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxpPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Um91dGVyTGluayBjbGFzcz1cInJlbGF0aXZlIHJvdW5kZWQtZnVsbCBoLTkgdy05IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLWJnLWNvbnRhaW5lci1oaWdoIHRyYW5zaXRpb24tb3BhY2l0eSBob3ZlcjpvcGFjaXR5LTcwXCIgdG89XCIvY2FydFwiIGFyaWEtbGFiZWw9XCJJciBhbCBjYXJyaXRvXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nIGNsYXNzPVwiaC01XCIgOnNyYz1cImNhcnRJY29uXCIgYWx0PVwiXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBkYXRhLXRlc3RpZD1cImNhcnQtY291bnRlclwiIGNsYXNzPVwiYWJzb2x1dGUgLXRvcC0xIC1yaWdodC0xIHctNSBoLTUgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1zZW1pYm9sZCBiZy1iZy1icmFuZCB0ZXh0LXRleHQtb24tYnJhbmQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyBjb3VudGVyIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvUm91dGVyTGluaz5cclxuICAgICAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsaSB2LWlmPVwiaXNBdXRoZW50aWNhdGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxSb3V0ZXJMaW5rIGNsYXNzPVwicmVsYXRpdmUgcm91bmRlZC1mdWxsIGgtOSB3LTkgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctYmctYnJhbmQgdHJhbnNpdGlvbi1vcGFjaXR5IGhvdmVyOm9wYWNpdHktNzBcIiA6dG89XCJwcm9maWxlUm91dGVcIiBhcmlhLWxhYmVsPVwiSXIgYWwgcGVyZmlsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nIGNsYXNzPVwiaC00XCIgOnNyYz1cInByb2ZpbGVJY29uXCIgYWx0PVwiXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvUm91dGVyTGluaz5cclxuICAgICAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgICAgPC9uYXY+XHJcbiAgICAgICAgPC9oZWFkZXI+XHJcbiAgICA8L2Rpdj5cclxuPC90ZW1wbGF0ZT4iXSwibWFwcGluZ3MiOiJBQUNJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkM7QUFDQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzQztBQUNBLENBQUMsQ0FBQyxDQUFDOzs7OztBQVZXO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FTQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvQjtBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMO0FBQ0EsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2RCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5QjtBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTjtBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7Ozs7Ozs7OztxQkFJSSxLQUFLLEVBQUMsbUJBQW1CO3FCQUNsQixLQUFLLEVBQUMsZ0dBQWdHOztxQkFPckcsS0FBSyxFQUFDLHlCQUF5QjtxQkFDNUIsS0FBSyxFQUFDLG1CQUFtQjs7O0VBQ0UsS0FBSyxFQUFDLE1BQU07Ozs7RUFLNUIsS0FBSyxFQUFDLE1BQU07O3FCQU12QixLQUFLLEVBQUMsa0NBQWtDOzs7RUFJMUIsYUFBVyxFQUFDLGNBQWM7RUFBQyxLQUFLLEVBQUMscUlBQXFJOzs7Ozs7Ozt3QkF6QnBNLG9CQXNDTSxPQXRDTixVQXNDTTtJQXJDRixvQkFvQ1MsVUFwQ1QsVUFvQ1M7TUFuQ0wsb0JBS007UUFKRixhQUdhO1VBSEQsS0FBSyxFQUFDLDBGQUEwRjtVQUFDLEVBQUUsRUFBQyxHQUFHO1VBQUMsWUFBVSxFQUFDLHVCQUF1Qjs7NEJBQ2xKLENBQStDO1lBQS9DLG9CQUErQztjQUExQyxLQUFLLEVBQUMsTUFBTTtjQUFFLEdBQUcsRUFBRSxxQkFBYztjQUFFLEdBQUcsRUFBQyxFQUFFOztzQ0FDOUMsb0JBQXVGLFVBQWpGLEtBQUssRUFBQyx5REFBeUQsSUFBQyxZQUFVOzs7OztNQUd4RixvQkE0Qk0sT0E1Qk4sVUE0Qk07UUEzQkYsb0JBV0ssTUFYTCxVQVdLO1dBVlMsc0JBQWU7NkJBQXpCLG9CQUlLLE1BSkwsVUFJSztnQkFIRCxvQkFFUztrQkFGRCxJQUFJLEVBQUMsUUFBUTtrQkFBQyxLQUFLLEVBQUMsa0VBQWtFO2tCQUFFLE9BQUssRUFBRSxtQkFBWTttQkFBRSxVQUVySDs7NkJBRUosb0JBSUssTUFKTCxVQUlLO2dCQUhELGFBRWE7a0JBRkQsRUFBRSxFQUFDLFFBQVE7a0JBQUMsS0FBSyxFQUFDLGtFQUFrRTs7b0NBQUMsQ0FFakc7cUNBRmlHLFNBRWpHOzs7Ozs7UUFHUixvQkFjSyxNQWRMLFVBY0s7VUFiRCxvQkFPSztZQU5ELGFBS2E7Y0FMRCxLQUFLLEVBQUMseUhBQXlIO2NBQUMsRUFBRSxFQUFDLE9BQU87Y0FBQyxZQUFVLEVBQUMsZUFBZTs7Z0NBQzdLLENBQXdDO2dCQUF4QyxvQkFBd0M7a0JBQW5DLEtBQUssRUFBQyxLQUFLO2tCQUFFLEdBQUcsRUFBRSxlQUFRO2tCQUFFLEdBQUcsRUFBQyxFQUFFOztnQkFDdkMsb0JBRU8sUUFGUCxXQUVPLG1CQURBLGNBQU87Ozs7O1dBSVosc0JBQWU7NkJBQXpCLG9CQUlLO2dCQUhELGFBRWE7a0JBRkQsS0FBSyxFQUFDLGdIQUFnSDtrQkFBRSxFQUFFLEVBQUUsbUJBQVk7a0JBQUUsWUFBVSxFQUFDLGNBQWM7O29DQUMzSyxDQUEyQztvQkFBM0Msb0JBQTJDO3NCQUF0QyxLQUFLLEVBQUMsS0FBSztzQkFBRSxHQUFHLEVBQUUsa0JBQVc7c0JBQUUsR0FBRyxFQUFDLEVBQUUiLCJpZ25vcmVMaXN0IjpbXX0=