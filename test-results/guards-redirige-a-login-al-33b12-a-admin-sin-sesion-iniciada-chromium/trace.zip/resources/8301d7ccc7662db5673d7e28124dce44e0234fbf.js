import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.vue");const _sfc_main = {  }
import { resolveComponent as _resolveComponent, openBlock as _openBlock, createBlock as _createBlock } from "/node_modules/.vite/deps/vue.js?v=7f2dea69"

function _sfc_render(_ctx, _cache) {
  const _component_RouterView = _resolveComponent("RouterView")

  return (_openBlock(), _createBlock(_component_RouterView))
}



_sfc_main.__hmrId = "7a7a37b1"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"C:/Users/simooone/Desktop/cosas/factoria f5/trabajos/project-p5-digital-academy-team3-restaurant-frontend/src/App.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQzovVXNlcnMvc2ltb29vbmUvRGVza3RvcC9jb3Nhcy9mYWN0b3JpYSBmNS90cmFiYWpvcy9wcm9qZWN0LXA1LWRpZ2l0YWwtYWNhZGVteS10ZWFtMy1yZXN0YXVyYW50LWZyb250ZW5kL3NyYy9BcHAudnVlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFwcC52dWUiXSwic291cmNlc0NvbnRlbnQiOlsiPHNjcmlwdCBzZXR1cD5cclxuXHJcbjwvc2NyaXB0PlxyXG5cclxuPHRlbXBsYXRlPlxyXG4gIDxSb3V0ZXJWaWV3IC8+XHJcbjwvdGVtcGxhdGU+Il0sIm1hcHBpbmdzIjoiOzs7Ozs7d0JBS0UsYUFBYyIsImlnbm9yZUxpc3QiOltdfQ==