import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/LoginView.vue");import MainHeader from "/src/components/common/MainHeader.vue";
import MainFooter from "/src/components/common/MainFooter.vue";
import loginPhoto from "/src/assets/login-photo.jpg?import";
import eyeIcon from "/src/assets/eye.svg?import"
import { ref } from "/node_modules/.vite/deps/vue.js?v=7f2dea69";
import { useAuth } from "/src/composables/useAuth.js";
import { useRouter } from "/node_modules/.vite/deps/vue-router.js?v=7f2dea69";


const _sfc_main = {
  __name: 'LoginView',
  setup(__props, { expose: __expose }) {
  __expose();

const user = ref('')
const password = ref('')
const rememberMe = ref(false)
const showPassword = ref(false)
const isSubmitting = ref(false)
const submitError = ref(null)
const { login } = useAuth()
const router = useRouter()

function togglePassword() { showPassword.value = !showPassword.value }

async function handleSubmit() {
    isSubmitting.value = true
    submitError.value = null
    try{
        await login(user.value, password.value)
        router.push('/')
    } catch (err) {
        if (err.status === 409) {
            router.push('/change-password')
        } else {
            submitError.value = 'Credenciales incorrectas'
        }
    } finally {
        isSubmitting.value = false
    }
}

const __returned__ = { user, password, rememberMe, showPassword, isSubmitting, submitError, login, router, togglePassword, handleSubmit, MainHeader, MainFooter, get loginPhoto() { return loginPhoto }, get eyeIcon() { return eyeIcon }, ref, get useAuth() { return useAuth }, get useRouter() { return useRouter } }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { createVNode as _createVNode, createElementVNode as _createElementVNode, vModelText as _vModelText, withDirectives as _withDirectives, vModelDynamic as _vModelDynamic, vModelCheckbox as _vModelCheckbox, toDisplayString as _toDisplayString, openBlock as _openBlock, createElementBlock as _createElementBlock, createCommentVNode as _createCommentVNode, withModifiers as _withModifiers } from "/node_modules/.vite/deps/vue.js?v=7f2dea69"

const _hoisted_1 = { class: "flex flex-col min-h-screen" }
const _hoisted_2 = { class: "flex-1" }
const _hoisted_3 = { class: "grid grid-cols-1 py-16 md:py-0 md:grid-cols-2 md:min-h-full" }
const _hoisted_4 = { class: "overflow-hidden md:min-h-[calc(100vh-88px)]" }
const _hoisted_5 = ["src"]
const _hoisted_6 = { class: "flex items-center justify-center px-8 md:px-20" }
const _hoisted_7 = { class: "flex flex-col gap-2" }
const _hoisted_8 = { class: "flex flex-col gap-2" }
const _hoisted_9 = { class: "relative" }
const _hoisted_10 = ["type"]
const _hoisted_11 = ["aria-label"]
const _hoisted_12 = ["src"]
const _hoisted_13 = { class: "flex items-center gap-2" }
const _hoisted_14 = { key: 0 }
const _hoisted_15 = ["disabled"]

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createElementBlock("div", _hoisted_1, [
    _createVNode($setup["MainHeader"]),
    _createElementVNode("main", _hoisted_2, [
      _createElementVNode("div", _hoisted_3, [
        _createElementVNode("div", _hoisted_4, [
          _createElementVNode("img", {
            src: $setup.loginPhoto,
            alt: "Foto de comida italiana",
            class: "w-full h-full object-cover hidden md:block"
          }, null, 8 /* PROPS */, _hoisted_5)
        ]),
        _createElementVNode("div", _hoisted_6, [
          _createElementVNode("form", {
            class: "w-full max-w-md space-y-5",
            onSubmit: _withModifiers($setup.handleSubmit, ["prevent"])
          }, [
            _cache[6] || (_cache[6] = _createElementVNode("h1", { class: "font-display text-3xl text-text-brand font-bold" }, "Iniciar sesión", -1 /* CACHED */)),
            _cache[7] || (_cache[7] = _createElementVNode("p", { class: "text-text-muted text-base" }, "Accede a dashboard de Administración o Cocina.", -1 /* CACHED */)),
            _createElementVNode("div", _hoisted_7, [
              _cache[3] || (_cache[3] = _createElementVNode("label", {
                for: "user",
                class: "text-sm font-semibold text-text-default uppercase tracking-wide"
              }, "USUARIO", -1 /* CACHED */)),
              _withDirectives(_createElementVNode("input", {
                id: "user",
                "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => (($setup.user) = $event)),
                type: "text",
                class: "w-full p-3 rounded-md border border-border-default bg-bg-input text-text-default focus:outline-none focus:border-border-brand",
                placeholder: "Tu usuario"
              }, null, 512 /* NEED_PATCH */), [
                [_vModelText, $setup.user]
              ])
            ]),
            _createElementVNode("div", _hoisted_8, [
              _cache[4] || (_cache[4] = _createElementVNode("div", null, [
                _createElementVNode("label", {
                  for: "password",
                  class: "text-sm font-semibold text-text-default uppercase tracking-wide"
                }, "CONTRASEÑA")
              ], -1 /* CACHED */)),
              _createElementVNode("div", _hoisted_9, [
                _withDirectives(_createElementVNode("input", {
                  id: "password",
                  "onUpdate:modelValue": _cache[1] || (_cache[1] = $event => (($setup.password) = $event)),
                  type: $setup.showPassword ? 'text' : 'password',
                  class: "w-full p-3 rounded-md border border-border-default bg-bg-input text-text-default focus:outline-none focus:border-border-brand"
                }, null, 8 /* PROPS */, _hoisted_10), [
                  [_vModelDynamic, $setup.password]
                ]),
                _createElementVNode("button", {
                  type: "button",
                  "aria-label": $setup.showPassword ? 'Ocultar contraseña' : 'Mostrar contraseña',
                  class: "absolute right-3 top-1/2 -translate-y-1/2 cursor-pointer",
                  onClick: $setup.togglePassword
                }, [
                  _createElementVNode("img", {
                    src: $setup.eyeIcon,
                    alt: ""
                  }, null, 8 /* PROPS */, _hoisted_12)
                ], 8 /* PROPS */, _hoisted_11)
              ])
            ]),
            _createElementVNode("div", _hoisted_13, [
              _withDirectives(_createElementVNode("input", {
                id: "remember",
                "onUpdate:modelValue": _cache[2] || (_cache[2] = $event => (($setup.rememberMe) = $event)),
                type: "checkbox",
                class: "accent-bg-brand w-4 h-4"
              }, null, 512 /* NEED_PATCH */), [
                [_vModelCheckbox, $setup.rememberMe]
              ]),
              _cache[5] || (_cache[5] = _createElementVNode("label", {
                for: "remember",
                class: "text-sm font-semibold text-text-default"
              }, "Recordarme", -1 /* CACHED */))
            ]),
            ($setup.submitError)
              ? (_openBlock(), _createElementBlock("p", _hoisted_14, _toDisplayString($setup.submitError), 1 /* TEXT */))
              : _createCommentVNode("v-if", true),
            _createElementVNode("button", {
              type: "submit",
              class: "w-full bg-bg-brand-darker text-text-on-brand py-3 rounded-md font-semibold transition-colors hover:bg-bg-brand",
              disabled: $setup.isSubmitting
            }, "Iniciar sesión", 8 /* PROPS */, _hoisted_15)
          ], 32 /* NEED_HYDRATION */)
        ])
      ])
    ]),
    _createVNode($setup["MainFooter"])
  ]))
}



_sfc_main.__hmrId = "45f5edd7"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"C:/Users/simooone/Desktop/cosas/factoria f5/trabajos/project-p5-digital-academy-team3-restaurant-frontend/src/views/LoginView.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTG9naW5WaWV3LnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8c2NyaXB0IHNldHVwPlxyXG5pbXBvcnQgTWFpbkhlYWRlciBmcm9tICcuLi9jb21wb25lbnRzL2NvbW1vbi9NYWluSGVhZGVyLnZ1ZSc7XHJcbmltcG9ydCBNYWluRm9vdGVyIGZyb20gJy4uL2NvbXBvbmVudHMvY29tbW9uL01haW5Gb290ZXIudnVlJztcclxuaW1wb3J0IGxvZ2luUGhvdG8gZnJvbSAnLi4vYXNzZXRzL2xvZ2luLXBob3RvLmpwZyc7XHJcbmltcG9ydCBleWVJY29uIGZyb20gJy4uL2Fzc2V0cy9leWUuc3ZnJ1xyXG5pbXBvcnQgeyByZWYgfSBmcm9tICd2dWUnO1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vY29tcG9zYWJsZXMvdXNlQXV0aC5qcyc7XHJcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gJ3Z1ZS1yb3V0ZXInO1xyXG5cclxuY29uc3QgdXNlciA9IHJlZignJylcclxuY29uc3QgcGFzc3dvcmQgPSByZWYoJycpXHJcbmNvbnN0IHJlbWVtYmVyTWUgPSByZWYoZmFsc2UpXHJcbmNvbnN0IHNob3dQYXNzd29yZCA9IHJlZihmYWxzZSlcclxuY29uc3QgaXNTdWJtaXR0aW5nID0gcmVmKGZhbHNlKVxyXG5jb25zdCBzdWJtaXRFcnJvciA9IHJlZihudWxsKVxyXG5jb25zdCB7IGxvZ2luIH0gPSB1c2VBdXRoKClcclxuY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKClcclxuXHJcbmZ1bmN0aW9uIHRvZ2dsZVBhc3N3b3JkKCkgeyBzaG93UGFzc3dvcmQudmFsdWUgPSAhc2hvd1Bhc3N3b3JkLnZhbHVlIH1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGhhbmRsZVN1Ym1pdCgpIHtcclxuICAgIGlzU3VibWl0dGluZy52YWx1ZSA9IHRydWVcclxuICAgIHN1Ym1pdEVycm9yLnZhbHVlID0gbnVsbFxyXG4gICAgdHJ5e1xyXG4gICAgICAgIGF3YWl0IGxvZ2luKHVzZXIudmFsdWUsIHBhc3N3b3JkLnZhbHVlKVxyXG4gICAgICAgIHJvdXRlci5wdXNoKCcvJylcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIGlmIChlcnIuc3RhdHVzID09PSA0MDkpIHtcclxuICAgICAgICAgICAgcm91dGVyLnB1c2goJy9jaGFuZ2UtcGFzc3dvcmQnKVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHN1Ym1pdEVycm9yLnZhbHVlID0gJ0NyZWRlbmNpYWxlcyBpbmNvcnJlY3RhcydcclxuICAgICAgICB9XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIGlzU3VibWl0dGluZy52YWx1ZSA9IGZhbHNlXHJcbiAgICB9XHJcbn1cclxuPC9zY3JpcHQ+XHJcblxyXG48dGVtcGxhdGU+XHJcbiAgICA8ZGl2IGNsYXNzPVwiZmxleCBmbGV4LWNvbCBtaW4taC1zY3JlZW5cIj5cclxuICAgICAgICA8TWFpbkhlYWRlciAvPlxyXG4gICAgICAgIDxtYWluIGNsYXNzPVwiZmxleC0xXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJncmlkIGdyaWQtY29scy0xIHB5LTE2IG1kOnB5LTAgbWQ6Z3JpZC1jb2xzLTIgbWQ6bWluLWgtZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cIm92ZXJmbG93LWhpZGRlbiBtZDptaW4taC1bY2FsYygxMDB2aC04OHB4KV1cIj5cclxuICAgICAgICAgICAgICAgICAgICA8aW1nIDpzcmM9XCJsb2dpblBob3RvXCIgYWx0PVwiRm90byBkZSBjb21pZGEgaXRhbGlhbmFcIiBjbGFzcz1cInctZnVsbCBoLWZ1bGwgb2JqZWN0LWNvdmVyIGhpZGRlbiBtZDpibG9ja1wiPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcHgtOCBtZDpweC0yMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxmb3JtIGNsYXNzPVwidy1mdWxsIG1heC13LW1kIHNwYWNlLXktNVwiIEBzdWJtaXQucHJldmVudD1cImhhbmRsZVN1Ym1pdFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDEgY2xhc3M9XCJmb250LWRpc3BsYXkgdGV4dC0zeGwgdGV4dC10ZXh0LWJyYW5kIGZvbnQtYm9sZFwiPkluaWNpYXIgc2VzacOzbjwvaDE+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzPVwidGV4dC10ZXh0LW11dGVkIHRleHQtYmFzZVwiPkFjY2VkZSBhIGRhc2hib2FyZCBkZSBBZG1pbmlzdHJhY2nDs24gbyBDb2NpbmEuPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBmbGV4LWNvbCBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGZvcj1cInVzZXJcIiBjbGFzcz1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXRleHQtZGVmYXVsdCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZVwiPlVTVUFSSU88L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IGlkPVwidXNlclwiIHYtbW9kZWw9XCJ1c2VyXCIgdHlwZT1cInRleHRcIiBjbGFzcz1cInctZnVsbCBwLTMgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWJvcmRlci1kZWZhdWx0IGJnLWJnLWlucHV0IHRleHQtdGV4dC1kZWZhdWx0IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItYm9yZGVyLWJyYW5kXCIgcGxhY2Vob2xkZXI9XCJUdSB1c3VhcmlvXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBmbGV4LWNvbCBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgZm9yPVwicGFzc3dvcmRcIiBjbGFzcz1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXRleHQtZGVmYXVsdCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZVwiPkNPTlRSQVNFw5FBPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInJlbGF0aXZlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IGlkPVwicGFzc3dvcmRcIiB2LW1vZGVsPVwicGFzc3dvcmRcIiA6dHlwZT1cInNob3dQYXNzd29yZCA/ICd0ZXh0JyA6ICdwYXNzd29yZCdcIiBjbGFzcz1cInctZnVsbCBwLTMgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWJvcmRlci1kZWZhdWx0IGJnLWJnLWlucHV0IHRleHQtdGV4dC1kZWZhdWx0IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItYm9yZGVyLWJyYW5kXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgOmFyaWEtbGFiZWw9XCJzaG93UGFzc3dvcmQgPyAnT2N1bHRhciBjb250cmFzZcOxYScgOiAnTW9zdHJhciBjb250cmFzZcOxYSdcIiBjbGFzcz1cImFic29sdXRlIHJpZ2h0LTMgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIGN1cnNvci1wb2ludGVyXCIgIEBjbGljaz1cInRvZ2dsZVBhc3N3b3JkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbWcgOnNyYz1cImV5ZUljb25cIiBhbHQ9XCJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgaWQ9XCJyZW1lbWJlclwiIHYtbW9kZWw9XCJyZW1lbWJlck1lXCIgdHlwZT1cImNoZWNrYm94XCIgY2xhc3M9XCJhY2NlbnQtYmctYnJhbmQgdy00IGgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGZvcj1cInJlbWVtYmVyXCIgY2xhc3M9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC10ZXh0LWRlZmF1bHRcIj5SZWNvcmRhcm1lPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIHYtaWY9XCJzdWJtaXRFcnJvclwiPnt7IHN1Ym1pdEVycm9yIH19PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBjbGFzcz1cInctZnVsbCBiZy1iZy1icmFuZC1kYXJrZXIgdGV4dC10ZXh0LW9uLWJyYW5kIHB5LTMgcm91bmRlZC1tZCBmb250LXNlbWlib2xkIHRyYW5zaXRpb24tY29sb3JzIGhvdmVyOmJnLWJnLWJyYW5kXCIgOmRpc2FibGVkPVwiaXNTdWJtaXR0aW5nXCI+SW5pY2lhciBzZXNpw7NuPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvbWFpbj5cclxuICAgICAgICA8TWFpbkZvb3RlciAvPlxyXG4gICAgPC9kaXY+XHJcbjwvdGVtcGxhdGU+Il0sIm1hcHBpbmdzIjoiQUFDQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzdELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkM7Ozs7OztBQVJjO0FBU2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzdCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxQjtBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEU7QUFDQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNSLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUM7Ozs7Ozs7Ozs7cUJBSVEsS0FBSyxFQUFDLDRCQUE0QjtxQkFFN0IsS0FBSyxFQUFDLFFBQVE7cUJBQ1gsS0FBSyxFQUFDLDZEQUE2RDtxQkFDL0QsS0FBSyxFQUFDLDZDQUE2Qzs7cUJBR25ELEtBQUssRUFBQyxnREFBZ0Q7cUJBSTlDLEtBQUssRUFBQyxxQkFBcUI7cUJBSTNCLEtBQUssRUFBQyxxQkFBcUI7cUJBSXZCLEtBQUssRUFBQyxVQUFVOzs7O3NCQU9wQixLQUFLLEVBQUMseUJBQXlCOzs7Ozt3QkExQnhELG9CQXFDTSxPQXJDTixVQXFDTTtJQXBDRixhQUFjO0lBQ2Qsb0JBaUNPLFFBakNQLFVBaUNPO01BaENILG9CQStCTSxPQS9CTixVQStCTTtRQTlCRixvQkFFTSxPQUZOLFVBRU07VUFERixvQkFBd0c7WUFBbEcsR0FBRyxFQUFFLGlCQUFVO1lBQUUsR0FBRyxFQUFDLHlCQUF5QjtZQUFDLEtBQUssRUFBQyw0Q0FBNEM7OztRQUUzRyxvQkEwQk0sT0ExQk4sVUEwQk07VUF6QkYsb0JBd0JPO1lBeEJELEtBQUssRUFBQywyQkFBMkI7WUFBRSxRQUFNLGlCQUFVLG1CQUFZOztzQ0FDakUsb0JBQStFLFFBQTNFLEtBQUssRUFBQyxpREFBaUQsSUFBQyxnQkFBYztzQ0FDMUUsb0JBQXVGLE9BQXBGLEtBQUssRUFBQywyQkFBMkIsSUFBQyxnREFBOEM7WUFDbkYsb0JBR00sT0FITixVQUdNO3dDQUZGLG9CQUF5RztnQkFBbEcsR0FBRyxFQUFDLE1BQU07Z0JBQUMsS0FBSyxFQUFDLGlFQUFpRTtpQkFBQyxTQUFPOzhCQUNqRyxvQkFBMk07Z0JBQXBNLEVBQUUsRUFBQyxNQUFNOzZFQUFVLFdBQUk7Z0JBQUUsSUFBSSxFQUFDLE1BQU07Z0JBQUMsS0FBSyxFQUFDLCtIQUErSDtnQkFBQyxXQUFXLEVBQUMsWUFBWTs7OEJBQWhMLFdBQUk7OztZQUVsQyxvQkFVTSxPQVZOLFVBVU07d0NBVEYsb0JBRU07Z0JBREYsb0JBQWdIO2tCQUF6RyxHQUFHLEVBQUMsVUFBVTtrQkFBQyxLQUFLLEVBQUMsaUVBQWlFO21CQUFDLFlBQVU7O2NBRTVHLG9CQUtNLE9BTE4sVUFLTTtnQ0FKRixvQkFBeU47a0JBQWxOLEVBQUUsRUFBQyxVQUFVOytFQUFVLGVBQVE7a0JBQUcsSUFBSSxFQUFFLG1CQUFZO2tCQUF3QixLQUFLLEVBQUMsK0hBQStIOzttQ0FBMUwsZUFBUTs7Z0JBQ3RDLG9CQUVTO2tCQUZELElBQUksRUFBQyxRQUFRO2tCQUFFLFlBQVUsRUFBRSxtQkFBWTtrQkFBZ0QsS0FBSyxFQUFDLDBEQUEwRDtrQkFBRyxPQUFLLEVBQUUscUJBQWM7O2tCQUNuTCxvQkFBMkI7b0JBQXJCLEdBQUcsRUFBRSxjQUFPO29CQUFFLEdBQUcsRUFBQyxFQUFFOzs7OztZQUl0QyxvQkFHTSxPQUhOLFdBR007OEJBRkYsb0JBQTBGO2dCQUFuRixFQUFFLEVBQUMsVUFBVTs2RUFBVSxpQkFBVTtnQkFBRSxJQUFJLEVBQUMsVUFBVTtnQkFBQyxLQUFLLEVBQUMseUJBQXlCOztrQ0FBM0QsaUJBQVU7O3dDQUN4QyxvQkFBd0Y7Z0JBQWpGLEdBQUcsRUFBQyxVQUFVO2dCQUFDLEtBQUssRUFBQyx5Q0FBeUM7aUJBQUMsWUFBVTs7YUFFM0Usa0JBQVc7K0JBQXBCLG9CQUEyQyxtQ0FBbEIsa0JBQVc7O1lBQ3BDLG9CQUE2TDtjQUFyTCxJQUFJLEVBQUMsUUFBUTtjQUFDLEtBQUssRUFBQyxnSEFBZ0g7Y0FBRSxRQUFRLEVBQUUsbUJBQVk7ZUFBRSxnQkFBYzs7Ozs7SUFLcE0sYUFBYyIsImlnbm9yZUxpc3QiOltdfQ==