import { Kn as ref, Nt as onDeactivated, Ot as nextTick, U as computed, Ut as provide, Wn as reactive, Yn as shallowRef, _n as watchEffect, gn as watch, kt as onActivated, nr as unref, nt as defineComponent, pt as h, qn as shallowReactive, ut as getCurrentInstance, xt as inject, zt as onUnmounted } from "/node_modules/.vite/deps/vue.runtime.esm-bundler-D2wK8Voh.js?v=7f2dea69";
//#region node_modules/nostics/dist/index.mjs
/**
* Renders a diagnostic into a multi-line, unicode-decorated string suitable
* for terminal output. The first line is `[<name>] <message>`; optional
* details (`fix`, `sources`, `docs`) follow with `├▶`/`╰▶` connectors.
*/
function formatDiagnostic(diagnostic) {
	const header = `[${diagnostic.name}] ${diagnostic.message}`;
	const details = [];
	if (diagnostic.fix) details.push(`fix: ${diagnostic.fix}`);
	if (diagnostic.sources?.length) details.push(`sources: ${diagnostic.sources.join(", ")}`);
	if (diagnostic.docs) details.push(`see: ${diagnostic.docs}`);
	if (details.length === 0) return header;
	return [header, ...details.map((detail, i) => {
		return `${i < details.length - 1 ? "├▶" : "╰▶"} ${detail}`;
	})].join("\n");
}
/**
* Transforms a value or a function that returns a value to a value.
*
* @param valFn either a value or a function that returns a value
* @param args  arguments to pass to the function if `valFn` is a function
*
* @internal
*/
function toValueWithArgs(valFn, ...args) {
	return typeof valFn === "function" ? valFn(...args) : valFn;
}
/**
* Creates a console reporter that renders each diagnostic with `formatter` and
* prints the result via `console[method]`. Both default sensibly (`'warn'` and
* {@link formatDiagnostic}); `method` can also be overridden per call through
* the reporter options.
*/
/* @__NO_SIDE_EFFECTS__ */
function createConsoleReporter({ method: defaultMethod = "warn", formatter = formatDiagnostic } = {}) {
	return (diagnostic, { method = defaultMethod } = {}) => {
		console[method](formatter(diagnostic));
	};
}
var captureStackTrace = Error.captureStackTrace;
var Diagnostic = class Diagnostic extends Error {
	name;
	/**
	* The diagnostic code, e.g. `MATH_E001`.
	* Also appears as the `name` property.
	*/
	code;
	/**
	* URL to extended documentation for this diagnostic code.
	* Auto-generated from {@link DefineDiagnosticsOptions.docsBase}.
	*/
	docs;
	/**
	* Optional actionable instructions on how to resolve the problem.
	*/
	fix;
	/**
	* Locations in user code that contributed to this diagnostic, in
	* `file:line:column` format. Relevant when the stack trace doesn't reflect
	* the user's source (e.g. compilers, bundlers), otherwise redundant with the
	* stack and should be omitted.
	*/
	sources;
	/**
	* Alias for {@link Error.message}: the reason this diagnostic was raised.
	*/
	get why() {
		return this.message;
	}
	/**
	* @param init        structured initializer; `why` is required
	* @param captureFrom V8 stack-cutoff frame. Defaults to {@link Diagnostic}
	* so the top of the trace is the `new Diagnostic(...)` call site.
	* `defineDiagnostics` passes its action method to strip its own frames too.
	* Ignored on engines without `Error.captureStackTrace`.
	*/
	constructor(init, captureFrom = Diagnostic) {
		super(init.why, { cause: init.cause });
		this.code = this.name = init.code;
		this.fix = init.fix;
		this.docs = init.docs;
		this.sources = init.sources;
		captureStackTrace?.(this, captureFrom);
	}
	/**
	* Converts the diagnostic into a serializable structured object.
	*/
	toJSON() {
		return {
			name: this.name,
			why: this.why,
			fix: this.fix,
			docs: this.docs,
			sources: this.sources,
			cause: this.cause,
			stack: this.stack
		};
	}
};
/**
* Resolves the docs URL for a code from a `docsBase` (string template or
* resolver function). Shared by {@link defineDiagnostics} and
* {@link defineProdDiagnostics}. Per-code `docs` overrides are handled by the
* caller; this only covers the `docsBase`-derived case.
*
* @internal
*/
function deriveDocs(docsBase, code) {
	return typeof docsBase === "string" ? `${docsBase}/${code.toLowerCase()}` : docsBase?.(code);
}
/**
* Creates a typed diagnostics object from a set of code definitions. Each
* code becomes a callable {@link DiagnosticHandle}: invoke to report, or
* `throw` the result to raise. No `new` required, no proxy.
*/
/* @__NO_SIDE_EFFECTS__ */
function defineDiagnostics(options) {
	const reporters = options.reporters ?? [];
	const result = {};
	const { docsBase } = options;
	for (const code of Object.keys(options.codes)) {
		const def = options.codes[code];
		const docs = def.docs === false ? void 0 : def.docs || deriveDocs(docsBase, code);
		const handle = (params = {}, reporterOptions = {}) => {
			const diagnostic = new Diagnostic({
				code,
				why: toValueWithArgs(def.why, params),
				fix: toValueWithArgs(def.fix, params),
				docs,
				cause: params.cause,
				sources: params.sources
			}, handle);
			for (const reporter of reporters) reporter(diagnostic, reporterOptions);
			return diagnostic;
		};
		result[code] = handle;
	}
	return result;
}
//#endregion
//#region node_modules/vue-router/dist/useApi-BPuI6ZR9.js
/*!
* vue-router v5.3.1
* (c) 2026 Eduardo San Martin Morote
* @license MIT
*/
/**
* Checks if a path is absolute, meaning it starts with a `/`.
*
* @param path - path to check
*
* @internal
*/
var isAbsolutePath = (path) => path.startsWith("/");
/**
* Allows differentiating lazy components from functional components and vue-class-component
* @internal
*
* @param component
*/
function isRouteComponent(component) {
	return typeof component === "object" || "displayName" in component || "props" in component || "__vccOpts" in component;
}
function isESModule(obj) {
	return obj.__esModule || obj[Symbol.toStringTag] === "Module" || obj.default && isRouteComponent(obj.default);
}
var assign = Object.assign;
function applyToParams(fn, params) {
	const newParams = {};
	for (const key in params) {
		const value = params[key];
		newParams[key] = isArray(value) ? value.map(fn) : fn(value);
	}
	return newParams;
}
var noop = () => {};
/**
* Typesafe alternative to Array.isArray
* https://github.com/microsoft/TypeScript/pull/48228
*
* @internal
*/
var isArray = Array.isArray;
function mergeOptions(defaults, partialOptions) {
	const options = {};
	for (const key in defaults) options[key] = key in partialOptions ? partialOptions[key] : defaults[key];
	return options;
}
var NavigationFailureSymbol = Symbol("navigation failure");
/**
* Enumeration with all possible types for navigation failures. Can be passed to
* {@link isNavigationFailure} to check for specific failures.
*/
var NavigationFailureType = /* @__PURE__ */ function(NavigationFailureType) {
	/**
	* An aborted navigation is a navigation that failed because a navigation
	* guard returned `false` or called `next(false)`
	*/
	NavigationFailureType[NavigationFailureType["aborted"] = 4] = "aborted";
	/**
	* A cancelled navigation is a navigation that failed because a more recent
	* navigation finished started (not necessarily finished).
	*/
	NavigationFailureType[NavigationFailureType["cancelled"] = 8] = "cancelled";
	/**
	* A duplicated navigation is a navigation that failed because it was
	* initiated while already being at the exact same location.
	*/
	NavigationFailureType[NavigationFailureType["duplicated"] = 16] = "duplicated";
	return NavigationFailureType;
}({});
var ErrorTypeMessages = {
	[1]({ location, currentLocation }) {
		return `No match for\n ${JSON.stringify(location)}${currentLocation ? "\nwhile being at\n" + JSON.stringify(currentLocation) : ""}`;
	},
	[2]({ from, to }) {
		return `Redirected from "${from.fullPath}" to "${stringifyRoute(to)}" via a navigation guard.`;
	},
	[4]({ from, to }) {
		return `Navigation aborted from "${from.fullPath}" to "${to.fullPath}" via a navigation guard.`;
	},
	[8]({ from, to }) {
		return `Navigation cancelled from "${from.fullPath}" to "${to.fullPath}" with a new navigation.`;
	},
	[16]({ from, to: _to }) {
		return `Avoided redundant navigation to current location: "${from.fullPath}".`;
	}
};
/**
* Creates a typed NavigationFailure object.
* @internal
* @param type - NavigationFailureType
* @param params - { from, to }
*/
function createRouterError(type, params) {
	return assign(new Error(ErrorTypeMessages[type](params)), {
		type,
		[NavigationFailureSymbol]: true
	}, params);
}
function isNavigationFailure(error, type) {
	return error instanceof Error && NavigationFailureSymbol in error && (type == null || !!(error.type & type));
}
var propertiesToLog = [
	"params",
	"query",
	"hash"
];
/**
* Stringifies a raw location for display in dev warnings.
*
* @internal
*/
function stringifyRoute(to) {
	if (!to || typeof to === "string") return to;
	if (to.path != null) return to.path;
	const location = {};
	for (const key of propertiesToLog) if (key in to) location[key] = to[key];
	return JSON.stringify(location, null, 2);
}
/**
* Runtime diagnostics catalog for Vue Router.
*
* Every entry has a stable `VUE_ROUTER_R####` code, a `why` that states the problem
* (the diagnosis only, never the remedy) and a `fix` that states the remedy
* (only, never the diagnosis). They are complementary: the reporter prints
* both, so neither repeats the other. The diagnosis substrings asserted by the
* warning tests stay in `why`. All call sites stay behind the existing `__DEV__` (or
* `process.env.NODE_ENV !== 'production'`) guards and remain bare expression
* statements so they tree-shake out of production builds.
*
* Codes are permanent: never rename or reuse one.
* - `VUE_ROUTER_R0###` core runtime warnings
* - `VUE_ROUTER_R1###` experimental data-loaders
*/
var diagnostics = /*#__PURE__*/ defineDiagnostics({
	reporters: [/*#__PURE__*/ createConsoleReporter()],
	codes: {
		VUE_ROUTER_R0001: {
			why: (p) => `Parent route "${p.name}" not found when adding child route`,
			fix: "Add the parent route before its children, or check the parent name for typos.",
			docs: "https://router.vuejs.org/guide/advanced/dynamic-routing.html#Adding-nested-routes"
		},
		VUE_ROUTER_R0002: {
			why: (p) => `Cannot remove non-existent route "${p.name}"`,
			fix: "Check the route name; it may already have been removed or was never added.",
			docs: "https://router.vuejs.org/guide/advanced/dynamic-routing.html#Removing-routes"
		},
		VUE_ROUTER_R0003: {
			why: (p) => `Location "${stringifyRoute(p.location)}" resolved to "${p.href}". A resolved location cannot start with multiple slashes.`,
			fix: "Remove the leading slashes from the location or fix the route configuration."
		},
		VUE_ROUTER_R0004: {
			why: (p) => `No match found for location with path "${stringifyRoute(p.path)}"`,
			fix: "Add a route matching this path or check for typos in the location.",
			docs: "https://router.vuejs.org/guide/essentials/dynamic-matching.html#Catch-all-404-Not-found-Route"
		},
		VUE_ROUTER_R0005: {
			why: (p) => `router.resolve() was passed an invalid location. This will fail in production.\nLocation: ${stringifyRoute(p.rawLocation)}`,
			fix: "Pass a valid route location: a string path or an object with `path` or `name`."
		},
		VUE_ROUTER_R0006: {
			why: (p) => `Path "${p.path}" was passed with params but they will be ignored because a "path" was passed.`,
			fix: "Use a named route `{ name, params }` instead of `{ path, params }`.",
			docs: "https://router.vuejs.org/guide/essentials/navigation.html#Navigate-to-a-different-location"
		},
		VUE_ROUTER_R0007: {
			why: (p) => `A \`hash\` should always start with the character "#" but received "${p.hash}".`,
			fix: (p) => `Prepend "#" to the hash in your route location: use "#${p.hash}".`
		},
		VUE_ROUTER_R0008: {
			why: (p) => `Invalid redirect found:\n${p.target}\n when navigating to "${p.to}".\nThis will break in production.`,
			fix: "A redirect must resolve to a location with a `name` or `path`; return one of those (or a string path) from `redirect`.",
			docs: "https://router.vuejs.org/guide/essentials/redirect-and-alias.html#Redirect"
		},
		VUE_ROUTER_R0009: {
			why: (p) => `Detected a possibly infinite redirection in a navigation guard when going from "${p.from}" to "${p.to}". Aborting to avoid a Stack Overflow. This might break in production if not fixed.`,
			fix: "A guard is returning a new location on every call; make that return conditional so it only redirects when actually needed.",
			docs: "https://router.vuejs.org/guide/advanced/navigation-guards.html#Global-Before-Guards"
		},
		VUE_ROUTER_R0010: {
			why: "Uncaught error during route navigation",
			fix: "Register an error handler with `router.onError()` to handle navigation errors."
		},
		VUE_ROUTER_R0011: {
			why: "Unexpected error when starting the router:",
			fix: "Inspect the actual cause; a navigation guard or async component likely threw during the initial navigation."
		},
		VUE_ROUTER_R0020: {
			why: (p) => `No active route record was found when calling \`${p.fn}()\`. Maybe you called it inside of App.vue?`,
			fix: "Call it from a component rendered inside <router-view> (a page component or one of its children), not from App.vue.",
			docs: "https://router.vuejs.org/guide/advanced/composition-api.html#Navigation-Guards"
		},
		VUE_ROUTER_R0021: {
			why: "No active route record was found when reactivating component with navigation guard. This is likely a bug in vue-router.",
			fix: "Report with a minimal reproduction at https://github.com/vuejs/router/issues/new/choose."
		},
		VUE_ROUTER_R0022: {
			why: (p) => `${p.fn}() was called outside of component setup but it must be called at the top of a setup function`,
			fix: "Call it synchronously at the top of `setup()`, before any `await`.",
			docs: "https://router.vuejs.org/guide/advanced/composition-api.html#Navigation-Guards"
		},
		VUE_ROUTER_R0023: {
			why: (p) => `The "next" callback was never called inside of ${p.name ? `"${p.name}"` : ""}:\n${p.guard}`,
			fix: "Make sure `next()` runs on every branch, including early returns and async paths, or drop the `next` parameter and return the value instead.",
			docs: "https://router.vuejs.org/guide/advanced/navigation-guards.html#Optional-third-argument-next"
		},
		VUE_ROUTER_R0024: {
			why: (p) => `The "next" callback was called more than once in one navigation guard when going from "${p.from}" to "${p.to}". This will fail in production.`,
			fix: "Call `next()` exactly once per guard: remove the extra call, or migrate to returning the value you passed to `next()`.",
			docs: "https://router.vuejs.org/guide/advanced/navigation-guards.html#Optional-third-argument-next"
		},
		VUE_ROUTER_R0025: {
			why: "The `next()` callback in navigation guards is deprecated.",
			fix: "Return the value instead: `next()` becomes `return`, `next(false)` becomes `return false`, `next(\"/path\")` becomes `return \"/path\"`.",
			docs: "https://router.vuejs.org/guide/advanced/navigation-guards.html#Optional-third-argument-next"
		},
		VUE_ROUTER_R0026: {
			why: (p) => `Record with path "${p.path}" is either missing a "component(s)" or "children" property.`,
			fix: "Add a `component`, `components`, or `children` to the route record.",
			docs: "https://router.vuejs.org/guide/essentials/nested-routes.html"
		},
		VUE_ROUTER_R0027: {
			why: (p) => `Component "${p.name}" in record with path "${p.path}" is not a valid component. Received "${p.received}".`,
			fix: "Pass a component or a function returning a Promise that resolves to one."
		},
		VUE_ROUTER_R0028: {
			why: (p) => `Component "${p.name}" in record with path "${p.path}" is a Promise instead of a function that returns a Promise. This will break in production if not fixed.`,
			fix: `Defer the import in an arrow function so it loads lazily: write "() => import('./MyPage.vue')", not "import('./MyPage.vue')".`,
			docs: "https://router.vuejs.org/guide/advanced/lazy-loading.html"
		},
		VUE_ROUTER_R0029: {
			why: (p) => `Component "${p.name}" in record with path "${p.path}" is defined using "defineAsyncComponent()".`,
			fix: `Drop the wrapper and pass "() => import('./MyPage.vue')" directly; the router handles lazy components itself.`,
			docs: "https://router.vuejs.org/guide/advanced/lazy-loading.html#Relationship-to-async-components"
		},
		VUE_ROUTER_R0030: {
			why: (p) => `Component "${p.name}" in record with path "${p.path}" is a function that does not return a Promise. This will break in production if not fixed.`,
			fix: "Return a dynamic import (`() => import(\"./MyPage.vue\")`) from the function, or add a `displayName` if it is a functional component.",
			docs: "https://router.vuejs.org/guide/advanced/lazy-loading.html"
		},
		VUE_ROUTER_R0040: {
			why: (p) => `Because "${p.el}" starts with "#", scrollBehavior resolves it as an element id via document.getElementById("${p.el.slice(1)}"), not as a CSS selector. No element has that id, but "${p.el}" does match an element with document.querySelector().`,
			fix: (p) => `Resolve the element yourself and return the node: el: document.querySelector('${p.el}').`,
			docs: "https://router.vuejs.org/guide/advanced/scroll-behavior.html"
		},
		VUE_ROUTER_R0041: {
			why: (p) => `The selector "${p.el}" is invalid. See https://mathiasbynens.be/notes/css-escapes or CSS.escape (https://developer.mozilla.org/en-US/docs/Web/API/CSS/escape) for the escaping rules.`,
			fix: "Build an id selector as `#${CSS.escape(id)}` so special characters in the id are escaped.",
			docs: "https://router.vuejs.org/guide/advanced/scroll-behavior.html"
		},
		VUE_ROUTER_R0042: {
			why: (p) => `Couldn't find element using selector "${p.el}" returned by scrollBehavior.`,
			fix: "Return a selector that matches an existing element, or guard against missing elements.",
			docs: "https://router.vuejs.org/guide/advanced/scroll-behavior.html"
		},
		VUE_ROUTER_R0050: {
			why: (p) => {
				let to;
				try {
					to = p.to === void 0 ? "undefined" : JSON.stringify(p.to);
				} catch {
					to = String(p.to);
				}
				return `Invalid value for prop "to" in useLink()\n- to: ${to}`;
			},
			fix: "Pass a valid route location (a string path or an object) to the \"to\" prop."
		},
		VUE_ROUTER_R0060: {
			why: (p) => `<router-view> can no longer be used directly inside <${p.comp}>.`,
			fix: (p) => `Wrap the slot's resolved component with <${p.comp}> instead of nesting <router-view> in it:\n\n<router-view v-slot="{ Component }">\n  <${p.comp}>\n    <component :is="Component" />\n  </${p.comp}>\n</router-view>`,
			docs: "https://router.vuejs.org/guide/advanced/router-view-slot.html#KeepAlive-Transition"
		},
		VUE_ROUTER_R0070: {
			why: (p) => `Cannot resolve a relative location without an absolute path. Trying to resolve "${p.to}" from "${p.from}".`,
			fix: (p) => `Resolve from an absolute \`from\` path that starts with "/", e.g. "/${p.from}".`
		},
		VUE_ROUTER_R0080: {
			why: (p) => `Error decoding "${p.text}". Using original value`,
			fix: "Ensure the value is correctly percent-encoded."
		},
		VUE_ROUTER_R0090: {
			why: (p) => `Found duplicated params with name "${p.name}" for path "${p.path}". Only the last one will be available on "$route.params".`,
			fix: "Give each param a unique name within the path.",
			docs: "https://router.vuejs.org/guide/essentials/route-matching-syntax.html"
		},
		VUE_ROUTER_R0100: {
			why: (p) => `Discarded invalid param(s) "${p.params}" when navigating.` + p.inherited + ` See https://github.com/vuejs/router/commit/e887570 for more details.`,
			fix: "Only pass params that exist on the target route."
		},
		VUE_ROUTER_R0101: {
			why: (p) => `The Matcher cannot resolve relative paths but received "${p.path}". Unless you directly called \`matcher.resolve("${p.path}")\`, this is probably a bug in vue-router. Please open an issue at https://github.com/vuejs/router/issues/new/choose.`,
			fix: "Pass an absolute path (starting with \"/\") to the matcher."
		},
		VUE_ROUTER_R0102: {
			why: (p) => `Alias "${p.alias}" and the original record: "${p.original}" must have the exact same param named "${p.name}"`,
			fix: "Use the same param names in the alias as in the original route.",
			docs: "https://router.vuejs.org/guide/essentials/redirect-and-alias.html#Alias"
		},
		VUE_ROUTER_R0103: {
			why: (p) => `The route named "${p.name}" has a child without a name, an empty path, and no children. Using that name won't render the empty path child, so this is probably a mistake.`,
			fix: "Move the `name` onto the empty-path child; or, if intentional, give the child its own name to silence this.",
			docs: "https://router.vuejs.org/guide/essentials/nested-routes.html#Nested-Named-Routes"
		},
		VUE_ROUTER_R0104: {
			why: (p) => `Absolute path "${p.path}" must have the exact same param named "${p.name}" as its parent "${p.parent}".`,
			fix: "Include the parent route params in the absolute child path.",
			docs: "https://router.vuejs.org/guide/essentials/nested-routes.html"
		},
		VUE_ROUTER_R0105: {
			why: (p) => `Finding ancestor route "${p.ancestor}" failed for "${p.record}"`,
			fix: "Report a reproduction at https://github.com/vuejs/router/issues/new/choose."
		},
		VUE_ROUTER_R0110: {
			why: `A hash base must end with a "#"`,
			fix: (p) => `Append "#" to the "base" argument passed to "createWebHashHistory()": "${p.base}" should be "${p.suggestion}".`
		},
		VUE_ROUTER_R0120: {
			why: "Error with push/replace State",
			fix: "The browser rejected the history API call; check for cross-origin or rate-limit issues."
		},
		VUE_ROUTER_R0121: {
			why: "history.state seems to have been manually replaced without preserving the necessary values.\nYou can find more information at https://router.vuejs.org/guide/migration/#Usage-of-history-state",
			fix: "Merge the router's state into your own when calling it manually: `history.replaceState({ ...history.state, ...yourState }, '', url)`.",
			docs: "https://router.vuejs.org/guide/migration.html#Usage-of-history-state"
		},
		VUE_ROUTER_R1001: {
			why: (p) => `Data loader "${String(p.key)}" has a different parent than the current context. This shouldn't be happening.`,
			fix: "Report a bug with a minimal reproduction at https://github.com/vuejs/router/."
		},
		VUE_ROUTER_R1002: {
			why: "Returning a NavigationResult is deprecated.",
			fix: "Replace `return new NavigationResult(to)` with `reroute(to)`, which throws internally to reroute.",
			docs: "https://router.vuejs.org/data-loaders/navigation-aware.html#Controlling-the-navigation-with-reroute-"
		},
		VUE_ROUTER_R1003: {
			why: (p) => `Loader "${p.key}"'s "commit()" was called but there is no staged data.`,
			fix: "Ensure the loader resolved before calling `commit()`.",
			docs: "https://router.vuejs.org/data-loaders/defining-loaders.html#Delaying-data-updates-with-commit"
		},
		VUE_ROUTER_R1004: {
			why: (p) => "A loader returned a NavigationResult but is not registered on the route." + p.key,
			fix: "Export the loader from the page component so it gets registered, e.g. `export const useUserData = defineLoader(...)`.",
			docs: "https://router.vuejs.org/data-loaders/organization.html"
		},
		VUE_ROUTER_R1005: {
			why: (p) => `Data loader "${p.key}" has itself as parent. This shouldn't be happening.`,
			fix: "Report a bug with a minimal reproduction at https://github.com/vuejs/router/."
		},
		VUE_ROUTER_R1006: {
			why: (p) => `A query was defined with the same key as the loader "[${p.key}]".\nSee https://pinia-colada.esm.dev/#TODO`,
			fix: "If the key is meant to match, use the data loader directly; otherwise rename the `useQuery()` key so it no longer collides.",
			docs: "https://router.vuejs.org/data-loaders/colada.html"
		},
		VUE_ROUTER_R1007: {
			why: "Data Loader was setup twice.",
			fix: "Register `DataLoaderPlugin` a single time via `app.use()`.",
			docs: "https://router.vuejs.org/data-loaders.html#Installation"
		},
		VUE_ROUTER_R1008: {
			why: "Data Loader is experimental and subject to breaking changes in the future.",
			docs: "https://router.vuejs.org/data-loaders.html"
		},
		VUE_ROUTER_R1009: {
			why: "Returning a NavigationResult from a loader is deprecated.",
			fix: "Call `reroute(to)` inside the loader instead of returning `new NavigationResult(to)`; it throws internally to reroute.",
			docs: "https://router.vuejs.org/data-loaders/navigation-aware.html#Controlling-the-navigation-with-reroute-"
		}
	}
});
/**
* RouteRecord being rendered by the closest ancestor Router View. Used for
* `onBeforeRouteUpdate` and `onBeforeRouteLeave`. rvlm stands for Router View
* Location Matched
*
* @internal
*/
var matchedRouteKey = Symbol("router view location matched");
/**
* Allows overriding the router view depth to control which component in
* `matched` is rendered. rvd stands for Router View Depth
*
* @internal
*/
var viewDepthKey = Symbol("router view depth");
/**
* Allows overriding the router instance returned by `useRouter` in tests. r
* stands for router
*
* @internal
*/
var routerKey = Symbol("router");
/**
* Allows overriding the current route returned by `useRoute` in tests. rl
* stands for route location
*
* @internal
*/
var routeLocationKey = Symbol("route location");
/**
* Allows overriding the current route used by router-view. Internally this is
* used when the `route` prop is passed.
*
* @internal
*/
var routerViewLocationKey = Symbol("router view location");
/**
* Returns the router instance. Equivalent to using `$router` inside
* templates.
*/
function useRouter() {
	return inject(routerKey);
}
/**
* Returns the current route location. Equivalent to using `$route` inside
* templates.
*/
function useRoute(_name) {
	return inject(routeLocationKey);
}
//#endregion
//#region node_modules/vue-router/node_modules/@vue/devtools-shared/dist/index.js
var __create$1 = Object.create;
var __defProp$1 = Object.defineProperty;
var __getOwnPropDesc$1 = Object.getOwnPropertyDescriptor;
var __getOwnPropNames$1 = Object.getOwnPropertyNames;
var __getProtoOf$1 = Object.getPrototypeOf;
var __hasOwnProp$1 = Object.prototype.hasOwnProperty;
var __commonJSMin$1 = (cb, mod) => () => (mod || cb((mod = { exports: {} }).exports, mod), mod.exports);
var __copyProps$1 = (to, from, except, desc) => {
	if (from && typeof from === "object" || typeof from === "function") for (var keys = __getOwnPropNames$1(from), i = 0, n = keys.length, key; i < n; i++) {
		key = keys[i];
		if (!__hasOwnProp$1.call(to, key) && key !== except) __defProp$1(to, key, {
			get: ((k) => from[k]).bind(null, key),
			enumerable: !(desc = __getOwnPropDesc$1(from, key)) || desc.enumerable
		});
	}
	return to;
};
var __toESM$1 = (mod, isNodeMode, target) => (target = mod != null ? __create$1(__getProtoOf$1(mod)) : {}, __copyProps$1(isNodeMode || !mod || !mod.__esModule ? __defProp$1(target, "default", {
	value: mod,
	enumerable: true
}) : target, mod));
var isBrowser$1 = typeof navigator !== "undefined";
var target = typeof window !== "undefined" ? window : typeof globalThis !== "undefined" ? globalThis : typeof global !== "undefined" ? global : {};
typeof target.chrome !== "undefined" && target.chrome.devtools;
isBrowser$1 && (target.self, target.top);
typeof navigator !== "undefined" && navigator.userAgent?.toLowerCase().includes("electron");
typeof window !== "undefined" && window.__NUXT__;
var import_rfdc = /* @__PURE__ */ __toESM$1((/* @__PURE__ */ __commonJSMin$1(((exports, module) => {
	module.exports = rfdc;
	function copyBuffer(cur) {
		if (cur instanceof Buffer) return Buffer.from(cur);
		return new cur.constructor(cur.buffer.slice(), cur.byteOffset, cur.length);
	}
	function rfdc(opts) {
		opts = opts || {};
		if (opts.circles) return rfdcCircles(opts);
		const constructorHandlers = /* @__PURE__ */ new Map();
		constructorHandlers.set(Date, (o) => new Date(o));
		constructorHandlers.set(Map, (o, fn) => new Map(cloneArray(Array.from(o), fn)));
		constructorHandlers.set(Set, (o, fn) => new Set(cloneArray(Array.from(o), fn)));
		if (opts.constructorHandlers) for (const handler of opts.constructorHandlers) constructorHandlers.set(handler[0], handler[1]);
		let handler = null;
		return opts.proto ? cloneProto : clone;
		function cloneArray(a, fn) {
			const keys = Object.keys(a);
			const a2 = new Array(keys.length);
			for (let i = 0; i < keys.length; i++) {
				const k = keys[i];
				const cur = a[k];
				if (typeof cur !== "object" || cur === null) a2[k] = cur;
				else if (cur.constructor !== Object && (handler = constructorHandlers.get(cur.constructor))) a2[k] = handler(cur, fn);
				else if (ArrayBuffer.isView(cur)) a2[k] = copyBuffer(cur);
				else a2[k] = fn(cur);
			}
			return a2;
		}
		function clone(o) {
			if (typeof o !== "object" || o === null) return o;
			if (Array.isArray(o)) return cloneArray(o, clone);
			if (o.constructor !== Object && (handler = constructorHandlers.get(o.constructor))) return handler(o, clone);
			const o2 = {};
			for (const k in o) {
				if (Object.hasOwnProperty.call(o, k) === false) continue;
				const cur = o[k];
				if (typeof cur !== "object" || cur === null) o2[k] = cur;
				else if (cur.constructor !== Object && (handler = constructorHandlers.get(cur.constructor))) o2[k] = handler(cur, clone);
				else if (ArrayBuffer.isView(cur)) o2[k] = copyBuffer(cur);
				else o2[k] = clone(cur);
			}
			return o2;
		}
		function cloneProto(o) {
			if (typeof o !== "object" || o === null) return o;
			if (Array.isArray(o)) return cloneArray(o, cloneProto);
			if (o.constructor !== Object && (handler = constructorHandlers.get(o.constructor))) return handler(o, cloneProto);
			const o2 = {};
			for (const k in o) {
				const cur = o[k];
				if (typeof cur !== "object" || cur === null) o2[k] = cur;
				else if (cur.constructor !== Object && (handler = constructorHandlers.get(cur.constructor))) o2[k] = handler(cur, cloneProto);
				else if (ArrayBuffer.isView(cur)) o2[k] = copyBuffer(cur);
				else o2[k] = cloneProto(cur);
			}
			return o2;
		}
	}
	function rfdcCircles(opts) {
		const refs = [];
		const refsNew = [];
		const constructorHandlers = /* @__PURE__ */ new Map();
		constructorHandlers.set(Date, (o) => new Date(o));
		constructorHandlers.set(Map, (o, fn) => new Map(cloneArray(Array.from(o), fn)));
		constructorHandlers.set(Set, (o, fn) => new Set(cloneArray(Array.from(o), fn)));
		if (opts.constructorHandlers) for (const handler of opts.constructorHandlers) constructorHandlers.set(handler[0], handler[1]);
		let handler = null;
		return opts.proto ? cloneProto : clone;
		function cloneArray(a, fn) {
			const keys = Object.keys(a);
			const a2 = new Array(keys.length);
			for (let i = 0; i < keys.length; i++) {
				const k = keys[i];
				const cur = a[k];
				if (typeof cur !== "object" || cur === null) a2[k] = cur;
				else if (cur.constructor !== Object && (handler = constructorHandlers.get(cur.constructor))) a2[k] = handler(cur, fn);
				else if (ArrayBuffer.isView(cur)) a2[k] = copyBuffer(cur);
				else {
					const index = refs.indexOf(cur);
					if (index !== -1) a2[k] = refsNew[index];
					else a2[k] = fn(cur);
				}
			}
			return a2;
		}
		function clone(o) {
			if (typeof o !== "object" || o === null) return o;
			if (Array.isArray(o)) return cloneArray(o, clone);
			if (o.constructor !== Object && (handler = constructorHandlers.get(o.constructor))) return handler(o, clone);
			const o2 = {};
			refs.push(o);
			refsNew.push(o2);
			for (const k in o) {
				if (Object.hasOwnProperty.call(o, k) === false) continue;
				const cur = o[k];
				if (typeof cur !== "object" || cur === null) o2[k] = cur;
				else if (cur.constructor !== Object && (handler = constructorHandlers.get(cur.constructor))) o2[k] = handler(cur, clone);
				else if (ArrayBuffer.isView(cur)) o2[k] = copyBuffer(cur);
				else {
					const i = refs.indexOf(cur);
					if (i !== -1) o2[k] = refsNew[i];
					else o2[k] = clone(cur);
				}
			}
			refs.pop();
			refsNew.pop();
			return o2;
		}
		function cloneProto(o) {
			if (typeof o !== "object" || o === null) return o;
			if (Array.isArray(o)) return cloneArray(o, cloneProto);
			if (o.constructor !== Object && (handler = constructorHandlers.get(o.constructor))) return handler(o, cloneProto);
			const o2 = {};
			refs.push(o);
			refsNew.push(o2);
			for (const k in o) {
				const cur = o[k];
				if (typeof cur !== "object" || cur === null) o2[k] = cur;
				else if (cur.constructor !== Object && (handler = constructorHandlers.get(cur.constructor))) o2[k] = handler(cur, cloneProto);
				else if (ArrayBuffer.isView(cur)) o2[k] = copyBuffer(cur);
				else {
					const i = refs.indexOf(cur);
					if (i !== -1) o2[k] = refsNew[i];
					else o2[k] = cloneProto(cur);
				}
			}
			refs.pop();
			refsNew.pop();
			return o2;
		}
	}
})))(), 1);
var classifyRE = /(?:^|[-_/])(\w)/g;
function toUpper(_, c) {
	return c ? c.toUpperCase() : "";
}
function classify(str) {
	return str && `${str}`.replace(classifyRE, toUpper);
}
function basename(filename, ext) {
	let normalizedFilename = filename.replace(/^[a-z]:/i, "").replace(/\\/g, "/");
	if (normalizedFilename.endsWith(`index${ext}`)) normalizedFilename = normalizedFilename.replace(`/index${ext}`, ext);
	const lastSlashIndex = normalizedFilename.lastIndexOf("/");
	const baseNameWithExt = normalizedFilename.substring(lastSlashIndex + 1);
	if (ext) {
		const extIndex = baseNameWithExt.lastIndexOf(ext);
		return baseNameWithExt.substring(0, extIndex);
	}
	return "";
}
/**
* @copyright [rfdc](https://github.com/davidmarkclements/rfdc)
* @description A really fast deep clone alternative
*/
var deepClone = (0, import_rfdc.default)({ circles: true });
//#endregion
//#region node_modules/vue-router/node_modules/perfect-debounce/dist/index.mjs
var DEBOUNCE_DEFAULTS = { trailing: true };
/**
Debounce functions
@param fn - Promise-returning/async function to debounce.
@param wait - Milliseconds to wait before calling `fn`. Default value is 25ms
@returns A function that delays calling `fn` until after `wait` milliseconds have elapsed since the last time it was called.
@example
```
import { debounce } from 'perfect-debounce';
const expensiveCall = async input => input;
const debouncedFn = debounce(expensiveCall, 200);
for (const number of [1, 2, 3]) {
console.log(await debouncedFn(number));
}
//=> 1
//=> 2
//=> 3
```
*/
function debounce(fn, wait = 25, options = {}) {
	options = {
		...DEBOUNCE_DEFAULTS,
		...options
	};
	if (!Number.isFinite(wait)) throw new TypeError("Expected `wait` to be a finite number");
	let leadingValue;
	let timeout;
	let resolveList = [];
	let currentPromise;
	let trailingArgs;
	const applyFn = (_this, args) => {
		currentPromise = _applyPromised(fn, _this, args);
		currentPromise.finally(() => {
			currentPromise = null;
			if (options.trailing && trailingArgs && !timeout) {
				const promise = applyFn(_this, trailingArgs);
				trailingArgs = null;
				return promise;
			}
		});
		return currentPromise;
	};
	const debounced = function(...args) {
		if (options.trailing) trailingArgs = args;
		if (currentPromise) return currentPromise;
		return new Promise((resolve) => {
			const shouldCallNow = !timeout && options.leading;
			clearTimeout(timeout);
			timeout = setTimeout(() => {
				timeout = null;
				const promise = options.leading ? leadingValue : applyFn(this, args);
				trailingArgs = null;
				for (const _resolve of resolveList) _resolve(promise);
				resolveList = [];
			}, wait);
			if (shouldCallNow) {
				leadingValue = applyFn(this, args);
				resolve(leadingValue);
			} else resolveList.push(resolve);
		});
	};
	const _clearTimeout = (timer) => {
		if (timer) {
			clearTimeout(timer);
			timeout = null;
		}
	};
	debounced.isPending = () => !!timeout;
	debounced.cancel = () => {
		_clearTimeout(timeout);
		resolveList = [];
		trailingArgs = null;
	};
	debounced.flush = () => {
		_clearTimeout(timeout);
		if (!trailingArgs || currentPromise) return;
		const args = trailingArgs;
		trailingArgs = null;
		return applyFn(this, args);
	};
	return debounced;
}
async function _applyPromised(fn, _this, args) {
	return await fn.apply(_this, args);
}
//#endregion
//#region node_modules/hookable/dist/index.mjs
function flatHooks(configHooks, hooks = {}, parentName) {
	for (const key in configHooks) {
		const subHook = configHooks[key];
		const name = parentName ? `${parentName}:${key}` : key;
		if (typeof subHook === "object" && subHook !== null) flatHooks(subHook, hooks, name);
		else if (typeof subHook === "function") hooks[name] = subHook;
	}
	return hooks;
}
var defaultTask = { run: (function_) => function_() };
var _createTask = () => defaultTask;
var createTask = typeof console.createTask !== "undefined" ? console.createTask : _createTask;
function serialTaskCaller(hooks, args) {
	const task = createTask(args.shift());
	return hooks.reduce((promise, hookFunction) => promise.then(() => task.run(() => hookFunction(...args))), Promise.resolve());
}
function parallelTaskCaller(hooks, args) {
	const task = createTask(args.shift());
	return Promise.all(hooks.map((hook) => task.run(() => hook(...args))));
}
function callEachWith(callbacks, arg0) {
	for (const callback of [...callbacks]) callback(arg0);
}
var Hookable = class {
	constructor() {
		this._hooks = {};
		this._before = void 0;
		this._after = void 0;
		this._deprecatedMessages = void 0;
		this._deprecatedHooks = {};
		this.hook = this.hook.bind(this);
		this.callHook = this.callHook.bind(this);
		this.callHookWith = this.callHookWith.bind(this);
	}
	hook(name, function_, options = {}) {
		if (!name || typeof function_ !== "function") return () => {};
		const originalName = name;
		let dep;
		while (this._deprecatedHooks[name]) {
			dep = this._deprecatedHooks[name];
			name = dep.to;
		}
		if (dep && !options.allowDeprecated) {
			let message = dep.message;
			if (!message) message = `${originalName} hook has been deprecated` + (dep.to ? `, please use ${dep.to}` : "");
			if (!this._deprecatedMessages) this._deprecatedMessages = /* @__PURE__ */ new Set();
			if (!this._deprecatedMessages.has(message)) {
				console.warn(message);
				this._deprecatedMessages.add(message);
			}
		}
		if (!function_.name) try {
			Object.defineProperty(function_, "name", {
				get: () => "_" + name.replace(/\W+/g, "_") + "_hook_cb",
				configurable: true
			});
		} catch {}
		this._hooks[name] = this._hooks[name] || [];
		this._hooks[name].push(function_);
		return () => {
			if (function_) {
				this.removeHook(name, function_);
				function_ = void 0;
			}
		};
	}
	hookOnce(name, function_) {
		let _unreg;
		let _function = (...arguments_) => {
			if (typeof _unreg === "function") _unreg();
			_unreg = void 0;
			_function = void 0;
			return function_(...arguments_);
		};
		_unreg = this.hook(name, _function);
		return _unreg;
	}
	removeHook(name, function_) {
		if (this._hooks[name]) {
			const index = this._hooks[name].indexOf(function_);
			if (index !== -1) this._hooks[name].splice(index, 1);
			if (this._hooks[name].length === 0) delete this._hooks[name];
		}
	}
	deprecateHook(name, deprecated) {
		this._deprecatedHooks[name] = typeof deprecated === "string" ? { to: deprecated } : deprecated;
		const _hooks = this._hooks[name] || [];
		delete this._hooks[name];
		for (const hook of _hooks) this.hook(name, hook);
	}
	deprecateHooks(deprecatedHooks) {
		Object.assign(this._deprecatedHooks, deprecatedHooks);
		for (const name in deprecatedHooks) this.deprecateHook(name, deprecatedHooks[name]);
	}
	addHooks(configHooks) {
		const hooks = flatHooks(configHooks);
		const removeFns = Object.keys(hooks).map((key) => this.hook(key, hooks[key]));
		return () => {
			for (const unreg of removeFns.splice(0, removeFns.length)) unreg();
		};
	}
	removeHooks(configHooks) {
		const hooks = flatHooks(configHooks);
		for (const key in hooks) this.removeHook(key, hooks[key]);
	}
	removeAllHooks() {
		for (const key in this._hooks) delete this._hooks[key];
	}
	callHook(name, ...arguments_) {
		arguments_.unshift(name);
		return this.callHookWith(serialTaskCaller, name, ...arguments_);
	}
	callHookParallel(name, ...arguments_) {
		arguments_.unshift(name);
		return this.callHookWith(parallelTaskCaller, name, ...arguments_);
	}
	callHookWith(caller, name, ...arguments_) {
		const event = this._before || this._after ? {
			name,
			args: arguments_,
			context: {}
		} : void 0;
		if (this._before) callEachWith(this._before, event);
		const result = caller(name in this._hooks ? [...this._hooks[name]] : [], arguments_);
		if (result instanceof Promise) return result.finally(() => {
			if (this._after && event) callEachWith(this._after, event);
		});
		if (this._after && event) callEachWith(this._after, event);
		return result;
	}
	beforeEach(function_) {
		this._before = this._before || [];
		this._before.push(function_);
		return () => {
			if (this._before !== void 0) {
				const index = this._before.indexOf(function_);
				if (index !== -1) this._before.splice(index, 1);
			}
		};
	}
	afterEach(function_) {
		this._after = this._after || [];
		this._after.push(function_);
		return () => {
			if (this._after !== void 0) {
				const index = this._after.indexOf(function_);
				if (index !== -1) this._after.splice(index, 1);
			}
		};
	}
};
function createHooks() {
	return new Hookable();
}
//#endregion
//#region node_modules/birpc/dist/index.mjs
var { clearTimeout: clearTimeout$1, setTimeout: setTimeout$1 } = globalThis;
Math.random.bind(Math);
var __commonJSMin = (cb, mod) => () => (mod || cb((mod = { exports: {} }).exports, mod), mod.exports);
function getComponentTypeName(options) {
	if (typeof options === "function") return options.displayName || options.name || options.__VUE_DEVTOOLS_COMPONENT_GUSSED_NAME__ || "";
	const name = options.name || options._componentTag || options.__VUE_DEVTOOLS_COMPONENT_GUSSED_NAME__ || options.__name;
	if (name === "index" && options.__file?.endsWith("index.vue")) return "";
	return name;
}
function getComponentFileName(options) {
	const file = options.__file;
	if (file) return classify(basename(file, ".vue"));
}
function saveComponentGussedName(instance, name) {
	instance.type.__VUE_DEVTOOLS_COMPONENT_GUSSED_NAME__ = name;
	return name;
}
function getAppRecord(instance) {
	if (instance.__VUE_DEVTOOLS_NEXT_APP_RECORD__) return instance.__VUE_DEVTOOLS_NEXT_APP_RECORD__;
	else if (instance.root) return instance.appContext.app.__VUE_DEVTOOLS_NEXT_APP_RECORD__;
}
function isFragment(instance) {
	const subTreeType = instance.subTree?.type;
	const appRecord = getAppRecord(instance);
	if (appRecord) return appRecord?.types?.Fragment === subTreeType;
	return false;
}
/**
* Get the appropriate display name for an instance.
*
* @param {Vue} instance
* @return {string}
*/
function getInstanceName(instance) {
	const name = getComponentTypeName(instance?.type || {});
	if (name) return name;
	if (instance?.root === instance) return "Root";
	for (const key in instance.parent?.type?.components) if (instance.parent.type.components[key] === instance?.type) return saveComponentGussedName(instance, key);
	for (const key in instance.appContext?.components) if (instance.appContext.components[key] === instance?.type) return saveComponentGussedName(instance, key);
	const fileName = getComponentFileName(instance?.type || {});
	if (fileName) return fileName;
	return "Anonymous Component";
}
/**
* Returns a devtools unique id for instance.
* @param {Vue} instance
*/
function getUniqueComponentId(instance) {
	return `${instance?.appContext?.app?.__VUE_DEVTOOLS_NEXT_APP_RECORD_ID__ ?? 0}:${instance === instance?.root ? "root" : instance.uid}`;
}
function getComponentInstance(appRecord, instanceId) {
	instanceId = instanceId || `${appRecord.id}:root`;
	return appRecord.instanceMap.get(instanceId) || appRecord.instanceMap.get(":root");
}
function createRect() {
	const rect = {
		top: 0,
		bottom: 0,
		left: 0,
		right: 0,
		get width() {
			return rect.right - rect.left;
		},
		get height() {
			return rect.bottom - rect.top;
		}
	};
	return rect;
}
var range;
function getTextRect(node) {
	if (!range) range = document.createRange();
	range.selectNode(node);
	return range.getBoundingClientRect();
}
function getFragmentRect(vnode) {
	const rect = createRect();
	if (!vnode.children) return rect;
	for (let i = 0, l = vnode.children.length; i < l; i++) {
		const childVnode = vnode.children[i];
		let childRect;
		if (childVnode.component) childRect = getComponentBoundingRect(childVnode.component);
		else if (childVnode.el) {
			const el = childVnode.el;
			if (el.nodeType === 1 || el.getBoundingClientRect) childRect = el.getBoundingClientRect();
			else if (el.nodeType === 3 && el.data.trim()) childRect = getTextRect(el);
		}
		if (childRect) mergeRects(rect, childRect);
	}
	return rect;
}
function mergeRects(a, b) {
	if (!a.top || b.top < a.top) a.top = b.top;
	if (!a.bottom || b.bottom > a.bottom) a.bottom = b.bottom;
	if (!a.left || b.left < a.left) a.left = b.left;
	if (!a.right || b.right > a.right) a.right = b.right;
	return a;
}
var DEFAULT_RECT = {
	top: 0,
	left: 0,
	right: 0,
	bottom: 0,
	width: 0,
	height: 0
};
function getComponentBoundingRect(instance) {
	const el = instance.subTree.el;
	if (typeof window === "undefined") return DEFAULT_RECT;
	if (isFragment(instance)) return getFragmentRect(instance.subTree);
	else if (el?.nodeType === 1) return el?.getBoundingClientRect();
	else if (instance.subTree.component) return getComponentBoundingRect(instance.subTree.component);
	else return DEFAULT_RECT;
}
function getRootElementsFromComponentInstance(instance) {
	if (isFragment(instance)) return getFragmentRootElements(instance.subTree);
	if (!instance.subTree) return [];
	return [instance.subTree.el];
}
function getFragmentRootElements(vnode) {
	if (!vnode.children) return [];
	const list = [];
	vnode.children.forEach((childVnode) => {
		if (childVnode.component) list.push(...getRootElementsFromComponentInstance(childVnode.component));
		else if (childVnode?.el) list.push(childVnode.el);
	});
	return list;
}
var CONTAINER_ELEMENT_ID = "__vue-devtools-component-inspector__";
var CARD_ELEMENT_ID = "__vue-devtools-component-inspector__card__";
var COMPONENT_NAME_ELEMENT_ID = "__vue-devtools-component-inspector__name__";
var INDICATOR_ELEMENT_ID = "__vue-devtools-component-inspector__indicator__";
var containerStyles = {
	display: "block",
	zIndex: 2147483640,
	position: "fixed",
	backgroundColor: "#42b88325",
	border: "1px solid #42b88350",
	borderRadius: "5px",
	transition: "all 0.1s ease-in",
	pointerEvents: "none"
};
var cardStyles = {
	fontFamily: "Arial, Helvetica, sans-serif",
	padding: "5px 8px",
	borderRadius: "4px",
	textAlign: "left",
	position: "absolute",
	left: 0,
	color: "#e9e9e9",
	fontSize: "14px",
	fontWeight: 600,
	lineHeight: "24px",
	backgroundColor: "#42b883",
	boxShadow: "0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px -1px rgba(0, 0, 0, 0.1)"
};
var indicatorStyles = {
	display: "inline-block",
	fontWeight: 400,
	fontStyle: "normal",
	fontSize: "12px",
	opacity: .7
};
function getContainerElement() {
	return document.getElementById(CONTAINER_ELEMENT_ID);
}
function getCardElement() {
	return document.getElementById(CARD_ELEMENT_ID);
}
function getIndicatorElement() {
	return document.getElementById(INDICATOR_ELEMENT_ID);
}
function getNameElement() {
	return document.getElementById(COMPONENT_NAME_ELEMENT_ID);
}
function getStyles(bounds) {
	return {
		left: `${Math.round(bounds.left * 100) / 100}px`,
		top: `${Math.round(bounds.top * 100) / 100}px`,
		width: `${Math.round(bounds.width * 100) / 100}px`,
		height: `${Math.round(bounds.height * 100) / 100}px`
	};
}
function create(options) {
	const containerEl = document.createElement("div");
	containerEl.id = options.elementId ?? CONTAINER_ELEMENT_ID;
	Object.assign(containerEl.style, {
		...containerStyles,
		...getStyles(options.bounds),
		...options.style
	});
	const cardEl = document.createElement("span");
	cardEl.id = CARD_ELEMENT_ID;
	Object.assign(cardEl.style, {
		...cardStyles,
		top: options.bounds.top < 35 ? 0 : "-35px"
	});
	const nameEl = document.createElement("span");
	nameEl.id = COMPONENT_NAME_ELEMENT_ID;
	nameEl.innerHTML = `&lt;${options.name}&gt;&nbsp;&nbsp;`;
	const indicatorEl = document.createElement("i");
	indicatorEl.id = INDICATOR_ELEMENT_ID;
	indicatorEl.innerHTML = `${Math.round(options.bounds.width * 100) / 100} x ${Math.round(options.bounds.height * 100) / 100}`;
	Object.assign(indicatorEl.style, indicatorStyles);
	cardEl.appendChild(nameEl);
	cardEl.appendChild(indicatorEl);
	containerEl.appendChild(cardEl);
	document.body.appendChild(containerEl);
	return containerEl;
}
function update(options) {
	const containerEl = getContainerElement();
	const cardEl = getCardElement();
	const nameEl = getNameElement();
	const indicatorEl = getIndicatorElement();
	if (containerEl) {
		Object.assign(containerEl.style, {
			...containerStyles,
			...getStyles(options.bounds)
		});
		Object.assign(cardEl.style, { top: options.bounds.top < 35 ? 0 : "-35px" });
		nameEl.innerHTML = `&lt;${options.name}&gt;&nbsp;&nbsp;`;
		indicatorEl.innerHTML = `${Math.round(options.bounds.width * 100) / 100} x ${Math.round(options.bounds.height * 100) / 100}`;
	}
}
function highlight(instance) {
	const bounds = getComponentBoundingRect(instance);
	if (!bounds.width && !bounds.height) return;
	const name = getInstanceName(instance);
	getContainerElement() ? update({
		bounds,
		name
	}) : create({
		bounds,
		name
	});
}
function unhighlight() {
	const el = getContainerElement();
	if (el) el.style.display = "none";
}
var inspectInstance = null;
function inspectFn(e) {
	const target = e.target;
	if (target) {
		const instance = target.__vueParentComponent;
		if (instance) {
			inspectInstance = instance;
			if (instance.vnode.el) {
				const bounds = getComponentBoundingRect(instance);
				const name = getInstanceName(instance);
				getContainerElement() ? update({
					bounds,
					name
				}) : create({
					bounds,
					name
				});
			}
		}
	}
}
function selectComponentFn(e, cb) {
	e.preventDefault();
	e.stopPropagation();
	if (inspectInstance) cb(getUniqueComponentId(inspectInstance));
}
var inspectComponentHighLighterSelectFn = null;
function cancelInspectComponentHighLighter() {
	unhighlight();
	window.removeEventListener("mouseover", inspectFn);
	window.removeEventListener("click", inspectComponentHighLighterSelectFn, true);
	inspectComponentHighLighterSelectFn = null;
}
function inspectComponentHighLighter() {
	window.addEventListener("mouseover", inspectFn);
	return new Promise((resolve) => {
		function onSelect(e) {
			e.preventDefault();
			e.stopPropagation();
			selectComponentFn(e, (id) => {
				window.removeEventListener("click", onSelect, true);
				inspectComponentHighLighterSelectFn = null;
				window.removeEventListener("mouseover", inspectFn);
				const el = getContainerElement();
				if (el) el.style.display = "none";
				resolve(JSON.stringify({ id }));
			});
		}
		inspectComponentHighLighterSelectFn = onSelect;
		window.addEventListener("click", onSelect, true);
	});
}
function scrollToComponent(options) {
	const instance = getComponentInstance(activeAppRecord.value, options.id);
	if (instance) {
		const [el] = getRootElementsFromComponentInstance(instance);
		if (typeof el.scrollIntoView === "function") el.scrollIntoView({ behavior: "smooth" });
		else {
			const bounds = getComponentBoundingRect(instance);
			const scrollTarget = document.createElement("div");
			const styles = {
				...getStyles(bounds),
				position: "absolute"
			};
			Object.assign(scrollTarget.style, styles);
			document.body.appendChild(scrollTarget);
			scrollTarget.scrollIntoView({ behavior: "smooth" });
			setTimeout(() => {
				document.body.removeChild(scrollTarget);
			}, 2e3);
		}
		setTimeout(() => {
			const bounds = getComponentBoundingRect(instance);
			if (bounds.width || bounds.height) {
				const name = getInstanceName(instance);
				const el = getContainerElement();
				el ? update({
					...options,
					name,
					bounds
				}) : create({
					...options,
					name,
					bounds
				});
				setTimeout(() => {
					if (el) el.style.display = "none";
				}, 1500);
			}
		}, 1200);
	}
}
target.__VUE_DEVTOOLS_COMPONENT_INSPECTOR_ENABLED__ ??= true;
function waitForInspectorInit(cb) {
	let total = 0;
	const timer = setInterval(() => {
		if (target.__VUE_INSPECTOR__) {
			clearInterval(timer);
			total += 30;
			cb();
		}
		if (total >= 5e3) clearInterval(timer);
	}, 30);
}
function setupInspector() {
	const inspector = target.__VUE_INSPECTOR__;
	const _openInEditor = inspector.openInEditor;
	inspector.openInEditor = async (...params) => {
		inspector.disable();
		_openInEditor(...params);
	};
}
function getComponentInspector() {
	return new Promise((resolve) => {
		function setup() {
			setupInspector();
			resolve(target.__VUE_INSPECTOR__);
		}
		if (!target.__VUE_INSPECTOR__) waitForInspectorInit(() => {
			setup();
		});
		else setup();
	});
}
/**
* To prevent include a **HUGE** vue package in the final bundle of chrome ext / electron
* we stub the necessary vue module.
* This implementation is based on the 1c3327a0fa5983aa9078e3f7bb2330f572435425 commit
*/
/**
* @from [@vue/reactivity](https://github.com/vuejs/core/blob/1c3327a0fa5983aa9078e3f7bb2330f572435425/packages/reactivity/src/constants.ts#L17-L23)
*/
var ReactiveFlags = /* @__PURE__ */ function(ReactiveFlags) {
	ReactiveFlags["SKIP"] = "__v_skip";
	ReactiveFlags["IS_REACTIVE"] = "__v_isReactive";
	ReactiveFlags["IS_READONLY"] = "__v_isReadonly";
	ReactiveFlags["IS_SHALLOW"] = "__v_isShallow";
	ReactiveFlags["RAW"] = "__v_raw";
	return ReactiveFlags;
}({});
/**
* @from [@vue/reactivity](https://github.com/vuejs/core/blob/1c3327a0fa5983aa9078e3f7bb2330f572435425/packages/reactivity/src/reactive.ts#L330-L332)
*/
function isReadonly(value) {
	return !!(value && value[ReactiveFlags.IS_READONLY]);
}
/**
* @from [@vue/reactivity](https://github.com/vuejs/core/blob/1c3327a0fa5983aa9078e3f7bb2330f572435425/packages/reactivity/src/reactive.ts#L312-L317)
*/
function isReactive$1(value) {
	if (isReadonly(value)) return isReactive$1(value[ReactiveFlags.RAW]);
	return !!(value && value[ReactiveFlags.IS_REACTIVE]);
}
function isRef$1(r) {
	return !!(r && r.__v_isRef === true);
}
/**
* @from [@vue/reactivity](https://github.com/vuejs/core/blob/1c3327a0fa5983aa9078e3f7bb2330f572435425/packages/reactivity/src/reactive.ts#L372-L375)
*/
function toRaw$1(observed) {
	const raw = observed && observed[ReactiveFlags.RAW];
	return raw ? toRaw$1(raw) : observed;
}
var StateEditor = class {
	constructor() {
		this.refEditor = new RefStateEditor();
	}
	set(object, path, value, cb) {
		const sections = Array.isArray(path) ? path : path.split(".");
		while (sections.length > 1) {
			const section = sections.shift();
			if (object instanceof Map) object = object.get(section);
			else if (object instanceof Set) object = Array.from(object.values())[section];
			else object = object[section];
			if (this.refEditor.isRef(object)) object = this.refEditor.get(object);
		}
		const field = sections[0];
		const item = this.refEditor.get(object)[field];
		if (cb) cb(object, field, value);
		else if (this.refEditor.isRef(item)) this.refEditor.set(item, value);
		else object[field] = value;
	}
	get(object, path) {
		const sections = Array.isArray(path) ? path : path.split(".");
		for (let i = 0; i < sections.length; i++) {
			if (object instanceof Map) object = object.get(sections[i]);
			else object = object[sections[i]];
			if (this.refEditor.isRef(object)) object = this.refEditor.get(object);
			if (!object) return void 0;
		}
		return object;
	}
	has(object, path, parent = false) {
		if (typeof object === "undefined") return false;
		const sections = Array.isArray(path) ? path.slice() : path.split(".");
		const size = !parent ? 1 : 2;
		while (object && sections.length > size) {
			const section = sections.shift();
			object = object[section];
			if (this.refEditor.isRef(object)) object = this.refEditor.get(object);
		}
		return object != null && Object.prototype.hasOwnProperty.call(object, sections[0]);
	}
	createDefaultSetCallback(state) {
		return (object, field, value) => {
			if (state.remove || state.newKey) if (Array.isArray(object)) object.splice(field, 1);
			else if (toRaw$1(object) instanceof Map) object.delete(field);
			else if (toRaw$1(object) instanceof Set) object.delete(Array.from(object.values())[field]);
			else Reflect.deleteProperty(object, field);
			if (!state.remove) {
				const target = object[state.newKey || field];
				if (this.refEditor.isRef(target)) this.refEditor.set(target, value);
				else if (toRaw$1(object) instanceof Map) object.set(state.newKey || field, value);
				else if (toRaw$1(object) instanceof Set) object.add(value);
				else object[state.newKey || field] = value;
			}
		};
	}
};
var RefStateEditor = class {
	set(ref, value) {
		if (isRef$1(ref)) ref.value = value;
		else {
			if (ref instanceof Set && Array.isArray(value)) {
				ref.clear();
				value.forEach((v) => ref.add(v));
				return;
			}
			const currentKeys = Object.keys(value);
			if (ref instanceof Map) {
				const previousKeysSet = new Set(ref.keys());
				currentKeys.forEach((key) => {
					ref.set(key, Reflect.get(value, key));
					previousKeysSet.delete(key);
				});
				previousKeysSet.forEach((key) => ref.delete(key));
				return;
			}
			const previousKeysSet = new Set(Object.keys(ref));
			currentKeys.forEach((key) => {
				Reflect.set(ref, key, Reflect.get(value, key));
				previousKeysSet.delete(key);
			});
			previousKeysSet.forEach((key) => Reflect.deleteProperty(ref, key));
		}
	}
	get(ref) {
		return isRef$1(ref) ? ref.value : ref;
	}
	isRef(ref) {
		return isRef$1(ref) || isReactive$1(ref);
	}
};
new StateEditor();
var TIMELINE_LAYERS_STATE_STORAGE_ID = "__VUE_DEVTOOLS_KIT_TIMELINE_LAYERS_STATE__";
function getTimelineLayersStateFromStorage() {
	if (typeof window === "undefined" || !isBrowser$1 || typeof localStorage === "undefined" || localStorage === null) return {
		recordingState: false,
		mouseEventEnabled: false,
		keyboardEventEnabled: false,
		componentEventEnabled: false,
		performanceEventEnabled: false,
		selected: ""
	};
	const state = typeof localStorage.getItem !== "undefined" ? localStorage.getItem(TIMELINE_LAYERS_STATE_STORAGE_ID) : null;
	return state ? JSON.parse(state) : {
		recordingState: false,
		mouseEventEnabled: false,
		keyboardEventEnabled: false,
		componentEventEnabled: false,
		performanceEventEnabled: false,
		selected: ""
	};
}
target.__VUE_DEVTOOLS_KIT_TIMELINE_LAYERS ??= [];
var devtoolsTimelineLayers = new Proxy(target.__VUE_DEVTOOLS_KIT_TIMELINE_LAYERS, { get(target, prop, receiver) {
	return Reflect.get(target, prop, receiver);
} });
function addTimelineLayer(options, descriptor) {
	devtoolsState.timelineLayersState[descriptor.id] = false;
	devtoolsTimelineLayers.push({
		...options,
		descriptorId: descriptor.id,
		appRecord: getAppRecord(descriptor.app)
	});
}
target.__VUE_DEVTOOLS_KIT_INSPECTOR__ ??= [];
var devtoolsInspector = new Proxy(target.__VUE_DEVTOOLS_KIT_INSPECTOR__, { get(target, prop, receiver) {
	return Reflect.get(target, prop, receiver);
} });
var callInspectorUpdatedHook = debounce(() => {
	devtoolsContext.hooks.callHook(DevToolsMessagingHookKeys.SEND_INSPECTOR_TO_CLIENT, getActiveInspectors());
});
function addInspector(inspector, descriptor) {
	devtoolsInspector.push({
		options: inspector,
		descriptor,
		treeFilterPlaceholder: inspector.treeFilterPlaceholder ?? "Search tree...",
		stateFilterPlaceholder: inspector.stateFilterPlaceholder ?? "Search state...",
		treeFilter: "",
		selectedNodeId: "",
		appRecord: getAppRecord(descriptor.app)
	});
	callInspectorUpdatedHook();
}
function getActiveInspectors() {
	return devtoolsInspector.filter((inspector) => inspector.descriptor.app === activeAppRecord.value.app).filter((inspector) => inspector.descriptor.id !== "components").map((inspector) => {
		const descriptor = inspector.descriptor;
		const options = inspector.options;
		return {
			id: options.id,
			label: options.label,
			logo: descriptor.logo,
			icon: `custom-ic-baseline-${options?.icon?.replace(/_/g, "-")}`,
			packageName: descriptor.packageName,
			homepage: descriptor.homepage,
			pluginId: descriptor.id
		};
	});
}
function getInspector(id, app) {
	return devtoolsInspector.find((inspector) => inspector.options.id === id && (app ? inspector.descriptor.app === app : true));
}
var DevToolsV6PluginAPIHookKeys = /* @__PURE__ */ function(DevToolsV6PluginAPIHookKeys) {
	DevToolsV6PluginAPIHookKeys["VISIT_COMPONENT_TREE"] = "visitComponentTree";
	DevToolsV6PluginAPIHookKeys["INSPECT_COMPONENT"] = "inspectComponent";
	DevToolsV6PluginAPIHookKeys["EDIT_COMPONENT_STATE"] = "editComponentState";
	DevToolsV6PluginAPIHookKeys["GET_INSPECTOR_TREE"] = "getInspectorTree";
	DevToolsV6PluginAPIHookKeys["GET_INSPECTOR_STATE"] = "getInspectorState";
	DevToolsV6PluginAPIHookKeys["EDIT_INSPECTOR_STATE"] = "editInspectorState";
	DevToolsV6PluginAPIHookKeys["INSPECT_TIMELINE_EVENT"] = "inspectTimelineEvent";
	DevToolsV6PluginAPIHookKeys["TIMELINE_CLEARED"] = "timelineCleared";
	DevToolsV6PluginAPIHookKeys["SET_PLUGIN_SETTINGS"] = "setPluginSettings";
	return DevToolsV6PluginAPIHookKeys;
}({});
var DevToolsContextHookKeys = /* @__PURE__ */ function(DevToolsContextHookKeys) {
	DevToolsContextHookKeys["ADD_INSPECTOR"] = "addInspector";
	DevToolsContextHookKeys["SEND_INSPECTOR_TREE"] = "sendInspectorTree";
	DevToolsContextHookKeys["SEND_INSPECTOR_STATE"] = "sendInspectorState";
	DevToolsContextHookKeys["CUSTOM_INSPECTOR_SELECT_NODE"] = "customInspectorSelectNode";
	DevToolsContextHookKeys["TIMELINE_LAYER_ADDED"] = "timelineLayerAdded";
	DevToolsContextHookKeys["TIMELINE_EVENT_ADDED"] = "timelineEventAdded";
	DevToolsContextHookKeys["GET_COMPONENT_INSTANCES"] = "getComponentInstances";
	DevToolsContextHookKeys["GET_COMPONENT_BOUNDS"] = "getComponentBounds";
	DevToolsContextHookKeys["GET_COMPONENT_NAME"] = "getComponentName";
	DevToolsContextHookKeys["COMPONENT_HIGHLIGHT"] = "componentHighlight";
	DevToolsContextHookKeys["COMPONENT_UNHIGHLIGHT"] = "componentUnhighlight";
	return DevToolsContextHookKeys;
}({});
var DevToolsMessagingHookKeys = /* @__PURE__ */ function(DevToolsMessagingHookKeys) {
	DevToolsMessagingHookKeys["SEND_INSPECTOR_TREE_TO_CLIENT"] = "sendInspectorTreeToClient";
	DevToolsMessagingHookKeys["SEND_INSPECTOR_STATE_TO_CLIENT"] = "sendInspectorStateToClient";
	DevToolsMessagingHookKeys["SEND_TIMELINE_EVENT_TO_CLIENT"] = "sendTimelineEventToClient";
	DevToolsMessagingHookKeys["SEND_INSPECTOR_TO_CLIENT"] = "sendInspectorToClient";
	DevToolsMessagingHookKeys["SEND_ACTIVE_APP_UNMOUNTED_TO_CLIENT"] = "sendActiveAppUpdatedToClient";
	DevToolsMessagingHookKeys["DEVTOOLS_STATE_UPDATED"] = "devtoolsStateUpdated";
	DevToolsMessagingHookKeys["DEVTOOLS_CONNECTED_UPDATED"] = "devtoolsConnectedUpdated";
	DevToolsMessagingHookKeys["ROUTER_INFO_UPDATED"] = "routerInfoUpdated";
	return DevToolsMessagingHookKeys;
}({});
function createDevToolsCtxHooks() {
	const hooks = createHooks();
	hooks.hook(DevToolsContextHookKeys.ADD_INSPECTOR, ({ inspector, plugin }) => {
		addInspector(inspector, plugin.descriptor);
	});
	const debounceSendInspectorTree = debounce(async ({ inspectorId, plugin }) => {
		if (!inspectorId || !plugin?.descriptor?.app || devtoolsState.highPerfModeEnabled) return;
		const inspector = getInspector(inspectorId, plugin.descriptor.app);
		const _payload = {
			app: plugin.descriptor.app,
			inspectorId,
			filter: inspector?.treeFilter || "",
			rootNodes: []
		};
		await new Promise((resolve) => {
			hooks.callHookWith(async (callbacks) => {
				await Promise.all(callbacks.map((cb) => cb(_payload)));
				resolve();
			}, DevToolsV6PluginAPIHookKeys.GET_INSPECTOR_TREE);
		});
		hooks.callHookWith(async (callbacks) => {
			await Promise.all(callbacks.map((cb) => cb({
				inspectorId,
				rootNodes: _payload.rootNodes
			})));
		}, DevToolsMessagingHookKeys.SEND_INSPECTOR_TREE_TO_CLIENT);
	}, 120);
	hooks.hook(DevToolsContextHookKeys.SEND_INSPECTOR_TREE, debounceSendInspectorTree);
	const debounceSendInspectorState = debounce(async ({ inspectorId, plugin }) => {
		if (!inspectorId || !plugin?.descriptor?.app || devtoolsState.highPerfModeEnabled) return;
		const inspector = getInspector(inspectorId, plugin.descriptor.app);
		const _payload = {
			app: plugin.descriptor.app,
			inspectorId,
			nodeId: inspector?.selectedNodeId || "",
			state: null
		};
		const ctx = { currentTab: `custom-inspector:${inspectorId}` };
		if (_payload.nodeId) await new Promise((resolve) => {
			hooks.callHookWith(async (callbacks) => {
				await Promise.all(callbacks.map((cb) => cb(_payload, ctx)));
				resolve();
			}, DevToolsV6PluginAPIHookKeys.GET_INSPECTOR_STATE);
		});
		hooks.callHookWith(async (callbacks) => {
			await Promise.all(callbacks.map((cb) => cb({
				inspectorId,
				nodeId: _payload.nodeId,
				state: _payload.state
			})));
		}, DevToolsMessagingHookKeys.SEND_INSPECTOR_STATE_TO_CLIENT);
	}, 120);
	hooks.hook(DevToolsContextHookKeys.SEND_INSPECTOR_STATE, debounceSendInspectorState);
	hooks.hook(DevToolsContextHookKeys.CUSTOM_INSPECTOR_SELECT_NODE, ({ inspectorId, nodeId, plugin }) => {
		const inspector = getInspector(inspectorId, plugin.descriptor.app);
		if (!inspector) return;
		inspector.selectedNodeId = nodeId;
	});
	hooks.hook(DevToolsContextHookKeys.TIMELINE_LAYER_ADDED, ({ options, plugin }) => {
		addTimelineLayer(options, plugin.descriptor);
	});
	hooks.hook(DevToolsContextHookKeys.TIMELINE_EVENT_ADDED, ({ options, plugin }) => {
		if (devtoolsState.highPerfModeEnabled || !devtoolsState.timelineLayersState?.[plugin.descriptor.id] && ![
			"performance",
			"component-event",
			"keyboard",
			"mouse"
		].includes(options.layerId)) return;
		hooks.callHookWith(async (callbacks) => {
			await Promise.all(callbacks.map((cb) => cb(options)));
		}, DevToolsMessagingHookKeys.SEND_TIMELINE_EVENT_TO_CLIENT);
	});
	hooks.hook(DevToolsContextHookKeys.GET_COMPONENT_INSTANCES, async ({ app }) => {
		const appRecord = app.__VUE_DEVTOOLS_NEXT_APP_RECORD__;
		if (!appRecord) return null;
		const appId = appRecord.id.toString();
		return [...appRecord.instanceMap].filter(([key]) => key.split(":")[0] === appId).map(([, instance]) => instance);
	});
	hooks.hook(DevToolsContextHookKeys.GET_COMPONENT_BOUNDS, async ({ instance }) => {
		return getComponentBoundingRect(instance);
	});
	hooks.hook(DevToolsContextHookKeys.GET_COMPONENT_NAME, ({ instance }) => {
		return getInstanceName(instance);
	});
	hooks.hook(DevToolsContextHookKeys.COMPONENT_HIGHLIGHT, ({ uid }) => {
		const instance = activeAppRecord.value.instanceMap.get(uid);
		if (instance) highlight(instance);
	});
	hooks.hook(DevToolsContextHookKeys.COMPONENT_UNHIGHLIGHT, () => {
		unhighlight();
	});
	return hooks;
}
target.__VUE_DEVTOOLS_KIT_APP_RECORDS__ ??= [];
target.__VUE_DEVTOOLS_KIT_ACTIVE_APP_RECORD__ ??= {};
target.__VUE_DEVTOOLS_KIT_ACTIVE_APP_RECORD_ID__ ??= "";
target.__VUE_DEVTOOLS_KIT_CUSTOM_TABS__ ??= [];
target.__VUE_DEVTOOLS_KIT_CUSTOM_COMMANDS__ ??= [];
var STATE_KEY = "__VUE_DEVTOOLS_KIT_GLOBAL_STATE__";
function initStateFactory() {
	return {
		connected: false,
		clientConnected: false,
		vitePluginDetected: true,
		appRecords: [],
		activeAppRecordId: "",
		tabs: [],
		commands: [],
		highPerfModeEnabled: true,
		devtoolsClientDetected: {},
		perfUniqueGroupId: 0,
		timelineLayersState: getTimelineLayersStateFromStorage()
	};
}
target[STATE_KEY] ??= initStateFactory();
var callStateUpdatedHook = debounce((state) => {
	devtoolsContext.hooks.callHook(DevToolsMessagingHookKeys.DEVTOOLS_STATE_UPDATED, { state });
});
debounce((state, oldState) => {
	devtoolsContext.hooks.callHook(DevToolsMessagingHookKeys.DEVTOOLS_CONNECTED_UPDATED, {
		state,
		oldState
	});
});
var devtoolsAppRecords = new Proxy(target.__VUE_DEVTOOLS_KIT_APP_RECORDS__, { get(_target, prop, receiver) {
	if (prop === "value") return target.__VUE_DEVTOOLS_KIT_APP_RECORDS__;
	return target.__VUE_DEVTOOLS_KIT_APP_RECORDS__[prop];
} });
var activeAppRecord = new Proxy(target.__VUE_DEVTOOLS_KIT_ACTIVE_APP_RECORD__, { get(_target, prop, receiver) {
	if (prop === "value") return target.__VUE_DEVTOOLS_KIT_ACTIVE_APP_RECORD__;
	else if (prop === "id") return target.__VUE_DEVTOOLS_KIT_ACTIVE_APP_RECORD_ID__;
	return target.__VUE_DEVTOOLS_KIT_ACTIVE_APP_RECORD__[prop];
} });
function updateAllStates() {
	callStateUpdatedHook({
		...target[STATE_KEY],
		appRecords: devtoolsAppRecords.value,
		activeAppRecordId: activeAppRecord.id,
		tabs: target.__VUE_DEVTOOLS_KIT_CUSTOM_TABS__,
		commands: target.__VUE_DEVTOOLS_KIT_CUSTOM_COMMANDS__
	});
}
function setActiveAppRecord(app) {
	target.__VUE_DEVTOOLS_KIT_ACTIVE_APP_RECORD__ = app;
	updateAllStates();
}
function setActiveAppRecordId(id) {
	target.__VUE_DEVTOOLS_KIT_ACTIVE_APP_RECORD_ID__ = id;
	updateAllStates();
}
var devtoolsState = new Proxy(target[STATE_KEY], {
	get(target$3, property) {
		if (property === "appRecords") return devtoolsAppRecords;
		else if (property === "activeAppRecordId") return activeAppRecord.id;
		else if (property === "tabs") return target.__VUE_DEVTOOLS_KIT_CUSTOM_TABS__;
		else if (property === "commands") return target.__VUE_DEVTOOLS_KIT_CUSTOM_COMMANDS__;
		return target[STATE_KEY][property];
	},
	deleteProperty(target, property) {
		delete target[property];
		return true;
	},
	set(target$4, property, value) {
		target$4[property] = value;
		target[STATE_KEY][property] = value;
		return true;
	}
});
function openInEditor(options = {}) {
	const { file, host, baseUrl = window.location.origin, line = 0, column = 0 } = options;
	if (file) {
		if (host === "chrome-extension") {
			const fileName = file.replace(/\\/g, "\\\\");
			const _baseUrl = window.VUE_DEVTOOLS_CONFIG?.openInEditorHost ?? "/";
			fetch(`${_baseUrl}__open-in-editor?file=${encodeURI(file)}`).then((response) => {
				if (!response.ok) {
					const msg = `Opening component ${fileName} failed`;
					console.log(`%c${msg}`, "color:red");
				}
			});
		} else if (devtoolsState.vitePluginDetected) {
			const _baseUrl = target.__VUE_DEVTOOLS_OPEN_IN_EDITOR_BASE_URL__ ?? baseUrl;
			target.__VUE_INSPECTOR__.openInEditor(_baseUrl, file, line, column);
		}
	}
}
target.__VUE_DEVTOOLS_KIT_PLUGIN_BUFFER__ ??= [];
var devtoolsPluginBuffer = new Proxy(target.__VUE_DEVTOOLS_KIT_PLUGIN_BUFFER__, { get(target, prop, receiver) {
	return Reflect.get(target, prop, receiver);
} });
function _getSettings(settings) {
	const _settings = {};
	Object.keys(settings).forEach((key) => {
		_settings[key] = settings[key].defaultValue;
	});
	return _settings;
}
function getPluginLocalKey(pluginId) {
	return `__VUE_DEVTOOLS_NEXT_PLUGIN_SETTINGS__${pluginId}__`;
}
function getPluginSettingsOptions(pluginId) {
	return (devtoolsPluginBuffer.find((item) => item[0].id === pluginId && !!item[0]?.settings)?.[0] ?? null)?.settings ?? null;
}
function getPluginSettings(pluginId, fallbackValue) {
	const localKey = getPluginLocalKey(pluginId);
	if (localKey) {
		const localSettings = localStorage.getItem(localKey);
		if (localSettings) return JSON.parse(localSettings);
	}
	if (pluginId) return _getSettings((devtoolsPluginBuffer.find((item) => item[0].id === pluginId)?.[0] ?? null)?.settings ?? {});
	return _getSettings(fallbackValue);
}
function initPluginSettings(pluginId, settings) {
	const localKey = getPluginLocalKey(pluginId);
	if (!localStorage.getItem(localKey)) localStorage.setItem(localKey, JSON.stringify(_getSettings(settings)));
}
function setPluginSettings(pluginId, key, value) {
	const localKey = getPluginLocalKey(pluginId);
	const localSettings = localStorage.getItem(localKey);
	const parsedLocalSettings = JSON.parse(localSettings || "{}");
	const updated = {
		...parsedLocalSettings,
		[key]: value
	};
	localStorage.setItem(localKey, JSON.stringify(updated));
	devtoolsContext.hooks.callHookWith((callbacks) => {
		callbacks.forEach((cb) => cb({
			pluginId,
			key,
			oldValue: parsedLocalSettings[key],
			newValue: value,
			settings: updated
		}));
	}, DevToolsV6PluginAPIHookKeys.SET_PLUGIN_SETTINGS);
}
var DevToolsHooks = /* @__PURE__ */ function(DevToolsHooks) {
	DevToolsHooks["APP_INIT"] = "app:init";
	DevToolsHooks["APP_UNMOUNT"] = "app:unmount";
	DevToolsHooks["COMPONENT_UPDATED"] = "component:updated";
	DevToolsHooks["COMPONENT_ADDED"] = "component:added";
	DevToolsHooks["COMPONENT_REMOVED"] = "component:removed";
	DevToolsHooks["COMPONENT_EMIT"] = "component:emit";
	DevToolsHooks["PERFORMANCE_START"] = "perf:start";
	DevToolsHooks["PERFORMANCE_END"] = "perf:end";
	DevToolsHooks["ADD_ROUTE"] = "router:add-route";
	DevToolsHooks["REMOVE_ROUTE"] = "router:remove-route";
	DevToolsHooks["RENDER_TRACKED"] = "render:tracked";
	DevToolsHooks["RENDER_TRIGGERED"] = "render:triggered";
	DevToolsHooks["APP_CONNECTED"] = "app:connected";
	DevToolsHooks["SETUP_DEVTOOLS_PLUGIN"] = "devtools-plugin:setup";
	return DevToolsHooks;
}({});
var devtoolsHooks = target.__VUE_DEVTOOLS_HOOK ??= createHooks();
var hook = {
	on: {
		vueAppInit(fn) {
			devtoolsHooks.hook(DevToolsHooks.APP_INIT, fn);
		},
		vueAppUnmount(fn) {
			devtoolsHooks.hook(DevToolsHooks.APP_UNMOUNT, fn);
		},
		vueAppConnected(fn) {
			devtoolsHooks.hook(DevToolsHooks.APP_CONNECTED, fn);
		},
		componentAdded(fn) {
			return devtoolsHooks.hook(DevToolsHooks.COMPONENT_ADDED, fn);
		},
		componentEmit(fn) {
			return devtoolsHooks.hook(DevToolsHooks.COMPONENT_EMIT, fn);
		},
		componentUpdated(fn) {
			return devtoolsHooks.hook(DevToolsHooks.COMPONENT_UPDATED, fn);
		},
		componentRemoved(fn) {
			return devtoolsHooks.hook(DevToolsHooks.COMPONENT_REMOVED, fn);
		},
		setupDevtoolsPlugin(fn) {
			devtoolsHooks.hook(DevToolsHooks.SETUP_DEVTOOLS_PLUGIN, fn);
		},
		perfStart(fn) {
			return devtoolsHooks.hook(DevToolsHooks.PERFORMANCE_START, fn);
		},
		perfEnd(fn) {
			return devtoolsHooks.hook(DevToolsHooks.PERFORMANCE_END, fn);
		}
	},
	setupDevToolsPlugin(pluginDescriptor, setupFn) {
		return devtoolsHooks.callHook(DevToolsHooks.SETUP_DEVTOOLS_PLUGIN, pluginDescriptor, setupFn);
	}
};
var DevToolsV6PluginAPI = class {
	constructor({ plugin, ctx }) {
		this.hooks = ctx.hooks;
		this.plugin = plugin;
	}
	get on() {
		return {
			visitComponentTree: (handler) => {
				this.hooks.hook(DevToolsV6PluginAPIHookKeys.VISIT_COMPONENT_TREE, handler);
			},
			inspectComponent: (handler) => {
				this.hooks.hook(DevToolsV6PluginAPIHookKeys.INSPECT_COMPONENT, handler);
			},
			editComponentState: (handler) => {
				this.hooks.hook(DevToolsV6PluginAPIHookKeys.EDIT_COMPONENT_STATE, handler);
			},
			getInspectorTree: (handler) => {
				this.hooks.hook(DevToolsV6PluginAPIHookKeys.GET_INSPECTOR_TREE, handler);
			},
			getInspectorState: (handler) => {
				this.hooks.hook(DevToolsV6PluginAPIHookKeys.GET_INSPECTOR_STATE, handler);
			},
			editInspectorState: (handler) => {
				this.hooks.hook(DevToolsV6PluginAPIHookKeys.EDIT_INSPECTOR_STATE, handler);
			},
			inspectTimelineEvent: (handler) => {
				this.hooks.hook(DevToolsV6PluginAPIHookKeys.INSPECT_TIMELINE_EVENT, handler);
			},
			timelineCleared: (handler) => {
				this.hooks.hook(DevToolsV6PluginAPIHookKeys.TIMELINE_CLEARED, handler);
			},
			setPluginSettings: (handler) => {
				this.hooks.hook(DevToolsV6PluginAPIHookKeys.SET_PLUGIN_SETTINGS, handler);
			}
		};
	}
	notifyComponentUpdate(instance) {
		if (devtoolsState.highPerfModeEnabled) return;
		const inspector = getActiveInspectors().find((i) => i.packageName === this.plugin.descriptor.packageName);
		if (inspector?.id) {
			if (instance) {
				const args = [
					instance.appContext.app,
					instance.uid,
					instance.parent?.uid,
					instance
				];
				devtoolsHooks.callHook(DevToolsHooks.COMPONENT_UPDATED, ...args);
			} else devtoolsHooks.callHook(DevToolsHooks.COMPONENT_UPDATED);
			this.hooks.callHook(DevToolsContextHookKeys.SEND_INSPECTOR_STATE, {
				inspectorId: inspector.id,
				plugin: this.plugin
			});
		}
	}
	addInspector(options) {
		this.hooks.callHook(DevToolsContextHookKeys.ADD_INSPECTOR, {
			inspector: options,
			plugin: this.plugin
		});
		if (this.plugin.descriptor.settings) initPluginSettings(options.id, this.plugin.descriptor.settings);
	}
	sendInspectorTree(inspectorId) {
		if (devtoolsState.highPerfModeEnabled) return;
		this.hooks.callHook(DevToolsContextHookKeys.SEND_INSPECTOR_TREE, {
			inspectorId,
			plugin: this.plugin
		});
	}
	sendInspectorState(inspectorId) {
		if (devtoolsState.highPerfModeEnabled) return;
		this.hooks.callHook(DevToolsContextHookKeys.SEND_INSPECTOR_STATE, {
			inspectorId,
			plugin: this.plugin
		});
	}
	selectInspectorNode(inspectorId, nodeId) {
		this.hooks.callHook(DevToolsContextHookKeys.CUSTOM_INSPECTOR_SELECT_NODE, {
			inspectorId,
			nodeId,
			plugin: this.plugin
		});
	}
	visitComponentTree(payload) {
		return this.hooks.callHook(DevToolsV6PluginAPIHookKeys.VISIT_COMPONENT_TREE, payload);
	}
	now() {
		if (devtoolsState.highPerfModeEnabled) return 0;
		return Date.now();
	}
	addTimelineLayer(options) {
		this.hooks.callHook(DevToolsContextHookKeys.TIMELINE_LAYER_ADDED, {
			options,
			plugin: this.plugin
		});
	}
	addTimelineEvent(options) {
		if (devtoolsState.highPerfModeEnabled) return;
		this.hooks.callHook(DevToolsContextHookKeys.TIMELINE_EVENT_ADDED, {
			options,
			plugin: this.plugin
		});
	}
	getSettings(pluginId) {
		return getPluginSettings(pluginId ?? this.plugin.descriptor.id, this.plugin.descriptor.settings);
	}
	getComponentInstances(app) {
		return this.hooks.callHook(DevToolsContextHookKeys.GET_COMPONENT_INSTANCES, { app });
	}
	getComponentBounds(instance) {
		return this.hooks.callHook(DevToolsContextHookKeys.GET_COMPONENT_BOUNDS, { instance });
	}
	getComponentName(instance) {
		return this.hooks.callHook(DevToolsContextHookKeys.GET_COMPONENT_NAME, { instance });
	}
	highlightElement(instance) {
		const uid = instance.__VUE_DEVTOOLS_NEXT_UID__;
		return this.hooks.callHook(DevToolsContextHookKeys.COMPONENT_HIGHLIGHT, { uid });
	}
	unhighlightElement() {
		return this.hooks.callHook(DevToolsContextHookKeys.COMPONENT_UNHIGHLIGHT);
	}
};
var DevToolsPluginAPI = DevToolsV6PluginAPI;
var UNDEFINED = "__vue_devtool_undefined__";
var INFINITY = "__vue_devtool_infinity__";
var NEGATIVE_INFINITY = "__vue_devtool_negative_infinity__";
var NAN = "__vue_devtool_nan__";
Object.entries({
	[UNDEFINED]: "undefined",
	[NAN]: "NaN",
	[INFINITY]: "Infinity",
	[NEGATIVE_INFINITY]: "-Infinity"
}).reduce((acc, [key, value]) => {
	acc[value] = key;
	return acc;
}, {});
target.__VUE_DEVTOOLS_KIT__REGISTERED_PLUGIN_APPS__ ??= /* @__PURE__ */ new Set();
function setupDevToolsPlugin(pluginDescriptor, setupFn) {
	return hook.setupDevToolsPlugin(pluginDescriptor, setupFn);
}
function callDevToolsPluginSetupFn(plugin, app) {
	const [pluginDescriptor, setupFn] = plugin;
	if (pluginDescriptor.app !== app) return;
	const api = new DevToolsPluginAPI({
		plugin: {
			setupFn,
			descriptor: pluginDescriptor
		},
		ctx: devtoolsContext
	});
	if (pluginDescriptor.packageName === "vuex") api.on.editInspectorState((payload) => {
		api.sendInspectorState(payload.inspectorId);
	});
	setupFn(api);
}
function registerDevToolsPlugin(app, options) {
	if (target.__VUE_DEVTOOLS_KIT__REGISTERED_PLUGIN_APPS__.has(app)) return;
	if (devtoolsState.highPerfModeEnabled && !options?.inspectingComponent) return;
	target.__VUE_DEVTOOLS_KIT__REGISTERED_PLUGIN_APPS__.add(app);
	devtoolsPluginBuffer.forEach((plugin) => {
		callDevToolsPluginSetupFn(plugin, app);
	});
}
var ROUTER_KEY = "__VUE_DEVTOOLS_ROUTER__";
var ROUTER_INFO_KEY = "__VUE_DEVTOOLS_ROUTER_INFO__";
target[ROUTER_INFO_KEY] ??= {
	currentRoute: null,
	routes: []
};
target[ROUTER_KEY] ??= {};
new Proxy(target[ROUTER_INFO_KEY], { get(target$1, property) {
	return target[ROUTER_INFO_KEY][property];
} });
new Proxy(target[ROUTER_KEY], { get(target$2, property) {
	if (property === "value") return target[ROUTER_KEY];
} });
function getRoutes(router) {
	const routesMap = /* @__PURE__ */ new Map();
	return (router?.getRoutes() || []).filter((i) => !routesMap.has(i.path) && routesMap.set(i.path, 1));
}
function filterRoutes(routes) {
	return routes.map((item) => {
		let { path, name, children, meta } = item;
		if (children?.length) children = filterRoutes(children);
		return {
			path,
			name,
			children,
			meta
		};
	});
}
function filterCurrentRoute(route) {
	if (route) {
		const { fullPath, hash, href, path, name, matched, params, query } = route;
		return {
			fullPath,
			hash,
			href,
			path,
			name,
			params,
			query,
			matched: filterRoutes(matched)
		};
	}
	return route;
}
function normalizeRouterInfo(appRecord, activeAppRecord) {
	function init() {
		const router = appRecord.app?.config.globalProperties.$router;
		const currentRoute = filterCurrentRoute(router?.currentRoute.value);
		const routes = filterRoutes(getRoutes(router));
		const c = console.warn;
		console.warn = () => {};
		target[ROUTER_INFO_KEY] = {
			currentRoute: currentRoute ? deepClone(currentRoute) : {},
			routes: deepClone(routes)
		};
		target[ROUTER_KEY] = router;
		console.warn = c;
	}
	init();
	hook.on.componentUpdated(debounce(() => {
		if (activeAppRecord.value?.app !== appRecord.app) return;
		init();
		if (devtoolsState.highPerfModeEnabled) return;
		devtoolsContext.hooks.callHook(DevToolsMessagingHookKeys.ROUTER_INFO_UPDATED, { state: target[ROUTER_INFO_KEY] });
	}, 200));
}
function createDevToolsApi(hooks) {
	return {
		async getInspectorTree(payload) {
			const _payload = {
				...payload,
				app: activeAppRecord.value.app,
				rootNodes: []
			};
			await new Promise((resolve) => {
				hooks.callHookWith(async (callbacks) => {
					await Promise.all(callbacks.map((cb) => cb(_payload)));
					resolve();
				}, DevToolsV6PluginAPIHookKeys.GET_INSPECTOR_TREE);
			});
			return _payload.rootNodes;
		},
		async getInspectorState(payload) {
			const _payload = {
				...payload,
				app: activeAppRecord.value.app,
				state: null
			};
			const ctx = { currentTab: `custom-inspector:${payload.inspectorId}` };
			await new Promise((resolve) => {
				hooks.callHookWith(async (callbacks) => {
					await Promise.all(callbacks.map((cb) => cb(_payload, ctx)));
					resolve();
				}, DevToolsV6PluginAPIHookKeys.GET_INSPECTOR_STATE);
			});
			return _payload.state;
		},
		editInspectorState(payload) {
			const stateEditor = new StateEditor();
			const _payload = {
				...payload,
				app: activeAppRecord.value.app,
				set: (obj, path = payload.path, value = payload.state.value, cb) => {
					stateEditor.set(obj, path, value, cb || stateEditor.createDefaultSetCallback(payload.state));
				}
			};
			hooks.callHookWith((callbacks) => {
				callbacks.forEach((cb) => cb(_payload));
			}, DevToolsV6PluginAPIHookKeys.EDIT_INSPECTOR_STATE);
		},
		sendInspectorState(inspectorId) {
			const inspector = getInspector(inspectorId);
			hooks.callHook(DevToolsContextHookKeys.SEND_INSPECTOR_STATE, {
				inspectorId,
				plugin: {
					descriptor: inspector.descriptor,
					setupFn: () => ({})
				}
			});
		},
		inspectComponentInspector() {
			return inspectComponentHighLighter();
		},
		cancelInspectComponentInspector() {
			return cancelInspectComponentHighLighter();
		},
		getComponentRenderCode(id) {
			const instance = getComponentInstance(activeAppRecord.value, id);
			if (instance) return !(typeof instance?.type === "function") ? instance.render.toString() : instance.type.toString();
		},
		scrollToComponent(id) {
			return scrollToComponent({ id });
		},
		openInEditor,
		getVueInspector: getComponentInspector,
		toggleApp(id, options) {
			const appRecord = devtoolsAppRecords.value.find((record) => record.id === id);
			if (appRecord) {
				setActiveAppRecordId(id);
				setActiveAppRecord(appRecord);
				normalizeRouterInfo(appRecord, activeAppRecord);
				callInspectorUpdatedHook();
				registerDevToolsPlugin(appRecord.app, options);
			}
		},
		inspectDOM(instanceId) {
			const instance = getComponentInstance(activeAppRecord.value, instanceId);
			if (instance) {
				const [el] = getRootElementsFromComponentInstance(instance);
				if (el) target.__VUE_DEVTOOLS_INSPECT_DOM_TARGET__ = el;
			}
		},
		updatePluginSettings(pluginId, key, value) {
			setPluginSettings(pluginId, key, value);
		},
		getPluginSettings(pluginId) {
			return {
				options: getPluginSettingsOptions(pluginId),
				values: getPluginSettings(pluginId)
			};
		}
	};
}
target.__VUE_DEVTOOLS_ENV__ ??= { vitePluginDetected: false };
var hooks = createDevToolsCtxHooks();
target.__VUE_DEVTOOLS_KIT_CONTEXT__ ??= {
	hooks,
	get state() {
		return {
			...devtoolsState,
			activeAppRecordId: activeAppRecord.id,
			activeAppRecord: activeAppRecord.value,
			appRecords: devtoolsAppRecords.value
		};
	},
	api: createDevToolsApi(hooks)
};
var devtoolsContext = target.__VUE_DEVTOOLS_KIT_CONTEXT__;
var require_speakingurl$1 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	(function(root) {
		"use strict";
		/**
		* charMap
		* @type {Object}
		*/
		var charMap = {
			"À": "A",
			"Á": "A",
			"Â": "A",
			"Ã": "A",
			"Ä": "Ae",
			"Å": "A",
			"Æ": "AE",
			"Ç": "C",
			"È": "E",
			"É": "E",
			"Ê": "E",
			"Ë": "E",
			"Ì": "I",
			"Í": "I",
			"Î": "I",
			"Ï": "I",
			"Ð": "D",
			"Ñ": "N",
			"Ò": "O",
			"Ó": "O",
			"Ô": "O",
			"Õ": "O",
			"Ö": "Oe",
			"Ő": "O",
			"Ø": "O",
			"Ù": "U",
			"Ú": "U",
			"Û": "U",
			"Ü": "Ue",
			"Ű": "U",
			"Ý": "Y",
			"Þ": "TH",
			"ß": "ss",
			"à": "a",
			"á": "a",
			"â": "a",
			"ã": "a",
			"ä": "ae",
			"å": "a",
			"æ": "ae",
			"ç": "c",
			"è": "e",
			"é": "e",
			"ê": "e",
			"ë": "e",
			"ì": "i",
			"í": "i",
			"î": "i",
			"ï": "i",
			"ð": "d",
			"ñ": "n",
			"ò": "o",
			"ó": "o",
			"ô": "o",
			"õ": "o",
			"ö": "oe",
			"ő": "o",
			"ø": "o",
			"ù": "u",
			"ú": "u",
			"û": "u",
			"ü": "ue",
			"ű": "u",
			"ý": "y",
			"þ": "th",
			"ÿ": "y",
			"ẞ": "SS",
			"ا": "a",
			"أ": "a",
			"إ": "i",
			"آ": "aa",
			"ؤ": "u",
			"ئ": "e",
			"ء": "a",
			"ب": "b",
			"ت": "t",
			"ث": "th",
			"ج": "j",
			"ح": "h",
			"خ": "kh",
			"د": "d",
			"ذ": "th",
			"ر": "r",
			"ز": "z",
			"س": "s",
			"ش": "sh",
			"ص": "s",
			"ض": "dh",
			"ط": "t",
			"ظ": "z",
			"ع": "a",
			"غ": "gh",
			"ف": "f",
			"ق": "q",
			"ك": "k",
			"ل": "l",
			"م": "m",
			"ن": "n",
			"ه": "h",
			"و": "w",
			"ي": "y",
			"ى": "a",
			"ة": "h",
			"ﻻ": "la",
			"ﻷ": "laa",
			"ﻹ": "lai",
			"ﻵ": "laa",
			"گ": "g",
			"چ": "ch",
			"پ": "p",
			"ژ": "zh",
			"ک": "k",
			"ی": "y",
			"َ": "a",
			"ً": "an",
			"ِ": "e",
			"ٍ": "en",
			"ُ": "u",
			"ٌ": "on",
			"ْ": "",
			"٠": "0",
			"١": "1",
			"٢": "2",
			"٣": "3",
			"٤": "4",
			"٥": "5",
			"٦": "6",
			"٧": "7",
			"٨": "8",
			"٩": "9",
			"۰": "0",
			"۱": "1",
			"۲": "2",
			"۳": "3",
			"۴": "4",
			"۵": "5",
			"۶": "6",
			"۷": "7",
			"۸": "8",
			"۹": "9",
			"က": "k",
			"ခ": "kh",
			"ဂ": "g",
			"ဃ": "ga",
			"င": "ng",
			"စ": "s",
			"ဆ": "sa",
			"ဇ": "z",
			"စျ": "za",
			"ည": "ny",
			"ဋ": "t",
			"ဌ": "ta",
			"ဍ": "d",
			"ဎ": "da",
			"ဏ": "na",
			"တ": "t",
			"ထ": "ta",
			"ဒ": "d",
			"ဓ": "da",
			"န": "n",
			"ပ": "p",
			"ဖ": "pa",
			"ဗ": "b",
			"ဘ": "ba",
			"မ": "m",
			"ယ": "y",
			"ရ": "ya",
			"လ": "l",
			"ဝ": "w",
			"သ": "th",
			"ဟ": "h",
			"ဠ": "la",
			"အ": "a",
			"ြ": "y",
			"ျ": "ya",
			"ွ": "w",
			"ြွ": "yw",
			"ျွ": "ywa",
			"ှ": "h",
			"ဧ": "e",
			"၏": "-e",
			"ဣ": "i",
			"ဤ": "-i",
			"ဉ": "u",
			"ဦ": "-u",
			"ဩ": "aw",
			"သြော": "aw",
			"ဪ": "aw",
			"၀": "0",
			"၁": "1",
			"၂": "2",
			"၃": "3",
			"၄": "4",
			"၅": "5",
			"၆": "6",
			"၇": "7",
			"၈": "8",
			"၉": "9",
			"္": "",
			"့": "",
			"း": "",
			"č": "c",
			"ď": "d",
			"ě": "e",
			"ň": "n",
			"ř": "r",
			"š": "s",
			"ť": "t",
			"ů": "u",
			"ž": "z",
			"Č": "C",
			"Ď": "D",
			"Ě": "E",
			"Ň": "N",
			"Ř": "R",
			"Š": "S",
			"Ť": "T",
			"Ů": "U",
			"Ž": "Z",
			"ހ": "h",
			"ށ": "sh",
			"ނ": "n",
			"ރ": "r",
			"ބ": "b",
			"ޅ": "lh",
			"ކ": "k",
			"އ": "a",
			"ވ": "v",
			"މ": "m",
			"ފ": "f",
			"ދ": "dh",
			"ތ": "th",
			"ލ": "l",
			"ގ": "g",
			"ޏ": "gn",
			"ސ": "s",
			"ޑ": "d",
			"ޒ": "z",
			"ޓ": "t",
			"ޔ": "y",
			"ޕ": "p",
			"ޖ": "j",
			"ޗ": "ch",
			"ޘ": "tt",
			"ޙ": "hh",
			"ޚ": "kh",
			"ޛ": "th",
			"ޜ": "z",
			"ޝ": "sh",
			"ޞ": "s",
			"ޟ": "d",
			"ޠ": "t",
			"ޡ": "z",
			"ޢ": "a",
			"ޣ": "gh",
			"ޤ": "q",
			"ޥ": "w",
			"ަ": "a",
			"ާ": "aa",
			"ި": "i",
			"ީ": "ee",
			"ު": "u",
			"ޫ": "oo",
			"ެ": "e",
			"ޭ": "ey",
			"ޮ": "o",
			"ޯ": "oa",
			"ް": "",
			"ა": "a",
			"ბ": "b",
			"გ": "g",
			"დ": "d",
			"ე": "e",
			"ვ": "v",
			"ზ": "z",
			"თ": "t",
			"ი": "i",
			"კ": "k",
			"ლ": "l",
			"მ": "m",
			"ნ": "n",
			"ო": "o",
			"პ": "p",
			"ჟ": "zh",
			"რ": "r",
			"ს": "s",
			"ტ": "t",
			"უ": "u",
			"ფ": "p",
			"ქ": "k",
			"ღ": "gh",
			"ყ": "q",
			"შ": "sh",
			"ჩ": "ch",
			"ც": "ts",
			"ძ": "dz",
			"წ": "ts",
			"ჭ": "ch",
			"ხ": "kh",
			"ჯ": "j",
			"ჰ": "h",
			"α": "a",
			"β": "v",
			"γ": "g",
			"δ": "d",
			"ε": "e",
			"ζ": "z",
			"η": "i",
			"θ": "th",
			"ι": "i",
			"κ": "k",
			"λ": "l",
			"μ": "m",
			"ν": "n",
			"ξ": "ks",
			"ο": "o",
			"π": "p",
			"ρ": "r",
			"σ": "s",
			"τ": "t",
			"υ": "y",
			"φ": "f",
			"χ": "x",
			"ψ": "ps",
			"ω": "o",
			"ά": "a",
			"έ": "e",
			"ί": "i",
			"ό": "o",
			"ύ": "y",
			"ή": "i",
			"ώ": "o",
			"ς": "s",
			"ϊ": "i",
			"ΰ": "y",
			"ϋ": "y",
			"ΐ": "i",
			"Α": "A",
			"Β": "B",
			"Γ": "G",
			"Δ": "D",
			"Ε": "E",
			"Ζ": "Z",
			"Η": "I",
			"Θ": "TH",
			"Ι": "I",
			"Κ": "K",
			"Λ": "L",
			"Μ": "M",
			"Ν": "N",
			"Ξ": "KS",
			"Ο": "O",
			"Π": "P",
			"Ρ": "R",
			"Σ": "S",
			"Τ": "T",
			"Υ": "Y",
			"Φ": "F",
			"Χ": "X",
			"Ψ": "PS",
			"Ω": "O",
			"Ά": "A",
			"Έ": "E",
			"Ί": "I",
			"Ό": "O",
			"Ύ": "Y",
			"Ή": "I",
			"Ώ": "O",
			"Ϊ": "I",
			"Ϋ": "Y",
			"ā": "a",
			"ē": "e",
			"ģ": "g",
			"ī": "i",
			"ķ": "k",
			"ļ": "l",
			"ņ": "n",
			"ū": "u",
			"Ā": "A",
			"Ē": "E",
			"Ģ": "G",
			"Ī": "I",
			"Ķ": "k",
			"Ļ": "L",
			"Ņ": "N",
			"Ū": "U",
			"Ќ": "Kj",
			"ќ": "kj",
			"Љ": "Lj",
			"љ": "lj",
			"Њ": "Nj",
			"њ": "nj",
			"Тс": "Ts",
			"тс": "ts",
			"ą": "a",
			"ć": "c",
			"ę": "e",
			"ł": "l",
			"ń": "n",
			"ś": "s",
			"ź": "z",
			"ż": "z",
			"Ą": "A",
			"Ć": "C",
			"Ę": "E",
			"Ł": "L",
			"Ń": "N",
			"Ś": "S",
			"Ź": "Z",
			"Ż": "Z",
			"Є": "Ye",
			"І": "I",
			"Ї": "Yi",
			"Ґ": "G",
			"є": "ye",
			"і": "i",
			"ї": "yi",
			"ґ": "g",
			"ă": "a",
			"Ă": "A",
			"ș": "s",
			"Ș": "S",
			"ț": "t",
			"Ț": "T",
			"ţ": "t",
			"Ţ": "T",
			"а": "a",
			"б": "b",
			"в": "v",
			"г": "g",
			"д": "d",
			"е": "e",
			"ё": "yo",
			"ж": "zh",
			"з": "z",
			"и": "i",
			"й": "i",
			"к": "k",
			"л": "l",
			"м": "m",
			"н": "n",
			"о": "o",
			"п": "p",
			"р": "r",
			"с": "s",
			"т": "t",
			"у": "u",
			"ф": "f",
			"х": "kh",
			"ц": "c",
			"ч": "ch",
			"ш": "sh",
			"щ": "sh",
			"ъ": "",
			"ы": "y",
			"ь": "",
			"э": "e",
			"ю": "yu",
			"я": "ya",
			"А": "A",
			"Б": "B",
			"В": "V",
			"Г": "G",
			"Д": "D",
			"Е": "E",
			"Ё": "Yo",
			"Ж": "Zh",
			"З": "Z",
			"И": "I",
			"Й": "I",
			"К": "K",
			"Л": "L",
			"М": "M",
			"Н": "N",
			"О": "O",
			"П": "P",
			"Р": "R",
			"С": "S",
			"Т": "T",
			"У": "U",
			"Ф": "F",
			"Х": "Kh",
			"Ц": "C",
			"Ч": "Ch",
			"Ш": "Sh",
			"Щ": "Sh",
			"Ъ": "",
			"Ы": "Y",
			"Ь": "",
			"Э": "E",
			"Ю": "Yu",
			"Я": "Ya",
			"ђ": "dj",
			"ј": "j",
			"ћ": "c",
			"џ": "dz",
			"Ђ": "Dj",
			"Ј": "j",
			"Ћ": "C",
			"Џ": "Dz",
			"ľ": "l",
			"ĺ": "l",
			"ŕ": "r",
			"Ľ": "L",
			"Ĺ": "L",
			"Ŕ": "R",
			"ş": "s",
			"Ş": "S",
			"ı": "i",
			"İ": "I",
			"ğ": "g",
			"Ğ": "G",
			"ả": "a",
			"Ả": "A",
			"ẳ": "a",
			"Ẳ": "A",
			"ẩ": "a",
			"Ẩ": "A",
			"đ": "d",
			"Đ": "D",
			"ẹ": "e",
			"Ẹ": "E",
			"ẽ": "e",
			"Ẽ": "E",
			"ẻ": "e",
			"Ẻ": "E",
			"ế": "e",
			"Ế": "E",
			"ề": "e",
			"Ề": "E",
			"ệ": "e",
			"Ệ": "E",
			"ễ": "e",
			"Ễ": "E",
			"ể": "e",
			"Ể": "E",
			"ỏ": "o",
			"ọ": "o",
			"Ọ": "o",
			"ố": "o",
			"Ố": "O",
			"ồ": "o",
			"Ồ": "O",
			"ổ": "o",
			"Ổ": "O",
			"ộ": "o",
			"Ộ": "O",
			"ỗ": "o",
			"Ỗ": "O",
			"ơ": "o",
			"Ơ": "O",
			"ớ": "o",
			"Ớ": "O",
			"ờ": "o",
			"Ờ": "O",
			"ợ": "o",
			"Ợ": "O",
			"ỡ": "o",
			"Ỡ": "O",
			"Ở": "o",
			"ở": "o",
			"ị": "i",
			"Ị": "I",
			"ĩ": "i",
			"Ĩ": "I",
			"ỉ": "i",
			"Ỉ": "i",
			"ủ": "u",
			"Ủ": "U",
			"ụ": "u",
			"Ụ": "U",
			"ũ": "u",
			"Ũ": "U",
			"ư": "u",
			"Ư": "U",
			"ứ": "u",
			"Ứ": "U",
			"ừ": "u",
			"Ừ": "U",
			"ự": "u",
			"Ự": "U",
			"ữ": "u",
			"Ữ": "U",
			"ử": "u",
			"Ử": "ư",
			"ỷ": "y",
			"Ỷ": "y",
			"ỳ": "y",
			"Ỳ": "Y",
			"ỵ": "y",
			"Ỵ": "Y",
			"ỹ": "y",
			"Ỹ": "Y",
			"ạ": "a",
			"Ạ": "A",
			"ấ": "a",
			"Ấ": "A",
			"ầ": "a",
			"Ầ": "A",
			"ậ": "a",
			"Ậ": "A",
			"ẫ": "a",
			"Ẫ": "A",
			"ắ": "a",
			"Ắ": "A",
			"ằ": "a",
			"Ằ": "A",
			"ặ": "a",
			"Ặ": "A",
			"ẵ": "a",
			"Ẵ": "A",
			"⓪": "0",
			"①": "1",
			"②": "2",
			"③": "3",
			"④": "4",
			"⑤": "5",
			"⑥": "6",
			"⑦": "7",
			"⑧": "8",
			"⑨": "9",
			"⑩": "10",
			"⑪": "11",
			"⑫": "12",
			"⑬": "13",
			"⑭": "14",
			"⑮": "15",
			"⑯": "16",
			"⑰": "17",
			"⑱": "18",
			"⑲": "18",
			"⑳": "18",
			"⓵": "1",
			"⓶": "2",
			"⓷": "3",
			"⓸": "4",
			"⓹": "5",
			"⓺": "6",
			"⓻": "7",
			"⓼": "8",
			"⓽": "9",
			"⓾": "10",
			"⓿": "0",
			"⓫": "11",
			"⓬": "12",
			"⓭": "13",
			"⓮": "14",
			"⓯": "15",
			"⓰": "16",
			"⓱": "17",
			"⓲": "18",
			"⓳": "19",
			"⓴": "20",
			"Ⓐ": "A",
			"Ⓑ": "B",
			"Ⓒ": "C",
			"Ⓓ": "D",
			"Ⓔ": "E",
			"Ⓕ": "F",
			"Ⓖ": "G",
			"Ⓗ": "H",
			"Ⓘ": "I",
			"Ⓙ": "J",
			"Ⓚ": "K",
			"Ⓛ": "L",
			"Ⓜ": "M",
			"Ⓝ": "N",
			"Ⓞ": "O",
			"Ⓟ": "P",
			"Ⓠ": "Q",
			"Ⓡ": "R",
			"Ⓢ": "S",
			"Ⓣ": "T",
			"Ⓤ": "U",
			"Ⓥ": "V",
			"Ⓦ": "W",
			"Ⓧ": "X",
			"Ⓨ": "Y",
			"Ⓩ": "Z",
			"ⓐ": "a",
			"ⓑ": "b",
			"ⓒ": "c",
			"ⓓ": "d",
			"ⓔ": "e",
			"ⓕ": "f",
			"ⓖ": "g",
			"ⓗ": "h",
			"ⓘ": "i",
			"ⓙ": "j",
			"ⓚ": "k",
			"ⓛ": "l",
			"ⓜ": "m",
			"ⓝ": "n",
			"ⓞ": "o",
			"ⓟ": "p",
			"ⓠ": "q",
			"ⓡ": "r",
			"ⓢ": "s",
			"ⓣ": "t",
			"ⓤ": "u",
			"ⓦ": "v",
			"ⓥ": "w",
			"ⓧ": "x",
			"ⓨ": "y",
			"ⓩ": "z",
			"“": "\"",
			"”": "\"",
			"‘": "'",
			"’": "'",
			"∂": "d",
			"ƒ": "f",
			"™": "(TM)",
			"©": "(C)",
			"œ": "oe",
			"Œ": "OE",
			"®": "(R)",
			"†": "+",
			"℠": "(SM)",
			"…": "...",
			"˚": "o",
			"º": "o",
			"ª": "a",
			"•": "*",
			"၊": ",",
			"။": ".",
			"$": "USD",
			"€": "EUR",
			"₢": "BRN",
			"₣": "FRF",
			"£": "GBP",
			"₤": "ITL",
			"₦": "NGN",
			"₧": "ESP",
			"₩": "KRW",
			"₪": "ILS",
			"₫": "VND",
			"₭": "LAK",
			"₮": "MNT",
			"₯": "GRD",
			"₱": "ARS",
			"₲": "PYG",
			"₳": "ARA",
			"₴": "UAH",
			"₵": "GHS",
			"¢": "cent",
			"¥": "CNY",
			"元": "CNY",
			"円": "YEN",
			"﷼": "IRR",
			"₠": "EWE",
			"฿": "THB",
			"₨": "INR",
			"₹": "INR",
			"₰": "PF",
			"₺": "TRY",
			"؋": "AFN",
			"₼": "AZN",
			"лв": "BGN",
			"៛": "KHR",
			"₡": "CRC",
			"₸": "KZT",
			"ден": "MKD",
			"zł": "PLN",
			"₽": "RUB",
			"₾": "GEL"
		};
		/**
		* special look ahead character array
		* These characters form with consonants to become 'single'/consonant combo
		* @type [Array]
		*/
		var lookAheadCharArray = ["်", "ް"];
		/**
		* diatricMap for languages where transliteration changes entirely as more diatrics are added
		* @type {Object}
		*/
		var diatricMap = {
			"ာ": "a",
			"ါ": "a",
			"ေ": "e",
			"ဲ": "e",
			"ိ": "i",
			"ီ": "i",
			"ို": "o",
			"ု": "u",
			"ူ": "u",
			"ေါင်": "aung",
			"ော": "aw",
			"ော်": "aw",
			"ေါ": "aw",
			"ေါ်": "aw",
			"်": "်",
			"က်": "et",
			"ိုက်": "aik",
			"ောက်": "auk",
			"င်": "in",
			"ိုင်": "aing",
			"ောင်": "aung",
			"စ်": "it",
			"ည်": "i",
			"တ်": "at",
			"ိတ်": "eik",
			"ုတ်": "ok",
			"ွတ်": "ut",
			"ေတ်": "it",
			"ဒ်": "d",
			"ိုဒ်": "ok",
			"ုဒ်": "ait",
			"န်": "an",
			"ာန်": "an",
			"ိန်": "ein",
			"ုန်": "on",
			"ွန်": "un",
			"ပ်": "at",
			"ိပ်": "eik",
			"ုပ်": "ok",
			"ွပ်": "ut",
			"န်ုပ်": "nub",
			"မ်": "an",
			"ိမ်": "ein",
			"ုမ်": "on",
			"ွမ်": "un",
			"ယ်": "e",
			"ိုလ်": "ol",
			"ဉ်": "in",
			"ံ": "an",
			"ိံ": "ein",
			"ုံ": "on",
			"ައް": "ah",
			"ަށް": "ah"
		};
		/**
		* langCharMap language specific characters translations
		* @type   {Object}
		*/
		var langCharMap = {
			"en": {},
			"az": {
				"ç": "c",
				"ə": "e",
				"ğ": "g",
				"ı": "i",
				"ö": "o",
				"ş": "s",
				"ü": "u",
				"Ç": "C",
				"Ə": "E",
				"Ğ": "G",
				"İ": "I",
				"Ö": "O",
				"Ş": "S",
				"Ü": "U"
			},
			"cs": {
				"č": "c",
				"ď": "d",
				"ě": "e",
				"ň": "n",
				"ř": "r",
				"š": "s",
				"ť": "t",
				"ů": "u",
				"ž": "z",
				"Č": "C",
				"Ď": "D",
				"Ě": "E",
				"Ň": "N",
				"Ř": "R",
				"Š": "S",
				"Ť": "T",
				"Ů": "U",
				"Ž": "Z"
			},
			"fi": {
				"ä": "a",
				"Ä": "A",
				"ö": "o",
				"Ö": "O"
			},
			"hu": {
				"ä": "a",
				"Ä": "A",
				"ö": "o",
				"Ö": "O",
				"ü": "u",
				"Ü": "U",
				"ű": "u",
				"Ű": "U"
			},
			"lt": {
				"ą": "a",
				"č": "c",
				"ę": "e",
				"ė": "e",
				"į": "i",
				"š": "s",
				"ų": "u",
				"ū": "u",
				"ž": "z",
				"Ą": "A",
				"Č": "C",
				"Ę": "E",
				"Ė": "E",
				"Į": "I",
				"Š": "S",
				"Ų": "U",
				"Ū": "U"
			},
			"lv": {
				"ā": "a",
				"č": "c",
				"ē": "e",
				"ģ": "g",
				"ī": "i",
				"ķ": "k",
				"ļ": "l",
				"ņ": "n",
				"š": "s",
				"ū": "u",
				"ž": "z",
				"Ā": "A",
				"Č": "C",
				"Ē": "E",
				"Ģ": "G",
				"Ī": "i",
				"Ķ": "k",
				"Ļ": "L",
				"Ņ": "N",
				"Š": "S",
				"Ū": "u",
				"Ž": "Z"
			},
			"pl": {
				"ą": "a",
				"ć": "c",
				"ę": "e",
				"ł": "l",
				"ń": "n",
				"ó": "o",
				"ś": "s",
				"ź": "z",
				"ż": "z",
				"Ą": "A",
				"Ć": "C",
				"Ę": "e",
				"Ł": "L",
				"Ń": "N",
				"Ó": "O",
				"Ś": "S",
				"Ź": "Z",
				"Ż": "Z"
			},
			"sv": {
				"ä": "a",
				"Ä": "A",
				"ö": "o",
				"Ö": "O"
			},
			"sk": {
				"ä": "a",
				"Ä": "A"
			},
			"sr": {
				"љ": "lj",
				"њ": "nj",
				"Љ": "Lj",
				"Њ": "Nj",
				"đ": "dj",
				"Đ": "Dj"
			},
			"tr": {
				"Ü": "U",
				"Ö": "O",
				"ü": "u",
				"ö": "o"
			}
		};
		/**
		* symbolMap language specific symbol translations
		* translations must be transliterated already
		* @type   {Object}
		*/
		var symbolMap = {
			"ar": {
				"∆": "delta",
				"∞": "la-nihaya",
				"♥": "hob",
				"&": "wa",
				"|": "aw",
				"<": "aqal-men",
				">": "akbar-men",
				"∑": "majmou",
				"¤": "omla"
			},
			"az": {},
			"ca": {
				"∆": "delta",
				"∞": "infinit",
				"♥": "amor",
				"&": "i",
				"|": "o",
				"<": "menys que",
				">": "mes que",
				"∑": "suma dels",
				"¤": "moneda"
			},
			"cs": {
				"∆": "delta",
				"∞": "nekonecno",
				"♥": "laska",
				"&": "a",
				"|": "nebo",
				"<": "mensi nez",
				">": "vetsi nez",
				"∑": "soucet",
				"¤": "mena"
			},
			"de": {
				"∆": "delta",
				"∞": "unendlich",
				"♥": "Liebe",
				"&": "und",
				"|": "oder",
				"<": "kleiner als",
				">": "groesser als",
				"∑": "Summe von",
				"¤": "Waehrung"
			},
			"dv": {
				"∆": "delta",
				"∞": "kolunulaa",
				"♥": "loabi",
				"&": "aai",
				"|": "noonee",
				"<": "ah vure kuda",
				">": "ah vure bodu",
				"∑": "jumula",
				"¤": "faisaa"
			},
			"en": {
				"∆": "delta",
				"∞": "infinity",
				"♥": "love",
				"&": "and",
				"|": "or",
				"<": "less than",
				">": "greater than",
				"∑": "sum",
				"¤": "currency"
			},
			"es": {
				"∆": "delta",
				"∞": "infinito",
				"♥": "amor",
				"&": "y",
				"|": "u",
				"<": "menos que",
				">": "mas que",
				"∑": "suma de los",
				"¤": "moneda"
			},
			"fa": {
				"∆": "delta",
				"∞": "bi-nahayat",
				"♥": "eshgh",
				"&": "va",
				"|": "ya",
				"<": "kamtar-az",
				">": "bishtar-az",
				"∑": "majmooe",
				"¤": "vahed"
			},
			"fi": {
				"∆": "delta",
				"∞": "aarettomyys",
				"♥": "rakkaus",
				"&": "ja",
				"|": "tai",
				"<": "pienempi kuin",
				">": "suurempi kuin",
				"∑": "summa",
				"¤": "valuutta"
			},
			"fr": {
				"∆": "delta",
				"∞": "infiniment",
				"♥": "Amour",
				"&": "et",
				"|": "ou",
				"<": "moins que",
				">": "superieure a",
				"∑": "somme des",
				"¤": "monnaie"
			},
			"ge": {
				"∆": "delta",
				"∞": "usasruloba",
				"♥": "siqvaruli",
				"&": "da",
				"|": "an",
				"<": "naklebi",
				">": "meti",
				"∑": "jami",
				"¤": "valuta"
			},
			"gr": {},
			"hu": {
				"∆": "delta",
				"∞": "vegtelen",
				"♥": "szerelem",
				"&": "es",
				"|": "vagy",
				"<": "kisebb mint",
				">": "nagyobb mint",
				"∑": "szumma",
				"¤": "penznem"
			},
			"it": {
				"∆": "delta",
				"∞": "infinito",
				"♥": "amore",
				"&": "e",
				"|": "o",
				"<": "minore di",
				">": "maggiore di",
				"∑": "somma",
				"¤": "moneta"
			},
			"lt": {
				"∆": "delta",
				"∞": "begalybe",
				"♥": "meile",
				"&": "ir",
				"|": "ar",
				"<": "maziau nei",
				">": "daugiau nei",
				"∑": "suma",
				"¤": "valiuta"
			},
			"lv": {
				"∆": "delta",
				"∞": "bezgaliba",
				"♥": "milestiba",
				"&": "un",
				"|": "vai",
				"<": "mazak neka",
				">": "lielaks neka",
				"∑": "summa",
				"¤": "valuta"
			},
			"my": {
				"∆": "kwahkhyaet",
				"∞": "asaonasme",
				"♥": "akhyait",
				"&": "nhin",
				"|": "tho",
				"<": "ngethaw",
				">": "kyithaw",
				"∑": "paungld",
				"¤": "ngwekye"
			},
			"mk": {},
			"nl": {
				"∆": "delta",
				"∞": "oneindig",
				"♥": "liefde",
				"&": "en",
				"|": "of",
				"<": "kleiner dan",
				">": "groter dan",
				"∑": "som",
				"¤": "valuta"
			},
			"pl": {
				"∆": "delta",
				"∞": "nieskonczonosc",
				"♥": "milosc",
				"&": "i",
				"|": "lub",
				"<": "mniejsze niz",
				">": "wieksze niz",
				"∑": "suma",
				"¤": "waluta"
			},
			"pt": {
				"∆": "delta",
				"∞": "infinito",
				"♥": "amor",
				"&": "e",
				"|": "ou",
				"<": "menor que",
				">": "maior que",
				"∑": "soma",
				"¤": "moeda"
			},
			"ro": {
				"∆": "delta",
				"∞": "infinit",
				"♥": "dragoste",
				"&": "si",
				"|": "sau",
				"<": "mai mic ca",
				">": "mai mare ca",
				"∑": "suma",
				"¤": "valuta"
			},
			"ru": {
				"∆": "delta",
				"∞": "beskonechno",
				"♥": "lubov",
				"&": "i",
				"|": "ili",
				"<": "menshe",
				">": "bolshe",
				"∑": "summa",
				"¤": "valjuta"
			},
			"sk": {
				"∆": "delta",
				"∞": "nekonecno",
				"♥": "laska",
				"&": "a",
				"|": "alebo",
				"<": "menej ako",
				">": "viac ako",
				"∑": "sucet",
				"¤": "mena"
			},
			"sr": {},
			"tr": {
				"∆": "delta",
				"∞": "sonsuzluk",
				"♥": "ask",
				"&": "ve",
				"|": "veya",
				"<": "kucuktur",
				">": "buyuktur",
				"∑": "toplam",
				"¤": "para birimi"
			},
			"uk": {
				"∆": "delta",
				"∞": "bezkinechnist",
				"♥": "lubov",
				"&": "i",
				"|": "abo",
				"<": "menshe",
				">": "bilshe",
				"∑": "suma",
				"¤": "valjuta"
			},
			"vn": {
				"∆": "delta",
				"∞": "vo cuc",
				"♥": "yeu",
				"&": "va",
				"|": "hoac",
				"<": "nho hon",
				">": "lon hon",
				"∑": "tong",
				"¤": "tien te"
			}
		};
		var uricChars = [
			";",
			"?",
			":",
			"@",
			"&",
			"=",
			"+",
			"$",
			",",
			"/"
		].join("");
		var uricNoSlashChars = [
			";",
			"?",
			":",
			"@",
			"&",
			"=",
			"+",
			"$",
			","
		].join("");
		var markChars = [
			".",
			"!",
			"~",
			"*",
			"'",
			"(",
			")"
		].join("");
		/**
		* getSlug
		* @param  {string} input input string
		* @param  {object|string} opts config object or separator string/char
		* @api    public
		* @return {string}  sluggified string
		*/
		var getSlug = function getSlug(input, opts) {
			var separator = "-";
			var result = "";
			var diatricString = "";
			var convertSymbols = true;
			var customReplacements = {};
			var maintainCase;
			var titleCase;
			var truncate;
			var uricFlag;
			var uricNoSlashFlag;
			var markFlag;
			var symbol;
			var langChar;
			var lucky;
			var i;
			var ch;
			var l;
			var lastCharWasSymbol;
			var lastCharWasDiatric;
			var allowedChars = "";
			if (typeof input !== "string") return "";
			if (typeof opts === "string") separator = opts;
			symbol = symbolMap.en;
			langChar = langCharMap.en;
			if (typeof opts === "object") {
				maintainCase = opts.maintainCase || false;
				customReplacements = opts.custom && typeof opts.custom === "object" ? opts.custom : customReplacements;
				truncate = +opts.truncate > 1 && opts.truncate || false;
				uricFlag = opts.uric || false;
				uricNoSlashFlag = opts.uricNoSlash || false;
				markFlag = opts.mark || false;
				convertSymbols = opts.symbols === false || opts.lang === false ? false : true;
				separator = opts.separator || separator;
				if (uricFlag) allowedChars += uricChars;
				if (uricNoSlashFlag) allowedChars += uricNoSlashChars;
				if (markFlag) allowedChars += markChars;
				symbol = opts.lang && symbolMap[opts.lang] && convertSymbols ? symbolMap[opts.lang] : convertSymbols ? symbolMap.en : {};
				langChar = opts.lang && langCharMap[opts.lang] ? langCharMap[opts.lang] : opts.lang === false || opts.lang === true ? {} : langCharMap.en;
				if (opts.titleCase && typeof opts.titleCase.length === "number" && Array.prototype.toString.call(opts.titleCase)) {
					opts.titleCase.forEach(function(v) {
						customReplacements[v + ""] = v + "";
					});
					titleCase = true;
				} else titleCase = !!opts.titleCase;
				if (opts.custom && typeof opts.custom.length === "number" && Array.prototype.toString.call(opts.custom)) opts.custom.forEach(function(v) {
					customReplacements[v + ""] = v + "";
				});
				Object.keys(customReplacements).forEach(function(v) {
					var r;
					if (v.length > 1) r = new RegExp("\\b" + escapeChars(v) + "\\b", "gi");
					else r = new RegExp(escapeChars(v), "gi");
					input = input.replace(r, customReplacements[v]);
				});
				for (ch in customReplacements) allowedChars += ch;
			}
			allowedChars += separator;
			allowedChars = escapeChars(allowedChars);
			input = input.replace(/(^\s+|\s+$)/g, "");
			lastCharWasSymbol = false;
			lastCharWasDiatric = false;
			for (i = 0, l = input.length; i < l; i++) {
				ch = input[i];
				if (isReplacedCustomChar(ch, customReplacements)) lastCharWasSymbol = false;
				else if (langChar[ch]) {
					ch = lastCharWasSymbol && langChar[ch].match(/[A-Za-z0-9]/) ? " " + langChar[ch] : langChar[ch];
					lastCharWasSymbol = false;
				} else if (ch in charMap) {
					if (i + 1 < l && lookAheadCharArray.indexOf(input[i + 1]) >= 0) {
						diatricString += ch;
						ch = "";
					} else if (lastCharWasDiatric === true) {
						ch = diatricMap[diatricString] + charMap[ch];
						diatricString = "";
					} else ch = lastCharWasSymbol && charMap[ch].match(/[A-Za-z0-9]/) ? " " + charMap[ch] : charMap[ch];
					lastCharWasSymbol = false;
					lastCharWasDiatric = false;
				} else if (ch in diatricMap) {
					diatricString += ch;
					ch = "";
					if (i === l - 1) ch = diatricMap[diatricString];
					lastCharWasDiatric = true;
				} else if (symbol[ch] && !(uricFlag && uricChars.indexOf(ch) !== -1) && !(uricNoSlashFlag && uricNoSlashChars.indexOf(ch) !== -1)) {
					ch = lastCharWasSymbol || result.substr(-1).match(/[A-Za-z0-9]/) ? separator + symbol[ch] : symbol[ch];
					ch += input[i + 1] !== void 0 && input[i + 1].match(/[A-Za-z0-9]/) ? separator : "";
					lastCharWasSymbol = true;
				} else {
					if (lastCharWasDiatric === true) {
						ch = diatricMap[diatricString] + ch;
						diatricString = "";
						lastCharWasDiatric = false;
					} else if (lastCharWasSymbol && (/[A-Za-z0-9]/.test(ch) || result.substr(-1).match(/A-Za-z0-9]/))) ch = " " + ch;
					lastCharWasSymbol = false;
				}
				result += ch.replace(new RegExp("[^\\w\\s" + allowedChars + "_-]", "g"), separator);
			}
			if (titleCase) result = result.replace(/(\w)(\S*)/g, function(_, i, r) {
				var j = i.toUpperCase() + (r !== null ? r : "");
				return Object.keys(customReplacements).indexOf(j.toLowerCase()) < 0 ? j : j.toLowerCase();
			});
			result = result.replace(/\s+/g, separator).replace(new RegExp("\\" + separator + "+", "g"), separator).replace(new RegExp("(^\\" + separator + "+|\\" + separator + "+$)", "g"), "");
			if (truncate && result.length > truncate) {
				lucky = result.charAt(truncate) === separator;
				result = result.slice(0, truncate);
				if (!lucky) result = result.slice(0, result.lastIndexOf(separator));
			}
			if (!maintainCase && !titleCase) result = result.toLowerCase();
			return result;
		};
		/**
		* createSlug curried(opts)(input)
		* @param   {object|string} opts config object or input string
		* @return  {Function} function getSlugWithConfig()
		**/
		var createSlug = function createSlug(opts) {
			/**
			* getSlugWithConfig
			* @param   {string} input string
			* @return  {string} slug string
			*/
			return function getSlugWithConfig(input) {
				return getSlug(input, opts);
			};
		};
		/**
		* escape Chars
		* @param   {string} input string
		*/
		var escapeChars = function escapeChars(input) {
			return input.replace(/[-\\^$*+?.()|[\]{}\/]/g, "\\$&");
		};
		/**
		* check if the char is an already converted char from custom list
		* @param   {char} ch character to check
		* @param   {object} customReplacements custom translation map
		*/
		var isReplacedCustomChar = function(ch, customReplacements) {
			for (var c in customReplacements) if (customReplacements[c] === ch) return true;
		};
		if (typeof module !== "undefined" && module.exports) {
			module.exports = getSlug;
			module.exports.createSlug = createSlug;
		} else if (typeof define !== "undefined" && define.amd) define([], function() {
			return getSlug;
		});
		else try {
			if (root.getSlug || root.createSlug) throw "speakingurl: globals exists /(getSlug|createSlug)/";
			else {
				root.getSlug = getSlug;
				root.createSlug = createSlug;
			}
		} catch (e) {}
	})(exports);
}));
(/* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = require_speakingurl$1();
})))();
target.__VUE_DEVTOOLS_NEXT_APP_RECORD_INFO__ ??= {
	id: 0,
	appIds: /* @__PURE__ */ new Set()
};
function toggleHighPerfMode(state) {
	devtoolsState.highPerfModeEnabled = state ?? !devtoolsState.highPerfModeEnabled;
	if (!state && activeAppRecord.value) registerDevToolsPlugin(activeAppRecord.value.app);
}
function updateDevToolsClientDetected(params) {
	devtoolsState.devtoolsClientDetected = {
		...devtoolsState.devtoolsClientDetected,
		...params
	};
	toggleHighPerfMode(!Object.values(devtoolsState.devtoolsClientDetected).some(Boolean));
}
target.__VUE_DEVTOOLS_UPDATE_CLIENT_DETECTED__ ??= updateDevToolsClientDetected;
var DoubleIndexedKV = class {
	constructor() {
		this.keyToValue = /* @__PURE__ */ new Map();
		this.valueToKey = /* @__PURE__ */ new Map();
	}
	set(key, value) {
		this.keyToValue.set(key, value);
		this.valueToKey.set(value, key);
	}
	getByKey(key) {
		return this.keyToValue.get(key);
	}
	getByValue(value) {
		return this.valueToKey.get(value);
	}
	clear() {
		this.keyToValue.clear();
		this.valueToKey.clear();
	}
};
var Registry = class {
	constructor(generateIdentifier) {
		this.generateIdentifier = generateIdentifier;
		this.kv = new DoubleIndexedKV();
	}
	register(value, identifier) {
		if (this.kv.getByValue(value)) return;
		if (!identifier) identifier = this.generateIdentifier(value);
		this.kv.set(identifier, value);
	}
	clear() {
		this.kv.clear();
	}
	getIdentifier(value) {
		return this.kv.getByValue(value);
	}
	getValue(identifier) {
		return this.kv.getByKey(identifier);
	}
};
var ClassRegistry = class extends Registry {
	constructor() {
		super((c) => c.name);
		this.classToAllowedProps = /* @__PURE__ */ new Map();
	}
	register(value, options) {
		if (typeof options === "object") {
			if (options.allowProps) this.classToAllowedProps.set(value, options.allowProps);
			super.register(value, options.identifier);
		} else super.register(value, options);
	}
	getAllowedProps(value) {
		return this.classToAllowedProps.get(value);
	}
};
function valuesOfObj(record) {
	if ("values" in Object) return Object.values(record);
	const values = [];
	for (const key in record) if (record.hasOwnProperty(key)) values.push(record[key]);
	return values;
}
function find(record, predicate) {
	const values = valuesOfObj(record);
	if ("find" in values) return values.find(predicate);
	const valuesNotNever = values;
	for (let i = 0; i < valuesNotNever.length; i++) {
		const value = valuesNotNever[i];
		if (predicate(value)) return value;
	}
}
function forEach(record, run) {
	Object.entries(record).forEach(([key, value]) => run(value, key));
}
function includes(arr, value) {
	return arr.indexOf(value) !== -1;
}
function findArr(record, predicate) {
	for (let i = 0; i < record.length; i++) {
		const value = record[i];
		if (predicate(value)) return value;
	}
}
var CustomTransformerRegistry = class {
	constructor() {
		this.transfomers = {};
	}
	register(transformer) {
		this.transfomers[transformer.name] = transformer;
	}
	findApplicable(v) {
		return find(this.transfomers, (transformer) => transformer.isApplicable(v));
	}
	findByName(name) {
		return this.transfomers[name];
	}
};
var getType$1 = (payload) => Object.prototype.toString.call(payload).slice(8, -1);
var isUndefined$1 = (payload) => typeof payload === "undefined";
var isNull$1 = (payload) => payload === null;
var isPlainObject$2 = (payload) => {
	if (typeof payload !== "object" || payload === null) return false;
	if (payload === Object.prototype) return false;
	if (Object.getPrototypeOf(payload) === null) return true;
	return Object.getPrototypeOf(payload) === Object.prototype;
};
var isEmptyObject = (payload) => isPlainObject$2(payload) && Object.keys(payload).length === 0;
var isArray$2 = (payload) => Array.isArray(payload);
var isString = (payload) => typeof payload === "string";
var isNumber = (payload) => typeof payload === "number" && !isNaN(payload);
var isBoolean = (payload) => typeof payload === "boolean";
var isRegExp = (payload) => payload instanceof RegExp;
var isMap = (payload) => payload instanceof Map;
var isSet = (payload) => payload instanceof Set;
var isSymbol = (payload) => getType$1(payload) === "Symbol";
var isDate = (payload) => payload instanceof Date && !isNaN(payload.valueOf());
var isError = (payload) => payload instanceof Error;
var isNaNValue = (payload) => typeof payload === "number" && isNaN(payload);
var isPrimitive = (payload) => isBoolean(payload) || isNull$1(payload) || isUndefined$1(payload) || isNumber(payload) || isString(payload) || isSymbol(payload);
var isBigint = (payload) => typeof payload === "bigint";
var isInfinite = (payload) => payload === Infinity || payload === -Infinity;
var isTypedArray = (payload) => ArrayBuffer.isView(payload) && !(payload instanceof DataView);
var isURL = (payload) => payload instanceof URL;
var escapeKey = (key) => key.replace(/\./g, "\\.");
var stringifyPath = (path) => path.map(String).map(escapeKey).join(".");
var parsePath = (string) => {
	const result = [];
	let segment = "";
	for (let i = 0; i < string.length; i++) {
		let char = string.charAt(i);
		if (char === "\\" && string.charAt(i + 1) === ".") {
			segment += ".";
			i++;
			continue;
		}
		if (char === ".") {
			result.push(segment);
			segment = "";
			continue;
		}
		segment += char;
	}
	const lastSegment = segment;
	result.push(lastSegment);
	return result;
};
function simpleTransformation(isApplicable, annotation, transform, untransform) {
	return {
		isApplicable,
		annotation,
		transform,
		untransform
	};
}
var simpleRules = [
	simpleTransformation(isUndefined$1, "undefined", () => null, () => void 0),
	simpleTransformation(isBigint, "bigint", (v) => v.toString(), (v) => {
		if (typeof BigInt !== "undefined") return BigInt(v);
		console.error("Please add a BigInt polyfill.");
		return v;
	}),
	simpleTransformation(isDate, "Date", (v) => v.toISOString(), (v) => new Date(v)),
	simpleTransformation(isError, "Error", (v, superJson) => {
		const baseError = {
			name: v.name,
			message: v.message
		};
		superJson.allowedErrorProps.forEach((prop) => {
			baseError[prop] = v[prop];
		});
		return baseError;
	}, (v, superJson) => {
		const e = new Error(v.message);
		e.name = v.name;
		e.stack = v.stack;
		superJson.allowedErrorProps.forEach((prop) => {
			e[prop] = v[prop];
		});
		return e;
	}),
	simpleTransformation(isRegExp, "regexp", (v) => "" + v, (regex) => {
		const body = regex.slice(1, regex.lastIndexOf("/"));
		const flags = regex.slice(regex.lastIndexOf("/") + 1);
		return new RegExp(body, flags);
	}),
	simpleTransformation(isSet, "set", (v) => [...v.values()], (v) => new Set(v)),
	simpleTransformation(isMap, "map", (v) => [...v.entries()], (v) => new Map(v)),
	simpleTransformation((v) => isNaNValue(v) || isInfinite(v), "number", (v) => {
		if (isNaNValue(v)) return "NaN";
		if (v > 0) return "Infinity";
		else return "-Infinity";
	}, Number),
	simpleTransformation((v) => v === 0 && 1 / v === -Infinity, "number", () => {
		return "-0";
	}, Number),
	simpleTransformation(isURL, "URL", (v) => v.toString(), (v) => new URL(v))
];
function compositeTransformation(isApplicable, annotation, transform, untransform) {
	return {
		isApplicable,
		annotation,
		transform,
		untransform
	};
}
var symbolRule = compositeTransformation((s, superJson) => {
	if (isSymbol(s)) return !!superJson.symbolRegistry.getIdentifier(s);
	return false;
}, (s, superJson) => {
	return ["symbol", superJson.symbolRegistry.getIdentifier(s)];
}, (v) => v.description, (_, a, superJson) => {
	const value = superJson.symbolRegistry.getValue(a[1]);
	if (!value) throw new Error("Trying to deserialize unknown symbol");
	return value;
});
var constructorToName = [
	Int8Array,
	Uint8Array,
	Int16Array,
	Uint16Array,
	Int32Array,
	Uint32Array,
	Float32Array,
	Float64Array,
	Uint8ClampedArray
].reduce((obj, ctor) => {
	obj[ctor.name] = ctor;
	return obj;
}, {});
var typedArrayRule = compositeTransformation(isTypedArray, (v) => ["typed-array", v.constructor.name], (v) => [...v], (v, a) => {
	const ctor = constructorToName[a[1]];
	if (!ctor) throw new Error("Trying to deserialize unknown typed array");
	return new ctor(v);
});
function isInstanceOfRegisteredClass(potentialClass, superJson) {
	if (potentialClass?.constructor) return !!superJson.classRegistry.getIdentifier(potentialClass.constructor);
	return false;
}
var classRule = compositeTransformation(isInstanceOfRegisteredClass, (clazz, superJson) => {
	return ["class", superJson.classRegistry.getIdentifier(clazz.constructor)];
}, (clazz, superJson) => {
	const allowedProps = superJson.classRegistry.getAllowedProps(clazz.constructor);
	if (!allowedProps) return { ...clazz };
	const result = {};
	allowedProps.forEach((prop) => {
		result[prop] = clazz[prop];
	});
	return result;
}, (v, a, superJson) => {
	const clazz = superJson.classRegistry.getValue(a[1]);
	if (!clazz) throw new Error(`Trying to deserialize unknown class '${a[1]}' - check https://github.com/blitz-js/superjson/issues/116#issuecomment-773996564`);
	return Object.assign(Object.create(clazz.prototype), v);
});
var customRule = compositeTransformation((value, superJson) => {
	return !!superJson.customTransformerRegistry.findApplicable(value);
}, (value, superJson) => {
	return ["custom", superJson.customTransformerRegistry.findApplicable(value).name];
}, (value, superJson) => {
	return superJson.customTransformerRegistry.findApplicable(value).serialize(value);
}, (v, a, superJson) => {
	const transformer = superJson.customTransformerRegistry.findByName(a[1]);
	if (!transformer) throw new Error("Trying to deserialize unknown custom value");
	return transformer.deserialize(v);
});
var compositeRules = [
	classRule,
	symbolRule,
	customRule,
	typedArrayRule
];
var transformValue = (value, superJson) => {
	const applicableCompositeRule = findArr(compositeRules, (rule) => rule.isApplicable(value, superJson));
	if (applicableCompositeRule) return {
		value: applicableCompositeRule.transform(value, superJson),
		type: applicableCompositeRule.annotation(value, superJson)
	};
	const applicableSimpleRule = findArr(simpleRules, (rule) => rule.isApplicable(value, superJson));
	if (applicableSimpleRule) return {
		value: applicableSimpleRule.transform(value, superJson),
		type: applicableSimpleRule.annotation
	};
};
var simpleRulesByAnnotation = {};
simpleRules.forEach((rule) => {
	simpleRulesByAnnotation[rule.annotation] = rule;
});
var untransformValue = (json, type, superJson) => {
	if (isArray$2(type)) switch (type[0]) {
		case "symbol": return symbolRule.untransform(json, type, superJson);
		case "class": return classRule.untransform(json, type, superJson);
		case "custom": return customRule.untransform(json, type, superJson);
		case "typed-array": return typedArrayRule.untransform(json, type, superJson);
		default: throw new Error("Unknown transformation: " + type);
	}
	else {
		const transformation = simpleRulesByAnnotation[type];
		if (!transformation) throw new Error("Unknown transformation: " + type);
		return transformation.untransform(json, superJson);
	}
};
var getNthKey = (value, n) => {
	if (n > value.size) throw new Error("index out of bounds");
	const keys = value.keys();
	while (n > 0) {
		keys.next();
		n--;
	}
	return keys.next().value;
};
function validatePath(path) {
	if (includes(path, "__proto__")) throw new Error("__proto__ is not allowed as a property");
	if (includes(path, "prototype")) throw new Error("prototype is not allowed as a property");
	if (includes(path, "constructor")) throw new Error("constructor is not allowed as a property");
}
var getDeep = (object, path) => {
	validatePath(path);
	for (let i = 0; i < path.length; i++) {
		const key = path[i];
		if (isSet(object)) object = getNthKey(object, +key);
		else if (isMap(object)) {
			const row = +key;
			const type = +path[++i] === 0 ? "key" : "value";
			const keyOfRow = getNthKey(object, row);
			switch (type) {
				case "key":
					object = keyOfRow;
					break;
				case "value": object = object.get(keyOfRow);
			}
		} else object = object[key];
	}
	return object;
};
var setDeep = (object, path, mapper) => {
	validatePath(path);
	if (path.length === 0) return mapper(object);
	let parent = object;
	for (let i = 0; i < path.length - 1; i++) {
		const key = path[i];
		if (isArray$2(parent)) {
			const index = +key;
			parent = parent[index];
		} else if (isPlainObject$2(parent)) parent = parent[key];
		else if (isSet(parent)) {
			const row = +key;
			parent = getNthKey(parent, row);
		} else if (isMap(parent)) {
			if (i === path.length - 2) break;
			const row = +key;
			const type = +path[++i] === 0 ? "key" : "value";
			const keyOfRow = getNthKey(parent, row);
			switch (type) {
				case "key":
					parent = keyOfRow;
					break;
				case "value": parent = parent.get(keyOfRow);
			}
		}
	}
	const lastKey = path[path.length - 1];
	if (isArray$2(parent)) parent[+lastKey] = mapper(parent[+lastKey]);
	else if (isPlainObject$2(parent)) parent[lastKey] = mapper(parent[lastKey]);
	if (isSet(parent)) {
		const oldValue = getNthKey(parent, +lastKey);
		const newValue = mapper(oldValue);
		if (oldValue !== newValue) {
			parent.delete(oldValue);
			parent.add(newValue);
		}
	}
	if (isMap(parent)) {
		const row = +path[path.length - 2];
		const keyToRow = getNthKey(parent, row);
		switch (+lastKey === 0 ? "key" : "value") {
			case "key": {
				const newKey = mapper(keyToRow);
				parent.set(newKey, parent.get(keyToRow));
				if (newKey !== keyToRow) parent.delete(keyToRow);
				break;
			}
			case "value": parent.set(keyToRow, mapper(parent.get(keyToRow)));
		}
	}
	return object;
};
function traverse(tree, walker, origin = []) {
	if (!tree) return;
	if (!isArray$2(tree)) {
		forEach(tree, (subtree, key) => traverse(subtree, walker, [...origin, ...parsePath(key)]));
		return;
	}
	const [nodeValue, children] = tree;
	if (children) forEach(children, (child, key) => {
		traverse(child, walker, [...origin, ...parsePath(key)]);
	});
	walker(nodeValue, origin);
}
function applyValueAnnotations(plain, annotations, superJson) {
	traverse(annotations, (type, path) => {
		plain = setDeep(plain, path, (v) => untransformValue(v, type, superJson));
	});
	return plain;
}
function applyReferentialEqualityAnnotations(plain, annotations) {
	function apply(identicalPaths, path) {
		const object = getDeep(plain, parsePath(path));
		identicalPaths.map(parsePath).forEach((identicalObjectPath) => {
			plain = setDeep(plain, identicalObjectPath, () => object);
		});
	}
	if (isArray$2(annotations)) {
		const [root, other] = annotations;
		root.forEach((identicalPath) => {
			plain = setDeep(plain, parsePath(identicalPath), () => plain);
		});
		if (other) forEach(other, apply);
	} else forEach(annotations, apply);
	return plain;
}
var isDeep = (object, superJson) => isPlainObject$2(object) || isArray$2(object) || isMap(object) || isSet(object) || isInstanceOfRegisteredClass(object, superJson);
function addIdentity(object, path, identities) {
	const existingSet = identities.get(object);
	if (existingSet) existingSet.push(path);
	else identities.set(object, [path]);
}
function generateReferentialEqualityAnnotations(identitites, dedupe) {
	const result = {};
	let rootEqualityPaths = void 0;
	identitites.forEach((paths) => {
		if (paths.length <= 1) return;
		if (!dedupe) paths = paths.map((path) => path.map(String)).sort((a, b) => a.length - b.length);
		const [representativePath, ...identicalPaths] = paths;
		if (representativePath.length === 0) rootEqualityPaths = identicalPaths.map(stringifyPath);
		else result[stringifyPath(representativePath)] = identicalPaths.map(stringifyPath);
	});
	if (rootEqualityPaths) if (isEmptyObject(result)) return [rootEqualityPaths];
	else return [rootEqualityPaths, result];
	else return isEmptyObject(result) ? void 0 : result;
}
var walker = (object, identities, superJson, dedupe, path = [], objectsInThisPath = [], seenObjects = /* @__PURE__ */ new Map()) => {
	const primitive = isPrimitive(object);
	if (!primitive) {
		addIdentity(object, path, identities);
		const seen = seenObjects.get(object);
		if (seen) return dedupe ? { transformedValue: null } : seen;
	}
	if (!isDeep(object, superJson)) {
		const transformed = transformValue(object, superJson);
		const result = transformed ? {
			transformedValue: transformed.value,
			annotations: [transformed.type]
		} : { transformedValue: object };
		if (!primitive) seenObjects.set(object, result);
		return result;
	}
	if (includes(objectsInThisPath, object)) return { transformedValue: null };
	const transformationResult = transformValue(object, superJson);
	const transformed = transformationResult?.value ?? object;
	const transformedValue = isArray$2(transformed) ? [] : {};
	const innerAnnotations = {};
	forEach(transformed, (value, index) => {
		if (index === "__proto__" || index === "constructor" || index === "prototype") throw new Error(`Detected property ${index}. This is a prototype pollution risk, please remove it from your object.`);
		const recursiveResult = walker(value, identities, superJson, dedupe, [...path, index], [...objectsInThisPath, object], seenObjects);
		transformedValue[index] = recursiveResult.transformedValue;
		if (isArray$2(recursiveResult.annotations)) innerAnnotations[index] = recursiveResult.annotations;
		else if (isPlainObject$2(recursiveResult.annotations)) forEach(recursiveResult.annotations, (tree, key) => {
			innerAnnotations[escapeKey(index) + "." + key] = tree;
		});
	});
	const result = isEmptyObject(innerAnnotations) ? {
		transformedValue,
		annotations: !!transformationResult ? [transformationResult.type] : void 0
	} : {
		transformedValue,
		annotations: !!transformationResult ? [transformationResult.type, innerAnnotations] : innerAnnotations
	};
	if (!primitive) seenObjects.set(object, result);
	return result;
};
function getType(payload) {
	return Object.prototype.toString.call(payload).slice(8, -1);
}
function isArray$1(payload) {
	return getType(payload) === "Array";
}
function isPlainObject$1(payload) {
	if (getType(payload) !== "Object") return false;
	const prototype = Object.getPrototypeOf(payload);
	return !!prototype && prototype.constructor === Object && prototype === Object.prototype;
}
function assignProp(carry, key, newVal, originalObject, includeNonenumerable) {
	const propType = {}.propertyIsEnumerable.call(originalObject, key) ? "enumerable" : "nonenumerable";
	if (propType === "enumerable") carry[key] = newVal;
	if (includeNonenumerable && propType === "nonenumerable") Object.defineProperty(carry, key, {
		value: newVal,
		enumerable: false,
		writable: true,
		configurable: true
	});
}
function copy(target, options = {}) {
	if (isArray$1(target)) return target.map((item) => copy(item, options));
	if (!isPlainObject$1(target)) return target;
	const props = Object.getOwnPropertyNames(target);
	const symbols = Object.getOwnPropertySymbols(target);
	return [...props, ...symbols].reduce((carry, key) => {
		if (isArray$1(options.props) && !options.props.includes(key)) return carry;
		const val = target[key];
		assignProp(carry, key, copy(val, options), target, options.nonenumerable);
		return carry;
	}, {});
}
var SuperJSON = class {
	/**
	* @param dedupeReferentialEqualities  If true, SuperJSON will make sure only one instance of referentially equal objects are serialized and the rest are replaced with `null`.
	*/
	constructor({ dedupe = false } = {}) {
		this.classRegistry = new ClassRegistry();
		this.symbolRegistry = new Registry((s) => s.description ?? "");
		this.customTransformerRegistry = new CustomTransformerRegistry();
		this.allowedErrorProps = [];
		this.dedupe = dedupe;
	}
	serialize(object) {
		const identities = /* @__PURE__ */ new Map();
		const output = walker(object, identities, this, this.dedupe);
		const res = { json: output.transformedValue };
		if (output.annotations) res.meta = {
			...res.meta,
			values: output.annotations
		};
		const equalityAnnotations = generateReferentialEqualityAnnotations(identities, this.dedupe);
		if (equalityAnnotations) res.meta = {
			...res.meta,
			referentialEqualities: equalityAnnotations
		};
		return res;
	}
	deserialize(payload) {
		const { json, meta } = payload;
		let result = copy(json);
		if (meta?.values) result = applyValueAnnotations(result, meta.values, this);
		if (meta?.referentialEqualities) result = applyReferentialEqualityAnnotations(result, meta.referentialEqualities);
		return result;
	}
	stringify(object) {
		return JSON.stringify(this.serialize(object));
	}
	parse(string) {
		return this.deserialize(JSON.parse(string));
	}
	registerClass(v, options) {
		this.classRegistry.register(v, options);
	}
	registerSymbol(v, identifier) {
		this.symbolRegistry.register(v, identifier);
	}
	registerCustom(transformer, name) {
		this.customTransformerRegistry.register({
			name,
			...transformer
		});
	}
	allowErrorProps(...props) {
		this.allowedErrorProps.push(...props);
	}
};
SuperJSON.defaultInstance = new SuperJSON();
SuperJSON.serialize = SuperJSON.defaultInstance.serialize.bind(SuperJSON.defaultInstance);
SuperJSON.deserialize = SuperJSON.defaultInstance.deserialize.bind(SuperJSON.defaultInstance);
SuperJSON.stringify = SuperJSON.defaultInstance.stringify.bind(SuperJSON.defaultInstance);
SuperJSON.parse = SuperJSON.defaultInstance.parse.bind(SuperJSON.defaultInstance);
SuperJSON.registerClass = SuperJSON.defaultInstance.registerClass.bind(SuperJSON.defaultInstance);
SuperJSON.registerSymbol = SuperJSON.defaultInstance.registerSymbol.bind(SuperJSON.defaultInstance);
SuperJSON.registerCustom = SuperJSON.defaultInstance.registerCustom.bind(SuperJSON.defaultInstance);
SuperJSON.allowErrorProps = SuperJSON.defaultInstance.allowErrorProps.bind(SuperJSON.defaultInstance);
SuperJSON.serialize;
SuperJSON.deserialize;
SuperJSON.stringify;
SuperJSON.parse;
SuperJSON.registerClass;
SuperJSON.registerCustom;
SuperJSON.registerSymbol;
SuperJSON.allowErrorProps;
target.__VUE_DEVTOOLS_KIT_MESSAGE_CHANNELS__ ??= [];
target.__VUE_DEVTOOLS_KIT_RPC_CLIENT__ ??= null;
target.__VUE_DEVTOOLS_KIT_RPC_SERVER__ ??= null;
target.__VUE_DEVTOOLS_KIT_VITE_RPC_CLIENT__ ??= null;
target.__VUE_DEVTOOLS_KIT_VITE_RPC_SERVER__ ??= null;
target.__VUE_DEVTOOLS_KIT_BROADCAST_RPC_SERVER__ ??= null;
//#endregion
//#region node_modules/vue-router/dist/devtools-CN5uWJaH.js
/*!
* vue-router v5.3.1
* (c) 2026 Eduardo San Martin Morote
* @license MIT
*/
var isBrowser = typeof document !== "undefined";
/**
* Encoding Rules (␣ = Space)
* - Path: ␣ " < > # ? { }
* - Query: ␣ " < > # & =
* - Hash: ␣ " < > `
*
* On top of that, the RFC3986 (https://tools.ietf.org/html/rfc3986#section-2.2)
* defines some extra characters to be encoded. Most browsers do not encode them
* in encodeURI https://github.com/whatwg/url/issues/369, so it may be safer to
* also encode `!'()*`. Leaving un-encoded only ASCII alphanumeric(`a-zA-Z0-9`)
* plus `-._~`. This extra safety should be applied to query by patching the
* string returned by encodeURIComponent encodeURI also encodes `[\]^`. `\`
* should be encoded to avoid ambiguity. Browsers (IE, FF, C) transform a `\`
* into a `/` if directly typed in. The _backtick_ (`````) should also be
* encoded everywhere because some browsers like FF encode it when directly
* written while others don't. Safari and IE don't encode ``"<>{}``` in hash.
*/
var HASH_RE = /#/g;
var AMPERSAND_RE = /&/g;
var SLASH_RE = /\//g;
var EQUAL_RE = /=/g;
var IM_RE = /\?/g;
var PLUS_RE = /\+/g;
/**
* NOTE: It's not clear to me if we should encode the + symbol in queries, it
* seems to be less flexible than not doing so and I can't find out the legacy
* systems requiring this for regular requests like text/html. In the standard,
* the encoding of the plus character is only mentioned for
* application/x-www-form-urlencoded
* (https://url.spec.whatwg.org/#urlencoded-parsing) and most browsers seems lo
* leave the plus character as is in queries. To be more flexible, we allow the
* plus character on the query, but it can also be manually encoded by the user.
*
* Resources:
* - https://url.spec.whatwg.org/#urlencoded-parsing
* - https://stackoverflow.com/questions/1634271/url-encoding-the-space-character-or-20
*/
var ENC_BRACKET_OPEN_RE = /%5B/g;
var ENC_BRACKET_CLOSE_RE = /%5D/g;
var ENC_CARET_RE = /%5E/g;
var ENC_BACKTICK_RE = /%60/g;
var ENC_CURLY_OPEN_RE = /%7B/g;
var ENC_PIPE_RE = /%7C/g;
var ENC_CURLY_CLOSE_RE = /%7D/g;
var ENC_SPACE_RE = /%20/g;
/**
* Encode characters that need to be encoded on the path, search and hash
* sections of the URL.
*
* @internal
* @param text - string to encode
* @returns encoded string
*/
function commonEncode(text) {
	return text == null ? "" : encodeURI("" + text).replace(ENC_PIPE_RE, "|").replace(ENC_BRACKET_OPEN_RE, "[").replace(ENC_BRACKET_CLOSE_RE, "]");
}
/**
* Encode characters that need to be encoded on the hash section of the URL.
*
* @param text - string to encode
* @returns encoded string
*/
function encodeHash(text) {
	return commonEncode(text).replace(ENC_CURLY_OPEN_RE, "{").replace(ENC_CURLY_CLOSE_RE, "}").replace(ENC_CARET_RE, "^");
}
/**
* Encode characters that need to be encoded query values on the query
* section of the URL.
*
* @param text - string to encode
* @returns encoded string
*/
function encodeQueryValue(text) {
	return commonEncode(text).replace(PLUS_RE, "%2B").replace(ENC_SPACE_RE, "+").replace(HASH_RE, "%23").replace(AMPERSAND_RE, "%26").replace(ENC_BACKTICK_RE, "`").replace(ENC_CURLY_OPEN_RE, "{").replace(ENC_CURLY_CLOSE_RE, "}").replace(ENC_CARET_RE, "^");
}
/**
* Like `encodeQueryValue` but also encodes the `=` character.
*
* @param text - string to encode
*/
function encodeQueryKey(text) {
	return encodeQueryValue(text).replace(EQUAL_RE, "%3D");
}
/**
* Encode characters that need to be encoded on the path section of the URL.
*
* @param text - string to encode
* @returns encoded string
*/
function encodePath(text) {
	return commonEncode(text).replace(HASH_RE, "%23").replace(IM_RE, "%3F");
}
/**
* Encode characters that need to be encoded on the path section of the URL as a
* param. This function encodes everything {@link encodePath} does plus the
* slash (`/`) character. If `text` is `null` or `undefined`, returns an empty
* string instead.
*
* @param text - string to encode
* @returns encoded string
*/
function encodeParam(text) {
	return encodePath(text).replace(SLASH_RE, "%2F");
}
function decode(text) {
	if (text == null) return null;
	try {
		return decodeURIComponent("" + text);
	} catch {
		diagnostics.VUE_ROUTER_R0080({ text: "" + text });
	}
	return "" + text;
}
var TRAILING_SLASH_RE = /\/$/;
var removeTrailingSlash = (path) => path.replace(TRAILING_SLASH_RE, "");
/**
* Transforms a URI into a normalized history location
*
* @param parseQuery
* @param location - URI to normalize
* @param currentLocation - current absolute location. Allows resolving relative
* paths. Must start with `/`. Defaults to `/`
* @returns a normalized history location
*/
function parseURL(parseQuery, location, currentLocation = "/") {
	let path, query = {}, searchString = "", hash = "";
	const hashPos = location.indexOf("#");
	let searchPos = location.indexOf("?");
	searchPos = hashPos >= 0 && searchPos > hashPos ? -1 : searchPos;
	if (searchPos >= 0) {
		path = location.slice(0, searchPos);
		searchString = location.slice(searchPos, hashPos > 0 ? hashPos : location.length);
		query = parseQuery(searchString.slice(1));
	}
	if (hashPos >= 0) {
		path = path || location.slice(0, hashPos);
		hash = location.slice(hashPos, location.length);
	}
	path = resolveRelativePath(path != null ? path : location, currentLocation);
	return {
		fullPath: path + searchString + hash,
		path,
		query,
		hash: decode(hash)
	};
}
/**
* Stringifies a URL object
*
* @param stringifyQuery
* @param location
*/
function stringifyURL(stringifyQuery, location) {
	const query = location.query ? stringifyQuery(location.query) : "";
	return location.path + (query && "?") + query + (location.hash || "");
}
/**
* Strips off the base from the beginning of a location.pathname in a non-case-sensitive way.
*
* @param pathname - location.pathname
* @param base - base to strip off
*/
function stripBase(pathname, base) {
	if (!base || !pathname.toLowerCase().startsWith(base.toLowerCase())) return pathname;
	return pathname.slice(base.length) || "/";
}
/**
* Checks if two RouteLocation are equal. This means that both locations are
* pointing towards the same {@link RouteRecord} and that all `params`, `query`
* parameters and `hash` are the same
*
* @param stringifyQuery - A function that takes a query object of type LocationQueryRaw and returns a string representation of it.
* @param a - first {@link RouteLocation}
* @param b - second {@link RouteLocation}
*/
function isSameRouteLocation(stringifyQuery, a, b) {
	const aLastIndex = a.matched.length - 1;
	const bLastIndex = b.matched.length - 1;
	return aLastIndex > -1 && aLastIndex === bLastIndex && isSameRouteRecord(a.matched[aLastIndex], b.matched[bLastIndex]) && isSameRouteLocationParams(a.params, b.params) && stringifyQuery(a.query) === stringifyQuery(b.query) && a.hash === b.hash;
}
/**
* Check if two `RouteRecords` are equal. Takes into account aliases: they are
* considered equal to the `RouteRecord` they are aliasing.
*
* @param a - first {@link RouteRecord}
* @param b - second {@link RouteRecord}
*/
function isSameRouteRecord(a, b) {
	return (a.aliasOf || a) === (b.aliasOf || b);
}
function isSameRouteLocationParams(a, b) {
	if (Object.keys(a).length !== Object.keys(b).length) return false;
	for (var key in a) if (!isSameRouteLocationParamsValue(a[key], b[key])) return false;
	return true;
}
function isSameRouteLocationParamsValue(a, b) {
	return isArray(a) ? isEquivalentArray(a, b) : isArray(b) ? isEquivalentArray(b, a) : (a && a.valueOf()) === (b && b.valueOf());
}
/**
* Check if two arrays are the same or if an array with one single entry is the
* same as another primitive value. Used to check query and parameters
*
* @param a - array of values
* @param b - array of values or a single value
*/
function isEquivalentArray(a, b) {
	return isArray(b) ? a.length === b.length && a.every((value, i) => value === b[i]) : a.length === 1 && a[0] === b;
}
/**
* Resolves a relative path that starts with `.`.
*
* @param to - path location we are resolving
* @param from - currentLocation.path, should start with `/`
*/
function resolveRelativePath(to, from) {
	if (isAbsolutePath(to)) return to;
	if (!isAbsolutePath(from)) {
		diagnostics.VUE_ROUTER_R0070({
			to,
			from
		});
		return to;
	}
	if (!to) return from;
	const fromSegments = from.split("/");
	const toSegments = to.split("/");
	const lastToSegment = toSegments[toSegments.length - 1];
	if (lastToSegment === ".." || lastToSegment === ".") toSegments.push("");
	let position = fromSegments.length - 1;
	let toPosition;
	let segment;
	for (toPosition = 0; toPosition < toSegments.length; toPosition++) {
		segment = toSegments[toPosition];
		if (segment === ".") continue;
		if (segment === "..") {
			if (position > 1) position--;
		} else break;
	}
	return fromSegments.slice(0, position).join("/") + "/" + toSegments.slice(toPosition).join("/");
}
/**
* Initial route location where the router is. Can be used in navigation guards
* to differentiate the initial navigation.
*
* @example
* ```js
* import { START_LOCATION } from 'vue-router'
*
* router.beforeEach((to, from) => {
*   if (from === START_LOCATION) {
*     // initial navigation
*   }
* })
* ```
*/
var START_LOCATION_NORMALIZED = {
	path: "/",
	name: void 0,
	params: {},
	query: {},
	hash: "",
	fullPath: "/",
	matched: [],
	meta: {},
	redirectedFrom: void 0
};
/**
* Normalizes a base by removing any trailing slash and reading the base tag if
* present.
*
* @param base - base to normalize
*/
function normalizeBase(base) {
	if (!base) {
		if (isBrowser) {
			const baseEl = document.querySelector("base");
			base = baseEl && baseEl.getAttribute("href") || "/";
			base = base.replace(/^\w+:\/\/[^/]+/, "");
		} else base = "/";
	}
	if (base[0] !== "/" && base[0] !== "#") base = "/" + base;
	return removeTrailingSlash(base);
}
var BEFORE_HASH_RE = /^[^#]+#/;
function createHref(base, location) {
	return base.replace(BEFORE_HASH_RE, "#") + location;
}
function getElementPosition(el, offset) {
	const docRect = document.documentElement.getBoundingClientRect();
	const elRect = el.getBoundingClientRect();
	return {
		behavior: offset.behavior,
		left: elRect.left - docRect.left - (offset.left || 0),
		top: elRect.top - docRect.top - (offset.top || 0)
	};
}
var computeScrollPosition = () => history.scrollRestoration === "manual" ? {
	left: window.scrollX,
	top: window.scrollY
} : null;
function scrollToPosition(position) {
	let scrollToOptions;
	if ("el" in position) {
		const positionEl = position.el;
		const isIdSelector = typeof positionEl === "string" && positionEl.startsWith("#");
		/**
		* `id`s can accept pretty much any characters, including CSS combinators
		* like `>` or `~`. It's still possible to retrieve elements using
		* `document.getElementById('~')` but it needs to be escaped when using
		* `document.querySelector('#\\~')` for it to be valid. The only
		* requirements for `id`s are them to be unique on the page and to not be
		* empty (`id=""`). Because of that, when passing an id selector, it should
		* be properly escaped for it to work with `querySelector`. We could check
		* for the id selector to be simple (no CSS combinators `+ >~`) but that
		* would make things inconsistent since they are valid characters for an
		* `id` but would need to be escaped when using `querySelector`, breaking
		* their usage and ending up in no selector returned. Selectors need to be
		* escaped:
		*
		* - `#1-thing` becomes `#\31 -thing`
		* - `#with~symbols` becomes `#with\\~symbols`
		*
		* - More information about  the topic can be found at
		*   https://mathiasbynens.be/notes/html5-id-class.
		* - Practical example: https://mathiasbynens.be/demo/html5-id
		*/
		if (typeof position.el === "string") {
			if (!isIdSelector || !document.getElementById(position.el.slice(1))) try {
				const foundEl = document.querySelector(position.el);
				if (isIdSelector && foundEl) {
					diagnostics.VUE_ROUTER_R0040({ el: position.el });
					return;
				}
			} catch {
				diagnostics.VUE_ROUTER_R0041({ el: position.el });
				return;
			}
		}
		const el = typeof positionEl === "string" ? isIdSelector ? document.getElementById(positionEl.slice(1)) : document.querySelector(positionEl) : positionEl;
		if (!el) {
			diagnostics.VUE_ROUTER_R0042({ el: position.el });
			return;
		}
		scrollToOptions = getElementPosition(el, position);
	} else scrollToOptions = position;
	if ("scrollBehavior" in document.documentElement.style) window.scrollTo(scrollToOptions);
	else window.scrollTo(scrollToOptions.left != null ? scrollToOptions.left : window.scrollX, scrollToOptions.top != null ? scrollToOptions.top : window.scrollY);
}
function getScrollKey(path, delta) {
	return (history.state ? history.state.position - delta : -1) + path;
}
var scrollPositions = /* @__PURE__ */ new Map();
function saveScrollPosition(key) {
	scrollPositions.set(key, computeScrollPosition());
}
function getSavedScrollPosition(key) {
	const scroll = scrollPositions.get(key);
	scrollPositions.delete(key);
	return scroll;
}
/**
* ScrollBehavior instance used by the router to compute and restore the scroll
* position when navigating.
*/
function isRouteLocation(route) {
	return typeof route === "string" || route && typeof route === "object";
}
function isRouteName(name) {
	return typeof name === "string" || typeof name === "symbol";
}
/**
* Transforms a queryString into a {@link LocationQuery} object. Accept both, a
* version with the leading `?` and without Should work as URLSearchParams

* @internal
*
* @param search - search string to parse
* @returns a query object
*/
function parseQuery(search) {
	const query = {};
	if (search === "" || search === "?") return query;
	const searchParams = (search[0] === "?" ? search.slice(1) : search).split("&");
	for (let i = 0; i < searchParams.length; ++i) {
		const searchParam = searchParams[i].replace(PLUS_RE, " ");
		const eqPos = searchParam.indexOf("=");
		const key = decode(eqPos < 0 ? searchParam : searchParam.slice(0, eqPos));
		const value = eqPos < 0 ? null : decode(searchParam.slice(eqPos + 1));
		if (key in query) {
			let currentValue = query[key];
			if (!isArray(currentValue)) currentValue = query[key] = [currentValue];
			currentValue.push(value);
		} else query[key] = value;
	}
	return query;
}
/**
* Stringifies a {@link LocationQueryRaw} object. Like `URLSearchParams`, it
* doesn't prepend a `?`
*
* @internal
*
* @param query - query object to stringify
* @returns string version of the query without the leading `?`
*/
function stringifyQuery(query) {
	let search = "";
	for (let key in query) {
		const value = query[key];
		key = encodeQueryKey(key);
		if (value == null) {
			if (value !== void 0) search += (search.length ? "&" : "") + key;
			continue;
		}
		(isArray(value) ? value.map((v) => v && encodeQueryValue(v)) : [value && encodeQueryValue(value)]).forEach((value) => {
			if (value !== void 0) {
				search += (search.length ? "&" : "") + key;
				if (value != null) search += "=" + value;
			}
		});
	}
	return search;
}
/**
* Transforms a {@link LocationQueryRaw} into a {@link LocationQuery} by casting
* numbers into strings, removing keys with an undefined value and replacing
* undefined with null in arrays
*
* @param query - query object to normalize
* @returns a normalized query object
*/
function normalizeQuery(query) {
	const normalizedQuery = {};
	for (const key in query) {
		const value = query[key];
		if (value !== void 0) normalizedQuery[key] = isArray(value) ? value.map((v) => v == null ? null : "" + v) : value == null ? value : "" + value;
	}
	return normalizedQuery;
}
/**
* Create a list of callbacks that can be reset. Used to create before and after navigation guards list
*/
function useCallbacks() {
	let handlers = [];
	function add(handler) {
		handlers.push(handler);
		return () => {
			const i = handlers.indexOf(handler);
			if (i > -1) handlers.splice(i, 1);
		};
	}
	function reset() {
		handlers = [];
	}
	return {
		add,
		list: () => handlers.slice(),
		reset
	};
}
function registerGuard(activeRecordRef, name, guard) {
	const record = activeRecordRef.value;
	if (!record) {
		{
			const fnName = name === "updateGuards" ? "onBeforeRouteUpdate" : "onBeforeRouteLeave";
			diagnostics.VUE_ROUTER_R0020({ fn: fnName });
		}
		return;
	}
	let currentRecord = record;
	const removeFromList = () => {
		currentRecord[name].delete(guard);
	};
	onUnmounted(removeFromList);
	onDeactivated(removeFromList);
	onActivated(() => {
		const newRecord = activeRecordRef.value;
		if (!newRecord) diagnostics.VUE_ROUTER_R0021();
		if (newRecord) currentRecord = newRecord;
		currentRecord[name].add(guard);
	});
	currentRecord[name].add(guard);
}
/**
* Add a navigation guard that triggers whenever the component for the current
* location is about to be left. Similar to {@link beforeRouteLeave} but can be
* used in any component. The guard is removed when the component is unmounted.
*
* @param leaveGuard - {@link NavigationGuard}
*/
function onBeforeRouteLeave(leaveGuard) {
	if (!getCurrentInstance()) {
		diagnostics.VUE_ROUTER_R0022({ fn: "onBeforeRouteLeave" });
		return;
	}
	registerGuard(inject(matchedRouteKey, {}), "leaveGuards", leaveGuard);
}
/**
* Add a navigation guard that triggers whenever the current location is about
* to be updated. Similar to {@link beforeRouteUpdate} but can be used in any
* component. The guard is removed when the component is unmounted.
*
* @param updateGuard - {@link NavigationGuard}
*/
function onBeforeRouteUpdate(updateGuard) {
	if (!getCurrentInstance()) {
		diagnostics.VUE_ROUTER_R0022({ fn: "onBeforeRouteUpdate" });
		return;
	}
	registerGuard(inject(matchedRouteKey, {}), "updateGuards", updateGuard);
}
function guardToPromiseFn(guard, to, from, record, name, runWithContext = (fn) => fn()) {
	const enterCallbackArray = record && (record.enterCallbacks[name] = record.enterCallbacks[name] || []);
	return () => new Promise((resolve, reject) => {
		const next = (valid) => {
			if (valid === false) reject(createRouterError(4, {
				from,
				to
			}));
			else if (valid instanceof Error) reject(valid);
			else if (isRouteLocation(valid)) reject(createRouterError(2, {
				from: to,
				to: valid
			}));
			else {
				if (enterCallbackArray && record.enterCallbacks[name] === enterCallbackArray && typeof valid === "function") enterCallbackArray.push(valid);
				resolve();
			}
		};
		const guardReturn = runWithContext(() => guard.call(record && record.instances[name], to, from, withDeprecationWarning(canOnlyBeCalledOnce(next, to, from))));
		let guardCall = Promise.resolve(guardReturn);
		if (guard.length < 3) guardCall = guardCall.then(next);
		if (guard.length > 2) {
			const guardInfo = {
				name: guard.name,
				guard: guard.toString()
			};
			if (typeof guardReturn === "object" && "then" in guardReturn) guardCall = guardCall.then((resolvedValue) => {
				if (!next._called) {
					diagnostics.VUE_ROUTER_R0023(guardInfo);
					return Promise.reject(/* @__PURE__ */ new Error("Invalid navigation guard"));
				}
				return resolvedValue;
			});
			else if (guardReturn !== void 0) {
				if (!next._called) {
					diagnostics.VUE_ROUTER_R0023(guardInfo);
					reject(/* @__PURE__ */ new Error("Invalid navigation guard"));
					return;
				}
			}
		}
		guardCall.catch((err) => reject(err));
	});
}
/**
* Wraps the next callback to warn when it is used. Dev-only: when __DEV__ is
* false (production builds), this branch is dead code and is stripped from the
* bundle.
*
* @internal
*/
function withDeprecationWarning(next) {
	let warned = false;
	return function() {
		if (!warned) {
			warned = true;
			diagnostics.VUE_ROUTER_R0025();
		}
		return next.apply(this, arguments);
	};
}
function canOnlyBeCalledOnce(next, to, from) {
	let called = 0;
	return function() {
		if (called++ === 1) diagnostics.VUE_ROUTER_R0024({
			from: from.fullPath,
			to: to.fullPath
		});
		next._called = true;
		if (called === 1) next.apply(null, arguments);
	};
}
function extractComponentsGuards(matched, guardType, to, from, runWithContext = (fn) => fn()) {
	const guards = [];
	for (const record of matched) {
		if (!record.components && record.children && !record.children.length) diagnostics.VUE_ROUTER_R0026({ path: record.path });
		for (const name in record.components) {
			let rawComponent = record.components[name];
			if (!rawComponent || typeof rawComponent !== "object" && typeof rawComponent !== "function") {
				diagnostics.VUE_ROUTER_R0027({
					name,
					path: record.path,
					received: String(rawComponent)
				});
				throw new Error("Invalid route component");
			} else if ("then" in rawComponent) {
				diagnostics.VUE_ROUTER_R0028({
					name,
					path: record.path
				});
				const promise = rawComponent;
				rawComponent = () => promise;
			} else if (rawComponent.__asyncLoader && !rawComponent.__warnedDefineAsync) {
				rawComponent.__warnedDefineAsync = true;
				diagnostics.VUE_ROUTER_R0029({
					name,
					path: record.path
				});
			}
			if (guardType !== "beforeRouteEnter" && !record.instances[name]) continue;
			if (isRouteComponent(rawComponent)) {
				const guard = (rawComponent.__vccOpts || rawComponent)[guardType];
				guard && guards.push(guardToPromiseFn(guard, to, from, record, name, runWithContext));
			} else {
				let componentPromise = rawComponent();
				if (!("catch" in componentPromise)) {
					diagnostics.VUE_ROUTER_R0030({
						name,
						path: record.path
					});
					componentPromise = Promise.resolve(componentPromise);
				}
				guards.push(() => componentPromise.then((resolved) => {
					if (!resolved) throw new Error(`Couldn't resolve component "${name}" at "${record.path}"`);
					const resolvedComponent = isESModule(resolved) ? resolved.default : resolved;
					record.mods[name] = resolved;
					record.components[name] = resolvedComponent;
					const guard = (resolvedComponent.__vccOpts || resolvedComponent)[guardType];
					return guard && guardToPromiseFn(guard, to, from, record, name, runWithContext)();
				}));
			}
		}
	}
	return guards;
}
/**
* Ensures a route is loaded, so it can be passed as o prop to `<RouterView>`.
*
* @param route - resolved route to load
*/
function loadRouteLocation(route) {
	return route.matched.every((record) => record.redirect) ? Promise.reject(/* @__PURE__ */ new Error("Cannot load a route that redirects.")) : Promise.all(route.matched.map((record) => record.components && Promise.all(Object.keys(record.components).reduce((promises, name) => {
		const rawComponent = record.components[name];
		if (typeof rawComponent === "function" && !("displayName" in rawComponent)) promises.push(rawComponent().then((resolved) => {
			if (!resolved) return Promise.reject(/* @__PURE__ */ new Error(`Couldn't resolve component "${name}" at "${record.path}". Ensure you passed a function that returns a promise.`));
			const resolvedComponent = isESModule(resolved) ? resolved.default : resolved;
			record.mods[name] = resolved;
			record.components[name] = resolvedComponent;
		}));
		return promises;
	}, [])))).then(() => route);
}
/**
* Split the leaving, updating, and entering records.
* @internal
*
* @param  to - Location we are navigating to
* @param from - Location we are navigating from
*/
function extractChangingRecords(to, from) {
	const leavingRecords = [];
	const updatingRecords = [];
	const enteringRecords = [];
	const len = Math.max(from.matched.length, to.matched.length);
	for (let i = 0; i < len; i++) {
		const recordFrom = from.matched[i];
		if (recordFrom) {
			if (to.matched.find((record) => isSameRouteRecord(record, recordFrom))) updatingRecords.push(recordFrom);
			else leavingRecords.push(recordFrom);
		}
		const recordTo = to.matched[i];
		if (recordTo) {
			if (!from.matched.find((record) => isSameRouteRecord(record, recordTo))) enteringRecords.push(recordTo);
		}
	}
	return [
		leavingRecords,
		updatingRecords,
		enteringRecords
	];
}
/**
* Copies a route location and removes any problematic properties that cannot be shown in devtools (e.g. Vue instances).
*
* @param routeLocation - routeLocation to format
* @param tooltip - optional tooltip
* @returns a copy of the routeLocation
*/
function formatRouteLocation(routeLocation, tooltip) {
	const copy = assign({}, routeLocation, { matched: routeLocation.matched.map((matched) => omit(matched, [
		"instances",
		"children",
		"aliasOf"
	])) });
	return { _custom: {
		type: null,
		readOnly: true,
		display: routeLocation.fullPath,
		tooltip,
		value: copy
	} };
}
function formatDisplay(display) {
	return { _custom: { display } };
}
var routerId = 0;
function addDevtools(app, router, matcher) {
	if (router.__hasDevtools) return;
	router.__hasDevtools = true;
	const id = routerId++;
	setupDevToolsPlugin({
		id: "org.vuejs.router" + (id ? "." + id : ""),
		label: "Vue Router",
		packageName: "vue-router",
		homepage: "https://router.vuejs.org",
		logo: "https://router.vuejs.org/logo.png",
		componentStateTypes: ["Routing"],
		app
	}, (api) => {
		api.on.inspectComponent((payload) => {
			if (payload.instanceData) payload.instanceData.state.push({
				type: "Routing",
				key: "$route",
				editable: false,
				value: formatRouteLocation(router.currentRoute.value, "Current Route")
			});
		});
		api.on.visitComponentTree(({ treeNode: node, componentInstance }) => {
			if (componentInstance.__vrv_devtools) {
				const info = componentInstance.__vrv_devtools;
				node.tags.push({
					label: (info.name ? `${info.name.toString()}: ` : "") + info.path,
					textColor: 0,
					tooltip: "This component is rendered by &lt;router-view&gt;",
					backgroundColor: PINK_500
				});
			}
			if (isArray(componentInstance.__vrl_devtools)) {
				componentInstance.__devtoolsApi = api;
				componentInstance.__vrl_devtools.forEach((devtoolsData) => {
					let label = devtoolsData.route.path;
					let backgroundColor = ORANGE_400;
					let tooltip = "";
					let textColor = 0;
					if (devtoolsData.error) {
						label = devtoolsData.error;
						backgroundColor = RED_100;
						textColor = RED_700;
					} else if (devtoolsData.isExactActive) {
						backgroundColor = LIME_500;
						tooltip = "This is exactly active";
					} else if (devtoolsData.isActive) {
						backgroundColor = BLUE_600;
						tooltip = "This link is active";
					}
					node.tags.push({
						label,
						textColor,
						tooltip,
						backgroundColor
					});
				});
			}
		});
		watch(router.currentRoute, () => {
			refreshRoutesView();
			api.notifyComponentUpdate();
			api.sendInspectorTree(routerInspectorId);
			api.sendInspectorState(routerInspectorId);
		});
		const navigationsLayerId = "router:navigations:" + id;
		api.addTimelineLayer({
			id: navigationsLayerId,
			label: `Router${id ? " " + id : ""} Navigations`,
			color: 4237508
		});
		router.onError((error, to) => {
			api.addTimelineEvent({
				layerId: navigationsLayerId,
				event: {
					title: "Error during Navigation",
					subtitle: to.fullPath,
					logType: "error",
					time: api.now(),
					data: { error },
					groupId: to.meta.__navigationId
				}
			});
		});
		let navigationId = 0;
		router.beforeEach((to, from) => {
			const data = {
				guard: formatDisplay("beforeEach"),
				from: formatRouteLocation(from, "Current Location during this navigation"),
				to: formatRouteLocation(to, "Target location")
			};
			Object.defineProperty(to.meta, "__navigationId", { value: navigationId++ });
			api.addTimelineEvent({
				layerId: navigationsLayerId,
				event: {
					time: api.now(),
					title: "Start of navigation",
					subtitle: to.fullPath,
					data,
					groupId: to.meta.__navigationId
				}
			});
		});
		router.afterEach((to, from, failure) => {
			const data = { guard: formatDisplay("afterEach") };
			if (failure) {
				data.failure = { _custom: {
					type: Error,
					readOnly: true,
					display: failure ? failure.message : "",
					tooltip: "Navigation Failure",
					value: failure
				} };
				data.status = formatDisplay("❌");
			} else data.status = formatDisplay("✅");
			data.from = formatRouteLocation(from, "Current Location during this navigation");
			data.to = formatRouteLocation(to, "Target location");
			api.addTimelineEvent({
				layerId: navigationsLayerId,
				event: {
					title: "End of navigation",
					subtitle: to.fullPath,
					time: api.now(),
					data,
					logType: failure ? "warning" : "default",
					groupId: to.meta.__navigationId
				}
			});
		});
		/**
		* Inspector of Existing routes
		*/
		const routerInspectorId = "router-inspector:" + id;
		api.addInspector({
			id: routerInspectorId,
			label: "Routes" + (id ? " " + id : ""),
			icon: "book",
			treeFilterPlaceholder: "Search routes"
		});
		function refreshRoutesView() {
			if (!activeRoutesPayload) return;
			const payload = activeRoutesPayload;
			let routes = matcher.getRoutes().filter((route) => !route.parent || !route.parent.record.components);
			routes.forEach(resetMatchStateOnRouteRecord);
			if (payload.filter) routes = routes.filter((route) => isRouteMatching(route, payload.filter.toLowerCase()));
			routes.forEach((route) => markRouteRecordActive(route, router.currentRoute.value));
			payload.rootNodes = routes.map(formatRouteRecordForInspector);
		}
		let activeRoutesPayload;
		api.on.getInspectorTree((payload) => {
			activeRoutesPayload = payload;
			if (payload.app === app && payload.inspectorId === routerInspectorId) refreshRoutesView();
		});
		/**
		* Display information about the currently selected route record
		*/
		api.on.getInspectorState((payload) => {
			if (payload.app === app && payload.inspectorId === routerInspectorId) {
				const route = matcher.getRoutes().find((route) => route.record.__vd_id === payload.nodeId);
				if (route) payload.state = { options: formatRouteRecordMatcherForStateInspector(route) };
			}
		});
		api.sendInspectorTree(routerInspectorId);
		api.sendInspectorState(routerInspectorId);
	});
}
function modifierForKey(key) {
	if (key.optional) return key.repeatable ? "*" : "?";
	else return key.repeatable ? "+" : "";
}
function formatRouteRecordMatcherForStateInspector(route) {
	const { record } = route;
	const fields = [{
		editable: false,
		key: "path",
		value: record.path
	}];
	if (record.name != null) fields.push({
		editable: false,
		key: "name",
		value: record.name
	});
	fields.push({
		editable: false,
		key: "regexp",
		value: route.re
	});
	if (route.keys.length) fields.push({
		editable: false,
		key: "keys",
		value: { _custom: {
			type: null,
			readOnly: true,
			display: route.keys.map((key) => `${key.name}${modifierForKey(key)}`).join(" "),
			tooltip: "Param keys",
			value: route.keys
		} }
	});
	if (record.redirect != null) fields.push({
		editable: false,
		key: "redirect",
		value: record.redirect
	});
	if (route.alias.length) fields.push({
		editable: false,
		key: "aliases",
		value: route.alias.map((alias) => alias.record.path)
	});
	if (Object.keys(route.record.meta).length) fields.push({
		editable: false,
		key: "meta",
		value: route.record.meta
	});
	fields.push({
		key: "score",
		editable: false,
		value: { _custom: {
			type: null,
			readOnly: true,
			display: route.score.map((score) => score.join(", ")).join(" | "),
			tooltip: "Score used to sort routes",
			value: route.score
		} }
	});
	return fields;
}
/**
* Extracted from tailwind palette
*/
var PINK_500 = 15485081;
var BLUE_600 = 2450411;
var LIME_500 = 8702998;
var CYAN_400 = 2282478;
var ORANGE_400 = 16486972;
var DARK = 6710886;
var RED_100 = 16704226;
var RED_700 = 12131356;
function formatRouteRecordForInspector(route) {
	const tags = [];
	const { record } = route;
	if (record.name != null) tags.push({
		label: String(record.name),
		textColor: 0,
		backgroundColor: CYAN_400
	});
	if (record.aliasOf) tags.push({
		label: "alias",
		textColor: 0,
		backgroundColor: ORANGE_400
	});
	if (route.__vd_match) tags.push({
		label: "matches",
		textColor: 0,
		backgroundColor: PINK_500
	});
	if (route.__vd_exactActive) tags.push({
		label: "exact",
		textColor: 0,
		backgroundColor: LIME_500
	});
	if (route.__vd_active) tags.push({
		label: "active",
		textColor: 0,
		backgroundColor: BLUE_600
	});
	if (record.redirect) tags.push({
		label: typeof record.redirect === "string" ? `redirect: ${record.redirect}` : "redirects",
		textColor: 16777215,
		backgroundColor: DARK
	});
	let id = record.__vd_id;
	if (id == null) {
		id = String(routeRecordId++);
		record.__vd_id = id;
	}
	return {
		id,
		label: record.path,
		tags,
		children: route.children.map(formatRouteRecordForInspector)
	};
}
var routeRecordId = 0;
var EXTRACT_REGEXP_RE = /^\/(.*)\/([a-z]*)$/;
function markRouteRecordActive(route, currentRoute) {
	const isExactActive = currentRoute.matched.length && isSameRouteRecord(currentRoute.matched[currentRoute.matched.length - 1], route.record);
	route.__vd_exactActive = route.__vd_active = isExactActive;
	if (!isExactActive) route.__vd_active = currentRoute.matched.some((match) => isSameRouteRecord(match, route.record));
	route.children.forEach((childRoute) => markRouteRecordActive(childRoute, currentRoute));
}
function resetMatchStateOnRouteRecord(route) {
	route.__vd_match = false;
	route.children.forEach(resetMatchStateOnRouteRecord);
}
function isRouteMatching(route, filter) {
	const found = String(route.re).match(EXTRACT_REGEXP_RE);
	route.__vd_match = false;
	if (!found || found.length < 3) return false;
	if (new RegExp(found[1].replace(/\$$/, ""), found[2]).test(filter)) {
		route.children.forEach((child) => isRouteMatching(child, filter));
		if (route.record.path !== "/" || filter === "/") {
			route.__vd_match = route.re.test(filter);
			return true;
		}
		return false;
	}
	const path = route.record.path.toLowerCase();
	const decodedPath = decode(path);
	if (!isAbsolutePath(filter) && (decodedPath.includes(filter) || path.includes(filter))) return true;
	if (decodedPath.startsWith(filter) || path.startsWith(filter)) return true;
	if (route.record.name && String(route.record.name).includes(filter)) return true;
	return route.children.some((child) => isRouteMatching(child, filter));
}
function omit(obj, keys) {
	const ret = {};
	for (const key in obj) if (!keys.includes(key)) ret[key] = obj[key];
	return ret;
}
//#endregion
//#region node_modules/vue-router/dist/vue-router.js
/*!
* vue-router v5.3.1
* (c) 2026 Eduardo San Martin Morote
* @license MIT
*/
var createBaseLocation = () => location.protocol + "//" + location.host;
/**
* Creates a normalized history location from a window.location object
* @param base - The base path
* @param location - The window.location object
*/
function createCurrentLocation(base, location) {
	const { pathname, search, hash } = location;
	const hashPos = base.indexOf("#");
	if (hashPos > -1) {
		let slicePos = hash.includes(base.slice(hashPos)) ? base.slice(hashPos).length : 1;
		let pathFromHash = hash.slice(slicePos);
		if (pathFromHash[0] !== "/") pathFromHash = "/" + pathFromHash;
		return stripBase(pathFromHash, "");
	}
	return stripBase(pathname, base) + search + hash;
}
function useHistoryListeners(base, historyState, currentLocation, replace) {
	let listeners = [];
	let teardowns = [];
	let pauseState = null;
	const popStateHandler = ({ state }) => {
		const to = createCurrentLocation(base, location);
		const from = currentLocation.value;
		const fromState = historyState.value;
		let delta = 0;
		if (state) {
			currentLocation.value = to;
			historyState.value = state;
			if (pauseState && pauseState === from) {
				pauseState = null;
				return;
			}
			delta = fromState ? state.position - fromState.position : 0;
		} else replace(to);
		listeners.forEach((listener) => {
			listener(currentLocation.value, from, {
				delta,
				type: "pop",
				direction: delta ? delta > 0 ? "forward" : "back" : ""
			});
		});
	};
	function pauseListeners() {
		pauseState = currentLocation.value;
	}
	function listen(callback) {
		listeners.push(callback);
		const teardown = () => {
			const index = listeners.indexOf(callback);
			if (index > -1) listeners.splice(index, 1);
		};
		teardowns.push(teardown);
		return teardown;
	}
	function beforeUnloadListener() {
		const { history } = window;
		if (!history.state) return;
		history.replaceState(assign({}, history.state, { scroll: computeScrollPosition() }), "");
	}
	function destroy() {
		for (const teardown of teardowns) teardown();
		teardowns = [];
		window.removeEventListener("popstate", popStateHandler);
		window.removeEventListener("pagehide", beforeUnloadListener);
	}
	window.addEventListener("popstate", popStateHandler);
	window.addEventListener("pagehide", beforeUnloadListener);
	return {
		pauseListeners,
		listen,
		destroy
	};
}
/**
* Creates a state object
*/
function buildState(back, current, forward, replaced = false) {
	return {
		back,
		current,
		forward,
		replaced,
		position: window.history.length,
		scroll: null
	};
}
function useHistoryStateNavigation(base) {
	const { history, location } = window;
	const currentLocation = { value: createCurrentLocation(base, location) };
	const historyState = { value: history.state };
	if (!historyState.value) changeLocation(currentLocation.value, {
		back: null,
		current: currentLocation.value,
		forward: null,
		position: history.length - 1,
		replaced: true,
		scroll: null
	}, true);
	function changeLocation(to, state, replace) {
		/**
		* if a base tag is provided, and we are on a normal domain, we have to
		* respect the provided `base` attribute because pushState() will use it and
		* potentially erase anything before the `#` like at
		* https://github.com/vuejs/router/issues/685 where a base of
		* `/folder/#` but a base of `/` would erase the `/folder/` section. If
		* there is no host, the `<base>` tag makes no sense and if there isn't a
		* base tag we can just use everything after the `#`.
		*/
		const hashIndex = base.indexOf("#");
		const url = hashIndex > -1 ? (location.host && document.querySelector("base") ? base : base.slice(hashIndex)) + to : createBaseLocation() + base + to;
		try {
			history[replace ? "replaceState" : "pushState"](state, "", url);
			historyState.value = state;
		} catch (err) {
			diagnostics.VUE_ROUTER_R0120({ cause: err });
			location[replace ? "replace" : "assign"](url);
		}
	}
	function replace(to, data) {
		changeLocation(to, assign({}, history.state, buildState(historyState.value.back, to, historyState.value.forward, true), data, { position: historyState.value.position }), true);
		currentLocation.value = to;
	}
	function push(to, data) {
		const currentState = assign({}, historyState.value, history.state, {
			forward: to,
			scroll: computeScrollPosition()
		});
		if (!history.state) diagnostics.VUE_ROUTER_R0121();
		changeLocation(currentState.current, currentState, true);
		changeLocation(to, assign({}, buildState(currentLocation.value, to, null), { position: currentState.position + 1 }, data), false);
		currentLocation.value = to;
	}
	return {
		location: currentLocation,
		state: historyState,
		push,
		replace
	};
}
/**
* Creates an HTML5 history. Most common history for single page applications.
*
* @param base -
*/
function createWebHistory(base) {
	base = normalizeBase(base);
	const historyNavigation = useHistoryStateNavigation(base);
	const historyListeners = useHistoryListeners(base, historyNavigation.state, historyNavigation.location, historyNavigation.replace);
	function go(delta, triggerListeners = true) {
		if (!triggerListeners) historyListeners.pauseListeners();
		history.go(delta);
	}
	const routerHistory = assign({
		location: "",
		base,
		go,
		createHref: createHref.bind(null, base)
	}, historyNavigation, historyListeners);
	Object.defineProperty(routerHistory, "location", {
		enumerable: true,
		get: () => historyNavigation.location.value
	});
	Object.defineProperty(routerHistory, "state", {
		enumerable: true,
		get: () => historyNavigation.state.value
	});
	return routerHistory;
}
/**
* Creates a hash history. Useful for web applications with no host (e.g. `file://`) or when configuring a server to
* handle any URL is not possible.
*
* @param base - optional base to provide. Defaults to `location.pathname + location.search` If there is a `<base>` tag
* in the `head`, its value will be ignored in favor of this parameter **but note it affects all the history.pushState()
* calls**, meaning that if you use a `<base>` tag, it's `href` value **has to match this parameter** (ignoring anything
* after the `#`).
*
* @example
* ```js
* // at https://example.com/folder
* createWebHashHistory() // gives a url of `https://example.com/folder#`
* createWebHashHistory('/folder/') // gives a url of `https://example.com/folder/#`
* // if the `#` is provided in the base, it won't be added by `createWebHashHistory`
* createWebHashHistory('/folder/#/app/') // gives a url of `https://example.com/folder/#/app/`
* // you should avoid doing this because it changes the original url and breaks copying urls
* createWebHashHistory('/other-folder/') // gives a url of `https://example.com/other-folder/#`
*
* // at file:///usr/etc/folder/index.html
* // for locations with no `host`, the base is ignored
* createWebHashHistory('/iAmIgnored') // gives a url of `file:///usr/etc/folder/index.html#`
* ```
*/
function createWebHashHistory(base) {
	base = location.host ? base || location.pathname + location.search : "";
	if (!base.includes("#")) base += "#";
	if (!base.endsWith("#/") && !base.endsWith("#")) diagnostics.VUE_ROUTER_R0110({
		base,
		suggestion: base.replace(/#.*$/, "#")
	});
	return createWebHistory(base);
}
/**
* Creates an in-memory based history. The main purpose of this history is to handle SSR. It starts in a special location that is nowhere.
* It's up to the user to replace that location with the starter location by either calling `router.push` or `router.replace`.
*
* @param base - Base applied to all urls, defaults to '/'
* @returns a history object that can be passed to the router constructor
*/
function createMemoryHistory(base = "") {
	let listeners = [];
	let queue = [["", {}]];
	let position = 0;
	base = normalizeBase(base);
	function setLocation(location, state = {}) {
		position++;
		if (position !== queue.length) queue.splice(position);
		queue.push([location, state]);
	}
	function triggerListeners(to, from, { direction, delta }) {
		const info = {
			direction,
			delta,
			type: "pop"
		};
		for (const callback of listeners) callback(to, from, info);
	}
	const routerHistory = {
		location: "",
		state: {},
		base,
		createHref: createHref.bind(null, base),
		replace(to, state) {
			queue.splice(position--, 1);
			setLocation(to, state);
		},
		push(to, state) {
			setLocation(to, state);
		},
		listen(callback) {
			listeners.push(callback);
			return () => {
				const index = listeners.indexOf(callback);
				if (index > -1) listeners.splice(index, 1);
			};
		},
		destroy() {
			listeners = [];
			queue = [["", {}]];
			position = 0;
		},
		go(delta, shouldTrigger = true) {
			const from = this.location;
			const direction = delta < 0 ? "back" : "forward";
			position = Math.max(0, Math.min(position + delta, queue.length - 1));
			if (shouldTrigger) triggerListeners(this.location, from, {
				direction,
				delta
			});
		}
	};
	Object.defineProperty(routerHistory, "location", {
		enumerable: true,
		get: () => queue[position][0]
	});
	Object.defineProperty(routerHistory, "state", {
		enumerable: true,
		get: () => queue[position][1]
	});
	return routerHistory;
}
var ROOT_TOKEN = {
	type: 0,
	value: ""
};
var VALID_PARAM_RE = /[a-zA-Z0-9_]/;
function tokenizePath(path) {
	if (!path) return [[]];
	if (path === "/") return [[ROOT_TOKEN]];
	if (!isAbsolutePath(path)) throw new Error(`Route paths should start with a "/": "${path}" should be "/${path}".`);
	function crash(message) {
		throw new Error(`ERR (${state})/"${buffer}": ${message}`);
	}
	let state = 0;
	let previousState = state;
	const tokens = [];
	let segment;
	function finalizeSegment() {
		if (segment) tokens.push(segment);
		segment = [];
	}
	let i = 0;
	let char;
	let buffer = "";
	let customRe = "";
	function consumeBuffer() {
		if (!buffer) return;
		if (state === 0) segment.push({
			type: 0,
			value: buffer
		});
		else if (state === 1 || state === 2 || state === 3) {
			if (segment.length > 1 && (char === "*" || char === "+")) crash(`A repeatable param (${buffer}) must be alone in its segment. eg: '/:ids+.`);
			segment.push({
				type: 1,
				value: buffer,
				regexp: customRe,
				repeatable: char === "*" || char === "+",
				optional: char === "*" || char === "?"
			});
		} else crash("Invalid state to consume buffer");
		buffer = "";
	}
	function addCharToBuffer() {
		buffer += char;
	}
	while (i < path.length) {
		char = path[i++];
		switch (state) {
			case 0:
				if (char === "\\") {
					previousState = state;
					state = 4;
				} else if (char === "/") {
					if (buffer) consumeBuffer();
					finalizeSegment();
				} else if (char === ":") {
					consumeBuffer();
					state = 1;
				} else addCharToBuffer();
				break;
			case 4:
				addCharToBuffer();
				state = previousState;
				break;
			case 1:
				if (char === "(") state = 2;
				else if (VALID_PARAM_RE.test(char)) addCharToBuffer();
				else {
					consumeBuffer();
					state = 0;
					if (char !== "*" && char !== "?" && char !== "+") i--;
				}
				break;
			case 2:
				if (char === ")") {
					if (customRe[customRe.length - 1] == "\\") customRe = customRe.slice(0, -1) + char;
					else state = 3;
				} else customRe += char;
				break;
			case 3:
				consumeBuffer();
				state = 0;
				if (char !== "*" && char !== "?" && char !== "+") i--;
				customRe = "";
				break;
			default: crash("Unknown state");
		}
	}
	if (state === 2) crash(`Unfinished custom RegExp for param "${buffer}"`);
	consumeBuffer();
	finalizeSegment();
	return tokens;
}
var BASE_PARAM_PATTERN = "[^/]+?";
var BASE_PATH_PARSER_OPTIONS = {
	sensitive: false,
	strict: false,
	start: true,
	end: true
};
var REGEX_CHARS_RE = /[.+*?^${}()[\]/\\]/g;
/**
* Creates a path parser from an array of Segments (a segment is an array of Tokens)
*
* @param segments - array of segments returned by tokenizePath
* @param extraOptions - optional options for the regexp
* @returns a PathParser
*/
function tokensToParser(segments, extraOptions) {
	const options = assign({}, BASE_PATH_PARSER_OPTIONS, extraOptions);
	const score = [];
	let pattern = options.start ? "^" : "";
	const keys = [];
	for (const segment of segments) {
		const segmentScores = segment.length ? [] : [90];
		if (options.strict && !segment.length) pattern += "/";
		for (let tokenIndex = 0; tokenIndex < segment.length; tokenIndex++) {
			const token = segment[tokenIndex];
			let subSegmentScore = 40 + (options.sensitive ? .25 : 0);
			if (token.type === 0) {
				if (!tokenIndex) pattern += "/";
				pattern += token.value.replace(REGEX_CHARS_RE, "\\$&");
				subSegmentScore += 40;
			} else if (token.type === 1) {
				const { value, repeatable, optional, regexp } = token;
				keys.push({
					name: value,
					repeatable,
					optional
				});
				const re = regexp ? regexp : BASE_PARAM_PATTERN;
				if (re !== BASE_PARAM_PATTERN) {
					subSegmentScore += 10;
					try {
						new RegExp(`(${re})`);
					} catch (err) {
						throw new Error(`Invalid custom RegExp for param "${value}" (${re}): ` + err.message);
					}
				}
				let subPattern = repeatable ? `((?:${re})(?:/(?:${re}))*)` : `(${re})`;
				if (!tokenIndex) subPattern = optional && segment.length < 2 ? `(?:/${subPattern})` : "/" + subPattern;
				if (optional) subPattern += "?";
				pattern += subPattern;
				subSegmentScore += 20;
				if (optional) subSegmentScore += -8;
				if (repeatable) subSegmentScore += -20;
				if (re === ".*") subSegmentScore += -50;
			}
			segmentScores.push(subSegmentScore);
		}
		score.push(segmentScores);
	}
	if (options.strict && options.end) {
		const i = score.length - 1;
		score[i][score[i].length - 1] += .7000000000000001;
	}
	if (!options.strict) pattern += "/?";
	if (options.end) pattern += "$";
	else if (options.strict && !pattern.endsWith("/")) pattern += "(?:/|$)";
	const re = new RegExp(pattern, options.sensitive ? "" : "i");
	function parse(path) {
		const match = path.match(re);
		const params = {};
		if (!match) return null;
		for (let i = 1; i < match.length; i++) {
			const value = match[i] || "";
			const key = keys[i - 1];
			params[key.name] = value && key.repeatable ? value.split("/") : value;
		}
		return params;
	}
	function stringify(params) {
		let path = "";
		let avoidDuplicatedSlash = false;
		for (const segment of segments) {
			if (!avoidDuplicatedSlash || !path.endsWith("/")) path += "/";
			avoidDuplicatedSlash = false;
			for (const token of segment) if (token.type === 0) path += token.value;
			else if (token.type === 1) {
				const { value, repeatable, optional } = token;
				const param = value in params ? params[value] : "";
				if (isArray(param) && !repeatable) throw new Error(`Provided param "${value}" is an array but it is not repeatable (* or + modifiers)`);
				const text = isArray(param) ? param.join("/") : param;
				if (!text) {
					if (optional) {
						if (segment.length < 2) {
							if (path.endsWith("/")) path = path.slice(0, -1);
							else avoidDuplicatedSlash = true;
						}
					} else throw new Error(`Missing required param "${value}"`);
				}
				path += text;
			}
		}
		return path || "/";
	}
	return {
		re,
		score,
		keys,
		parse,
		stringify
	};
}
/**
* Compares an array of numbers as used in PathParser.score and returns a
* number. This function can be used to `sort` an array
*
* @param a - first array of numbers
* @param b - second array of numbers
* @returns 0 if both are equal, < 0 if a should be sorted first, > 0 if b
* should be sorted first
*/
function compareScoreArray(a, b) {
	let i = 0;
	while (i < a.length && i < b.length) {
		const diff = b[i] - a[i];
		if (diff) return diff;
		i++;
	}
	if (a.length < b.length) return a.length === 1 && a[0] === 80 ? -1 : 1;
	else if (a.length > b.length) return b.length === 1 && b[0] === 80 ? 1 : -1;
	return 0;
}
/**
* Compare function that can be used with `sort` to sort an array of PathParser
*
* @param a - first PathParser
* @param b - second PathParser
* @returns 0 if both are equal, < 0 if a should be sorted first, > 0 if b
*/
function comparePathParserScore(a, b) {
	let i = 0;
	const aScore = a.score;
	const bScore = b.score;
	while (i < aScore.length && i < bScore.length) {
		const comp = compareScoreArray(aScore[i], bScore[i]);
		if (comp) return comp;
		i++;
	}
	if (Math.abs(bScore.length - aScore.length) === 1) {
		if (isLastScoreNegative(aScore)) return 1;
		if (isLastScoreNegative(bScore)) return -1;
	}
	return bScore.length - aScore.length;
}
/**
* This allows detecting splats at the end of a path: /home/:id(.*)*
*
* @param score - score to check
* @returns true if the last entry is negative
*/
function isLastScoreNegative(score) {
	const last = score[score.length - 1];
	return score.length > 0 && last[last.length - 1] < 0;
}
var PATH_PARSER_OPTIONS_DEFAULTS = {
	strict: false,
	end: true,
	sensitive: false
};
function createRouteRecordMatcher(record, parent, options) {
	const parser = tokensToParser(tokenizePath(record.path), options);
	{
		const existingKeys = /* @__PURE__ */ new Set();
		for (const key of parser.keys) {
			if (existingKeys.has(key.name)) diagnostics.VUE_ROUTER_R0090({
				name: key.name,
				path: record.path
			});
			existingKeys.add(key.name);
		}
	}
	const matcher = assign(parser, {
		record,
		parent,
		children: [],
		alias: []
	});
	if (parent) {
		if (!matcher.record.aliasOf === !parent.record.aliasOf) parent.children.push(matcher);
	}
	return matcher;
}
/**
* Creates a Router Matcher.
*
* @internal
* @param routes - array of initial routes
* @param globalOptions - global route options
*/
function createRouterMatcher(routes, globalOptions) {
	const matchers = [];
	const matcherMap = /* @__PURE__ */ new Map();
	globalOptions = mergeOptions(PATH_PARSER_OPTIONS_DEFAULTS, globalOptions);
	function getRecordMatcher(name) {
		return matcherMap.get(name);
	}
	function addRoute(record, parent, originalRecord) {
		const isRootAdd = !originalRecord;
		const mainNormalizedRecord = normalizeRouteRecord(record);
		checkChildMissingNameWithEmptyPath(mainNormalizedRecord, parent);
		mainNormalizedRecord.aliasOf = originalRecord && originalRecord.record;
		const options = mergeOptions(globalOptions, record);
		const normalizedRecords = [mainNormalizedRecord];
		if ("alias" in record) {
			const aliases = typeof record.alias === "string" ? [record.alias] : record.alias;
			for (const alias of aliases) normalizedRecords.push(normalizeRouteRecord(assign({}, mainNormalizedRecord, {
				components: originalRecord ? originalRecord.record.components : mainNormalizedRecord.components,
				path: alias,
				aliasOf: originalRecord ? originalRecord.record : mainNormalizedRecord
			})));
		}
		let matcher;
		let originalMatcher;
		for (const normalizedRecord of normalizedRecords) {
			const { path } = normalizedRecord;
			if (parent && !isAbsolutePath(path)) {
				const parentPath = parent.record.path;
				const connectingSlash = parentPath[parentPath.length - 1] === "/" ? "" : "/";
				normalizedRecord.path = parent.record.path + (path && connectingSlash + path);
			}
			if (normalizedRecord.path === "*") throw new Error("Catch all routes (\"*\") must now be defined using a param with a custom regexp.\nSee more at https://router.vuejs.org/guide/migration/#Removed-star-or-catch-all-routes.");
			matcher = createRouteRecordMatcher(normalizedRecord, parent, options);
			if (parent && isAbsolutePath(path)) checkMissingParamsInAbsolutePath(matcher, parent);
			if (originalRecord) {
				originalRecord.alias.push(matcher);
				checkSameParams(originalRecord, matcher);
			} else {
				originalMatcher = originalMatcher || matcher;
				if (originalMatcher !== matcher) originalMatcher.alias.push(matcher);
				if (isRootAdd && record.name && !isAliasRecord(matcher)) {
					checkSameNameAsAncestor(record, parent);
					removeRoute(record.name);
				}
			}
			if (isMatchable(matcher)) insertMatcher(matcher);
			if (mainNormalizedRecord.children) {
				const children = mainNormalizedRecord.children;
				for (let i = 0; i < children.length; i++) addRoute(children[i], matcher, originalRecord && originalRecord.children[i]);
			}
			originalRecord = originalRecord || matcher;
		}
		return originalMatcher ? () => {
			removeRoute(originalMatcher);
		} : noop;
	}
	function removeRoute(matcherRef) {
		if (isRouteName(matcherRef)) {
			const matcher = matcherMap.get(matcherRef);
			if (matcher) {
				matcherMap.delete(matcherRef);
				matchers.splice(matchers.indexOf(matcher), 1);
				matcher.children.forEach(removeRoute);
				matcher.alias.forEach(removeRoute);
			}
		} else {
			const index = matchers.indexOf(matcherRef);
			if (index > -1) {
				matchers.splice(index, 1);
				if (matcherRef.record.name) matcherMap.delete(matcherRef.record.name);
				matcherRef.children.forEach(removeRoute);
				matcherRef.alias.forEach(removeRoute);
			}
		}
	}
	function getRoutes() {
		return matchers;
	}
	function insertMatcher(matcher) {
		const index = findInsertionIndex(matcher, matchers);
		matchers.splice(index, 0, matcher);
		if (matcher.record.name && !isAliasRecord(matcher)) matcherMap.set(matcher.record.name, matcher);
	}
	function resolve(location, currentLocation) {
		let matcher;
		let params = {};
		let path;
		let name;
		if ("name" in location && location.name) {
			matcher = matcherMap.get(location.name);
			if (!matcher) throw createRouterError(1, { location });
			{
				const invalidParams = Object.keys(location.params || {}).filter((paramName) => !matcher.keys.find((k) => k.name === paramName));
				if (invalidParams.length) {
					const isInherited = !matcher.keys.length && invalidParams.some((name) => name in currentLocation.params);
					diagnostics.VUE_ROUTER_R0100({
						params: invalidParams.join("\", \""),
						inherited: isInherited ? ` If you are using a catch-all route with a named redirect, pass an empty \`params\` object: \`redirect: { name: '...', params: {} }\`.` : ""
					});
				}
			}
			name = matcher.record.name;
			params = assign(pickParams(currentLocation.params, matcher.keys.filter((k) => !k.optional).concat(matcher.parent ? matcher.parent.keys.filter((k) => k.optional) : []).map((k) => k.name)), location.params && pickParams(location.params, matcher.keys.map((k) => k.name)));
			path = matcher.stringify(params);
		} else if (location.path != null) {
			path = location.path;
			if (!isAbsolutePath(path)) diagnostics.VUE_ROUTER_R0101({ path });
			matcher = matchers.find((m) => m.re.test(path));
			if (matcher) {
				params = matcher.parse(path);
				name = matcher.record.name;
				matcher.keys.forEach((key) => {
					if (key.optional && !params[key.name]) delete params[key.name];
				});
			}
		} else {
			matcher = currentLocation.name ? matcherMap.get(currentLocation.name) : matchers.find((m) => m.re.test(currentLocation.path));
			if (!matcher) throw createRouterError(1, {
				location,
				currentLocation
			});
			name = matcher.record.name;
			params = assign({}, currentLocation.params, location.params);
			path = matcher.stringify(params);
		}
		const matched = [];
		let parentMatcher = matcher;
		while (parentMatcher) {
			matched.unshift(parentMatcher.record);
			parentMatcher = parentMatcher.parent;
		}
		return {
			name,
			path,
			params,
			matched,
			meta: mergeMetaFields(matched)
		};
	}
	routes.forEach((route) => addRoute(route));
	function clearRoutes() {
		matchers.length = 0;
		matcherMap.clear();
	}
	return {
		addRoute,
		resolve,
		removeRoute,
		clearRoutes,
		getRoutes,
		getRecordMatcher
	};
}
/**
* Picks an object param to contain only specified keys.
*
* @param params - params object to pick from
* @param keys - keys to pick
*/
function pickParams(params, keys) {
	const newParams = {};
	for (const key of keys) if (key in params) newParams[key] = params[key];
	return newParams;
}
/**
* Normalizes a RouteRecordRaw. Creates a copy
*
* @param record
* @returns the normalized version
*/
function normalizeRouteRecord(record) {
	const normalized = {
		path: record.path,
		redirect: record.redirect,
		name: record.name,
		meta: record.meta || {},
		aliasOf: record.aliasOf,
		beforeEnter: record.beforeEnter,
		props: normalizeRecordProps(record),
		children: record.children || [],
		instances: {},
		leaveGuards: /* @__PURE__ */ new Set(),
		updateGuards: /* @__PURE__ */ new Set(),
		enterCallbacks: {},
		components: "components" in record ? record.components || null : record.component && { default: record.component }
	};
	Object.defineProperty(normalized, "mods", { value: {} });
	return normalized;
}
/**
* Normalize the optional `props` in a record to always be an object similar to
* components. Also accept a boolean for components.
* @param record
*/
function normalizeRecordProps(record) {
	const propsObject = {};
	const props = record.props || false;
	if ("component" in record) propsObject.default = props;
	else for (const name in record.components) propsObject[name] = typeof props === "object" ? props[name] : props;
	return propsObject;
}
/**
* Checks if a record or any of its parent is an alias
* @param record
*/
function isAliasRecord(record) {
	while (record) {
		if (record.record.aliasOf) return true;
		record = record.parent;
	}
	return false;
}
/**
* Merge meta fields of an array of records
*
* @param matched - array of matched records
*/
function mergeMetaFields(matched) {
	return matched.reduce((meta, record) => assign(meta, record.meta), {});
}
function isSameParam(a, b) {
	return a.name === b.name && a.optional === b.optional && a.repeatable === b.repeatable;
}
/**
* Check if a path and its alias have the same required params
*
* @param a - original record
* @param b - alias record
*/
function checkSameParams(a, b) {
	for (const key of a.keys) if (!key.optional && !b.keys.find(isSameParam.bind(null, key))) {
		diagnostics.VUE_ROUTER_R0102({
			alias: b.record.path,
			original: a.record.path,
			name: key.name
		});
		return;
	}
	for (const key of b.keys) if (!key.optional && !a.keys.find(isSameParam.bind(null, key))) {
		diagnostics.VUE_ROUTER_R0102({
			alias: b.record.path,
			original: a.record.path,
			name: key.name
		});
		return;
	}
}
/**
* A route with a name and a child with an empty path without a name should warn when adding the route
*
* @param mainNormalizedRecord - RouteRecordNormalized
* @param parent - RouteRecordMatcher
*/
function checkChildMissingNameWithEmptyPath(mainNormalizedRecord, parent) {
	if (parent && parent.record.name && !mainNormalizedRecord.name && !mainNormalizedRecord.path && mainNormalizedRecord.children.length === 0) diagnostics.VUE_ROUTER_R0103({ name: String(parent.record.name) });
}
function checkSameNameAsAncestor(record, parent) {
	for (let ancestor = parent; ancestor; ancestor = ancestor.parent) if (ancestor.record.name === record.name) throw new Error(`A route named "${String(record.name)}" has been added as a ${parent === ancestor ? "child" : "descendant"} of a route with the same name. Route names must be unique and a nested route cannot use the same name as an ancestor.`);
}
function checkMissingParamsInAbsolutePath(record, parent) {
	for (const key of parent.keys) if (!record.keys.find(isSameParam.bind(null, key))) {
		diagnostics.VUE_ROUTER_R0104({
			path: record.record.path,
			name: key.name,
			parent: parent.record.path
		});
		return;
	}
}
/**
* Performs a binary search to find the correct insertion index for a new matcher.
*
* Matchers are primarily sorted by their score. If scores are tied then we also consider parent/child relationships,
* with descendants coming before ancestors. If there's still a tie, new routes are inserted after existing routes.
*
* @param matcher - new matcher to be inserted
* @param matchers - existing matchers
*/
function findInsertionIndex(matcher, matchers) {
	let lower = 0;
	let upper = matchers.length;
	while (lower !== upper) {
		const mid = lower + upper >> 1;
		if (comparePathParserScore(matcher, matchers[mid]) < 0) upper = mid;
		else lower = mid + 1;
	}
	const insertionAncestor = getInsertionAncestor(matcher);
	if (insertionAncestor) {
		upper = matchers.lastIndexOf(insertionAncestor, upper - 1);
		if (upper < 0) diagnostics.VUE_ROUTER_R0105({
			ancestor: insertionAncestor.record.path,
			record: matcher.record.path
		});
	}
	return upper;
}
function getInsertionAncestor(matcher) {
	let ancestor = matcher;
	while (ancestor = ancestor.parent) if (isMatchable(ancestor) && comparePathParserScore(matcher, ancestor) === 0) return ancestor;
}
/**
* Checks if a matcher can be reachable. This means if it's possible to reach it as a route. For example, routes without
* a component, or name, or redirect, are just used to group other routes.
* @param matcher
* @param matcher.record record of the matcher
* @returns
*/
function isMatchable({ record }) {
	return !!(record.name || record.components && Object.keys(record.components).length || record.redirect);
}
/**
* Returns the internal behavior of a {@link RouterLink} without the rendering part.
*
* @param props - a `to` location and an optional `replace` flag
*/
function useLink(props) {
	const router = inject(routerKey);
	const currentRoute = inject(routeLocationKey);
	let hasPrevious = false;
	let previousTo = null;
	const route = computed(() => {
		const to = unref(props.to);
		if (!hasPrevious || to !== previousTo) {
			if (!isRouteLocation(to)) diagnostics.VUE_ROUTER_R0050({ to });
			previousTo = to;
			hasPrevious = true;
		}
		return router.resolve(to);
	});
	const activeRecordIndex = computed(() => {
		const { matched } = route.value;
		const { length } = matched;
		const routeMatched = matched[length - 1];
		const currentMatched = currentRoute.matched;
		if (!routeMatched || !currentMatched.length) return -1;
		const index = currentMatched.findIndex(isSameRouteRecord.bind(null, routeMatched));
		if (index > -1) return index;
		const parentRecordPath = getOriginalPath(matched[length - 2]);
		return length > 1 && getOriginalPath(routeMatched) === parentRecordPath && currentMatched[currentMatched.length - 1].path !== parentRecordPath ? currentMatched.findIndex(isSameRouteRecord.bind(null, matched[length - 2])) : index;
	});
	const isActive = computed(() => activeRecordIndex.value > -1 && includesParams(currentRoute.params, route.value.params));
	const isExactActive = computed(() => activeRecordIndex.value > -1 && activeRecordIndex.value === currentRoute.matched.length - 1 && isSameRouteLocationParams(currentRoute.params, route.value.params));
	function navigate(e = {}) {
		if (guardEvent(e)) {
			const p = router[unref(props.replace) ? "replace" : "push"](unref(props.to)).catch(noop);
			if (props.viewTransition && typeof document !== "undefined" && "startViewTransition" in document) document.startViewTransition(() => p);
			return p;
		}
		return Promise.resolve();
	}
	if (isBrowser) {
		const instance = getCurrentInstance();
		if (instance) {
			const linkContextDevtools = {
				route: route.value,
				isActive: isActive.value,
				isExactActive: isExactActive.value,
				error: null
			};
			instance.__vrl_devtools = instance.__vrl_devtools || [];
			instance.__vrl_devtools.push(linkContextDevtools);
			watchEffect(() => {
				linkContextDevtools.route = route.value;
				linkContextDevtools.isActive = isActive.value;
				linkContextDevtools.isExactActive = isExactActive.value;
				linkContextDevtools.error = isRouteLocation(unref(props.to)) ? null : "Invalid \"to\" value";
			}, { flush: "post" });
		}
	}
	/**
	* NOTE: update {@link _RouterLinkI}'s `$slots` type when updating this
	*/
	return {
		route,
		href: computed(() => route.value.href),
		isActive,
		isExactActive,
		navigate
	};
}
function preferSingleVNode(vnodes) {
	return vnodes.length === 1 ? vnodes[0] : vnodes;
}
/**
* Component to render a link that triggers a navigation on click.
*/
var RouterLink = /* @__PURE__ */ defineComponent({
	name: "RouterLink",
	compatConfig: { MODE: 3 },
	props: {
		to: {
			type: [String, Object],
			required: true
		},
		replace: Boolean,
		activeClass: String,
		exactActiveClass: String,
		custom: Boolean,
		ariaCurrentValue: {
			type: String,
			default: "page"
		},
		viewTransition: Boolean
	},
	useLink,
	setup(props, { slots }) {
		const link = reactive(useLink(props));
		const { options } = inject(routerKey);
		const elClass = computed(() => ({
			[getLinkClass(props.activeClass, options.linkActiveClass, "router-link-active")]: link.isActive,
			[getLinkClass(props.exactActiveClass, options.linkExactActiveClass, "router-link-exact-active")]: link.isExactActive
		}));
		return () => {
			const children = slots.default && preferSingleVNode(slots.default(link));
			return props.custom ? children : h("a", {
				"aria-current": link.isExactActive ? props.ariaCurrentValue : null,
				href: link.href,
				onClick: link.navigate,
				class: elClass.value
			}, children);
		};
	}
});
function guardEvent(e) {
	if (e.metaKey || e.altKey || e.ctrlKey || e.shiftKey) return;
	if (e.defaultPrevented) return;
	if (e.button !== void 0 && e.button !== 0) return;
	if (e.currentTarget && e.currentTarget.getAttribute) {
		const target = e.currentTarget.getAttribute("target");
		if (/\b_blank\b/i.test(target)) return;
	}
	if (e.preventDefault) e.preventDefault();
	return true;
}
function includesParams(outer, inner) {
	for (const key in inner) {
		const innerValue = inner[key];
		const outerValue = outer[key];
		if (isArray(innerValue)) {
			if (!isArray(outerValue) || outerValue.length !== innerValue.length || innerValue.some((value, i) => value.valueOf() !== outerValue[i].valueOf())) return false;
		} else if (innerValue !== outerValue) return false;
	}
	return true;
}
/**
* Get the original path value of a record by following its aliasOf
* @param record
*/
function getOriginalPath(record) {
	return record ? record.aliasOf ? record.aliasOf.path : record.path : "";
}
/**
* Utility class to get the active class based on defaults.
* @param propClass
* @param globalClass
* @param defaultClass
*/
var getLinkClass = (propClass, globalClass, defaultClass) => propClass != null ? propClass : globalClass != null ? globalClass : defaultClass;
var RouterViewImpl = /*#__PURE__*/ defineComponent({
	name: "RouterView",
	inheritAttrs: false,
	props: {
		name: {
			type: String,
			default: "default"
		},
		route: Object
	},
	compatConfig: { MODE: 3 },
	setup(props, { attrs, slots }) {
		warnDeprecatedUsage();
		const injectedRoute = inject(routerViewLocationKey);
		const routeToDisplay = computed(() => props.route || injectedRoute.value);
		const injectedDepth = inject(viewDepthKey, 0);
		const depth = computed(() => {
			let initialDepth = unref(injectedDepth);
			const { matched } = routeToDisplay.value;
			let matchedRoute;
			while ((matchedRoute = matched[initialDepth]) && !matchedRoute.components) initialDepth++;
			return initialDepth;
		});
		const matchedRouteRef = computed(() => routeToDisplay.value.matched[depth.value]);
		provide(viewDepthKey, computed(() => depth.value + 1));
		provide(matchedRouteKey, matchedRouteRef);
		provide(routerViewLocationKey, routeToDisplay);
		const viewRef = ref();
		watch(() => [
			viewRef.value,
			matchedRouteRef.value,
			props.name
		], ([instance, to, name], [oldInstance, from, _oldName]) => {
			if (to) {
				to.instances[name] = instance;
				if (from && from !== to && instance && instance === oldInstance) {
					if (!to.leaveGuards.size) to.leaveGuards = from.leaveGuards;
					if (!to.updateGuards.size) to.updateGuards = from.updateGuards;
				}
			}
			if (instance && to && (!from || !isSameRouteRecord(to, from) || !oldInstance)) (to.enterCallbacks[name] || []).forEach((callback) => callback(instance));
		}, { flush: "post" });
		return () => {
			const route = routeToDisplay.value;
			const currentName = props.name;
			const matchedRoute = matchedRouteRef.value;
			const ViewComponent = matchedRoute && matchedRoute.components[currentName];
			if (!ViewComponent) return normalizeSlot(slots.default, {
				Component: ViewComponent,
				route
			});
			const routePropsOption = matchedRoute.props[currentName];
			const routeProps = routePropsOption ? routePropsOption === true ? route.params : typeof routePropsOption === "function" ? routePropsOption(route) : routePropsOption : null;
			const onVnodeUnmounted = (vnode) => {
				if (vnode.component.isUnmounted) matchedRoute.instances[currentName] = null;
			};
			const component = h(ViewComponent, assign({}, routeProps, attrs, {
				onVnodeUnmounted,
				ref: viewRef
			}));
			if (isBrowser && component.ref) {
				const info = {
					depth: depth.value,
					name: matchedRoute.name,
					path: matchedRoute.path,
					meta: matchedRoute.meta
				};
				(isArray(component.ref) ? component.ref.map((r) => r.i) : [component.ref.i]).forEach((instance) => {
					if (instance) instance.__vrv_devtools = info;
				});
			}
			return normalizeSlot(slots.default, {
				Component: component,
				route
			}) || component;
		};
	}
});
function normalizeSlot(slot, data) {
	if (!slot) return null;
	const slotContent = slot(data);
	return slotContent.length === 1 ? slotContent[0] : slotContent;
}
/**
* Component to display the current route the user is at.
*/
var RouterView = RouterViewImpl;
function warnDeprecatedUsage() {
	const instance = getCurrentInstance();
	const parentName = instance.parent && instance.parent.type.name;
	const parentSubTreeType = instance.parent && instance.parent.subTree && instance.parent.subTree.type;
	if (parentName && (parentName === "KeepAlive" || parentName.includes("Transition")) && typeof parentSubTreeType === "object" && parentSubTreeType.name === "RouterView") {
		const comp = parentName === "KeepAlive" ? "keep-alive" : "transition";
		diagnostics.VUE_ROUTER_R0060({ comp });
	}
}
/**
* Creates a Router instance that can be used by a Vue app.
*
* @param options - {@link RouterOptions}
*/
function createRouter(options) {
	const matcher = createRouterMatcher(options.routes, options);
	const parseQuery$1 = options.parseQuery || parseQuery;
	const stringifyQuery$1 = options.stringifyQuery || stringifyQuery;
	const routerHistory = options.history;
	if (!routerHistory) throw new Error("Provide the \"history\" option when calling \"createRouter()\": https://router.vuejs.org/api/interfaces/RouterOptions.html#history");
	const beforeGuards = useCallbacks();
	const beforeResolveGuards = useCallbacks();
	const afterGuards = useCallbacks();
	const currentRoute = shallowRef(START_LOCATION_NORMALIZED);
	const routesVersion = shallowRef(0);
	let pendingLocation = START_LOCATION_NORMALIZED;
	if (isBrowser && options.scrollBehavior && "scrollRestoration" in history) history.scrollRestoration = "manual";
	const normalizeParams = applyToParams.bind(null, (paramValue) => "" + paramValue);
	const encodeParams = applyToParams.bind(null, encodeParam);
	const decodeParams = applyToParams.bind(null, decode);
	function addRoute(parentOrRoute, route) {
		let parent;
		let record;
		if (isRouteName(parentOrRoute)) {
			parent = matcher.getRecordMatcher(parentOrRoute);
			if (!parent) diagnostics.VUE_ROUTER_R0001({ name: String(parentOrRoute) });
			record = route;
		} else record = parentOrRoute;
		const removeRoute = matcher.addRoute(record, parent);
		routesVersion.value++;
		return () => {
			removeRoute();
			routesVersion.value++;
		};
	}
	function removeRoute(name) {
		const recordMatcher = matcher.getRecordMatcher(name);
		if (recordMatcher) {
			matcher.removeRoute(recordMatcher);
			routesVersion.value++;
		} else diagnostics.VUE_ROUTER_R0002({ name: String(name) });
	}
	function clearRoutes() {
		matcher.clearRoutes();
		routesVersion.value++;
	}
	function getRoutes() {
		return matcher.getRoutes().map((routeMatcher) => routeMatcher.record);
	}
	function hasRoute(name) {
		return !!matcher.getRecordMatcher(name);
	}
	function resolve(rawLocation, currentLocation) {
		routesVersion.value;
		if (typeof rawLocation === "string") {
			currentLocation = currentLocation || (rawLocation.startsWith("/") ? START_LOCATION_NORMALIZED : currentRoute.value);
			const locationNormalized = parseURL(parseQuery$1, rawLocation, currentLocation.path);
			const matchedRoute = matcher.resolve({ path: locationNormalized.path }, currentLocation);
			const href = routerHistory.createHref(locationNormalized.fullPath);
			if (href.startsWith("//")) diagnostics.VUE_ROUTER_R0003({
				location: rawLocation,
				href
			});
			else if (!matchedRoute.matched.length) diagnostics.VUE_ROUTER_R0004({ path: rawLocation });
			return assign(locationNormalized, matchedRoute, {
				params: decodeParams(matchedRoute.params),
				redirectedFrom: void 0,
				href
			});
		}
		if (!isRouteLocation(rawLocation)) {
			diagnostics.VUE_ROUTER_R0005({ rawLocation });
			return resolve({});
		}
		currentLocation = assign({}, currentLocation || (rawLocation.path != null && rawLocation.path.startsWith("/") && !("name" in rawLocation && rawLocation.name) ? START_LOCATION_NORMALIZED : currentRoute.value));
		let matcherLocation;
		if (rawLocation.path != null) {
			if ("params" in rawLocation && !("name" in rawLocation) && Object.keys(rawLocation.params).length) diagnostics.VUE_ROUTER_R0006({ path: rawLocation.path });
			matcherLocation = assign({}, rawLocation, { path: parseURL(parseQuery$1, rawLocation.path, currentLocation.path).path });
		} else {
			const targetParams = assign({}, rawLocation.params);
			for (const key in targetParams) if (targetParams[key] == null) delete targetParams[key];
			matcherLocation = assign({}, rawLocation, { params: encodeParams(targetParams) });
			currentLocation.params = encodeParams(currentLocation.params);
		}
		const matchedRoute = matcher.resolve(matcherLocation, currentLocation);
		const hash = rawLocation.hash || "";
		if (hash && !hash.startsWith("#")) diagnostics.VUE_ROUTER_R0007({ hash });
		matchedRoute.params = normalizeParams(decodeParams(matchedRoute.params));
		const fullPath = stringifyURL(stringifyQuery$1, assign({}, rawLocation, {
			hash: encodeHash(hash),
			path: matchedRoute.path
		}));
		const href = routerHistory.createHref(fullPath);
		if (href.startsWith("//")) diagnostics.VUE_ROUTER_R0003({
			location: rawLocation,
			href
		});
		else if (!matchedRoute.matched.length) diagnostics.VUE_ROUTER_R0004({ path: rawLocation.path != null ? rawLocation.path : rawLocation });
		return assign({
			fullPath,
			hash,
			query: stringifyQuery$1 === stringifyQuery ? normalizeQuery(rawLocation.query) : rawLocation.query || {}
		}, matchedRoute, {
			redirectedFrom: void 0,
			href
		});
	}
	function locationAsObject(to) {
		return typeof to === "string" ? parseURL(parseQuery$1, to, currentRoute.value.path) : assign({}, to);
	}
	function checkCanceledNavigation(to, from) {
		if (pendingLocation !== to) return createRouterError(8, {
			from,
			to
		});
	}
	function push(to) {
		return pushWithRedirect(to);
	}
	function replace(to) {
		return push(assign(locationAsObject(to), { replace: true }));
	}
	function handleRedirectRecord(to, from) {
		const lastMatched = to.matched[to.matched.length - 1];
		if (lastMatched && lastMatched.redirect) {
			const { redirect } = lastMatched;
			let newTargetLocation = typeof redirect === "function" ? redirect(to, from) : redirect;
			if (typeof newTargetLocation === "string") {
				newTargetLocation = newTargetLocation.includes("?") || newTargetLocation.includes("#") ? newTargetLocation = locationAsObject(newTargetLocation) : { path: newTargetLocation };
				newTargetLocation.params = {};
			}
			if (newTargetLocation.path == null && !("name" in newTargetLocation)) {
				diagnostics.VUE_ROUTER_R0008({
					target: JSON.stringify(newTargetLocation, null, 2),
					to: to.fullPath
				});
				throw new Error("Invalid redirect");
			}
			return assign({
				query: to.query,
				hash: to.hash,
				params: newTargetLocation.path != null ? {} : to.params
			}, newTargetLocation);
		}
	}
	function pushWithRedirect(to, redirectedFrom) {
		const targetLocation = pendingLocation = resolve(to);
		const from = currentRoute.value;
		const data = to.state;
		const force = to.force;
		const replace = to.replace === true;
		const shouldRedirect = handleRedirectRecord(targetLocation, from);
		if (shouldRedirect) return pushWithRedirect(assign(locationAsObject(shouldRedirect), {
			state: typeof shouldRedirect === "object" ? assign({}, data, shouldRedirect.state) : data,
			force,
			replace
		}), redirectedFrom || targetLocation);
		const toLocation = targetLocation;
		toLocation.redirectedFrom = redirectedFrom;
		let failure;
		if (!force && isSameRouteLocation(stringifyQuery$1, from, targetLocation)) {
			failure = createRouterError(16, {
				to: toLocation,
				from
			});
			handleScroll(from, from, true, false);
		}
		return (failure ? Promise.resolve(failure) : navigate(toLocation, from)).catch((error) => isNavigationFailure(error) ? isNavigationFailure(error, 2) ? error : markAsReady(error) : triggerError(error, toLocation, from)).then((failure) => {
			if (failure) {
				if (isNavigationFailure(failure, 2)) {
					if (isSameRouteLocation(stringifyQuery$1, resolve(failure.to), toLocation) && redirectedFrom && (redirectedFrom._count = redirectedFrom._count ? redirectedFrom._count + 1 : 1) > 30) {
						diagnostics.VUE_ROUTER_R0009({
							from: from.fullPath,
							to: toLocation.fullPath
						});
						return Promise.reject(/* @__PURE__ */ new Error("Infinite redirect in navigation guard"));
					}
					return pushWithRedirect(assign({ replace }, locationAsObject(failure.to), {
						state: typeof failure.to === "object" ? assign({}, data, failure.to.state) : data,
						force
					}), redirectedFrom || toLocation);
				}
			} else failure = finalizeNavigation(toLocation, from, true, replace, data);
			triggerAfterEach(toLocation, from, failure);
			return failure;
		});
	}
	/**
	* Helper to reject and skip all navigation guards if a new navigation happened
	* @param to
	* @param from
	*/
	function checkCanceledNavigationAndReject(to, from) {
		const error = checkCanceledNavigation(to, from);
		return error ? Promise.reject(error) : Promise.resolve();
	}
	function runWithContext(fn) {
		const app = installedApps.values().next().value;
		return app && typeof app.runWithContext === "function" ? app.runWithContext(fn) : fn();
	}
	function navigate(to, from) {
		let guards;
		const [leavingRecords, updatingRecords, enteringRecords] = extractChangingRecords(to, from);
		guards = extractComponentsGuards(leavingRecords.reverse(), "beforeRouteLeave", to, from);
		for (const record of leavingRecords) record.leaveGuards.forEach((guard) => {
			guards.push(guardToPromiseFn(guard, to, from));
		});
		const canceledNavigationCheck = checkCanceledNavigationAndReject.bind(null, to, from);
		guards.push(canceledNavigationCheck);
		return runGuardQueue(guards).then(() => {
			guards = [];
			for (const guard of beforeGuards.list()) guards.push(guardToPromiseFn(guard, to, from));
			guards.push(canceledNavigationCheck);
			return runGuardQueue(guards);
		}).then(() => {
			guards = extractComponentsGuards(updatingRecords, "beforeRouteUpdate", to, from);
			for (const record of updatingRecords) record.updateGuards.forEach((guard) => {
				guards.push(guardToPromiseFn(guard, to, from));
			});
			guards.push(canceledNavigationCheck);
			return runGuardQueue(guards);
		}).then(() => {
			guards = [];
			for (const record of enteringRecords) if (record.beforeEnter) {
				if (isArray(record.beforeEnter)) for (const beforeEnter of record.beforeEnter) guards.push(guardToPromiseFn(beforeEnter, to, from));
				else guards.push(guardToPromiseFn(record.beforeEnter, to, from));
			}
			guards.push(canceledNavigationCheck);
			return runGuardQueue(guards);
		}).then(() => {
			to.matched.forEach((record) => record.enterCallbacks = {});
			guards = extractComponentsGuards(enteringRecords, "beforeRouteEnter", to, from, runWithContext);
			guards.push(canceledNavigationCheck);
			return runGuardQueue(guards);
		}).then(() => {
			guards = [];
			for (const guard of beforeResolveGuards.list()) guards.push(guardToPromiseFn(guard, to, from));
			guards.push(canceledNavigationCheck);
			return runGuardQueue(guards);
		}).catch((err) => isNavigationFailure(err, 8) ? err : Promise.reject(err));
	}
	function triggerAfterEach(to, from, failure) {
		afterGuards.list().forEach((guard) => runWithContext(() => guard(to, from, failure)));
	}
	/**
	* - Cleans up any navigation guards
	* - Changes the url if necessary
	* - Calls the scrollBehavior
	*/
	function finalizeNavigation(toLocation, from, isPush, replace, data) {
		const error = checkCanceledNavigation(toLocation, from);
		if (error) return error;
		const isFirstNavigation = from === START_LOCATION_NORMALIZED;
		const state = !isBrowser ? {} : history.state;
		if (isPush) {
			if (replace || isFirstNavigation) routerHistory.replace(toLocation.fullPath, assign({ scroll: isFirstNavigation && state && state.scroll }, data));
			else routerHistory.push(toLocation.fullPath, data);
		}
		currentRoute.value = toLocation;
		handleScroll(toLocation, from, isPush, isFirstNavigation);
		markAsReady();
	}
	let removeHistoryListener;
	function setupListeners() {
		if (removeHistoryListener) return;
		removeHistoryListener = routerHistory.listen((to, _from, info) => {
			if (!router.listening) return;
			const toLocation = resolve(to);
			const shouldRedirect = handleRedirectRecord(toLocation, router.currentRoute.value);
			if (shouldRedirect) {
				pushWithRedirect(assign(shouldRedirect, {
					replace: true,
					force: true
				}), toLocation).catch(noop);
				return;
			}
			pendingLocation = toLocation;
			const from = currentRoute.value;
			if (isBrowser && info.delta) saveScrollPosition(getScrollKey(from.fullPath, info.delta));
			navigate(toLocation, from).catch((error) => {
				if (isNavigationFailure(error, 12)) return error;
				if (isNavigationFailure(error, 2)) {
					pushWithRedirect(assign(locationAsObject(error.to), { force: true }), toLocation).then((failure) => {
						if (isNavigationFailure(failure, 20) && !info.delta && info.type === "pop") routerHistory.go(-1, false);
					}).catch(noop);
					return Promise.reject();
				}
				if (info.delta) routerHistory.go(-info.delta, false);
				return triggerError(error, toLocation, from);
			}).then((failure) => {
				failure = failure || finalizeNavigation(toLocation, from, false);
				if (failure) {
					if (info.delta && !isNavigationFailure(failure, 8)) routerHistory.go(-info.delta, false);
					else if (info.type === "pop" && isNavigationFailure(failure, 20)) routerHistory.go(-1, false);
				}
				triggerAfterEach(toLocation, from, failure);
			}).catch(noop);
		});
	}
	let readyHandlers = useCallbacks();
	let errorListeners = useCallbacks();
	let ready;
	/**
	* Trigger errorListeners added via onError and throws the error as well
	*
	* @param error - error to throw
	* @param to - location we were navigating to when the error happened
	* @param from - location we were navigating from when the error happened
	* @returns the error as a rejected promise
	*/
	function triggerError(error, to, from) {
		markAsReady(error);
		const list = errorListeners.list();
		if (list.length) list.forEach((handler) => handler(error, to, from));
		else {
			diagnostics.VUE_ROUTER_R0010();
			console.error(error);
		}
		return Promise.reject(error);
	}
	function isReady() {
		if (ready && currentRoute.value !== START_LOCATION_NORMALIZED) return Promise.resolve();
		return new Promise((resolve, reject) => {
			readyHandlers.add([resolve, reject]);
		});
	}
	function markAsReady(err) {
		if (!ready) {
			ready = !err;
			setupListeners();
			readyHandlers.list().forEach(([resolve, reject]) => err ? reject(err) : resolve());
			readyHandlers.reset();
		}
		return err;
	}
	function handleScroll(to, from, isPush, isFirstNavigation) {
		const { scrollBehavior } = options;
		if (!isBrowser || !scrollBehavior) return Promise.resolve();
		const scrollPosition = !isPush && getSavedScrollPosition(getScrollKey(to.fullPath, 0)) || (isFirstNavigation || !isPush) && history.state && history.state.scroll || null;
		return nextTick().then(() => scrollBehavior(to, from, scrollPosition)).then((position) => to === currentRoute.value && position && scrollToPosition(position)).catch((err) => to === currentRoute.value && triggerError(err, to, from));
	}
	const go = (delta) => routerHistory.go(delta);
	let started;
	const installedApps = /* @__PURE__ */ new Set();
	const router = {
		currentRoute,
		listening: true,
		addRoute,
		removeRoute,
		clearRoutes,
		hasRoute,
		getRoutes,
		resolve,
		options,
		push,
		replace,
		go,
		back: () => go(-1),
		forward: () => go(1),
		beforeEach: beforeGuards.add,
		beforeResolve: beforeResolveGuards.add,
		afterEach: afterGuards.add,
		onError: errorListeners.add,
		isReady,
		install(app) {
			app.component("RouterLink", RouterLink);
			app.component("RouterView", RouterView);
			app.config.globalProperties.$router = router;
			Object.defineProperty(app.config.globalProperties, "$route", {
				enumerable: true,
				get: () => unref(currentRoute)
			});
			if (isBrowser && !started && currentRoute.value === START_LOCATION_NORMALIZED) {
				started = true;
				push(routerHistory.location).catch((err) => {
					diagnostics.VUE_ROUTER_R0011({ cause: err });
				});
			}
			const reactiveRoute = {};
			for (const key in START_LOCATION_NORMALIZED) Object.defineProperty(reactiveRoute, key, {
				get: () => currentRoute.value[key],
				enumerable: true
			});
			app.provide(routerKey, router);
			app.provide(routeLocationKey, shallowReactive(reactiveRoute));
			app.provide(routerViewLocationKey, currentRoute);
			const unmountApp = app.unmount;
			installedApps.add(app);
			app.unmount = function() {
				installedApps.delete(app);
				if (installedApps.size < 1) {
					pendingLocation = START_LOCATION_NORMALIZED;
					removeHistoryListener && removeHistoryListener();
					removeHistoryListener = null;
					currentRoute.value = START_LOCATION_NORMALIZED;
					started = false;
					ready = false;
				}
				unmountApp();
			};
			if (isBrowser && true) addDevtools(app, router, matcher);
		}
	};
	function runGuardQueue(guards) {
		return guards.reduce((promise, guard) => promise.then(() => runWithContext(guard)), Promise.resolve());
	}
	return router;
}
//#endregion
export { NavigationFailureType, RouterLink, RouterView, START_LOCATION_NORMALIZED as START_LOCATION, createMemoryHistory, createRouter, createRouterMatcher, createWebHashHistory, createWebHistory, isNavigationFailure, loadRouteLocation, matchedRouteKey, onBeforeRouteLeave, onBeforeRouteUpdate, parseQuery, routeLocationKey, routerKey, routerViewLocationKey, stringifyQuery, useLink, useRoute, useRouter, viewDepthKey };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQU1BLFNBQVMsaUJBQWlCLFlBQVk7Q0FDckMsTUFBTSxTQUFTLElBQUksV0FBVyxLQUFLLElBQUksV0FBVztDQUNsRCxNQUFNLFVBQVUsQ0FBQztDQUNqQixJQUFJLFdBQVcsS0FBSyxRQUFRLEtBQUssUUFBUSxXQUFXLEtBQUs7Q0FDekQsSUFBSSxXQUFXLFNBQVMsUUFBUSxRQUFRLEtBQUssWUFBWSxXQUFXLFFBQVEsS0FBSyxJQUFJLEdBQUc7Q0FDeEYsSUFBSSxXQUFXLE1BQU0sUUFBUSxLQUFLLFFBQVEsV0FBVyxNQUFNO0NBQzNELElBQUksUUFBUSxXQUFXLEdBQUcsT0FBTztDQUNqQyxPQUFPLENBQUMsUUFBUSxHQUFHLFFBQVEsS0FBSyxRQUFRLE1BQU07RUFDN0MsT0FBTyxHQUFHLElBQUksUUFBUSxTQUFTLElBQUksT0FBTyxLQUFLLEdBQUc7Q0FDbkQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLElBQUk7QUFDZDs7Ozs7Ozs7O0FBV0EsU0FBUyxnQkFBZ0IsT0FBTyxHQUFHLE1BQU07Q0FDeEMsT0FBTyxPQUFPLFVBQVUsYUFBYSxNQUFNLEdBQUcsSUFBSSxJQUFJO0FBQ3ZEOzs7Ozs7OztBQVVBLFNBQVMsc0JBQXNCLEVBQUUsUUFBUSxnQkFBZ0IsUUFBUSxZQUFZLHFCQUFxQixDQUFDLEdBQUc7Q0FDckcsUUFBUSxZQUFZLEVBQUUsU0FBUyxrQkFBa0IsQ0FBQyxNQUFNO0VBQ3ZELFFBQVEsT0FBTyxDQUFDLFVBQVUsVUFBVSxDQUFDO0NBQ3RDO0FBQ0Q7QUFDQSxJQUFNLG9CQUFvQixNQUFNO0FBQ2hDLElBQUksYUFBYSxNQUFNLG1CQUFtQixNQUFNO0NBQy9DOzs7OztDQUtBOzs7OztDQUtBOzs7O0NBSUE7Ozs7Ozs7Q0FPQTs7OztDQUlBLElBQUksTUFBTTtFQUNULE9BQU8sS0FBSztDQUNiOzs7Ozs7OztDQVFBLFlBQVksTUFBTSxjQUFjLFlBQVk7RUFDM0MsTUFBTSxLQUFLLEtBQUssRUFBRSxPQUFPLEtBQUssTUFBTSxDQUFDO0VBQ3JDLEtBQUssT0FBTyxLQUFLLE9BQU8sS0FBSztFQUM3QixLQUFLLE1BQU0sS0FBSztFQUNoQixLQUFLLE9BQU8sS0FBSztFQUNqQixLQUFLLFVBQVUsS0FBSztFQUNwQixvQkFBb0IsTUFBTSxXQUFXO0NBQ3RDOzs7O0NBSUEsU0FBUztFQUNSLE9BQU87R0FDTixNQUFNLEtBQUs7R0FDWCxLQUFLLEtBQUs7R0FDVixLQUFLLEtBQUs7R0FDVixNQUFNLEtBQUs7R0FDWCxTQUFTLEtBQUs7R0FDZCxPQUFPLEtBQUs7R0FDWixPQUFPLEtBQUs7RUFDYjtDQUNEO0FBQ0Q7Ozs7Ozs7OztBQVNBLFNBQVMsV0FBVyxVQUFVLE1BQU07Q0FDbkMsT0FBTyxPQUFPLGFBQWEsV0FBVyxHQUFHLFNBQVMsR0FBRyxLQUFLLFlBQVksTUFBTSxXQUFXLElBQUk7QUFDNUY7Ozs7Ozs7QUFPQSxTQUFTLGtCQUFrQixTQUFTO0NBQ25DLE1BQU0sWUFBWSxRQUFRLGFBQWEsQ0FBQztDQUN4QyxNQUFNLFNBQVMsQ0FBQztDQUNoQixNQUFNLEVBQUUsYUFBYTtDQUNyQixLQUFLLE1BQU0sUUFBUSxPQUFPLEtBQUssUUFBUSxLQUFLLEdBQUc7RUFDOUMsTUFBTSxNQUFNLFFBQVEsTUFBTTtFQUMxQixNQUFNLE9BQU8sSUFBSSxTQUFTLFFBQVEsS0FBSyxJQUFJLElBQUksUUFBUSxXQUFXLFVBQVUsSUFBSTtFQUNoRixNQUFNLFVBQVUsU0FBUyxDQUFDLEdBQUcsa0JBQWtCLENBQUMsTUFBTTtHQUNyRCxNQUFNLGFBQWEsSUFBSSxXQUFXO0lBQ2pDO0lBQ0EsS0FBSyxnQkFBZ0IsSUFBSSxLQUFLLE1BQU07SUFDcEMsS0FBSyxnQkFBZ0IsSUFBSSxLQUFLLE1BQU07SUFDcEM7SUFDQSxPQUFPLE9BQU87SUFDZCxTQUFTLE9BQU87R0FDakIsR0FBRyxNQUFNO0dBQ1QsS0FBSyxNQUFNLFlBQVksV0FBVyxTQUFTLFlBQVksZUFBZTtHQUN0RSxPQUFPO0VBQ1I7RUFDQSxPQUFPLFFBQVE7Q0FDaEI7Q0FDQSxPQUFPO0FBQ1I7Ozs7Ozs7Ozs7Ozs7OztBQ3hIQSxJQUFNLGtCQUFrQixTQUFTLEtBQUssV0FBVyxHQUFHOzs7Ozs7O0FBT3BELFNBQVMsaUJBQWlCLFdBQVc7Q0FDcEMsT0FBTyxPQUFPLGNBQWMsWUFBWSxpQkFBaUIsYUFBYSxXQUFXLGFBQWEsZUFBZTtBQUM5RztBQUNBLFNBQVMsV0FBVyxLQUFLO0NBQ3hCLE9BQU8sSUFBSSxjQUFjLElBQUksT0FBTyxpQkFBaUIsWUFBWSxJQUFJLFdBQVcsaUJBQWlCLElBQUksT0FBTztBQUM3RztBQUNBLElBQU0sU0FBUyxPQUFPO0FBQ3RCLFNBQVMsY0FBYyxJQUFJLFFBQVE7Q0FDbEMsTUFBTSxZQUFZLENBQUM7Q0FDbkIsS0FBSyxNQUFNLE9BQU8sUUFBUTtFQUN6QixNQUFNLFFBQVEsT0FBTztFQUNyQixVQUFVLE9BQU8sUUFBUSxLQUFLLElBQUksTUFBTSxJQUFJLEVBQUUsSUFBSSxHQUFHLEtBQUs7Q0FDM0Q7Q0FDQSxPQUFPO0FBQ1I7QUFDQSxJQUFNLGFBQWEsQ0FBQzs7Ozs7OztBQU9wQixJQUFNLFVBQVUsTUFBTTtBQUN0QixTQUFTLGFBQWEsVUFBVSxnQkFBZ0I7Q0FDL0MsTUFBTSxVQUFVLENBQUM7Q0FDakIsS0FBSyxNQUFNLE9BQU8sVUFBVSxRQUFRLE9BQU8sT0FBTyxpQkFBaUIsZUFBZSxPQUFPLFNBQVM7Q0FDbEcsT0FBTztBQUNSO0FBR0EsSUFBTSwwQkFBMEIsT0FBK0Msb0JBQXlCOzs7OztBQUt4RyxJQUFJLHdCQUF3Qyx5QkFBUyx1QkFBdUI7Ozs7O0NBSzNFLHNCQUFzQixzQkFBc0IsYUFBYSxLQUFLOzs7OztDQUs5RCxzQkFBc0Isc0JBQXNCLGVBQWUsS0FBSzs7Ozs7Q0FLaEUsc0JBQXNCLHNCQUFzQixnQkFBZ0IsTUFBTTtDQUNsRSxPQUFPO0FBQ1IsRUFBRSxDQUFDLENBQUM7QUFDSixJQUFNLG9CQUFvQjtDQUN6QixDQUFDLEdBQUcsRUFBRSxVQUFVLG1CQUFtQjtFQUNsQyxPQUFPLGtCQUFrQixLQUFLLFVBQVUsUUFBUSxJQUFJLGtCQUFrQix1QkFBdUIsS0FBSyxVQUFVLGVBQWUsSUFBSTtDQUNoSTtDQUNBLENBQUMsR0FBRyxFQUFFLE1BQU0sTUFBTTtFQUNqQixPQUFPLG9CQUFvQixLQUFLLFNBQVMsUUFBUSxlQUFlLEVBQUUsRUFBRTtDQUNyRTtDQUNBLENBQUMsR0FBRyxFQUFFLE1BQU0sTUFBTTtFQUNqQixPQUFPLDRCQUE0QixLQUFLLFNBQVMsUUFBUSxHQUFHLFNBQVM7Q0FDdEU7Q0FDQSxDQUFDLEdBQUcsRUFBRSxNQUFNLE1BQU07RUFDakIsT0FBTyw4QkFBOEIsS0FBSyxTQUFTLFFBQVEsR0FBRyxTQUFTO0NBQ3hFO0NBQ0EsQ0FBQyxJQUFJLEVBQUUsTUFBTSxJQUFJLE9BQU87RUFDdkIsT0FBTyxzREFBc0QsS0FBSyxTQUFTO0NBQzVFO0FBQ0Q7Ozs7Ozs7QUFPQSxTQUFTLGtCQUFrQixNQUFNLFFBQVE7Q0FDWSxPQUFPLE9BQU8sSUFBSSxNQUFNLGtCQUFrQixLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUc7RUFDN0c7R0FDQywwQkFBMEI7Q0FDNUIsR0FBRyxNQUFNO0FBS1Y7QUFDQSxTQUFTLG9CQUFvQixPQUFPLE1BQU07Q0FDekMsT0FBTyxpQkFBaUIsU0FBUywyQkFBMkIsVUFBVSxRQUFRLFFBQVEsQ0FBQyxFQUFFLE1BQU0sT0FBTztBQUN2RztBQUNBLElBQU0sa0JBQWtCO0NBQ3ZCO0NBQ0E7Q0FDQTtBQUNEOzs7Ozs7QUFNQSxTQUFTLGVBQWUsSUFBSTtDQUMzQixJQUFJLENBQUMsTUFBTSxPQUFPLE9BQU8sVUFBVSxPQUFPO0NBQzFDLElBQUksR0FBRyxRQUFRLE1BQU0sT0FBTyxHQUFHO0NBQy9CLE1BQU0sV0FBVyxDQUFDO0NBQ2xCLEtBQUssTUFBTSxPQUFPLGlCQUFpQixJQUFJLE9BQU8sSUFBSSxTQUFTLE9BQU8sR0FBRztDQUNyRSxPQUFPLEtBQUssVUFBVSxVQUFVLE1BQU0sQ0FBQztBQUN4Qzs7Ozs7Ozs7Ozs7Ozs7OztBQWtCQSxJQUFNLGNBQTRCLGdDQUFrQjtDQUNuRCxXQUFXLENBQWUsb0NBQXNCLENBQUM7Q0FDakQsT0FBTztFQUNOLGtCQUFrQjtHQUNqQixNQUFNLE1BQU0saUJBQWlCLEVBQUUsS0FBSztHQUNwQyxLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBQ0Esa0JBQWtCO0dBQ2pCLE1BQU0sTUFBTSxxQ0FBcUMsRUFBRSxLQUFLO0dBQ3hELEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFDQSxrQkFBa0I7R0FDakIsTUFBTSxNQUFNLGFBQWEsZUFBZSxFQUFFLFFBQVEsRUFBRSxpQkFBaUIsRUFBRSxLQUFLO0dBQzVFLEtBQUs7RUFDTjtFQUNBLGtCQUFrQjtHQUNqQixNQUFNLE1BQU0sMENBQTBDLGVBQWUsRUFBRSxJQUFJLEVBQUU7R0FDN0UsS0FBSztHQUNMLE1BQU07RUFDUDtFQUNBLGtCQUFrQjtHQUNqQixNQUFNLE1BQU0sNkZBQTZGLGVBQWUsRUFBRSxXQUFXO0dBQ3JJLEtBQUs7RUFDTjtFQUNBLGtCQUFrQjtHQUNqQixNQUFNLE1BQU0sU0FBUyxFQUFFLEtBQUs7R0FDNUIsS0FBSztHQUNMLE1BQU07RUFDUDtFQUNBLGtCQUFrQjtHQUNqQixNQUFNLE1BQU0sdUVBQXVFLEVBQUUsS0FBSztHQUMxRixNQUFNLE1BQU0seURBQXlELEVBQUUsS0FBSztFQUM3RTtFQUNBLGtCQUFrQjtHQUNqQixNQUFNLE1BQU0sNEJBQTRCLEVBQUUsT0FBTyx5QkFBeUIsRUFBRSxHQUFHO0dBQy9FLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFDQSxrQkFBa0I7R0FDakIsTUFBTSxNQUFNLG1GQUFtRixFQUFFLEtBQUssUUFBUSxFQUFFLEdBQUc7R0FDbkgsS0FBSztHQUNMLE1BQU07RUFDUDtFQUNBLGtCQUFrQjtHQUNqQixLQUFLO0dBQ0wsS0FBSztFQUNOO0VBQ0Esa0JBQWtCO0dBQ2pCLEtBQUs7R0FDTCxLQUFLO0VBQ047RUFDQSxrQkFBa0I7R0FDakIsTUFBTSxNQUFNLG1EQUFtRCxFQUFFLEdBQUc7R0FDcEUsS0FBSztHQUNMLE1BQU07RUFDUDtFQUNBLGtCQUFrQjtHQUNqQixLQUFLO0dBQ0wsS0FBSztFQUNOO0VBQ0Esa0JBQWtCO0dBQ2pCLE1BQU0sTUFBTSxHQUFHLEVBQUUsR0FBRztHQUNwQixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBQ0Esa0JBQWtCO0dBQ2pCLE1BQU0sTUFBTSxrREFBa0QsRUFBRSxPQUFPLElBQUksRUFBRSxLQUFLLEtBQUssR0FBRyxLQUFLLEVBQUU7R0FDakcsS0FBSztHQUNMLE1BQU07RUFDUDtFQUNBLGtCQUFrQjtHQUNqQixNQUFNLE1BQU0sMEZBQTBGLEVBQUUsS0FBSyxRQUFRLEVBQUUsR0FBRztHQUMxSCxLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBQ0Esa0JBQWtCO0dBQ2pCLEtBQUs7R0FDTCxLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBQ0Esa0JBQWtCO0dBQ2pCLE1BQU0sTUFBTSxxQkFBcUIsRUFBRSxLQUFLO0dBQ3hDLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFDQSxrQkFBa0I7R0FDakIsTUFBTSxNQUFNLGNBQWMsRUFBRSxLQUFLLHlCQUF5QixFQUFFLEtBQUssd0NBQXdDLEVBQUUsU0FBUztHQUNwSCxLQUFLO0VBQ047RUFDQSxrQkFBa0I7R0FDakIsTUFBTSxNQUFNLGNBQWMsRUFBRSxLQUFLLHlCQUF5QixFQUFFLEtBQUs7R0FDakUsS0FBSztHQUNMLE1BQU07RUFDUDtFQUNBLGtCQUFrQjtHQUNqQixNQUFNLE1BQU0sY0FBYyxFQUFFLEtBQUsseUJBQXlCLEVBQUUsS0FBSztHQUNqRSxLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBQ0Esa0JBQWtCO0dBQ2pCLE1BQU0sTUFBTSxjQUFjLEVBQUUsS0FBSyx5QkFBeUIsRUFBRSxLQUFLO0dBQ2pFLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFDQSxrQkFBa0I7R0FDakIsTUFBTSxNQUFNLFlBQVksRUFBRSxHQUFHLDhGQUE4RixFQUFFLEdBQUcsTUFBTSxDQUFDLEVBQUUsMERBQTBELEVBQUUsR0FBRztHQUN4TSxNQUFNLE1BQU0saUZBQWlGLEVBQUUsR0FBRztHQUNsRyxNQUFNO0VBQ1A7RUFDQSxrQkFBa0I7R0FDakIsTUFBTSxNQUFNLGlCQUFpQixFQUFFLEdBQUc7R0FDbEMsS0FBSztHQUNMLE1BQU07RUFDUDtFQUNBLGtCQUFrQjtHQUNqQixNQUFNLE1BQU0seUNBQXlDLEVBQUUsR0FBRztHQUMxRCxLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBQ0Esa0JBQWtCO0dBQ2pCLE1BQU0sTUFBTTtJQUNYLElBQUk7SUFDSixJQUFJO0tBQ0gsS0FBSyxFQUFFLE9BQU8sS0FBSyxJQUFJLGNBQWMsS0FBSyxVQUFVLEVBQUUsRUFBRTtJQUN6RCxRQUFRO0tBQ1AsS0FBSyxPQUFPLEVBQUUsRUFBRTtJQUNqQjtJQUNBLE9BQU8sbURBQW1EO0dBQzNEO0dBQ0EsS0FBSztFQUNOO0VBQ0Esa0JBQWtCO0dBQ2pCLE1BQU0sTUFBTSx3REFBd0QsRUFBRSxLQUFLO0dBQzNFLE1BQU0sTUFBTSw0Q0FBNEMsRUFBRSxLQUFLLHdGQUF3RixFQUFFLEtBQUssNENBQTRDLEVBQUUsS0FBSztHQUNqTixNQUFNO0VBQ1A7RUFDQSxrQkFBa0I7R0FDakIsTUFBTSxNQUFNLG1GQUFtRixFQUFFLEdBQUcsVUFBVSxFQUFFLEtBQUs7R0FDckgsTUFBTSxNQUFNLHVFQUF1RSxFQUFFLEtBQUs7RUFDM0Y7RUFDQSxrQkFBa0I7R0FDakIsTUFBTSxNQUFNLG1CQUFtQixFQUFFLEtBQUs7R0FDdEMsS0FBSztFQUNOO0VBQ0Esa0JBQWtCO0dBQ2pCLE1BQU0sTUFBTSxzQ0FBc0MsRUFBRSxLQUFLLGNBQWMsRUFBRSxLQUFLO0dBQzlFLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFDQSxrQkFBa0I7R0FDakIsTUFBTSxNQUFNLCtCQUErQixFQUFFLE9BQU8sc0JBQXNCLEVBQUUsWUFBWTtHQUN4RixLQUFLO0VBQ047RUFDQSxrQkFBa0I7R0FDakIsTUFBTSxNQUFNLDJEQUEyRCxFQUFFLEtBQUssbURBQW1ELEVBQUUsS0FBSztHQUN4SSxLQUFLO0VBQ047RUFDQSxrQkFBa0I7R0FDakIsTUFBTSxNQUFNLFVBQVUsRUFBRSxNQUFNLDhCQUE4QixFQUFFLFNBQVMsMENBQTBDLEVBQUUsS0FBSztHQUN4SCxLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBQ0Esa0JBQWtCO0dBQ2pCLE1BQU0sTUFBTSxvQkFBb0IsRUFBRSxLQUFLO0dBQ3ZDLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFDQSxrQkFBa0I7R0FDakIsTUFBTSxNQUFNLGtCQUFrQixFQUFFLEtBQUssMENBQTBDLEVBQUUsS0FBSyxtQkFBbUIsRUFBRSxPQUFPO0dBQ2xILEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFDQSxrQkFBa0I7R0FDakIsTUFBTSxNQUFNLDJCQUEyQixFQUFFLFNBQVMsZ0JBQWdCLEVBQUUsT0FBTztHQUMzRSxLQUFLO0VBQ047RUFDQSxrQkFBa0I7R0FDakIsS0FBSztHQUNMLE1BQU0sTUFBTSwwRUFBMEUsRUFBRSxLQUFLLGVBQWUsRUFBRSxXQUFXO0VBQzFIO0VBQ0Esa0JBQWtCO0dBQ2pCLEtBQUs7R0FDTCxLQUFLO0VBQ047RUFDQSxrQkFBa0I7R0FDakIsS0FBSztHQUNMLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFDQSxrQkFBa0I7R0FDakIsTUFBTSxNQUFNLGdCQUFnQixPQUFPLEVBQUUsR0FBRyxFQUFFO0dBQzFDLEtBQUs7RUFDTjtFQUNBLGtCQUFrQjtHQUNqQixLQUFLO0dBQ0wsS0FBSztHQUNMLE1BQU07RUFDUDtFQUNBLGtCQUFrQjtHQUNqQixNQUFNLE1BQU0sV0FBVyxFQUFFLElBQUk7R0FDN0IsS0FBSztHQUNMLE1BQU07RUFDUDtFQUNBLGtCQUFrQjtHQUNqQixNQUFNLE1BQU0sNkVBQTZFLEVBQUU7R0FDM0YsS0FBSztHQUNMLE1BQU07RUFDUDtFQUNBLGtCQUFrQjtHQUNqQixNQUFNLE1BQU0sZ0JBQWdCLEVBQUUsSUFBSTtHQUNsQyxLQUFLO0VBQ047RUFDQSxrQkFBa0I7R0FDakIsTUFBTSxNQUFNLHlEQUF5RCxFQUFFLElBQUk7R0FDM0UsS0FBSztHQUNMLE1BQU07RUFDUDtFQUNBLGtCQUFrQjtHQUNqQixLQUFLO0dBQ0wsS0FBSztHQUNMLE1BQU07RUFDUDtFQUNBLGtCQUFrQjtHQUNqQixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBQ0Esa0JBQWtCO0dBQ2pCLEtBQUs7R0FDTCxLQUFLO0dBQ0wsTUFBTTtFQUNQO0NBQ0Q7QUFDRCxDQUFDOzs7Ozs7OztBQVVELElBQU0sa0JBQWtCLE9BQStDLDhCQUFtQzs7Ozs7OztBQU8xRyxJQUFNLGVBQWUsT0FBK0MsbUJBQXdCOzs7Ozs7O0FBTzVGLElBQU0sWUFBWSxPQUErQyxRQUFhOzs7Ozs7O0FBTzlFLElBQU0sbUJBQW1CLE9BQStDLGdCQUFxQjs7Ozs7OztBQU83RixJQUFNLHdCQUF3QixPQUErQyxzQkFBMkI7Ozs7O0FBT3hHLFNBQVMsWUFBWTtDQUNwQixPQUFPLE9BQU8sU0FBUztBQUN4Qjs7Ozs7QUFLQSxTQUFTLFNBQVMsT0FBTztDQUN4QixPQUFPLE9BQU8sZ0JBQWdCO0FBQy9COzs7QUN4YkEsSUFBSUEsYUFBVyxPQUFPO0FBQ3RCLElBQUlDLGNBQVksT0FBTztBQUN2QixJQUFJQyxxQkFBbUIsT0FBTztBQUM5QixJQUFJQyxzQkFBb0IsT0FBTztBQUMvQixJQUFJQyxpQkFBZSxPQUFPO0FBQzFCLElBQUlDLGlCQUFlLE9BQU8sVUFBVTtBQUNwQyxJQUFJQyxtQkFBaUIsSUFBSSxlQUFlLE9BQU8sSUFBSSxNQUFNLEVBQUUsU0FBUyxDQUFDLEVBQUUsR0FBRyxTQUFTLEdBQUcsR0FBRyxJQUFJO0FBQzdGLElBQUlDLGlCQUFlLElBQUksTUFBTSxRQUFRLFNBQVM7Q0FDN0MsSUFBSSxRQUFRLE9BQU8sU0FBUyxZQUFZLE9BQU8sU0FBUyxZQUFZLEtBQUssSUFBSSxPQUFPSixvQkFBa0IsSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxLQUFLLElBQUksR0FBRyxLQUFLO0VBQ3JKLE1BQU0sS0FBSztFQUNYLElBQUksQ0FBQ0UsZUFBYSxLQUFLLElBQUksR0FBRyxLQUFLLFFBQVEsUUFBUSxZQUFVLElBQUksS0FBSztHQUNyRSxPQUFPLE1BQU0sS0FBSyxJQUFJLEtBQUssTUFBTSxHQUFHO0dBQ3BDLFlBQVksRUFBRSxPQUFPSCxtQkFBaUIsTUFBTSxHQUFHLE1BQU0sS0FBSztFQUMzRCxDQUFDO0NBQ0Y7Q0FDQSxPQUFPO0FBQ1I7QUFDQSxJQUFJTSxhQUFXLEtBQUssWUFBWSxZQUFZLFNBQVMsT0FBTyxPQUFPUixXQUFTSSxlQUFhLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBR0csY0FBWSxjQUFjLENBQUMsT0FBTyxDQUFDLElBQUksYUFBYU4sWUFBVSxRQUFRLFdBQVc7Q0FDckwsT0FBTztDQUNQLFlBQVk7QUFDYixDQUFDLElBQUksUUFBUSxHQUFHO0FBU2hCLElBQU1RLGNBQVksT0FBTyxjQUFjO0FBQ3ZDLElBQU0sU0FBUyxPQUFPLFdBQVcsY0FBYyxTQUFTLE9BQU8sZUFBZSxjQUFjLGFBQWEsT0FBTyxXQUFXLGNBQWMsU0FBUyxDQUFDO0FBQzNILE9BQU8sT0FBTyxXQUFXLGVBQWlCLE9BQU8sT0FBTztBQUM3REEsZ0JBQWEsT0FBTyxNQUFTLE9BQU87QUFDbEMsT0FBTyxjQUFjLGVBQWUsVUFBVSxXQUFXLFlBQVksQ0FBQyxDQUFDLFNBQVMsVUFBVTtBQUM3RixPQUFPLFdBQVcsZUFBaUIsT0FBTztBQUk1RCxJQUFJLGNBQThCLDJCQUF5QixrQ0FBZ0IsU0FBUyxXQUFXO0NBQzlGLE9BQU8sVUFBVTtDQUNqQixTQUFTLFdBQVcsS0FBSztFQUN4QixJQUFJLGVBQWUsUUFBUSxPQUFPLE9BQU8sS0FBSyxHQUFHO0VBQ2pELE9BQU8sSUFBSSxJQUFJLFlBQVksSUFBSSxPQUFPLE1BQU0sR0FBRyxJQUFJLFlBQVksSUFBSSxNQUFNO0NBQzFFO0NBQ0EsU0FBUyxLQUFLLE1BQU07RUFDbkIsT0FBTyxRQUFRLENBQUM7RUFDaEIsSUFBSSxLQUFLLFNBQVMsT0FBTyxZQUFZLElBQUk7RUFDekMsTUFBTSxzQ0FBc0MsSUFBSSxJQUFJO0VBQ3BELG9CQUFvQixJQUFJLE9BQU8sTUFBTSxJQUFJLEtBQUssQ0FBQyxDQUFDO0VBQ2hELG9CQUFvQixJQUFJLE1BQU0sR0FBRyxPQUFPLElBQUksSUFBSSxXQUFXLE1BQU0sS0FBSyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7RUFDOUUsb0JBQW9CLElBQUksTUFBTSxHQUFHLE9BQU8sSUFBSSxJQUFJLFdBQVcsTUFBTSxLQUFLLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztFQUM5RSxJQUFJLEtBQUsscUJBQXFCLEtBQUssTUFBTSxXQUFXLEtBQUsscUJBQXFCLG9CQUFvQixJQUFJLFFBQVEsSUFBSSxRQUFRLEVBQUU7RUFDNUgsSUFBSSxVQUFVO0VBQ2QsT0FBTyxLQUFLLFFBQVEsYUFBYTtFQUNqQyxTQUFTLFdBQVcsR0FBRyxJQUFJO0dBQzFCLE1BQU0sT0FBTyxPQUFPLEtBQUssQ0FBQztHQUMxQixNQUFNLEtBQUssSUFBSSxNQUFNLEtBQUssTUFBTTtHQUNoQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxRQUFRLEtBQUs7SUFDckMsTUFBTSxJQUFJLEtBQUs7SUFDZixNQUFNLE1BQU0sRUFBRTtJQUNkLElBQUksT0FBTyxRQUFRLFlBQVksUUFBUSxNQUFNLEdBQUcsS0FBSztTQUNoRCxJQUFJLElBQUksZ0JBQWdCLFdBQVcsVUFBVSxvQkFBb0IsSUFBSSxJQUFJLFdBQVcsSUFBSSxHQUFHLEtBQUssUUFBUSxLQUFLLEVBQUU7U0FDL0csSUFBSSxZQUFZLE9BQU8sR0FBRyxHQUFHLEdBQUcsS0FBSyxXQUFXLEdBQUc7U0FDbkQsR0FBRyxLQUFLLEdBQUcsR0FBRztHQUNwQjtHQUNBLE9BQU87RUFDUjtFQUNBLFNBQVMsTUFBTSxHQUFHO0dBQ2pCLElBQUksT0FBTyxNQUFNLFlBQVksTUFBTSxNQUFNLE9BQU87R0FDaEQsSUFBSSxNQUFNLFFBQVEsQ0FBQyxHQUFHLE9BQU8sV0FBVyxHQUFHLEtBQUs7R0FDaEQsSUFBSSxFQUFFLGdCQUFnQixXQUFXLFVBQVUsb0JBQW9CLElBQUksRUFBRSxXQUFXLElBQUksT0FBTyxRQUFRLEdBQUcsS0FBSztHQUMzRyxNQUFNLEtBQUssQ0FBQztHQUNaLEtBQUssTUFBTSxLQUFLLEdBQUc7SUFDbEIsSUFBSSxPQUFPLGVBQWUsS0FBSyxHQUFHLENBQUMsTUFBTSxPQUFPO0lBQ2hELE1BQU0sTUFBTSxFQUFFO0lBQ2QsSUFBSSxPQUFPLFFBQVEsWUFBWSxRQUFRLE1BQU0sR0FBRyxLQUFLO1NBQ2hELElBQUksSUFBSSxnQkFBZ0IsV0FBVyxVQUFVLG9CQUFvQixJQUFJLElBQUksV0FBVyxJQUFJLEdBQUcsS0FBSyxRQUFRLEtBQUssS0FBSztTQUNsSCxJQUFJLFlBQVksT0FBTyxHQUFHLEdBQUcsR0FBRyxLQUFLLFdBQVcsR0FBRztTQUNuRCxHQUFHLEtBQUssTUFBTSxHQUFHO0dBQ3ZCO0dBQ0EsT0FBTztFQUNSO0VBQ0EsU0FBUyxXQUFXLEdBQUc7R0FDdEIsSUFBSSxPQUFPLE1BQU0sWUFBWSxNQUFNLE1BQU0sT0FBTztHQUNoRCxJQUFJLE1BQU0sUUFBUSxDQUFDLEdBQUcsT0FBTyxXQUFXLEdBQUcsVUFBVTtHQUNyRCxJQUFJLEVBQUUsZ0JBQWdCLFdBQVcsVUFBVSxvQkFBb0IsSUFBSSxFQUFFLFdBQVcsSUFBSSxPQUFPLFFBQVEsR0FBRyxVQUFVO0dBQ2hILE1BQU0sS0FBSyxDQUFDO0dBQ1osS0FBSyxNQUFNLEtBQUssR0FBRztJQUNsQixNQUFNLE1BQU0sRUFBRTtJQUNkLElBQUksT0FBTyxRQUFRLFlBQVksUUFBUSxNQUFNLEdBQUcsS0FBSztTQUNoRCxJQUFJLElBQUksZ0JBQWdCLFdBQVcsVUFBVSxvQkFBb0IsSUFBSSxJQUFJLFdBQVcsSUFBSSxHQUFHLEtBQUssUUFBUSxLQUFLLFVBQVU7U0FDdkgsSUFBSSxZQUFZLE9BQU8sR0FBRyxHQUFHLEdBQUcsS0FBSyxXQUFXLEdBQUc7U0FDbkQsR0FBRyxLQUFLLFdBQVcsR0FBRztHQUM1QjtHQUNBLE9BQU87RUFDUjtDQUNEO0NBQ0EsU0FBUyxZQUFZLE1BQU07RUFDMUIsTUFBTSxPQUFPLENBQUM7RUFDZCxNQUFNLFVBQVUsQ0FBQztFQUNqQixNQUFNLHNDQUFzQyxJQUFJLElBQUk7RUFDcEQsb0JBQW9CLElBQUksT0FBTyxNQUFNLElBQUksS0FBSyxDQUFDLENBQUM7RUFDaEQsb0JBQW9CLElBQUksTUFBTSxHQUFHLE9BQU8sSUFBSSxJQUFJLFdBQVcsTUFBTSxLQUFLLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztFQUM5RSxvQkFBb0IsSUFBSSxNQUFNLEdBQUcsT0FBTyxJQUFJLElBQUksV0FBVyxNQUFNLEtBQUssQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO0VBQzlFLElBQUksS0FBSyxxQkFBcUIsS0FBSyxNQUFNLFdBQVcsS0FBSyxxQkFBcUIsb0JBQW9CLElBQUksUUFBUSxJQUFJLFFBQVEsRUFBRTtFQUM1SCxJQUFJLFVBQVU7RUFDZCxPQUFPLEtBQUssUUFBUSxhQUFhO0VBQ2pDLFNBQVMsV0FBVyxHQUFHLElBQUk7R0FDMUIsTUFBTSxPQUFPLE9BQU8sS0FBSyxDQUFDO0dBQzFCLE1BQU0sS0FBSyxJQUFJLE1BQU0sS0FBSyxNQUFNO0dBQ2hDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLFFBQVEsS0FBSztJQUNyQyxNQUFNLElBQUksS0FBSztJQUNmLE1BQU0sTUFBTSxFQUFFO0lBQ2QsSUFBSSxPQUFPLFFBQVEsWUFBWSxRQUFRLE1BQU0sR0FBRyxLQUFLO1NBQ2hELElBQUksSUFBSSxnQkFBZ0IsV0FBVyxVQUFVLG9CQUFvQixJQUFJLElBQUksV0FBVyxJQUFJLEdBQUcsS0FBSyxRQUFRLEtBQUssRUFBRTtTQUMvRyxJQUFJLFlBQVksT0FBTyxHQUFHLEdBQUcsR0FBRyxLQUFLLFdBQVcsR0FBRztTQUNuRDtLQUNKLE1BQU0sUUFBUSxLQUFLLFFBQVEsR0FBRztLQUM5QixJQUFJLFVBQVUsSUFBSSxHQUFHLEtBQUssUUFBUTtVQUM3QixHQUFHLEtBQUssR0FBRyxHQUFHO0lBQ3BCO0dBQ0Q7R0FDQSxPQUFPO0VBQ1I7RUFDQSxTQUFTLE1BQU0sR0FBRztHQUNqQixJQUFJLE9BQU8sTUFBTSxZQUFZLE1BQU0sTUFBTSxPQUFPO0dBQ2hELElBQUksTUFBTSxRQUFRLENBQUMsR0FBRyxPQUFPLFdBQVcsR0FBRyxLQUFLO0dBQ2hELElBQUksRUFBRSxnQkFBZ0IsV0FBVyxVQUFVLG9CQUFvQixJQUFJLEVBQUUsV0FBVyxJQUFJLE9BQU8sUUFBUSxHQUFHLEtBQUs7R0FDM0csTUFBTSxLQUFLLENBQUM7R0FDWixLQUFLLEtBQUssQ0FBQztHQUNYLFFBQVEsS0FBSyxFQUFFO0dBQ2YsS0FBSyxNQUFNLEtBQUssR0FBRztJQUNsQixJQUFJLE9BQU8sZUFBZSxLQUFLLEdBQUcsQ0FBQyxNQUFNLE9BQU87SUFDaEQsTUFBTSxNQUFNLEVBQUU7SUFDZCxJQUFJLE9BQU8sUUFBUSxZQUFZLFFBQVEsTUFBTSxHQUFHLEtBQUs7U0FDaEQsSUFBSSxJQUFJLGdCQUFnQixXQUFXLFVBQVUsb0JBQW9CLElBQUksSUFBSSxXQUFXLElBQUksR0FBRyxLQUFLLFFBQVEsS0FBSyxLQUFLO1NBQ2xILElBQUksWUFBWSxPQUFPLEdBQUcsR0FBRyxHQUFHLEtBQUssV0FBVyxHQUFHO1NBQ25EO0tBQ0osTUFBTSxJQUFJLEtBQUssUUFBUSxHQUFHO0tBQzFCLElBQUksTUFBTSxJQUFJLEdBQUcsS0FBSyxRQUFRO1VBQ3pCLEdBQUcsS0FBSyxNQUFNLEdBQUc7SUFDdkI7R0FDRDtHQUNBLEtBQUssSUFBSTtHQUNULFFBQVEsSUFBSTtHQUNaLE9BQU87RUFDUjtFQUNBLFNBQVMsV0FBVyxHQUFHO0dBQ3RCLElBQUksT0FBTyxNQUFNLFlBQVksTUFBTSxNQUFNLE9BQU87R0FDaEQsSUFBSSxNQUFNLFFBQVEsQ0FBQyxHQUFHLE9BQU8sV0FBVyxHQUFHLFVBQVU7R0FDckQsSUFBSSxFQUFFLGdCQUFnQixXQUFXLFVBQVUsb0JBQW9CLElBQUksRUFBRSxXQUFXLElBQUksT0FBTyxRQUFRLEdBQUcsVUFBVTtHQUNoSCxNQUFNLEtBQUssQ0FBQztHQUNaLEtBQUssS0FBSyxDQUFDO0dBQ1gsUUFBUSxLQUFLLEVBQUU7R0FDZixLQUFLLE1BQU0sS0FBSyxHQUFHO0lBQ2xCLE1BQU0sTUFBTSxFQUFFO0lBQ2QsSUFBSSxPQUFPLFFBQVEsWUFBWSxRQUFRLE1BQU0sR0FBRyxLQUFLO1NBQ2hELElBQUksSUFBSSxnQkFBZ0IsV0FBVyxVQUFVLG9CQUFvQixJQUFJLElBQUksV0FBVyxJQUFJLEdBQUcsS0FBSyxRQUFRLEtBQUssVUFBVTtTQUN2SCxJQUFJLFlBQVksT0FBTyxHQUFHLEdBQUcsR0FBRyxLQUFLLFdBQVcsR0FBRztTQUNuRDtLQUNKLE1BQU0sSUFBSSxLQUFLLFFBQVEsR0FBRztLQUMxQixJQUFJLE1BQU0sSUFBSSxHQUFHLEtBQUssUUFBUTtVQUN6QixHQUFHLEtBQUssV0FBVyxHQUFHO0lBQzVCO0dBQ0Q7R0FDQSxLQUFLLElBQUk7R0FDVCxRQUFRLElBQUk7R0FDWixPQUFPO0VBQ1I7Q0FDRDtBQUNELEVBQUUsR0FBRyxHQUFHLENBQUM7QUFJVCxJQUFNLGFBQWE7QUFHbkIsU0FBUyxRQUFRLEdBQUcsR0FBRztDQUN0QixPQUFPLElBQUksRUFBRSxZQUFZLElBQUk7QUFDOUI7QUFDQSxTQUFTLFNBQVMsS0FBSztDQUN0QixPQUFPLE9BQU8sR0FBRyxNQUFNLFFBQVEsWUFBWSxPQUFPO0FBQ25EO0FBU0EsU0FBUyxTQUFTLFVBQVUsS0FBSztDQUNoQyxJQUFJLHFCQUFxQixTQUFTLFFBQVEsWUFBWSxFQUFFLENBQUMsQ0FBQyxRQUFRLE9BQU8sR0FBRztDQUM1RSxJQUFJLG1CQUFtQixTQUFTLFFBQVEsS0FBSyxHQUFHLHFCQUFxQixtQkFBbUIsUUFBUSxTQUFTLE9BQU8sR0FBRztDQUNuSCxNQUFNLGlCQUFpQixtQkFBbUIsWUFBWSxHQUFHO0NBQ3pELE1BQU0sa0JBQWtCLG1CQUFtQixVQUFVLGlCQUFpQixDQUFDO0NBQ3ZFLElBQUksS0FBSztFQUNSLE1BQU0sV0FBVyxnQkFBZ0IsWUFBWSxHQUFHO0VBQ2hELE9BQU8sZ0JBQWdCLFVBQVUsR0FBRyxRQUFRO0NBQzdDO0NBQ0EsT0FBTztBQUNSOzs7OztBQW1CQSxJQUFNLGFBQWEsR0FBRyxZQUFZLFNBQVMsRUFBRSxTQUFTLEtBQUssQ0FBQzs7O0FDNU41RCxJQUFNLG9CQUFvQixFQUFFLFVBQVUsS0FBSzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQW1CM0MsU0FBUyxTQUFTLElBQUksT0FBTyxJQUFJLFVBQVUsQ0FBQyxHQUFHO0NBQzlDLFVBQVU7RUFDVCxHQUFHO0VBQ0gsR0FBRztDQUNKO0NBQ0EsSUFBSSxDQUFDLE9BQU8sU0FBUyxJQUFJLEdBQUcsTUFBTSxJQUFJLFVBQVUsdUNBQXVDO0NBQ3ZGLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSSxjQUFjLENBQUM7Q0FDbkIsSUFBSTtDQUNKLElBQUk7Q0FDSixNQUFNLFdBQVcsT0FBTyxTQUFTO0VBQ2hDLGlCQUFpQixlQUFlLElBQUksT0FBTyxJQUFJO0VBQy9DLGVBQWUsY0FBYztHQUM1QixpQkFBaUI7R0FDakIsSUFBSSxRQUFRLFlBQVksZ0JBQWdCLENBQUMsU0FBUztJQUNqRCxNQUFNLFVBQVUsUUFBUSxPQUFPLFlBQVk7SUFDM0MsZUFBZTtJQUNmLE9BQU87R0FDUjtFQUNELENBQUM7RUFDRCxPQUFPO0NBQ1I7Q0FDQSxNQUFNLFlBQVksU0FBUyxHQUFHLE1BQU07RUFDbkMsSUFBSSxRQUFRLFVBQVUsZUFBZTtFQUNyQyxJQUFJLGdCQUFnQixPQUFPO0VBQzNCLE9BQU8sSUFBSSxTQUFTLFlBQVk7R0FDL0IsTUFBTSxnQkFBZ0IsQ0FBQyxXQUFXLFFBQVE7R0FDMUMsYUFBYSxPQUFPO0dBQ3BCLFVBQVUsaUJBQWlCO0lBQzFCLFVBQVU7SUFDVixNQUFNLFVBQVUsUUFBUSxVQUFVLGVBQWUsUUFBUSxNQUFNLElBQUk7SUFDbkUsZUFBZTtJQUNmLEtBQUssTUFBTSxZQUFZLGFBQWEsU0FBUyxPQUFPO0lBQ3BELGNBQWMsQ0FBQztHQUNoQixHQUFHLElBQUk7R0FDUCxJQUFJLGVBQWU7SUFDbEIsZUFBZSxRQUFRLE1BQU0sSUFBSTtJQUNqQyxRQUFRLFlBQVk7R0FDckIsT0FBTyxZQUFZLEtBQUssT0FBTztFQUNoQyxDQUFDO0NBQ0Y7Q0FDQSxNQUFNLGlCQUFpQixVQUFVO0VBQ2hDLElBQUksT0FBTztHQUNWLGFBQWEsS0FBSztHQUNsQixVQUFVO0VBQ1g7Q0FDRDtDQUNBLFVBQVUsa0JBQWtCLENBQUMsQ0FBQztDQUM5QixVQUFVLGVBQWU7RUFDeEIsY0FBYyxPQUFPO0VBQ3JCLGNBQWMsQ0FBQztFQUNmLGVBQWU7Q0FDaEI7Q0FDQSxVQUFVLGNBQWM7RUFDdkIsY0FBYyxPQUFPO0VBQ3JCLElBQUksQ0FBQyxnQkFBZ0IsZ0JBQWdCO0VBQ3JDLE1BQU0sT0FBTztFQUNiLGVBQWU7RUFDZixPQUFPLFFBQVEsTUFBTSxJQUFJO0NBQzFCO0NBQ0EsT0FBTztBQUNSO0FBQ0EsZUFBZSxlQUFlLElBQUksT0FBTyxNQUFNO0NBQzlDLE9BQU8sTUFBTSxHQUFHLE1BQU0sT0FBTyxJQUFJO0FBQ2xDOzs7QUNyRkEsU0FBUyxVQUFVLGFBQWEsUUFBUSxDQUFDLEdBQUcsWUFBWTtDQUN0RCxLQUFLLE1BQU0sT0FBTyxhQUFhO0VBQzdCLE1BQU0sVUFBVSxZQUFZO0VBQzVCLE1BQU0sT0FBTyxhQUFhLEdBQUcsV0FBVyxHQUFHLFFBQVE7RUFDbkQsSUFBSSxPQUFPLFlBQVksWUFBWSxZQUFZLE1BQzdDLFVBQVUsU0FBUyxPQUFPLElBQUk7T0FDekIsSUFBSSxPQUFPLFlBQVksWUFDNUIsTUFBTSxRQUFRO0NBRWxCO0NBQ0EsT0FBTztBQUNUO0FBNkJBLElBQU0sY0FBYyxFQUFFLE1BQU0sY0FBYyxVQUFVLEVBQUU7QUFDdEQsSUFBTSxvQkFBb0I7QUFDMUIsSUFBTSxhQUFhLE9BQU8sUUFBUSxlQUFlLGNBQWMsUUFBUSxhQUFhO0FBQ3BGLFNBQVMsaUJBQWlCLE9BQU8sTUFBTTtDQUVyQyxNQUFNLE9BQU8sV0FEQSxLQUFLLE1BQ00sQ0FBSTtDQUM1QixPQUFPLE1BQU0sUUFDVixTQUFTLGlCQUFpQixRQUFRLFdBQVcsS0FBSyxVQUFVLGFBQWEsR0FBRyxJQUFJLENBQUMsQ0FBQyxHQUNuRixRQUFRLFFBQVEsQ0FDbEI7QUFDRjtBQUNBLFNBQVMsbUJBQW1CLE9BQU8sTUFBTTtDQUV2QyxNQUFNLE9BQU8sV0FEQSxLQUFLLE1BQ00sQ0FBSTtDQUM1QixPQUFPLFFBQVEsSUFBSSxNQUFNLEtBQUssU0FBUyxLQUFLLFVBQVUsS0FBSyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDdkU7QUFVQSxTQUFTLGFBQWEsV0FBVyxNQUFNO0NBQ3JDLEtBQUssTUFBTSxZQUFZLENBQUMsR0FBRyxTQUFTLEdBQ2xDLFNBQVMsSUFBSTtBQUVqQjtBQUVBLElBQU0sV0FBTixNQUFlO0NBQ2IsY0FBYztFQUNaLEtBQUssU0FBUyxDQUFDO0VBQ2YsS0FBSyxVQUFVLEtBQUs7RUFDcEIsS0FBSyxTQUFTLEtBQUs7RUFDbkIsS0FBSyxzQkFBc0IsS0FBSztFQUNoQyxLQUFLLG1CQUFtQixDQUFDO0VBQ3pCLEtBQUssT0FBTyxLQUFLLEtBQUssS0FBSyxJQUFJO0VBQy9CLEtBQUssV0FBVyxLQUFLLFNBQVMsS0FBSyxJQUFJO0VBQ3ZDLEtBQUssZUFBZSxLQUFLLGFBQWEsS0FBSyxJQUFJO0NBQ2pEO0NBQ0EsS0FBSyxNQUFNLFdBQVcsVUFBVSxDQUFDLEdBQUc7RUFDbEMsSUFBSSxDQUFDLFFBQVEsT0FBTyxjQUFjLFlBQ2hDLGFBQWEsQ0FDYjtFQUVGLE1BQU0sZUFBZTtFQUNyQixJQUFJO0VBQ0osT0FBTyxLQUFLLGlCQUFpQixPQUFPO0dBQ2xDLE1BQU0sS0FBSyxpQkFBaUI7R0FDNUIsT0FBTyxJQUFJO0VBQ2I7RUFDQSxJQUFJLE9BQU8sQ0FBQyxRQUFRLGlCQUFpQjtHQUNuQyxJQUFJLFVBQVUsSUFBSTtHQUNsQixJQUFJLENBQUMsU0FDSCxVQUFVLEdBQUcsYUFBYSw4QkFBOEIsSUFBSSxLQUFLLGdCQUFnQixJQUFJLE9BQU87R0FFOUYsSUFBSSxDQUFDLEtBQUsscUJBQ1IsS0FBSyxzQ0FBc0MsSUFBSSxJQUFJO0dBRXJELElBQUksQ0FBQyxLQUFLLG9CQUFvQixJQUFJLE9BQU8sR0FBRztJQUMxQyxRQUFRLEtBQUssT0FBTztJQUNwQixLQUFLLG9CQUFvQixJQUFJLE9BQU87R0FDdEM7RUFDRjtFQUNBLElBQUksQ0FBQyxVQUFVLE1BQ2IsSUFBSTtHQUNGLE9BQU8sZUFBZSxXQUFXLFFBQVE7SUFDdkMsV0FBVyxNQUFNLEtBQUssUUFBUSxRQUFRLEdBQUcsSUFBSTtJQUM3QyxjQUFjO0dBQ2hCLENBQUM7RUFDSCxRQUFRLENBQ1I7RUFFRixLQUFLLE9BQU8sUUFBUSxLQUFLLE9BQU8sU0FBUyxDQUFDO0VBQzFDLEtBQUssT0FBTyxLQUFLLENBQUMsS0FBSyxTQUFTO0VBQ2hDLGFBQWE7R0FDWCxJQUFJLFdBQVc7SUFDYixLQUFLLFdBQVcsTUFBTSxTQUFTO0lBQy9CLFlBQVksS0FBSztHQUNuQjtFQUNGO0NBQ0Y7Q0FDQSxTQUFTLE1BQU0sV0FBVztFQUN4QixJQUFJO0VBQ0osSUFBSSxhQUFhLEdBQUcsZUFBZTtHQUNqQyxJQUFJLE9BQU8sV0FBVyxZQUNwQixPQUFPO0dBRVQsU0FBUyxLQUFLO0dBQ2QsWUFBWSxLQUFLO0dBQ2pCLE9BQU8sVUFBVSxHQUFHLFVBQVU7RUFDaEM7RUFDQSxTQUFTLEtBQUssS0FBSyxNQUFNLFNBQVM7RUFDbEMsT0FBTztDQUNUO0NBQ0EsV0FBVyxNQUFNLFdBQVc7RUFDMUIsSUFBSSxLQUFLLE9BQU8sT0FBTztHQUNyQixNQUFNLFFBQVEsS0FBSyxPQUFPLEtBQUssQ0FBQyxRQUFRLFNBQVM7R0FDakQsSUFBSSxVQUFVLElBQ1osS0FBSyxPQUFPLEtBQUssQ0FBQyxPQUFPLE9BQU8sQ0FBQztHQUVuQyxJQUFJLEtBQUssT0FBTyxLQUFLLENBQUMsV0FBVyxHQUMvQixPQUFPLEtBQUssT0FBTztFQUV2QjtDQUNGO0NBQ0EsY0FBYyxNQUFNLFlBQVk7RUFDOUIsS0FBSyxpQkFBaUIsUUFBUSxPQUFPLGVBQWUsV0FBVyxFQUFFLElBQUksV0FBVyxJQUFJO0VBQ3BGLE1BQU0sU0FBUyxLQUFLLE9BQU8sU0FBUyxDQUFDO0VBQ3JDLE9BQU8sS0FBSyxPQUFPO0VBQ25CLEtBQUssTUFBTSxRQUFRLFFBQ2pCLEtBQUssS0FBSyxNQUFNLElBQUk7Q0FFeEI7Q0FDQSxlQUFlLGlCQUFpQjtFQUM5QixPQUFPLE9BQU8sS0FBSyxrQkFBa0IsZUFBZTtFQUNwRCxLQUFLLE1BQU0sUUFBUSxpQkFDakIsS0FBSyxjQUFjLE1BQU0sZ0JBQWdCLEtBQUs7Q0FFbEQ7Q0FDQSxTQUFTLGFBQWE7RUFDcEIsTUFBTSxRQUFRLFVBQVUsV0FBVztFQUNuQyxNQUFNLFlBQVksT0FBTyxLQUFLLEtBQUssQ0FBQyxDQUFDLEtBQ2xDLFFBQVEsS0FBSyxLQUFLLEtBQUssTUFBTSxJQUFJLENBQ3BDO0VBQ0EsYUFBYTtHQUNYLEtBQUssTUFBTSxTQUFTLFVBQVUsT0FBTyxHQUFHLFVBQVUsTUFBTSxHQUN0RCxNQUFNO0VBRVY7Q0FDRjtDQUNBLFlBQVksYUFBYTtFQUN2QixNQUFNLFFBQVEsVUFBVSxXQUFXO0VBQ25DLEtBQUssTUFBTSxPQUFPLE9BQ2hCLEtBQUssV0FBVyxLQUFLLE1BQU0sSUFBSTtDQUVuQztDQUNBLGlCQUFpQjtFQUNmLEtBQUssTUFBTSxPQUFPLEtBQUssUUFDckIsT0FBTyxLQUFLLE9BQU87Q0FFdkI7Q0FDQSxTQUFTLE1BQU0sR0FBRyxZQUFZO0VBQzVCLFdBQVcsUUFBUSxJQUFJO0VBQ3ZCLE9BQU8sS0FBSyxhQUFhLGtCQUFrQixNQUFNLEdBQUcsVUFBVTtDQUNoRTtDQUNBLGlCQUFpQixNQUFNLEdBQUcsWUFBWTtFQUNwQyxXQUFXLFFBQVEsSUFBSTtFQUN2QixPQUFPLEtBQUssYUFBYSxvQkFBb0IsTUFBTSxHQUFHLFVBQVU7Q0FDbEU7Q0FDQSxhQUFhLFFBQVEsTUFBTSxHQUFHLFlBQVk7RUFDeEMsTUFBTSxRQUFRLEtBQUssV0FBVyxLQUFLLFNBQVM7R0FBRTtHQUFNLE1BQU07R0FBWSxTQUFTLENBQUM7RUFBRSxJQUFJLEtBQUs7RUFDM0YsSUFBSSxLQUFLLFNBQ1AsYUFBYSxLQUFLLFNBQVMsS0FBSztFQUVsQyxNQUFNLFNBQVMsT0FDYixRQUFRLEtBQUssU0FBUyxDQUFDLEdBQUcsS0FBSyxPQUFPLEtBQUssSUFBSSxDQUFDLEdBQ2hELFVBQ0Y7RUFDQSxJQUFJLGtCQUFrQixTQUNwQixPQUFPLE9BQU8sY0FBYztHQUMxQixJQUFJLEtBQUssVUFBVSxPQUNqQixhQUFhLEtBQUssUUFBUSxLQUFLO0VBRW5DLENBQUM7RUFFSCxJQUFJLEtBQUssVUFBVSxPQUNqQixhQUFhLEtBQUssUUFBUSxLQUFLO0VBRWpDLE9BQU87Q0FDVDtDQUNBLFdBQVcsV0FBVztFQUNwQixLQUFLLFVBQVUsS0FBSyxXQUFXLENBQUM7RUFDaEMsS0FBSyxRQUFRLEtBQUssU0FBUztFQUMzQixhQUFhO0dBQ1gsSUFBSSxLQUFLLFlBQVksS0FBSyxHQUFHO0lBQzNCLE1BQU0sUUFBUSxLQUFLLFFBQVEsUUFBUSxTQUFTO0lBQzVDLElBQUksVUFBVSxJQUNaLEtBQUssUUFBUSxPQUFPLE9BQU8sQ0FBQztHQUVoQztFQUNGO0NBQ0Y7Q0FDQSxVQUFVLFdBQVc7RUFDbkIsS0FBSyxTQUFTLEtBQUssVUFBVSxDQUFDO0VBQzlCLEtBQUssT0FBTyxLQUFLLFNBQVM7RUFDMUIsYUFBYTtHQUNYLElBQUksS0FBSyxXQUFXLEtBQUssR0FBRztJQUMxQixNQUFNLFFBQVEsS0FBSyxPQUFPLFFBQVEsU0FBUztJQUMzQyxJQUFJLFVBQVUsSUFDWixLQUFLLE9BQU8sT0FBTyxPQUFPLENBQUM7R0FFL0I7RUFDRjtDQUNGO0FBQ0Y7QUFDQSxTQUFTLGNBQWM7Q0FDckIsT0FBTyxJQUFJLFNBQVM7QUFDdEI7OztBQ3pPQSxJQUFNLEVBQUUsOEJBQWMsNkJBQWU7QUFDdEIsS0FBSyxPQUFPLEtBQUssSUFBSTtBQ0dwQyxJQUFJLGlCQUFpQixJQUFJLGVBQWUsT0FBTyxJQUFJLE1BQU0sRUFBRSxTQUFTLENBQUMsRUFBRSxHQUFHLFNBQVMsR0FBRyxHQUFHLElBQUk7QUErQjdGLFNBQVMscUJBQXFCLFNBQVM7Q0FDdEMsSUFBSSxPQUFPLFlBQVksWUFBWSxPQUFPLFFBQVEsZUFBZSxRQUFRLFFBQVEsUUFBUSwwQ0FBMEM7Q0FDbkksTUFBTSxPQUFPLFFBQVEsUUFBUSxRQUFRLGlCQUFpQixRQUFRLDBDQUEwQyxRQUFRO0NBQ2hILElBQUksU0FBUyxXQUFXLFFBQVEsUUFBUSxTQUFTLFdBQVcsR0FBRyxPQUFPO0NBQ3RFLE9BQU87QUFDUjtBQUNBLFNBQVMscUJBQXFCLFNBQVM7Q0FDdEMsTUFBTSxPQUFPLFFBQVE7Q0FDckIsSUFBSSxNQUFNLE9BQU8sU0FBUyxTQUFTLE1BQU0sTUFBTSxDQUFDO0FBQ2pEO0FBTUEsU0FBUyx3QkFBd0IsVUFBVSxNQUFNO0NBQ2hELFNBQVMsS0FBSyx5Q0FBeUM7Q0FDdkQsT0FBTztBQUNSO0FBQ0EsU0FBUyxhQUFhLFVBQVU7Q0FDL0IsSUFBSSxTQUFTLGtDQUFrQyxPQUFPLFNBQVM7TUFDMUQsSUFBSSxTQUFTLE1BQU0sT0FBTyxTQUFTLFdBQVcsSUFBSTtBQUN4RDtBQVdBLFNBQVMsV0FBVyxVQUFVO0NBQzdCLE1BQU0sY0FBYyxTQUFTLFNBQVM7Q0FDdEMsTUFBTSxZQUFZLGFBQWEsUUFBUTtDQUN2QyxJQUFJLFdBQVcsT0FBTyxXQUFXLE9BQU8sYUFBYTtDQUNyRCxPQUFPO0FBQ1I7Ozs7Ozs7QUFVQSxTQUFTLGdCQUFnQixVQUFVO0NBQ2xDLE1BQU0sT0FBTyxxQkFBcUIsVUFBVSxRQUFRLENBQUMsQ0FBQztDQUN0RCxJQUFJLE1BQU0sT0FBTztDQUNqQixJQUFJLFVBQVUsU0FBUyxVQUFVLE9BQU87Q0FDeEMsS0FBSyxNQUFNLE9BQU8sU0FBUyxRQUFRLE1BQU0sWUFBWSxJQUFJLFNBQVMsT0FBTyxLQUFLLFdBQVcsU0FBUyxVQUFVLE1BQU0sT0FBTyx3QkFBd0IsVUFBVSxHQUFHO0NBQzlKLEtBQUssTUFBTSxPQUFPLFNBQVMsWUFBWSxZQUFZLElBQUksU0FBUyxXQUFXLFdBQVcsU0FBUyxVQUFVLE1BQU0sT0FBTyx3QkFBd0IsVUFBVSxHQUFHO0NBQzNKLE1BQU0sV0FBVyxxQkFBcUIsVUFBVSxRQUFRLENBQUMsQ0FBQztDQUMxRCxJQUFJLFVBQVUsT0FBTztDQUNyQixPQUFPO0FBQ1I7Ozs7O0FBS0EsU0FBUyxxQkFBcUIsVUFBVTtDQUN2QyxPQUFPLEdBQUcsVUFBVSxZQUFZLEtBQUssdUNBQXVDLEVBQUUsR0FBRyxhQUFhLFVBQVUsT0FBTyxTQUFTLFNBQVM7QUFDbEk7QUFlQSxTQUFTLHFCQUFxQixXQUFXLFlBQVk7Q0FDcEQsYUFBYSxjQUFjLEdBQUcsVUFBVSxHQUFHO0NBQzNDLE9BQU8sVUFBVSxZQUFZLElBQUksVUFBVSxLQUFLLFVBQVUsWUFBWSxJQUFJLE9BQU87QUFDbEY7QUFNQSxTQUFTLGFBQWE7Q0FDckIsTUFBTSxPQUFPO0VBQ1osS0FBSztFQUNMLFFBQVE7RUFDUixNQUFNO0VBQ04sT0FBTztFQUNQLElBQUksUUFBUTtHQUNYLE9BQU8sS0FBSyxRQUFRLEtBQUs7RUFDMUI7RUFDQSxJQUFJLFNBQVM7R0FDWixPQUFPLEtBQUssU0FBUyxLQUFLO0VBQzNCO0NBQ0Q7Q0FDQSxPQUFPO0FBQ1I7QUFDQSxJQUFJO0FBQ0osU0FBUyxZQUFZLE1BQU07Q0FDMUIsSUFBSSxDQUFDLE9BQU8sUUFBUSxTQUFTLFlBQVk7Q0FDekMsTUFBTSxXQUFXLElBQUk7Q0FDckIsT0FBTyxNQUFNLHNCQUFzQjtBQUNwQztBQUNBLFNBQVMsZ0JBQWdCLE9BQU87Q0FDL0IsTUFBTSxPQUFPLFdBQVc7Q0FDeEIsSUFBSSxDQUFDLE1BQU0sVUFBVSxPQUFPO0NBQzVCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLFNBQVMsUUFBUSxJQUFJLEdBQUcsS0FBSztFQUN0RCxNQUFNLGFBQWEsTUFBTSxTQUFTO0VBQ2xDLElBQUk7RUFDSixJQUFJLFdBQVcsV0FBVyxZQUFZLHlCQUF5QixXQUFXLFNBQVM7T0FDOUUsSUFBSSxXQUFXLElBQUk7R0FDdkIsTUFBTSxLQUFLLFdBQVc7R0FDdEIsSUFBSSxHQUFHLGFBQWEsS0FBSyxHQUFHLHVCQUF1QixZQUFZLEdBQUcsc0JBQXNCO1FBQ25GLElBQUksR0FBRyxhQUFhLEtBQUssR0FBRyxLQUFLLEtBQUssR0FBRyxZQUFZLFlBQVksRUFBRTtFQUN6RTtFQUNBLElBQUksV0FBVyxXQUFXLE1BQU0sU0FBUztDQUMxQztDQUNBLE9BQU87QUFDUjtBQUNBLFNBQVMsV0FBVyxHQUFHLEdBQUc7Q0FDekIsSUFBSSxDQUFDLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFO0NBQ3ZDLElBQUksQ0FBQyxFQUFFLFVBQVUsRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFLFNBQVMsRUFBRTtDQUNuRCxJQUFJLENBQUMsRUFBRSxRQUFRLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUU7Q0FDM0MsSUFBSSxDQUFDLEVBQUUsU0FBUyxFQUFFLFFBQVEsRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFO0NBQy9DLE9BQU87QUFDUjtBQUNBLElBQU0sZUFBZTtDQUNwQixLQUFLO0NBQ0wsTUFBTTtDQUNOLE9BQU87Q0FDUCxRQUFRO0NBQ1IsT0FBTztDQUNQLFFBQVE7QUFDVDtBQUNBLFNBQVMseUJBQXlCLFVBQVU7Q0FDM0MsTUFBTSxLQUFLLFNBQVMsUUFBUTtDQUM1QixJQUFJLE9BQU8sV0FBVyxhQUFhLE9BQU87Q0FDMUMsSUFBSSxXQUFXLFFBQVEsR0FBRyxPQUFPLGdCQUFnQixTQUFTLE9BQU87TUFDNUQsSUFBSSxJQUFJLGFBQWEsR0FBRyxPQUFPLElBQUksc0JBQXNCO01BQ3pELElBQUksU0FBUyxRQUFRLFdBQVcsT0FBTyx5QkFBeUIsU0FBUyxRQUFRLFNBQVM7TUFDMUYsT0FBTztBQUNiO0FBR0EsU0FBUyxxQ0FBcUMsVUFBVTtDQUN2RCxJQUFJLFdBQVcsUUFBUSxHQUFHLE9BQU8sd0JBQXdCLFNBQVMsT0FBTztDQUN6RSxJQUFJLENBQUMsU0FBUyxTQUFTLE9BQU8sQ0FBQztDQUMvQixPQUFPLENBQUMsU0FBUyxRQUFRLEVBQUU7QUFDNUI7QUFDQSxTQUFTLHdCQUF3QixPQUFPO0NBQ3ZDLElBQUksQ0FBQyxNQUFNLFVBQVUsT0FBTyxDQUFDO0NBQzdCLE1BQU0sT0FBTyxDQUFDO0NBQ2QsTUFBTSxTQUFTLFNBQVMsZUFBZTtFQUN0QyxJQUFJLFdBQVcsV0FBVyxLQUFLLEtBQUssR0FBRyxxQ0FBcUMsV0FBVyxTQUFTLENBQUM7T0FDNUYsSUFBSSxZQUFZLElBQUksS0FBSyxLQUFLLFdBQVcsRUFBRTtDQUNqRCxDQUFDO0NBQ0QsT0FBTztBQUNSO0FBR0EsSUFBTSx1QkFBdUI7QUFDN0IsSUFBTSxrQkFBa0I7QUFDeEIsSUFBTSw0QkFBNEI7QUFDbEMsSUFBTSx1QkFBdUI7QUFDN0IsSUFBTSxrQkFBa0I7Q0FDdkIsU0FBUztDQUNULFFBQVE7Q0FDUixVQUFVO0NBQ1YsaUJBQWlCO0NBQ2pCLFFBQVE7Q0FDUixjQUFjO0NBQ2QsWUFBWTtDQUNaLGVBQWU7QUFDaEI7QUFDQSxJQUFNLGFBQWE7Q0FDbEIsWUFBWTtDQUNaLFNBQVM7Q0FDVCxjQUFjO0NBQ2QsV0FBVztDQUNYLFVBQVU7Q0FDVixNQUFNO0NBQ04sT0FBTztDQUNQLFVBQVU7Q0FDVixZQUFZO0NBQ1osWUFBWTtDQUNaLGlCQUFpQjtDQUNqQixXQUFXO0FBQ1o7QUFDQSxJQUFNLGtCQUFrQjtDQUN2QixTQUFTO0NBQ1QsWUFBWTtDQUNaLFdBQVc7Q0FDWCxVQUFVO0NBQ1YsU0FBUztBQUNWO0FBQ0EsU0FBUyxzQkFBc0I7Q0FDOUIsT0FBTyxTQUFTLGVBQWUsb0JBQW9CO0FBQ3BEO0FBQ0EsU0FBUyxpQkFBaUI7Q0FDekIsT0FBTyxTQUFTLGVBQWUsZUFBZTtBQUMvQztBQUNBLFNBQVMsc0JBQXNCO0NBQzlCLE9BQU8sU0FBUyxlQUFlLG9CQUFvQjtBQUNwRDtBQUNBLFNBQVMsaUJBQWlCO0NBQ3pCLE9BQU8sU0FBUyxlQUFlLHlCQUF5QjtBQUN6RDtBQUNBLFNBQVMsVUFBVSxRQUFRO0NBQzFCLE9BQU87RUFDTixNQUFNLEdBQUcsS0FBSyxNQUFNLE9BQU8sT0FBTyxHQUFHLElBQUksSUFBSTtFQUM3QyxLQUFLLEdBQUcsS0FBSyxNQUFNLE9BQU8sTUFBTSxHQUFHLElBQUksSUFBSTtFQUMzQyxPQUFPLEdBQUcsS0FBSyxNQUFNLE9BQU8sUUFBUSxHQUFHLElBQUksSUFBSTtFQUMvQyxRQUFRLEdBQUcsS0FBSyxNQUFNLE9BQU8sU0FBUyxHQUFHLElBQUksSUFBSTtDQUNsRDtBQUNEO0FBQ0EsU0FBUyxPQUFPLFNBQVM7Q0FDeEIsTUFBTSxjQUFjLFNBQVMsY0FBYyxLQUFLO0NBQ2hELFlBQVksS0FBSyxRQUFRLGFBQWE7Q0FDdEMsT0FBTyxPQUFPLFlBQVksT0FBTztFQUNoQyxHQUFHO0VBQ0gsR0FBRyxVQUFVLFFBQVEsTUFBTTtFQUMzQixHQUFHLFFBQVE7Q0FDWixDQUFDO0NBQ0QsTUFBTSxTQUFTLFNBQVMsY0FBYyxNQUFNO0NBQzVDLE9BQU8sS0FBSztDQUNaLE9BQU8sT0FBTyxPQUFPLE9BQU87RUFDM0IsR0FBRztFQUNILEtBQUssUUFBUSxPQUFPLE1BQU0sS0FBSyxJQUFJO0NBQ3BDLENBQUM7Q0FDRCxNQUFNLFNBQVMsU0FBUyxjQUFjLE1BQU07Q0FDNUMsT0FBTyxLQUFLO0NBQ1osT0FBTyxZQUFZLE9BQU8sUUFBUSxLQUFLO0NBQ3ZDLE1BQU0sY0FBYyxTQUFTLGNBQWMsR0FBRztDQUM5QyxZQUFZLEtBQUs7Q0FDakIsWUFBWSxZQUFZLEdBQUcsS0FBSyxNQUFNLFFBQVEsT0FBTyxRQUFRLEdBQUcsSUFBSSxJQUFJLEtBQUssS0FBSyxNQUFNLFFBQVEsT0FBTyxTQUFTLEdBQUcsSUFBSTtDQUN2SCxPQUFPLE9BQU8sWUFBWSxPQUFPLGVBQWU7Q0FDaEQsT0FBTyxZQUFZLE1BQU07Q0FDekIsT0FBTyxZQUFZLFdBQVc7Q0FDOUIsWUFBWSxZQUFZLE1BQU07Q0FDOUIsU0FBUyxLQUFLLFlBQVksV0FBVztDQUNyQyxPQUFPO0FBQ1I7QUFDQSxTQUFTLE9BQU8sU0FBUztDQUN4QixNQUFNLGNBQWMsb0JBQW9CO0NBQ3hDLE1BQU0sU0FBUyxlQUFlO0NBQzlCLE1BQU0sU0FBUyxlQUFlO0NBQzlCLE1BQU0sY0FBYyxvQkFBb0I7Q0FDeEMsSUFBSSxhQUFhO0VBQ2hCLE9BQU8sT0FBTyxZQUFZLE9BQU87R0FDaEMsR0FBRztHQUNILEdBQUcsVUFBVSxRQUFRLE1BQU07RUFDNUIsQ0FBQztFQUNELE9BQU8sT0FBTyxPQUFPLE9BQU8sRUFBRSxLQUFLLFFBQVEsT0FBTyxNQUFNLEtBQUssSUFBSSxRQUFRLENBQUM7RUFDMUUsT0FBTyxZQUFZLE9BQU8sUUFBUSxLQUFLO0VBQ3ZDLFlBQVksWUFBWSxHQUFHLEtBQUssTUFBTSxRQUFRLE9BQU8sUUFBUSxHQUFHLElBQUksSUFBSSxLQUFLLEtBQUssTUFBTSxRQUFRLE9BQU8sU0FBUyxHQUFHLElBQUk7Q0FDeEg7QUFDRDtBQUNBLFNBQVMsVUFBVSxVQUFVO0NBQzVCLE1BQU0sU0FBUyx5QkFBeUIsUUFBUTtDQUNoRCxJQUFJLENBQUMsT0FBTyxTQUFTLENBQUMsT0FBTyxRQUFRO0NBQ3JDLE1BQU0sT0FBTyxnQkFBZ0IsUUFBUTtDQUNyQyxvQkFBb0IsSUFBSSxPQUFPO0VBQzlCO0VBQ0E7Q0FDRCxDQUFDLElBQUksT0FBTztFQUNYO0VBQ0E7Q0FDRCxDQUFDO0FBQ0Y7QUFDQSxTQUFTLGNBQWM7Q0FDdEIsTUFBTSxLQUFLLG9CQUFvQjtDQUMvQixJQUFJLElBQUksR0FBRyxNQUFNLFVBQVU7QUFDNUI7QUFDQSxJQUFJLGtCQUFrQjtBQUN0QixTQUFTLFVBQVUsR0FBRztDQUNyQixNQUFNLFNBQVMsRUFBRTtDQUNqQixJQUFJLFFBQVE7RUFDWCxNQUFNLFdBQVcsT0FBTztFQUN4QixJQUFJLFVBQVU7R0FDYixrQkFBa0I7R0FDbEIsSUFBSSxTQUFTLE1BQU0sSUFBSTtJQUN0QixNQUFNLFNBQVMseUJBQXlCLFFBQVE7SUFDaEQsTUFBTSxPQUFPLGdCQUFnQixRQUFRO0lBQ3JDLG9CQUFvQixJQUFJLE9BQU87S0FDOUI7S0FDQTtJQUNELENBQUMsSUFBSSxPQUFPO0tBQ1g7S0FDQTtJQUNELENBQUM7R0FDRjtFQUNEO0NBQ0Q7QUFDRDtBQUNBLFNBQVMsa0JBQWtCLEdBQUcsSUFBSTtDQUNqQyxFQUFFLGVBQWU7Q0FDakIsRUFBRSxnQkFBZ0I7Q0FDbEIsSUFBSSxpQkFBaUIsR0FBRyxxQkFBcUIsZUFBZSxDQUFDO0FBQzlEO0FBQ0EsSUFBSSxzQ0FBc0M7QUFDMUMsU0FBUyxvQ0FBb0M7Q0FDNUMsWUFBWTtDQUNaLE9BQU8sb0JBQW9CLGFBQWEsU0FBUztDQUNqRCxPQUFPLG9CQUFvQixTQUFTLHFDQUFxQyxJQUFJO0NBQzdFLHNDQUFzQztBQUN2QztBQUNBLFNBQVMsOEJBQThCO0NBQ3RDLE9BQU8saUJBQWlCLGFBQWEsU0FBUztDQUM5QyxPQUFPLElBQUksU0FBUyxZQUFZO0VBQy9CLFNBQVMsU0FBUyxHQUFHO0dBQ3BCLEVBQUUsZUFBZTtHQUNqQixFQUFFLGdCQUFnQjtHQUNsQixrQkFBa0IsSUFBSSxPQUFPO0lBQzVCLE9BQU8sb0JBQW9CLFNBQVMsVUFBVSxJQUFJO0lBQ2xELHNDQUFzQztJQUN0QyxPQUFPLG9CQUFvQixhQUFhLFNBQVM7SUFDakQsTUFBTSxLQUFLLG9CQUFvQjtJQUMvQixJQUFJLElBQUksR0FBRyxNQUFNLFVBQVU7SUFDM0IsUUFBUSxLQUFLLFVBQVUsRUFBRSxHQUFHLENBQUMsQ0FBQztHQUMvQixDQUFDO0VBQ0Y7RUFDQSxzQ0FBc0M7RUFDdEMsT0FBTyxpQkFBaUIsU0FBUyxVQUFVLElBQUk7Q0FDaEQsQ0FBQztBQUNGO0FBQ0EsU0FBUyxrQkFBa0IsU0FBUztDQUNuQyxNQUFNLFdBQVcscUJBQXFCLGdCQUFnQixPQUFPLFFBQVEsRUFBRTtDQUN2RSxJQUFJLFVBQVU7RUFDYixNQUFNLENBQUMsTUFBTSxxQ0FBcUMsUUFBUTtFQUMxRCxJQUFJLE9BQU8sR0FBRyxtQkFBbUIsWUFBWSxHQUFHLGVBQWUsRUFBRSxVQUFVLFNBQVMsQ0FBQztPQUNoRjtHQUNKLE1BQU0sU0FBUyx5QkFBeUIsUUFBUTtHQUNoRCxNQUFNLGVBQWUsU0FBUyxjQUFjLEtBQUs7R0FDakQsTUFBTSxTQUFTO0lBQ2QsR0FBRyxVQUFVLE1BQU07SUFDbkIsVUFBVTtHQUNYO0dBQ0EsT0FBTyxPQUFPLGFBQWEsT0FBTyxNQUFNO0dBQ3hDLFNBQVMsS0FBSyxZQUFZLFlBQVk7R0FDdEMsYUFBYSxlQUFlLEVBQUUsVUFBVSxTQUFTLENBQUM7R0FDbEQsaUJBQWlCO0lBQ2hCLFNBQVMsS0FBSyxZQUFZLFlBQVk7R0FDdkMsR0FBRyxHQUFHO0VBQ1A7RUFDQSxpQkFBaUI7R0FDaEIsTUFBTSxTQUFTLHlCQUF5QixRQUFRO0dBQ2hELElBQUksT0FBTyxTQUFTLE9BQU8sUUFBUTtJQUNsQyxNQUFNLE9BQU8sZ0JBQWdCLFFBQVE7SUFDckMsTUFBTSxLQUFLLG9CQUFvQjtJQUMvQixLQUFLLE9BQU87S0FDWCxHQUFHO0tBQ0g7S0FDQTtJQUNELENBQUMsSUFBSSxPQUFPO0tBQ1gsR0FBRztLQUNIO0tBQ0E7SUFDRCxDQUFDO0lBQ0QsaUJBQWlCO0tBQ2hCLElBQUksSUFBSSxHQUFHLE1BQU0sVUFBVTtJQUM1QixHQUFHLElBQUk7R0FDUjtFQUNELEdBQUcsSUFBSTtDQUNSO0FBQ0Q7QUFHQSxPQUFPLGlEQUFpRDtBQUl4RCxTQUFTLHFCQUFxQixJQUFJO0NBQ2pDLElBQUksUUFBUTtDQUNaLE1BQU0sUUFBUSxrQkFBa0I7RUFDL0IsSUFBSSxPQUFPLG1CQUFtQjtHQUM3QixjQUFjLEtBQUs7R0FDbkIsU0FBUztHQUNULEdBQUc7RUFDSjtFQUNBLElBQUksU0FBUyxLQUFLLGNBQWMsS0FBSztDQUN0QyxHQUFHLEVBQUU7QUFDTjtBQUNBLFNBQVMsaUJBQWlCO0NBQ3pCLE1BQU0sWUFBWSxPQUFPO0NBQ3pCLE1BQU0sZ0JBQWdCLFVBQVU7Q0FDaEMsVUFBVSxlQUFlLE9BQU8sR0FBRyxXQUFXO0VBQzdDLFVBQVUsUUFBUTtFQUNsQixjQUFjLEdBQUcsTUFBTTtDQUN4QjtBQUNEO0FBQ0EsU0FBUyx3QkFBd0I7Q0FDaEMsT0FBTyxJQUFJLFNBQVMsWUFBWTtFQUMvQixTQUFTLFFBQVE7R0FDaEIsZUFBZTtHQUNmLFFBQVEsT0FBTyxpQkFBaUI7RUFDakM7RUFDQSxJQUFJLENBQUMsT0FBTyxtQkFBbUIsMkJBQTJCO0dBQ3pELE1BQU07RUFDUCxDQUFDO09BQ0ksTUFBTTtDQUNaLENBQUM7QUFDRjs7Ozs7Ozs7O0FBV0EsSUFBSSxnQkFBZ0MseUJBQVMsZUFBZTtDQUMzRCxjQUFjLFVBQVU7Q0FDeEIsY0FBYyxpQkFBaUI7Q0FDL0IsY0FBYyxpQkFBaUI7Q0FDL0IsY0FBYyxnQkFBZ0I7Q0FDOUIsY0FBYyxTQUFTO0NBQ3ZCLE9BQU87QUFDUixFQUFFLENBQUMsQ0FBQzs7OztBQUlKLFNBQVMsV0FBVyxPQUFPO0NBQzFCLE9BQU8sQ0FBQyxFQUFFLFNBQVMsTUFBTSxjQUFjO0FBQ3hDOzs7O0FBSUEsU0FBUyxhQUFhLE9BQU87Q0FDNUIsSUFBSSxXQUFXLEtBQUssR0FBRyxPQUFPLGFBQWEsTUFBTSxjQUFjLElBQUk7Q0FDbkUsT0FBTyxDQUFDLEVBQUUsU0FBUyxNQUFNLGNBQWM7QUFDeEM7QUFDQSxTQUFTLFFBQVEsR0FBRztDQUNuQixPQUFPLENBQUMsRUFBRSxLQUFLLEVBQUUsY0FBYztBQUNoQzs7OztBQUlBLFNBQVMsUUFBUSxVQUFVO0NBQzFCLE1BQU0sTUFBTSxZQUFZLFNBQVMsY0FBYztDQUMvQyxPQUFPLE1BQU0sUUFBUSxHQUFHLElBQUk7QUFDN0I7QUFHQSxJQUFJLGNBQWMsTUFBTTtDQUN2QixjQUFjO0VBQ2IsS0FBSyxZQUFZLElBQUksZUFBZTtDQUNyQztDQUNBLElBQUksUUFBUSxNQUFNLE9BQU8sSUFBSTtFQUM1QixNQUFNLFdBQVcsTUFBTSxRQUFRLElBQUksSUFBSSxPQUFPLEtBQUssTUFBTSxHQUFHO0VBQzVELE9BQU8sU0FBUyxTQUFTLEdBQUc7R0FDM0IsTUFBTSxVQUFVLFNBQVMsTUFBTTtHQUMvQixJQUFJLGtCQUFrQixLQUFLLFNBQVMsT0FBTyxJQUFJLE9BQU87UUFDakQsSUFBSSxrQkFBa0IsS0FBSyxTQUFTLE1BQU0sS0FBSyxPQUFPLE9BQU8sQ0FBQyxDQUFDLENBQUM7UUFDaEUsU0FBUyxPQUFPO0dBQ3JCLElBQUksS0FBSyxVQUFVLE1BQU0sTUFBTSxHQUFHLFNBQVMsS0FBSyxVQUFVLElBQUksTUFBTTtFQUNyRTtFQUNBLE1BQU0sUUFBUSxTQUFTO0VBQ3ZCLE1BQU0sT0FBTyxLQUFLLFVBQVUsSUFBSSxNQUFNLENBQUMsQ0FBQztFQUN4QyxJQUFJLElBQUksR0FBRyxRQUFRLE9BQU8sS0FBSztPQUMxQixJQUFJLEtBQUssVUFBVSxNQUFNLElBQUksR0FBRyxLQUFLLFVBQVUsSUFBSSxNQUFNLEtBQUs7T0FDOUQsT0FBTyxTQUFTO0NBQ3RCO0NBQ0EsSUFBSSxRQUFRLE1BQU07RUFDakIsTUFBTSxXQUFXLE1BQU0sUUFBUSxJQUFJLElBQUksT0FBTyxLQUFLLE1BQU0sR0FBRztFQUM1RCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksU0FBUyxRQUFRLEtBQUs7R0FDekMsSUFBSSxrQkFBa0IsS0FBSyxTQUFTLE9BQU8sSUFBSSxTQUFTLEVBQUU7UUFDckQsU0FBUyxPQUFPLFNBQVM7R0FDOUIsSUFBSSxLQUFLLFVBQVUsTUFBTSxNQUFNLEdBQUcsU0FBUyxLQUFLLFVBQVUsSUFBSSxNQUFNO0dBQ3BFLElBQUksQ0FBQyxRQUFRLE9BQU8sS0FBSztFQUMxQjtFQUNBLE9BQU87Q0FDUjtDQUNBLElBQUksUUFBUSxNQUFNLFNBQVMsT0FBTztFQUNqQyxJQUFJLE9BQU8sV0FBVyxhQUFhLE9BQU87RUFDMUMsTUFBTSxXQUFXLE1BQU0sUUFBUSxJQUFJLElBQUksS0FBSyxNQUFNLElBQUksS0FBSyxNQUFNLEdBQUc7RUFDcEUsTUFBTSxPQUFPLENBQUMsU0FBUyxJQUFJO0VBQzNCLE9BQU8sVUFBVSxTQUFTLFNBQVMsTUFBTTtHQUN4QyxNQUFNLFVBQVUsU0FBUyxNQUFNO0dBQy9CLFNBQVMsT0FBTztHQUNoQixJQUFJLEtBQUssVUFBVSxNQUFNLE1BQU0sR0FBRyxTQUFTLEtBQUssVUFBVSxJQUFJLE1BQU07RUFDckU7RUFDQSxPQUFPLFVBQVUsUUFBUSxPQUFPLFVBQVUsZUFBZSxLQUFLLFFBQVEsU0FBUyxFQUFFO0NBQ2xGO0NBQ0EseUJBQXlCLE9BQU87RUFDL0IsUUFBUSxRQUFRLE9BQU8sVUFBVTtHQUNoQyxJQUFJLE1BQU0sVUFBVSxNQUFNLFFBQVEsSUFBSSxNQUFNLFFBQVEsTUFBTSxHQUFHLE9BQU8sT0FBTyxPQUFPLENBQUM7UUFDOUUsSUFBSSxRQUFRLE1BQU0sYUFBYSxLQUFLLE9BQU8sT0FBTyxLQUFLO1FBQ3ZELElBQUksUUFBUSxNQUFNLGFBQWEsS0FBSyxPQUFPLE9BQU8sTUFBTSxLQUFLLE9BQU8sT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNO1FBQ3BGLFFBQVEsZUFBZSxRQUFRLEtBQUs7R0FDekMsSUFBSSxDQUFDLE1BQU0sUUFBUTtJQUNsQixNQUFNLFNBQVMsT0FBTyxNQUFNLFVBQVU7SUFDdEMsSUFBSSxLQUFLLFVBQVUsTUFBTSxNQUFNLEdBQUcsS0FBSyxVQUFVLElBQUksUUFBUSxLQUFLO1NBQzdELElBQUksUUFBUSxNQUFNLGFBQWEsS0FBSyxPQUFPLElBQUksTUFBTSxVQUFVLE9BQU8sS0FBSztTQUMzRSxJQUFJLFFBQVEsTUFBTSxhQUFhLEtBQUssT0FBTyxJQUFJLEtBQUs7U0FDcEQsT0FBTyxNQUFNLFVBQVUsU0FBUztHQUN0QztFQUNEO0NBQ0Q7QUFDRDtBQUNBLElBQUksaUJBQWlCLE1BQU07Q0FDMUIsSUFBSSxLQUFLLE9BQU87RUFDZixJQUFJLFFBQVEsR0FBRyxHQUFHLElBQUksUUFBUTtPQUN6QjtHQUNKLElBQUksZUFBZSxPQUFPLE1BQU0sUUFBUSxLQUFLLEdBQUc7SUFDL0MsSUFBSSxNQUFNO0lBQ1YsTUFBTSxTQUFTLE1BQU0sSUFBSSxJQUFJLENBQUMsQ0FBQztJQUMvQjtHQUNEO0dBQ0EsTUFBTSxjQUFjLE9BQU8sS0FBSyxLQUFLO0dBQ3JDLElBQUksZUFBZSxLQUFLO0lBQ3ZCLE1BQU0sa0JBQWtCLElBQUksSUFBSSxJQUFJLEtBQUssQ0FBQztJQUMxQyxZQUFZLFNBQVMsUUFBUTtLQUM1QixJQUFJLElBQUksS0FBSyxRQUFRLElBQUksT0FBTyxHQUFHLENBQUM7S0FDcEMsZ0JBQWdCLE9BQU8sR0FBRztJQUMzQixDQUFDO0lBQ0QsZ0JBQWdCLFNBQVMsUUFBUSxJQUFJLE9BQU8sR0FBRyxDQUFDO0lBQ2hEO0dBQ0Q7R0FDQSxNQUFNLGtCQUFrQixJQUFJLElBQUksT0FBTyxLQUFLLEdBQUcsQ0FBQztHQUNoRCxZQUFZLFNBQVMsUUFBUTtJQUM1QixRQUFRLElBQUksS0FBSyxLQUFLLFFBQVEsSUFBSSxPQUFPLEdBQUcsQ0FBQztJQUM3QyxnQkFBZ0IsT0FBTyxHQUFHO0dBQzNCLENBQUM7R0FDRCxnQkFBZ0IsU0FBUyxRQUFRLFFBQVEsZUFBZSxLQUFLLEdBQUcsQ0FBQztFQUNsRTtDQUNEO0NBQ0EsSUFBSSxLQUFLO0VBQ1IsT0FBTyxRQUFRLEdBQUcsSUFBSSxJQUFJLFFBQVE7Q0FDbkM7Q0FDQSxNQUFNLEtBQUs7RUFDVixPQUFPLFFBQVEsR0FBRyxLQUFLLGFBQWEsR0FBRztDQUN4QztBQUNEO0FBZ0JvQixJQUFJLFlBQVk7QUFNcEMsSUFBTSxtQ0FBbUM7QUFLekMsU0FBUyxvQ0FBb0M7Q0FDNUMsSUFBSSxPQUFPLFdBQVcsZUFBZSxDQUFDQSxlQUFhLE9BQU8saUJBQWlCLGVBQWUsaUJBQWlCLE1BQU0sT0FBTztFQUN2SCxnQkFBZ0I7RUFDaEIsbUJBQW1CO0VBQ25CLHNCQUFzQjtFQUN0Qix1QkFBdUI7RUFDdkIseUJBQXlCO0VBQ3pCLFVBQVU7Q0FDWDtDQUNBLE1BQU0sUUFBUSxPQUFPLGFBQWEsWUFBWSxjQUFjLGFBQWEsUUFBUSxnQ0FBZ0MsSUFBSTtDQUNySCxPQUFPLFFBQVEsS0FBSyxNQUFNLEtBQUssSUFBSTtFQUNsQyxnQkFBZ0I7RUFDaEIsbUJBQW1CO0VBQ25CLHNCQUFzQjtFQUN0Qix1QkFBdUI7RUFDdkIseUJBQXlCO0VBQ3pCLFVBQVU7Q0FDWDtBQUNEO0FBR0EsT0FBTyx1Q0FBdUMsQ0FBQztBQUMvQyxJQUFNLHlCQUF5QixJQUFJLE1BQU0sT0FBTyxvQ0FBb0MsRUFBRSxJQUFJLFFBQVEsTUFBTSxVQUFVO0NBQ2pILE9BQU8sUUFBUSxJQUFJLFFBQVEsTUFBTSxRQUFRO0FBQzFDLEVBQUUsQ0FBQztBQUNILFNBQVMsaUJBQWlCLFNBQVMsWUFBWTtDQUM5QyxjQUFjLG9CQUFvQixXQUFXLE1BQU07Q0FDbkQsdUJBQXVCLEtBQUs7RUFDM0IsR0FBRztFQUNILGNBQWMsV0FBVztFQUN6QixXQUFXLGFBQWEsV0FBVyxHQUFHO0NBQ3ZDLENBQUM7QUFDRjtBQVdBLE9BQU8sbUNBQW1DLENBQUM7QUFDM0MsSUFBTSxvQkFBb0IsSUFBSSxNQUFNLE9BQU8sZ0NBQWdDLEVBQUUsSUFBSSxRQUFRLE1BQU0sVUFBVTtDQUN4RyxPQUFPLFFBQVEsSUFBSSxRQUFRLE1BQU0sUUFBUTtBQUMxQyxFQUFFLENBQUM7QUFDSCxJQUFNLDJCQUEyQixlQUFlO0NBQy9DLGdCQUFnQixNQUFNLFNBQVMsMEJBQTBCLDBCQUEwQixvQkFBb0IsQ0FBQztBQUN6RyxDQUFDO0FBQ0QsU0FBUyxhQUFhLFdBQVcsWUFBWTtDQUM1QyxrQkFBa0IsS0FBSztFQUN0QixTQUFTO0VBQ1Q7RUFDQSx1QkFBdUIsVUFBVSx5QkFBeUI7RUFDMUQsd0JBQXdCLFVBQVUsMEJBQTBCO0VBQzVELFlBQVk7RUFDWixnQkFBZ0I7RUFDaEIsV0FBVyxhQUFhLFdBQVcsR0FBRztDQUN2QyxDQUFDO0NBQ0QseUJBQXlCO0FBQzFCO0FBQ0EsU0FBUyxzQkFBc0I7Q0FDOUIsT0FBTyxrQkFBa0IsUUFBUSxjQUFjLFVBQVUsV0FBVyxRQUFRLGdCQUFnQixNQUFNLEdBQUcsQ0FBQyxDQUFDLFFBQVEsY0FBYyxVQUFVLFdBQVcsT0FBTyxZQUFZLENBQUMsQ0FBQyxLQUFLLGNBQWM7RUFDekwsTUFBTSxhQUFhLFVBQVU7RUFDN0IsTUFBTSxVQUFVLFVBQVU7RUFDMUIsT0FBTztHQUNOLElBQUksUUFBUTtHQUNaLE9BQU8sUUFBUTtHQUNmLE1BQU0sV0FBVztHQUNqQixNQUFNLHNCQUFzQixTQUFTLE1BQU0sUUFBUSxNQUFNLEdBQUc7R0FDNUQsYUFBYSxXQUFXO0dBQ3hCLFVBQVUsV0FBVztHQUNyQixVQUFVLFdBQVc7RUFDdEI7Q0FDRCxDQUFDO0FBQ0Y7QUFzQkEsU0FBUyxhQUFhLElBQUksS0FBSztDQUM5QixPQUFPLGtCQUFrQixNQUFNLGNBQWMsVUFBVSxRQUFRLE9BQU8sT0FBTyxNQUFNLFVBQVUsV0FBVyxRQUFRLE1BQU0sS0FBSztBQUM1SDtBQVNBLElBQUksOEJBQThDLHlCQUFTLDZCQUE2QjtDQUN2Riw0QkFBNEIsMEJBQTBCO0NBQ3RELDRCQUE0Qix1QkFBdUI7Q0FDbkQsNEJBQTRCLDBCQUEwQjtDQUN0RCw0QkFBNEIsd0JBQXdCO0NBQ3BELDRCQUE0Qix5QkFBeUI7Q0FDckQsNEJBQTRCLDBCQUEwQjtDQUN0RCw0QkFBNEIsNEJBQTRCO0NBQ3hELDRCQUE0QixzQkFBc0I7Q0FDbEQsNEJBQTRCLHlCQUF5QjtDQUNyRCxPQUFPO0FBQ1IsRUFBRSxDQUFDLENBQUM7QUFDSixJQUFJLDBCQUEwQyx5QkFBUyx5QkFBeUI7Q0FDL0Usd0JBQXdCLG1CQUFtQjtDQUMzQyx3QkFBd0IseUJBQXlCO0NBQ2pELHdCQUF3QiwwQkFBMEI7Q0FDbEQsd0JBQXdCLGtDQUFrQztDQUMxRCx3QkFBd0IsMEJBQTBCO0NBQ2xELHdCQUF3QiwwQkFBMEI7Q0FDbEQsd0JBQXdCLDZCQUE2QjtDQUNyRCx3QkFBd0IsMEJBQTBCO0NBQ2xELHdCQUF3Qix3QkFBd0I7Q0FDaEQsd0JBQXdCLHlCQUF5QjtDQUNqRCx3QkFBd0IsMkJBQTJCO0NBQ25ELE9BQU87QUFDUixFQUFFLENBQUMsQ0FBQztBQUNKLElBQUksNEJBQTRDLHlCQUFTLDJCQUEyQjtDQUNuRiwwQkFBMEIsbUNBQW1DO0NBQzdELDBCQUEwQixvQ0FBb0M7Q0FDOUQsMEJBQTBCLG1DQUFtQztDQUM3RCwwQkFBMEIsOEJBQThCO0NBQ3hELDBCQUEwQix5Q0FBeUM7Q0FDbkUsMEJBQTBCLDRCQUE0QjtDQUN0RCwwQkFBMEIsZ0NBQWdDO0NBQzFELDBCQUEwQix5QkFBeUI7Q0FDbkQsT0FBTztBQUNSLEVBQUUsQ0FBQyxDQUFDO0FBQ0osU0FBUyx5QkFBeUI7Q0FDakMsTUFBTSxRQUFRLFlBQVk7Q0FDMUIsTUFBTSxLQUFLLHdCQUF3QixnQkFBZ0IsRUFBRSxXQUFXLGFBQWE7RUFDNUUsYUFBYSxXQUFXLE9BQU8sVUFBVTtDQUMxQyxDQUFDO0NBQ0QsTUFBTSw0QkFBNEIsU0FBUyxPQUFPLEVBQUUsYUFBYSxhQUFhO0VBQzdFLElBQUksQ0FBQyxlQUFlLENBQUMsUUFBUSxZQUFZLE9BQU8sY0FBYyxxQkFBcUI7RUFDbkYsTUFBTSxZQUFZLGFBQWEsYUFBYSxPQUFPLFdBQVcsR0FBRztFQUNqRSxNQUFNLFdBQVc7R0FDaEIsS0FBSyxPQUFPLFdBQVc7R0FDdkI7R0FDQSxRQUFRLFdBQVcsY0FBYztHQUNqQyxXQUFXLENBQUM7RUFDYjtFQUNBLE1BQU0sSUFBSSxTQUFTLFlBQVk7R0FDOUIsTUFBTSxhQUFhLE9BQU8sY0FBYztJQUN2QyxNQUFNLFFBQVEsSUFBSSxVQUFVLEtBQUssT0FBTyxHQUFHLFFBQVEsQ0FBQyxDQUFDO0lBQ3JELFFBQVE7R0FDVCxHQUFHLDRCQUE0QixrQkFBa0I7RUFDbEQsQ0FBQztFQUNELE1BQU0sYUFBYSxPQUFPLGNBQWM7R0FDdkMsTUFBTSxRQUFRLElBQUksVUFBVSxLQUFLLE9BQU8sR0FBRztJQUMxQztJQUNBLFdBQVcsU0FBUztHQUNyQixDQUFDLENBQUMsQ0FBQztFQUNKLEdBQUcsMEJBQTBCLDZCQUE2QjtDQUMzRCxHQUFHLEdBQUc7Q0FDTixNQUFNLEtBQUssd0JBQXdCLHFCQUFxQix5QkFBeUI7Q0FDakYsTUFBTSw2QkFBNkIsU0FBUyxPQUFPLEVBQUUsYUFBYSxhQUFhO0VBQzlFLElBQUksQ0FBQyxlQUFlLENBQUMsUUFBUSxZQUFZLE9BQU8sY0FBYyxxQkFBcUI7RUFDbkYsTUFBTSxZQUFZLGFBQWEsYUFBYSxPQUFPLFdBQVcsR0FBRztFQUNqRSxNQUFNLFdBQVc7R0FDaEIsS0FBSyxPQUFPLFdBQVc7R0FDdkI7R0FDQSxRQUFRLFdBQVcsa0JBQWtCO0dBQ3JDLE9BQU87RUFDUjtFQUNBLE1BQU0sTUFBTSxFQUFFLFlBQVksb0JBQW9CLGNBQWM7RUFDNUQsSUFBSSxTQUFTLFFBQVEsTUFBTSxJQUFJLFNBQVMsWUFBWTtHQUNuRCxNQUFNLGFBQWEsT0FBTyxjQUFjO0lBQ3ZDLE1BQU0sUUFBUSxJQUFJLFVBQVUsS0FBSyxPQUFPLEdBQUcsVUFBVSxHQUFHLENBQUMsQ0FBQztJQUMxRCxRQUFRO0dBQ1QsR0FBRyw0QkFBNEIsbUJBQW1CO0VBQ25ELENBQUM7RUFDRCxNQUFNLGFBQWEsT0FBTyxjQUFjO0dBQ3ZDLE1BQU0sUUFBUSxJQUFJLFVBQVUsS0FBSyxPQUFPLEdBQUc7SUFDMUM7SUFDQSxRQUFRLFNBQVM7SUFDakIsT0FBTyxTQUFTO0dBQ2pCLENBQUMsQ0FBQyxDQUFDO0VBQ0osR0FBRywwQkFBMEIsOEJBQThCO0NBQzVELEdBQUcsR0FBRztDQUNOLE1BQU0sS0FBSyx3QkFBd0Isc0JBQXNCLDBCQUEwQjtDQUNuRixNQUFNLEtBQUssd0JBQXdCLCtCQUErQixFQUFFLGFBQWEsUUFBUSxhQUFhO0VBQ3JHLE1BQU0sWUFBWSxhQUFhLGFBQWEsT0FBTyxXQUFXLEdBQUc7RUFDakUsSUFBSSxDQUFDLFdBQVc7RUFDaEIsVUFBVSxpQkFBaUI7Q0FDNUIsQ0FBQztDQUNELE1BQU0sS0FBSyx3QkFBd0IsdUJBQXVCLEVBQUUsU0FBUyxhQUFhO0VBQ2pGLGlCQUFpQixTQUFTLE9BQU8sVUFBVTtDQUM1QyxDQUFDO0NBQ0QsTUFBTSxLQUFLLHdCQUF3Qix1QkFBdUIsRUFBRSxTQUFTLGFBQWE7RUFDakYsSUFBSSxjQUFjLHVCQUF1QixDQUFDLGNBQWMsc0JBQXNCLE9BQU8sV0FBVyxPQUFPLENBQUM7R0FDdkc7R0FDQTtHQUNBO0dBQ0E7RUFDRCxDQUFDLENBQUMsU0FBUyxRQUFRLE9BQU8sR0FBRztFQUM3QixNQUFNLGFBQWEsT0FBTyxjQUFjO0dBQ3ZDLE1BQU0sUUFBUSxJQUFJLFVBQVUsS0FBSyxPQUFPLEdBQUcsT0FBTyxDQUFDLENBQUM7RUFDckQsR0FBRywwQkFBMEIsNkJBQTZCO0NBQzNELENBQUM7Q0FDRCxNQUFNLEtBQUssd0JBQXdCLHlCQUF5QixPQUFPLEVBQUUsVUFBVTtFQUM5RSxNQUFNLFlBQVksSUFBSTtFQUN0QixJQUFJLENBQUMsV0FBVyxPQUFPO0VBQ3ZCLE1BQU0sUUFBUSxVQUFVLEdBQUcsU0FBUztFQUNwQyxPQUFPLENBQUMsR0FBRyxVQUFVLFdBQVcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxTQUFTLElBQUksTUFBTSxHQUFHLENBQUMsQ0FBQyxPQUFPLEtBQUssQ0FBQyxDQUFDLEtBQUssR0FBRyxjQUFjLFFBQVE7Q0FDaEgsQ0FBQztDQUNELE1BQU0sS0FBSyx3QkFBd0Isc0JBQXNCLE9BQU8sRUFBRSxlQUFlO0VBQ2hGLE9BQU8seUJBQXlCLFFBQVE7Q0FDekMsQ0FBQztDQUNELE1BQU0sS0FBSyx3QkFBd0IscUJBQXFCLEVBQUUsZUFBZTtFQUN4RSxPQUFPLGdCQUFnQixRQUFRO0NBQ2hDLENBQUM7Q0FDRCxNQUFNLEtBQUssd0JBQXdCLHNCQUFzQixFQUFFLFVBQVU7RUFDcEUsTUFBTSxXQUFXLGdCQUFnQixNQUFNLFlBQVksSUFBSSxHQUFHO0VBQzFELElBQUksVUFBVSxVQUFVLFFBQVE7Q0FDakMsQ0FBQztDQUNELE1BQU0sS0FBSyx3QkFBd0IsNkJBQTZCO0VBQy9ELFlBQVk7Q0FDYixDQUFDO0NBQ0QsT0FBTztBQUNSO0FBR0EsT0FBTyxxQ0FBcUMsQ0FBQztBQUM3QyxPQUFPLDJDQUEyQyxDQUFDO0FBQ25ELE9BQU8sOENBQThDO0FBQ3JELE9BQU8scUNBQXFDLENBQUM7QUFDN0MsT0FBTyx5Q0FBeUMsQ0FBQztBQUNqRCxJQUFNLFlBQVk7QUFDbEIsU0FBUyxtQkFBbUI7Q0FDM0IsT0FBTztFQUNOLFdBQVc7RUFDWCxpQkFBaUI7RUFDakIsb0JBQW9CO0VBQ3BCLFlBQVksQ0FBQztFQUNiLG1CQUFtQjtFQUNuQixNQUFNLENBQUM7RUFDUCxVQUFVLENBQUM7RUFDWCxxQkFBcUI7RUFDckIsd0JBQXdCLENBQUM7RUFDekIsbUJBQW1CO0VBQ25CLHFCQUFxQixrQ0FBa0M7Q0FDeEQ7QUFDRDtBQUNBLE9BQU8sZUFBZSxpQkFBaUI7QUFDdkMsSUFBTSx1QkFBdUIsVUFBVSxVQUFVO0NBQ2hELGdCQUFnQixNQUFNLFNBQVMsMEJBQTBCLHdCQUF3QixFQUFFLE1BQU0sQ0FBQztBQUMzRixDQUFDO0FBQ2dDLFVBQVUsT0FBTyxhQUFhO0NBQzlELGdCQUFnQixNQUFNLFNBQVMsMEJBQTBCLDRCQUE0QjtFQUNwRjtFQUNBO0NBQ0QsQ0FBQztBQUNGLENBQUM7QUFDRCxJQUFNLHFCQUFxQixJQUFJLE1BQU0sT0FBTyxrQ0FBa0MsRUFBRSxJQUFJLFNBQVMsTUFBTSxVQUFVO0NBQzVHLElBQUksU0FBUyxTQUFTLE9BQU8sT0FBTztDQUNwQyxPQUFPLE9BQU8saUNBQWlDO0FBQ2hELEVBQUUsQ0FBQztBQU9ILElBQU0sa0JBQWtCLElBQUksTUFBTSxPQUFPLHdDQUF3QyxFQUFFLElBQUksU0FBUyxNQUFNLFVBQVU7Q0FDL0csSUFBSSxTQUFTLFNBQVMsT0FBTyxPQUFPO01BQy9CLElBQUksU0FBUyxNQUFNLE9BQU8sT0FBTztDQUN0QyxPQUFPLE9BQU8sdUNBQXVDO0FBQ3RELEVBQUUsQ0FBQztBQUNILFNBQVMsa0JBQWtCO0NBQzFCLHFCQUFxQjtFQUNwQixHQUFHLE9BQU87RUFDVixZQUFZLG1CQUFtQjtFQUMvQixtQkFBbUIsZ0JBQWdCO0VBQ25DLE1BQU0sT0FBTztFQUNiLFVBQVUsT0FBTztDQUNsQixDQUFDO0FBQ0Y7QUFDQSxTQUFTLG1CQUFtQixLQUFLO0NBQ2hDLE9BQU8seUNBQXlDO0NBQ2hELGdCQUFnQjtBQUNqQjtBQUNBLFNBQVMscUJBQXFCLElBQUk7Q0FDakMsT0FBTyw0Q0FBNEM7Q0FDbkQsZ0JBQWdCO0FBQ2pCO0FBQ0EsSUFBTSxnQkFBZ0IsSUFBSSxNQUFNLE9BQU8sWUFBWTtDQUNsRCxJQUFJLFVBQVUsVUFBVTtFQUN2QixJQUFJLGFBQWEsY0FBYyxPQUFPO09BQ2pDLElBQUksYUFBYSxxQkFBcUIsT0FBTyxnQkFBZ0I7T0FDN0QsSUFBSSxhQUFhLFFBQVEsT0FBTyxPQUFPO09BQ3ZDLElBQUksYUFBYSxZQUFZLE9BQU8sT0FBTztFQUNoRCxPQUFPLE9BQU8sVUFBVSxDQUFDO0NBQzFCO0NBQ0EsZUFBZSxRQUFRLFVBQVU7RUFDaEMsT0FBTyxPQUFPO0VBQ2QsT0FBTztDQUNSO0NBQ0EsSUFBSSxVQUFVLFVBQVUsT0FBTztFQUM5QixTQUFTLFlBQVk7RUFDckIsT0FBTyxVQUFVLENBQUMsWUFBWTtFQUM5QixPQUFPO0NBQ1I7QUFDRCxDQUFDO0FBdUVELFNBQVMsYUFBYSxVQUFVLENBQUMsR0FBRztDQUNuQyxNQUFNLEVBQUUsTUFBTSxNQUFNLFVBQVUsT0FBTyxTQUFTLFFBQVEsT0FBTyxHQUFHLFNBQVMsTUFBTTtDQUMvRSxJQUFJLE1BQU07RUFDVCxJQUFJLFNBQVMsb0JBQW9CO0dBQ2hDLE1BQU0sV0FBVyxLQUFLLFFBQVEsT0FBTyxNQUFNO0dBQzNDLE1BQU0sV0FBVyxPQUFPLHFCQUFxQixvQkFBb0I7R0FDakUsTUFBTSxHQUFHLFNBQVMsd0JBQXdCLFVBQVUsSUFBSSxHQUFHLENBQUMsQ0FBQyxNQUFNLGFBQWE7SUFDL0UsSUFBSSxDQUFDLFNBQVMsSUFBSTtLQUNqQixNQUFNLE1BQU0scUJBQXFCLFNBQVM7S0FDMUMsUUFBUSxJQUFJLEtBQUssT0FBTyxXQUFXO0lBQ3BDO0dBQ0QsQ0FBQztFQUNGLE9BQU8sSUFBSSxjQUFjLG9CQUFvQjtHQUM1QyxNQUFNLFdBQVcsT0FBTyw0Q0FBNEM7R0FDcEUsT0FBTyxrQkFBa0IsYUFBYSxVQUFVLE1BQU0sTUFBTSxNQUFNO0VBQ25FO0NBQ0Q7QUFDRDtBQUdBLE9BQU8sdUNBQXVDLENBQUM7QUFDL0MsSUFBTSx1QkFBdUIsSUFBSSxNQUFNLE9BQU8sb0NBQW9DLEVBQUUsSUFBSSxRQUFRLE1BQU0sVUFBVTtDQUMvRyxPQUFPLFFBQVEsSUFBSSxRQUFRLE1BQU0sUUFBUTtBQUMxQyxFQUFFLENBQUM7QUFNSCxTQUFTLGFBQWEsVUFBVTtDQUMvQixNQUFNLFlBQVksQ0FBQztDQUNuQixPQUFPLEtBQUssUUFBUSxDQUFDLENBQUMsU0FBUyxRQUFRO0VBQ3RDLFVBQVUsT0FBTyxTQUFTLElBQUksQ0FBQztDQUNoQyxDQUFDO0NBQ0QsT0FBTztBQUNSO0FBQ0EsU0FBUyxrQkFBa0IsVUFBVTtDQUNwQyxPQUFPLHdDQUF3QyxTQUFTO0FBQ3pEO0FBQ0EsU0FBUyx5QkFBeUIsVUFBVTtDQUMzQyxRQUFRLHFCQUFxQixNQUFNLFNBQVMsS0FBSyxFQUFFLENBQUMsT0FBTyxZQUFZLENBQUMsQ0FBQyxLQUFLLEVBQUUsRUFBRSxRQUFRLENBQUMsR0FBRyxNQUFNLE9BQU8sWUFBWTtBQUN4SDtBQUNBLFNBQVMsa0JBQWtCLFVBQVUsZUFBZTtDQUNuRCxNQUFNLFdBQVcsa0JBQWtCLFFBQVE7Q0FDM0MsSUFBSSxVQUFVO0VBQ2IsTUFBTSxnQkFBZ0IsYUFBYSxRQUFRLFFBQVE7RUFDbkQsSUFBSSxlQUFlLE9BQU8sS0FBSyxNQUFNLGFBQWE7Q0FDbkQ7Q0FDQSxJQUFJLFVBQVUsT0FBTyxjQUFjLHFCQUFxQixNQUFNLFNBQVMsS0FBSyxFQUFFLENBQUMsT0FBTyxRQUFRLENBQUMsR0FBRyxNQUFNLE9BQU8sWUFBWSxDQUFDLENBQUM7Q0FDN0gsT0FBTyxhQUFhLGFBQWE7QUFDbEM7QUFDQSxTQUFTLG1CQUFtQixVQUFVLFVBQVU7Q0FDL0MsTUFBTSxXQUFXLGtCQUFrQixRQUFRO0NBQzNDLElBQUksQ0FBQyxhQUFhLFFBQVEsUUFBUSxHQUFHLGFBQWEsUUFBUSxVQUFVLEtBQUssVUFBVSxhQUFhLFFBQVEsQ0FBQyxDQUFDO0FBQzNHO0FBQ0EsU0FBUyxrQkFBa0IsVUFBVSxLQUFLLE9BQU87Q0FDaEQsTUFBTSxXQUFXLGtCQUFrQixRQUFRO0NBQzNDLE1BQU0sZ0JBQWdCLGFBQWEsUUFBUSxRQUFRO0NBQ25ELE1BQU0sc0JBQXNCLEtBQUssTUFBTSxpQkFBaUIsSUFBSTtDQUM1RCxNQUFNLFVBQVU7RUFDZixHQUFHO0dBQ0YsTUFBTTtDQUNSO0NBQ0EsYUFBYSxRQUFRLFVBQVUsS0FBSyxVQUFVLE9BQU8sQ0FBQztDQUN0RCxnQkFBZ0IsTUFBTSxjQUFjLGNBQWM7RUFDakQsVUFBVSxTQUFTLE9BQU8sR0FBRztHQUM1QjtHQUNBO0dBQ0EsVUFBVSxvQkFBb0I7R0FDOUIsVUFBVTtHQUNWLFVBQVU7RUFDWCxDQUFDLENBQUM7Q0FDSCxHQUFHLDRCQUE0QixtQkFBbUI7QUFDbkQ7QUFHQSxJQUFJLGdCQUFnQyx5QkFBUyxlQUFlO0NBQzNELGNBQWMsY0FBYztDQUM1QixjQUFjLGlCQUFpQjtDQUMvQixjQUFjLHVCQUF1QjtDQUNyQyxjQUFjLHFCQUFxQjtDQUNuQyxjQUFjLHVCQUF1QjtDQUNyQyxjQUFjLG9CQUFvQjtDQUNsQyxjQUFjLHVCQUF1QjtDQUNyQyxjQUFjLHFCQUFxQjtDQUNuQyxjQUFjLGVBQWU7Q0FDN0IsY0FBYyxrQkFBa0I7Q0FDaEMsY0FBYyxvQkFBb0I7Q0FDbEMsY0FBYyxzQkFBc0I7Q0FDcEMsY0FBYyxtQkFBbUI7Q0FDakMsY0FBYywyQkFBMkI7Q0FDekMsT0FBTztBQUNSLEVBQUUsQ0FBQyxDQUFDO0FBR0osSUFBTSxnQkFBZ0IsT0FBTyx3QkFBd0IsWUFBWTtBQXdHakUsSUFBTSxPQUFPO0NBQ1o7RUF2R0EsV0FBVyxJQUFJO0dBQ2QsY0FBYyxLQUFLLGNBQWMsVUFBVSxFQUFFO0VBQzlDO0VBQ0EsY0FBYyxJQUFJO0dBQ2pCLGNBQWMsS0FBSyxjQUFjLGFBQWEsRUFBRTtFQUNqRDtFQUNBLGdCQUFnQixJQUFJO0dBQ25CLGNBQWMsS0FBSyxjQUFjLGVBQWUsRUFBRTtFQUNuRDtFQUNBLGVBQWUsSUFBSTtHQUNsQixPQUFPLGNBQWMsS0FBSyxjQUFjLGlCQUFpQixFQUFFO0VBQzVEO0VBQ0EsY0FBYyxJQUFJO0dBQ2pCLE9BQU8sY0FBYyxLQUFLLGNBQWMsZ0JBQWdCLEVBQUU7RUFDM0Q7RUFDQSxpQkFBaUIsSUFBSTtHQUNwQixPQUFPLGNBQWMsS0FBSyxjQUFjLG1CQUFtQixFQUFFO0VBQzlEO0VBQ0EsaUJBQWlCLElBQUk7R0FDcEIsT0FBTyxjQUFjLEtBQUssY0FBYyxtQkFBbUIsRUFBRTtFQUM5RDtFQUNBLG9CQUFvQixJQUFJO0dBQ3ZCLGNBQWMsS0FBSyxjQUFjLHVCQUF1QixFQUFFO0VBQzNEO0VBQ0EsVUFBVSxJQUFJO0dBQ2IsT0FBTyxjQUFjLEtBQUssY0FBYyxtQkFBbUIsRUFBRTtFQUM5RDtFQUNBLFFBQVEsSUFBSTtHQUNYLE9BQU8sY0FBYyxLQUFLLGNBQWMsaUJBQWlCLEVBQUU7RUFDNUQ7Q0EwRUE7Q0FDQSxvQkFBb0Isa0JBQWtCLFNBQVM7RUFDOUMsT0FBTyxjQUFjLFNBQVMsY0FBYyx1QkFBdUIsa0JBQWtCLE9BQU87Q0FDN0Y7QUFDRDtBQUdBLElBQUksc0JBQXNCLE1BQU07Q0FDL0IsWUFBWSxFQUFFLFFBQVEsT0FBTztFQUM1QixLQUFLLFFBQVEsSUFBSTtFQUNqQixLQUFLLFNBQVM7Q0FDZjtDQUNBLElBQUksS0FBSztFQUNSLE9BQU87R0FDTixxQkFBcUIsWUFBWTtJQUNoQyxLQUFLLE1BQU0sS0FBSyw0QkFBNEIsc0JBQXNCLE9BQU87R0FDMUU7R0FDQSxtQkFBbUIsWUFBWTtJQUM5QixLQUFLLE1BQU0sS0FBSyw0QkFBNEIsbUJBQW1CLE9BQU87R0FDdkU7R0FDQSxxQkFBcUIsWUFBWTtJQUNoQyxLQUFLLE1BQU0sS0FBSyw0QkFBNEIsc0JBQXNCLE9BQU87R0FDMUU7R0FDQSxtQkFBbUIsWUFBWTtJQUM5QixLQUFLLE1BQU0sS0FBSyw0QkFBNEIsb0JBQW9CLE9BQU87R0FDeEU7R0FDQSxvQkFBb0IsWUFBWTtJQUMvQixLQUFLLE1BQU0sS0FBSyw0QkFBNEIscUJBQXFCLE9BQU87R0FDekU7R0FDQSxxQkFBcUIsWUFBWTtJQUNoQyxLQUFLLE1BQU0sS0FBSyw0QkFBNEIsc0JBQXNCLE9BQU87R0FDMUU7R0FDQSx1QkFBdUIsWUFBWTtJQUNsQyxLQUFLLE1BQU0sS0FBSyw0QkFBNEIsd0JBQXdCLE9BQU87R0FDNUU7R0FDQSxrQkFBa0IsWUFBWTtJQUM3QixLQUFLLE1BQU0sS0FBSyw0QkFBNEIsa0JBQWtCLE9BQU87R0FDdEU7R0FDQSxvQkFBb0IsWUFBWTtJQUMvQixLQUFLLE1BQU0sS0FBSyw0QkFBNEIscUJBQXFCLE9BQU87R0FDekU7RUFDRDtDQUNEO0NBQ0Esc0JBQXNCLFVBQVU7RUFDL0IsSUFBSSxjQUFjLHFCQUFxQjtFQUN2QyxNQUFNLFlBQVksb0JBQW9CLENBQUMsQ0FBQyxNQUFNLE1BQU0sRUFBRSxnQkFBZ0IsS0FBSyxPQUFPLFdBQVcsV0FBVztFQUN4RyxJQUFJLFdBQVcsSUFBSTtHQUNsQixJQUFJLFVBQVU7SUFDYixNQUFNLE9BQU87S0FDWixTQUFTLFdBQVc7S0FDcEIsU0FBUztLQUNULFNBQVMsUUFBUTtLQUNqQjtJQUNEO0lBQ0EsY0FBYyxTQUFTLGNBQWMsbUJBQW1CLEdBQUcsSUFBSTtHQUNoRSxPQUFPLGNBQWMsU0FBUyxjQUFjLGlCQUFpQjtHQUM3RCxLQUFLLE1BQU0sU0FBUyx3QkFBd0Isc0JBQXNCO0lBQ2pFLGFBQWEsVUFBVTtJQUN2QixRQUFRLEtBQUs7R0FDZCxDQUFDO0VBQ0Y7Q0FDRDtDQUNBLGFBQWEsU0FBUztFQUNyQixLQUFLLE1BQU0sU0FBUyx3QkFBd0IsZUFBZTtHQUMxRCxXQUFXO0dBQ1gsUUFBUSxLQUFLO0VBQ2QsQ0FBQztFQUNELElBQUksS0FBSyxPQUFPLFdBQVcsVUFBVSxtQkFBbUIsUUFBUSxJQUFJLEtBQUssT0FBTyxXQUFXLFFBQVE7Q0FDcEc7Q0FDQSxrQkFBa0IsYUFBYTtFQUM5QixJQUFJLGNBQWMscUJBQXFCO0VBQ3ZDLEtBQUssTUFBTSxTQUFTLHdCQUF3QixxQkFBcUI7R0FDaEU7R0FDQSxRQUFRLEtBQUs7RUFDZCxDQUFDO0NBQ0Y7Q0FDQSxtQkFBbUIsYUFBYTtFQUMvQixJQUFJLGNBQWMscUJBQXFCO0VBQ3ZDLEtBQUssTUFBTSxTQUFTLHdCQUF3QixzQkFBc0I7R0FDakU7R0FDQSxRQUFRLEtBQUs7RUFDZCxDQUFDO0NBQ0Y7Q0FDQSxvQkFBb0IsYUFBYSxRQUFRO0VBQ3hDLEtBQUssTUFBTSxTQUFTLHdCQUF3Qiw4QkFBOEI7R0FDekU7R0FDQTtHQUNBLFFBQVEsS0FBSztFQUNkLENBQUM7Q0FDRjtDQUNBLG1CQUFtQixTQUFTO0VBQzNCLE9BQU8sS0FBSyxNQUFNLFNBQVMsNEJBQTRCLHNCQUFzQixPQUFPO0NBQ3JGO0NBQ0EsTUFBTTtFQUNMLElBQUksY0FBYyxxQkFBcUIsT0FBTztFQUM5QyxPQUFPLEtBQUssSUFBSTtDQUNqQjtDQUNBLGlCQUFpQixTQUFTO0VBQ3pCLEtBQUssTUFBTSxTQUFTLHdCQUF3QixzQkFBc0I7R0FDakU7R0FDQSxRQUFRLEtBQUs7RUFDZCxDQUFDO0NBQ0Y7Q0FDQSxpQkFBaUIsU0FBUztFQUN6QixJQUFJLGNBQWMscUJBQXFCO0VBQ3ZDLEtBQUssTUFBTSxTQUFTLHdCQUF3QixzQkFBc0I7R0FDakU7R0FDQSxRQUFRLEtBQUs7RUFDZCxDQUFDO0NBQ0Y7Q0FDQSxZQUFZLFVBQVU7RUFDckIsT0FBTyxrQkFBa0IsWUFBWSxLQUFLLE9BQU8sV0FBVyxJQUFJLEtBQUssT0FBTyxXQUFXLFFBQVE7Q0FDaEc7Q0FDQSxzQkFBc0IsS0FBSztFQUMxQixPQUFPLEtBQUssTUFBTSxTQUFTLHdCQUF3Qix5QkFBeUIsRUFBRSxJQUFJLENBQUM7Q0FDcEY7Q0FDQSxtQkFBbUIsVUFBVTtFQUM1QixPQUFPLEtBQUssTUFBTSxTQUFTLHdCQUF3QixzQkFBc0IsRUFBRSxTQUFTLENBQUM7Q0FDdEY7Q0FDQSxpQkFBaUIsVUFBVTtFQUMxQixPQUFPLEtBQUssTUFBTSxTQUFTLHdCQUF3QixvQkFBb0IsRUFBRSxTQUFTLENBQUM7Q0FDcEY7Q0FDQSxpQkFBaUIsVUFBVTtFQUMxQixNQUFNLE1BQU0sU0FBUztFQUNyQixPQUFPLEtBQUssTUFBTSxTQUFTLHdCQUF3QixxQkFBcUIsRUFBRSxJQUFJLENBQUM7Q0FDaEY7Q0FDQSxxQkFBcUI7RUFDcEIsT0FBTyxLQUFLLE1BQU0sU0FBUyx3QkFBd0IscUJBQXFCO0NBQ3pFO0FBQ0Q7QUFHQSxJQUFNLG9CQUFvQjtBQThEMUIsSUFBTSxZQUFZO0FBQ2xCLElBQU0sV0FBVztBQUNqQixJQUFNLG9CQUFvQjtBQUMxQixJQUFNLE1BQU07QUEwQ2EsT0FBTyxRQUFRO0VBTHRDLFlBQVk7RUFDWixNQUFNO0VBQ04sV0FBVztFQUNYLG9CQUFvQjtBQUVrQixDQUFRLENBQUMsQ0FBQyxRQUFRLEtBQUssQ0FBQyxLQUFLLFdBQVc7Q0FDL0UsSUFBSSxTQUFTO0NBQ2IsT0FBTztBQUNSLEdBQUcsQ0FBQyxDQUFDO0FBMnhCTCxPQUFPLGlFQUFpRSxJQUFJLElBQUk7QUFDaEYsU0FBUyxvQkFBb0Isa0JBQWtCLFNBQVM7Q0FDdkQsT0FBTyxLQUFLLG9CQUFvQixrQkFBa0IsT0FBTztBQUMxRDtBQUNBLFNBQVMsMEJBQTBCLFFBQVEsS0FBSztDQUMvQyxNQUFNLENBQUMsa0JBQWtCLFdBQVc7Q0FDcEMsSUFBSSxpQkFBaUIsUUFBUSxLQUFLO0NBQ2xDLE1BQU0sTUFBTSxJQUFJLGtCQUFrQjtFQUNqQyxRQUFRO0dBQ1A7R0FDQSxZQUFZO0VBQ2I7RUFDQSxLQUFLO0NBQ04sQ0FBQztDQUNELElBQUksaUJBQWlCLGdCQUFnQixRQUFRLElBQUksR0FBRyxvQkFBb0IsWUFBWTtFQUNuRixJQUFJLG1CQUFtQixRQUFRLFdBQVc7Q0FDM0MsQ0FBQztDQUNELFFBQVEsR0FBRztBQUNaO0FBSUEsU0FBUyx1QkFBdUIsS0FBSyxTQUFTO0NBQzdDLElBQUksT0FBTyw2Q0FBNkMsSUFBSSxHQUFHLEdBQUc7Q0FDbEUsSUFBSSxjQUFjLHVCQUF1QixDQUFDLFNBQVMscUJBQXFCO0NBQ3hFLE9BQU8sNkNBQTZDLElBQUksR0FBRztDQUMzRCxxQkFBcUIsU0FBUyxXQUFXO0VBQ3hDLDBCQUEwQixRQUFRLEdBQUc7Q0FDdEMsQ0FBQztBQUNGO0FBR0EsSUFBTSxhQUFhO0FBQ25CLElBQU0sa0JBQWtCO0FBQ3hCLE9BQU8scUJBQXFCO0NBQzNCLGNBQWM7Q0FDZCxRQUFRLENBQUM7QUFDVjtBQUNBLE9BQU8sZ0JBQWdCLENBQUM7QUFDRyxJQUFJLE1BQU0sT0FBTyxrQkFBa0IsRUFBRSxJQUFJLFVBQVUsVUFBVTtDQUN2RixPQUFPLE9BQU8sZ0JBQWdCLENBQUM7QUFDaEMsRUFBRSxDQUFDO0FBQ29CLElBQUksTUFBTSxPQUFPLGFBQWEsRUFBRSxJQUFJLFVBQVUsVUFBVTtDQUM5RSxJQUFJLGFBQWEsU0FBUyxPQUFPLE9BQU87QUFDekMsRUFBRSxDQUFDO0FBR0gsU0FBUyxVQUFVLFFBQVE7Q0FDMUIsTUFBTSw0QkFBNEIsSUFBSSxJQUFJO0NBQzFDLFFBQVEsUUFBUSxVQUFVLEtBQUssQ0FBQyxHQUFHLFFBQVEsTUFBTSxDQUFDLFVBQVUsSUFBSSxFQUFFLElBQUksS0FBSyxVQUFVLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQztBQUNwRztBQUNBLFNBQVMsYUFBYSxRQUFRO0NBQzdCLE9BQU8sT0FBTyxLQUFLLFNBQVM7RUFDM0IsSUFBSSxFQUFFLE1BQU0sTUFBTSxVQUFVLFNBQVM7RUFDckMsSUFBSSxVQUFVLFFBQVEsV0FBVyxhQUFhLFFBQVE7RUFDdEQsT0FBTztHQUNOO0dBQ0E7R0FDQTtHQUNBO0VBQ0Q7Q0FDRCxDQUFDO0FBQ0Y7QUFDQSxTQUFTLG1CQUFtQixPQUFPO0NBQ2xDLElBQUksT0FBTztFQUNWLE1BQU0sRUFBRSxVQUFVLE1BQU0sTUFBTSxNQUFNLE1BQU0sU0FBUyxRQUFRLFVBQVU7RUFDckUsT0FBTztHQUNOO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0EsU0FBUyxhQUFhLE9BQU87RUFDOUI7Q0FDRDtDQUNBLE9BQU87QUFDUjtBQUNBLFNBQVMsb0JBQW9CLFdBQVcsaUJBQWlCO0NBQ3hELFNBQVMsT0FBTztFQUNmLE1BQU0sU0FBUyxVQUFVLEtBQUssT0FBTyxpQkFBaUI7RUFDdEQsTUFBTSxlQUFlLG1CQUFtQixRQUFRLGFBQWEsS0FBSztFQUNsRSxNQUFNLFNBQVMsYUFBYSxVQUFVLE1BQU0sQ0FBQztFQUM3QyxNQUFNLElBQUksUUFBUTtFQUNsQixRQUFRLGFBQWEsQ0FBQztFQUN0QixPQUFPLG1CQUFtQjtHQUN6QixjQUFjLGVBQWUsVUFBVSxZQUFZLElBQUksQ0FBQztHQUN4RCxRQUFRLFVBQVUsTUFBTTtFQUN6QjtFQUNBLE9BQU8sY0FBYztFQUNyQixRQUFRLE9BQU87Q0FDaEI7Q0FDQSxLQUFLO0NBQ0wsS0FBSyxHQUFHLGlCQUFpQixlQUFlO0VBQ3ZDLElBQUksZ0JBQWdCLE9BQU8sUUFBUSxVQUFVLEtBQUs7RUFDbEQsS0FBSztFQUNMLElBQUksY0FBYyxxQkFBcUI7RUFDdkMsZ0JBQWdCLE1BQU0sU0FBUywwQkFBMEIscUJBQXFCLEVBQUUsT0FBTyxPQUFPLGlCQUFpQixDQUFDO0NBQ2pILEdBQUcsR0FBRyxDQUFDO0FBQ1I7QUFHQSxTQUFTLGtCQUFrQixPQUFPO0NBQ2pDLE9BQU87RUFDTixNQUFNLGlCQUFpQixTQUFTO0dBQy9CLE1BQU0sV0FBVztJQUNoQixHQUFHO0lBQ0gsS0FBSyxnQkFBZ0IsTUFBTTtJQUMzQixXQUFXLENBQUM7R0FDYjtHQUNBLE1BQU0sSUFBSSxTQUFTLFlBQVk7SUFDOUIsTUFBTSxhQUFhLE9BQU8sY0FBYztLQUN2QyxNQUFNLFFBQVEsSUFBSSxVQUFVLEtBQUssT0FBTyxHQUFHLFFBQVEsQ0FBQyxDQUFDO0tBQ3JELFFBQVE7SUFDVCxHQUFHLDRCQUE0QixrQkFBa0I7R0FDbEQsQ0FBQztHQUNELE9BQU8sU0FBUztFQUNqQjtFQUNBLE1BQU0sa0JBQWtCLFNBQVM7R0FDaEMsTUFBTSxXQUFXO0lBQ2hCLEdBQUc7SUFDSCxLQUFLLGdCQUFnQixNQUFNO0lBQzNCLE9BQU87R0FDUjtHQUNBLE1BQU0sTUFBTSxFQUFFLFlBQVksb0JBQW9CLFFBQVEsY0FBYztHQUNwRSxNQUFNLElBQUksU0FBUyxZQUFZO0lBQzlCLE1BQU0sYUFBYSxPQUFPLGNBQWM7S0FDdkMsTUFBTSxRQUFRLElBQUksVUFBVSxLQUFLLE9BQU8sR0FBRyxVQUFVLEdBQUcsQ0FBQyxDQUFDO0tBQzFELFFBQVE7SUFDVCxHQUFHLDRCQUE0QixtQkFBbUI7R0FDbkQsQ0FBQztHQUNELE9BQU8sU0FBUztFQUNqQjtFQUNBLG1CQUFtQixTQUFTO0dBQzNCLE1BQU0sY0FBYyxJQUFJLFlBQVk7R0FDcEMsTUFBTSxXQUFXO0lBQ2hCLEdBQUc7SUFDSCxLQUFLLGdCQUFnQixNQUFNO0lBQzNCLE1BQU0sS0FBSyxPQUFPLFFBQVEsTUFBTSxRQUFRLFFBQVEsTUFBTSxPQUFPLE9BQU87S0FDbkUsWUFBWSxJQUFJLEtBQUssTUFBTSxPQUFPLE1BQU0sWUFBWSx5QkFBeUIsUUFBUSxLQUFLLENBQUM7SUFDNUY7R0FDRDtHQUNBLE1BQU0sY0FBYyxjQUFjO0lBQ2pDLFVBQVUsU0FBUyxPQUFPLEdBQUcsUUFBUSxDQUFDO0dBQ3ZDLEdBQUcsNEJBQTRCLG9CQUFvQjtFQUNwRDtFQUNBLG1CQUFtQixhQUFhO0dBQy9CLE1BQU0sWUFBWSxhQUFhLFdBQVc7R0FDMUMsTUFBTSxTQUFTLHdCQUF3QixzQkFBc0I7SUFDNUQ7SUFDQSxRQUFRO0tBQ1AsWUFBWSxVQUFVO0tBQ3RCLGdCQUFnQixDQUFDO0lBQ2xCO0dBQ0QsQ0FBQztFQUNGO0VBQ0EsNEJBQTRCO0dBQzNCLE9BQU8sNEJBQTRCO0VBQ3BDO0VBQ0Esa0NBQWtDO0dBQ2pDLE9BQU8sa0NBQWtDO0VBQzFDO0VBQ0EsdUJBQXVCLElBQUk7R0FDMUIsTUFBTSxXQUFXLHFCQUFxQixnQkFBZ0IsT0FBTyxFQUFFO0dBQy9ELElBQUksVUFBVSxPQUFPLEVBQUUsT0FBTyxVQUFVLFNBQVMsY0FBYyxTQUFTLE9BQU8sU0FBUyxJQUFJLFNBQVMsS0FBSyxTQUFTO0VBQ3BIO0VBQ0Esa0JBQWtCLElBQUk7R0FDckIsT0FBTyxrQkFBa0IsRUFBRSxHQUFHLENBQUM7RUFDaEM7RUFDQTtFQUNBLGlCQUFpQjtFQUNqQixVQUFVLElBQUksU0FBUztHQUN0QixNQUFNLFlBQVksbUJBQW1CLE1BQU0sTUFBTSxXQUFXLE9BQU8sT0FBTyxFQUFFO0dBQzVFLElBQUksV0FBVztJQUNkLHFCQUFxQixFQUFFO0lBQ3ZCLG1CQUFtQixTQUFTO0lBQzVCLG9CQUFvQixXQUFXLGVBQWU7SUFDOUMseUJBQXlCO0lBQ3pCLHVCQUF1QixVQUFVLEtBQUssT0FBTztHQUM5QztFQUNEO0VBQ0EsV0FBVyxZQUFZO0dBQ3RCLE1BQU0sV0FBVyxxQkFBcUIsZ0JBQWdCLE9BQU8sVUFBVTtHQUN2RSxJQUFJLFVBQVU7SUFDYixNQUFNLENBQUMsTUFBTSxxQ0FBcUMsUUFBUTtJQUMxRCxJQUFJLElBQUksT0FBTyxzQ0FBc0M7R0FDdEQ7RUFDRDtFQUNBLHFCQUFxQixVQUFVLEtBQUssT0FBTztHQUMxQyxrQkFBa0IsVUFBVSxLQUFLLEtBQUs7RUFDdkM7RUFDQSxrQkFBa0IsVUFBVTtHQUMzQixPQUFPO0lBQ04sU0FBUyx5QkFBeUIsUUFBUTtJQUMxQyxRQUFRLGtCQUFrQixRQUFRO0dBQ25DO0VBQ0Q7Q0FDRDtBQUNEO0FBR0EsT0FBTyx5QkFBeUIsRUFBRSxvQkFBb0IsTUFBTTtBQVk1RCxJQUFNLFFBQVEsdUJBQXVCO0FBQ3JDLE9BQU8saUNBQWlDO0NBQ3ZDO0NBQ0EsSUFBSSxRQUFRO0VBQ1gsT0FBTztHQUNOLEdBQUc7R0FDSCxtQkFBbUIsZ0JBQWdCO0dBQ25DLGlCQUFpQixnQkFBZ0I7R0FDakMsWUFBWSxtQkFBbUI7RUFDaEM7Q0FDRDtDQUNBLEtBQUssa0JBQWtCLEtBQUs7QUFDN0I7QUFDQSxJQUFNLGtCQUFrQixPQUFPO0FBRy9CLElBQUksd0JBQXdDLGdDQUFnQixTQUFTLFdBQVc7Q0FDL0UsQ0FBQyxTQUFTLE1BQU07RUFDZjs7Ozs7RUFLQSxJQUFJLFVBQVU7R0FDYixLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsTUFBTTtHQUNOLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLE1BQU07R0FDTixNQUFNO0dBQ04sS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxRQUFRO0dBQ1IsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLE1BQU07R0FDTixNQUFNO0dBQ04sS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsTUFBTTtHQUNOLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLE9BQU87R0FDUCxNQUFNO0dBQ04sS0FBSztHQUNMLEtBQUs7RUFDTjs7Ozs7O0VBTUEsSUFBSSxxQkFBcUIsQ0FBQyxLQUFLLEdBQUc7Ozs7O0VBS2xDLElBQUksYUFBYTtHQUNoQixLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxNQUFNO0dBQ04sS0FBSztHQUNMLEtBQUs7R0FDTCxRQUFRO0dBQ1IsTUFBTTtHQUNOLE9BQU87R0FDUCxNQUFNO0dBQ04sT0FBTztHQUNQLEtBQUs7R0FDTCxNQUFNO0dBQ04sUUFBUTtHQUNSLFFBQVE7R0FDUixNQUFNO0dBQ04sUUFBUTtHQUNSLFFBQVE7R0FDUixNQUFNO0dBQ04sTUFBTTtHQUNOLE1BQU07R0FDTixPQUFPO0dBQ1AsT0FBTztHQUNQLE9BQU87R0FDUCxPQUFPO0dBQ1AsTUFBTTtHQUNOLFFBQVE7R0FDUixPQUFPO0dBQ1AsTUFBTTtHQUNOLE9BQU87R0FDUCxPQUFPO0dBQ1AsT0FBTztHQUNQLE9BQU87R0FDUCxNQUFNO0dBQ04sT0FBTztHQUNQLE9BQU87R0FDUCxPQUFPO0dBQ1AsU0FBUztHQUNULE1BQU07R0FDTixPQUFPO0dBQ1AsT0FBTztHQUNQLE9BQU87R0FDUCxNQUFNO0dBQ04sUUFBUTtHQUNSLE1BQU07R0FDTixLQUFLO0dBQ0wsTUFBTTtHQUNOLE1BQU07R0FDTixPQUFPO0dBQ1AsT0FBTztFQUNSOzs7OztFQUtBLElBQUksY0FBYztHQUNqQixNQUFNLENBQUM7R0FDUCxNQUFNO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7R0FDTjtHQUNBLE1BQU07SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7R0FDTjtHQUNBLE1BQU07SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0dBQ047R0FDQSxNQUFNO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7R0FDTjtHQUNBLE1BQU07SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztHQUNOO0dBQ0EsTUFBTTtJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7R0FDTjtHQUNBLE1BQU07SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7R0FDTjtHQUNBLE1BQU07SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0dBQ047R0FDQSxNQUFNO0lBQ0wsS0FBSztJQUNMLEtBQUs7R0FDTjtHQUNBLE1BQU07SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7R0FDTjtHQUNBLE1BQU07SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0dBQ047RUFDRDs7Ozs7O0VBTUEsSUFBSSxZQUFZO0dBQ2YsTUFBTTtJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztHQUNOO0dBQ0EsTUFBTSxDQUFDO0dBQ1AsTUFBTTtJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztHQUNOO0dBQ0EsTUFBTTtJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztHQUNOO0dBQ0EsTUFBTTtJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztHQUNOO0dBQ0EsTUFBTTtJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztHQUNOO0dBQ0EsTUFBTTtJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztHQUNOO0dBQ0EsTUFBTTtJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztHQUNOO0dBQ0EsTUFBTTtJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztHQUNOO0dBQ0EsTUFBTTtJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztHQUNOO0dBQ0EsTUFBTTtJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztHQUNOO0dBQ0EsTUFBTTtJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztHQUNOO0dBQ0EsTUFBTSxDQUFDO0dBQ1AsTUFBTTtJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztHQUNOO0dBQ0EsTUFBTTtJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztHQUNOO0dBQ0EsTUFBTTtJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztHQUNOO0dBQ0EsTUFBTTtJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztHQUNOO0dBQ0EsTUFBTTtJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztHQUNOO0dBQ0EsTUFBTSxDQUFDO0dBQ1AsTUFBTTtJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztHQUNOO0dBQ0EsTUFBTTtJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztHQUNOO0dBQ0EsTUFBTTtJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztHQUNOO0dBQ0EsTUFBTTtJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztHQUNOO0dBQ0EsTUFBTTtJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztHQUNOO0dBQ0EsTUFBTTtJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztHQUNOO0dBQ0EsTUFBTSxDQUFDO0dBQ1AsTUFBTTtJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztHQUNOO0dBQ0EsTUFBTTtJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztHQUNOO0dBQ0EsTUFBTTtJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztHQUNOO0VBQ0Q7RUFDQSxJQUFJLFlBQVk7R0FDZjtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtFQUNELENBQUMsQ0FBQyxLQUFLLEVBQUU7RUFDVCxJQUFJLG1CQUFtQjtHQUN0QjtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7RUFDRCxDQUFDLENBQUMsS0FBSyxFQUFFO0VBQ1QsSUFBSSxZQUFZO0dBQ2Y7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7RUFDRCxDQUFDLENBQUMsS0FBSyxFQUFFOzs7Ozs7OztFQVFULElBQUksVUFBVSxTQUFTLFFBQVEsT0FBTyxNQUFNO0dBQzNDLElBQUksWUFBWTtHQUNoQixJQUFJLFNBQVM7R0FDYixJQUFJLGdCQUFnQjtHQUNwQixJQUFJLGlCQUFpQjtHQUNyQixJQUFJLHFCQUFxQixDQUFDO0dBQzFCLElBQUk7R0FDSixJQUFJO0dBQ0osSUFBSTtHQUNKLElBQUk7R0FDSixJQUFJO0dBQ0osSUFBSTtHQUNKLElBQUk7R0FDSixJQUFJO0dBQ0osSUFBSTtHQUNKLElBQUk7R0FDSixJQUFJO0dBQ0osSUFBSTtHQUNKLElBQUk7R0FDSixJQUFJO0dBQ0osSUFBSSxlQUFlO0dBQ25CLElBQUksT0FBTyxVQUFVLFVBQVUsT0FBTztHQUN0QyxJQUFJLE9BQU8sU0FBUyxVQUFVLFlBQVk7R0FDMUMsU0FBUyxVQUFVO0dBQ25CLFdBQVcsWUFBWTtHQUN2QixJQUFJLE9BQU8sU0FBUyxVQUFVO0lBQzdCLGVBQWUsS0FBSyxnQkFBZ0I7SUFDcEMscUJBQXFCLEtBQUssVUFBVSxPQUFPLEtBQUssV0FBVyxXQUFXLEtBQUssU0FBUztJQUNwRixXQUFXLENBQUMsS0FBSyxXQUFXLEtBQUssS0FBSyxZQUFZO0lBQ2xELFdBQVcsS0FBSyxRQUFRO0lBQ3hCLGtCQUFrQixLQUFLLGVBQWU7SUFDdEMsV0FBVyxLQUFLLFFBQVE7SUFDeEIsaUJBQWlCLEtBQUssWUFBWSxTQUFTLEtBQUssU0FBUyxRQUFRLFFBQVE7SUFDekUsWUFBWSxLQUFLLGFBQWE7SUFDOUIsSUFBSSxVQUFVLGdCQUFnQjtJQUM5QixJQUFJLGlCQUFpQixnQkFBZ0I7SUFDckMsSUFBSSxVQUFVLGdCQUFnQjtJQUM5QixTQUFTLEtBQUssUUFBUSxVQUFVLEtBQUssU0FBUyxpQkFBaUIsVUFBVSxLQUFLLFFBQVEsaUJBQWlCLFVBQVUsS0FBSyxDQUFDO0lBQ3ZILFdBQVcsS0FBSyxRQUFRLFlBQVksS0FBSyxRQUFRLFlBQVksS0FBSyxRQUFRLEtBQUssU0FBUyxTQUFTLEtBQUssU0FBUyxPQUFPLENBQUMsSUFBSSxZQUFZO0lBQ3ZJLElBQUksS0FBSyxhQUFhLE9BQU8sS0FBSyxVQUFVLFdBQVcsWUFBWSxNQUFNLFVBQVUsU0FBUyxLQUFLLEtBQUssU0FBUyxHQUFHO0tBQ2pILEtBQUssVUFBVSxRQUFRLFNBQVMsR0FBRztNQUNsQyxtQkFBbUIsSUFBSSxNQUFNLElBQUk7S0FDbEMsQ0FBQztLQUNELFlBQVk7SUFDYixPQUFPLFlBQVksQ0FBQyxDQUFDLEtBQUs7SUFDMUIsSUFBSSxLQUFLLFVBQVUsT0FBTyxLQUFLLE9BQU8sV0FBVyxZQUFZLE1BQU0sVUFBVSxTQUFTLEtBQUssS0FBSyxNQUFNLEdBQUcsS0FBSyxPQUFPLFFBQVEsU0FBUyxHQUFHO0tBQ3hJLG1CQUFtQixJQUFJLE1BQU0sSUFBSTtJQUNsQyxDQUFDO0lBQ0QsT0FBTyxLQUFLLGtCQUFrQixDQUFDLENBQUMsUUFBUSxTQUFTLEdBQUc7S0FDbkQsSUFBSTtLQUNKLElBQUksRUFBRSxTQUFTLEdBQUcsSUFBSSxJQUFJLE9BQU8sUUFBUSxZQUFZLENBQUMsSUFBSSxPQUFPLElBQUk7VUFDaEUsSUFBSSxJQUFJLE9BQU8sWUFBWSxDQUFDLEdBQUcsSUFBSTtLQUN4QyxRQUFRLE1BQU0sUUFBUSxHQUFHLG1CQUFtQixFQUFFO0lBQy9DLENBQUM7SUFDRCxLQUFLLE1BQU0sb0JBQW9CLGdCQUFnQjtHQUNoRDtHQUNBLGdCQUFnQjtHQUNoQixlQUFlLFlBQVksWUFBWTtHQUN2QyxRQUFRLE1BQU0sUUFBUSxnQkFBZ0IsRUFBRTtHQUN4QyxvQkFBb0I7R0FDcEIscUJBQXFCO0dBQ3JCLEtBQUssSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRLElBQUksR0FBRyxLQUFLO0lBQ3pDLEtBQUssTUFBTTtJQUNYLElBQUkscUJBQXFCLElBQUksa0JBQWtCLEdBQUcsb0JBQW9CO1NBQ2pFLElBQUksU0FBUyxLQUFLO0tBQ3RCLEtBQUsscUJBQXFCLFNBQVMsR0FBRyxDQUFDLE1BQU0sYUFBYSxJQUFJLE1BQU0sU0FBUyxNQUFNLFNBQVM7S0FDNUYsb0JBQW9CO0lBQ3JCLE9BQU8sSUFBSSxNQUFNLFNBQVM7S0FDekIsSUFBSSxJQUFJLElBQUksS0FBSyxtQkFBbUIsUUFBUSxNQUFNLElBQUksRUFBRSxLQUFLLEdBQUc7TUFDL0QsaUJBQWlCO01BQ2pCLEtBQUs7S0FDTixPQUFPLElBQUksdUJBQXVCLE1BQU07TUFDdkMsS0FBSyxXQUFXLGlCQUFpQixRQUFRO01BQ3pDLGdCQUFnQjtLQUNqQixPQUFPLEtBQUsscUJBQXFCLFFBQVEsR0FBRyxDQUFDLE1BQU0sYUFBYSxJQUFJLE1BQU0sUUFBUSxNQUFNLFFBQVE7S0FDaEcsb0JBQW9CO0tBQ3BCLHFCQUFxQjtJQUN0QixPQUFPLElBQUksTUFBTSxZQUFZO0tBQzVCLGlCQUFpQjtLQUNqQixLQUFLO0tBQ0wsSUFBSSxNQUFNLElBQUksR0FBRyxLQUFLLFdBQVc7S0FDakMscUJBQXFCO0lBQ3RCLE9BQU8sSUFBSSxPQUFPLE9BQU8sRUFBRSxZQUFZLFVBQVUsUUFBUSxFQUFFLE1BQU0sT0FBTyxFQUFFLG1CQUFtQixpQkFBaUIsUUFBUSxFQUFFLE1BQU0sS0FBSztLQUNsSSxLQUFLLHFCQUFxQixPQUFPLE9BQU8sRUFBRSxDQUFDLENBQUMsTUFBTSxhQUFhLElBQUksWUFBWSxPQUFPLE1BQU0sT0FBTztLQUNuRyxNQUFNLE1BQU0sSUFBSSxPQUFPLEtBQUssS0FBSyxNQUFNLElBQUksRUFBRSxDQUFDLE1BQU0sYUFBYSxJQUFJLFlBQVk7S0FDakYsb0JBQW9CO0lBQ3JCLE9BQU87S0FDTixJQUFJLHVCQUF1QixNQUFNO01BQ2hDLEtBQUssV0FBVyxpQkFBaUI7TUFDakMsZ0JBQWdCO01BQ2hCLHFCQUFxQjtLQUN0QixPQUFPLElBQUksc0JBQXNCLGNBQWMsS0FBSyxFQUFFLEtBQUssT0FBTyxPQUFPLEVBQUUsQ0FBQyxDQUFDLE1BQU0sWUFBWSxJQUFJLEtBQUssTUFBTTtLQUM5RyxvQkFBb0I7SUFDckI7SUFDQSxVQUFVLEdBQUcsUUFBUSxJQUFJLE9BQU8sYUFBYSxlQUFlLE9BQU8sR0FBRyxHQUFHLFNBQVM7R0FDbkY7R0FDQSxJQUFJLFdBQVcsU0FBUyxPQUFPLFFBQVEsY0FBYyxTQUFTLEdBQUcsR0FBRyxHQUFHO0lBQ3RFLElBQUksSUFBSSxFQUFFLFlBQVksS0FBSyxNQUFNLE9BQU8sSUFBSTtJQUM1QyxPQUFPLE9BQU8sS0FBSyxrQkFBa0IsQ0FBQyxDQUFDLFFBQVEsRUFBRSxZQUFZLENBQUMsSUFBSSxJQUFJLElBQUksRUFBRSxZQUFZO0dBQ3pGLENBQUM7R0FDRCxTQUFTLE9BQU8sUUFBUSxRQUFRLFNBQVMsQ0FBQyxDQUFDLFFBQVEsSUFBSSxPQUFPLE9BQU8sWUFBWSxLQUFLLEdBQUcsR0FBRyxTQUFTLENBQUMsQ0FBQyxRQUFRLElBQUksT0FBTyxTQUFTLFlBQVksU0FBUyxZQUFZLE9BQU8sR0FBRyxHQUFHLEVBQUU7R0FDbkwsSUFBSSxZQUFZLE9BQU8sU0FBUyxVQUFVO0lBQ3pDLFFBQVEsT0FBTyxPQUFPLFFBQVEsTUFBTTtJQUNwQyxTQUFTLE9BQU8sTUFBTSxHQUFHLFFBQVE7SUFDakMsSUFBSSxDQUFDLE9BQU8sU0FBUyxPQUFPLE1BQU0sR0FBRyxPQUFPLFlBQVksU0FBUyxDQUFDO0dBQ25FO0dBQ0EsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFdBQVcsU0FBUyxPQUFPLFlBQVk7R0FDN0QsT0FBTztFQUNSOzs7Ozs7RUFNQSxJQUFJLGFBQWEsU0FBUyxXQUFXLE1BQU07Ozs7OztHQU0xQyxPQUFPLFNBQVMsa0JBQWtCLE9BQU87SUFDeEMsT0FBTyxRQUFRLE9BQU8sSUFBSTtHQUMzQjtFQUNEOzs7OztFQUtBLElBQUksY0FBYyxTQUFTLFlBQVksT0FBTztHQUM3QyxPQUFPLE1BQU0sUUFBUSwwQkFBMEIsTUFBTTtFQUN0RDs7Ozs7O0VBTUEsSUFBSSx1QkFBdUIsU0FBUyxJQUFJLG9CQUFvQjtHQUMzRCxLQUFLLElBQUksS0FBSyxvQkFBb0IsSUFBSSxtQkFBbUIsT0FBTyxJQUFJLE9BQU87RUFDNUU7RUFDQSxJQUFJLE9BQU8sV0FBVyxlQUFlLE9BQU8sU0FBUztHQUNwRCxPQUFPLFVBQVU7R0FDakIsT0FBTyxRQUFRLGFBQWE7RUFDN0IsT0FBTyxJQUFJLE9BQU8sV0FBVyxlQUFlLE9BQU8sS0FBSyxPQUFPLENBQUMsR0FBRyxXQUFXO0dBQzdFLE9BQU87RUFDUixDQUFDO09BQ0ksSUFBSTtHQUNSLElBQUksS0FBSyxXQUFXLEtBQUssWUFBWSxNQUFNO1FBQ3RDO0lBQ0osS0FBSyxVQUFVO0lBQ2YsS0FBSyxhQUFhO0dBQ25CO0VBQ0QsU0FBUyxHQUFHLENBQUM7Q0FDZCxHQUFHLE9BQU87QUFDWCxFQUFFO0NBR2dFLGdDQUFnQixTQUFTLFdBQVc7Q0FDckcsT0FBTyxVQUFVLHNCQUFzQjtBQUN4QyxFQUFFLEdBQUc7QUFDaUIsT0FBTywwQ0FBMEM7Q0FDdEUsSUFBSTtDQUNKLHdCQUF3QixJQUFJLElBQUk7QUFDakM7QUFxTkEsU0FBUyxtQkFBbUIsT0FBTztDQUNsQyxjQUFjLHNCQUFzQixTQUFTLENBQUMsY0FBYztDQUM1RCxJQUFJLENBQUMsU0FBUyxnQkFBZ0IsT0FBTyx1QkFBdUIsZ0JBQWdCLE1BQU0sR0FBRztBQUN0RjtBQXlIQSxTQUFTLDZCQUE2QixRQUFRO0NBQzdDLGNBQWMseUJBQXlCO0VBQ3RDLEdBQUcsY0FBYztFQUNqQixHQUFHO0NBQ0o7Q0FDQSxtQkFBbUIsQ0FBQyxPQUFPLE9BQU8sY0FBYyxzQkFBc0IsQ0FBQyxDQUFDLEtBQUssT0FBTyxDQUFDO0FBQ3RGO0FBQ0EsT0FBTyw0Q0FBNEM7QUFHbkQsSUFBSSxrQkFBa0IsTUFBTTtDQUMzQixjQUFjO0VBQ2IsS0FBSyw2QkFBNkIsSUFBSSxJQUFJO0VBQzFDLEtBQUssNkJBQTZCLElBQUksSUFBSTtDQUMzQztDQUNBLElBQUksS0FBSyxPQUFPO0VBQ2YsS0FBSyxXQUFXLElBQUksS0FBSyxLQUFLO0VBQzlCLEtBQUssV0FBVyxJQUFJLE9BQU8sR0FBRztDQUMvQjtDQUNBLFNBQVMsS0FBSztFQUNiLE9BQU8sS0FBSyxXQUFXLElBQUksR0FBRztDQUMvQjtDQUNBLFdBQVcsT0FBTztFQUNqQixPQUFPLEtBQUssV0FBVyxJQUFJLEtBQUs7Q0FDakM7Q0FDQSxRQUFRO0VBQ1AsS0FBSyxXQUFXLE1BQU07RUFDdEIsS0FBSyxXQUFXLE1BQU07Q0FDdkI7QUFDRDtBQUdBLElBQUksV0FBVyxNQUFNO0NBQ3BCLFlBQVksb0JBQW9CO0VBQy9CLEtBQUsscUJBQXFCO0VBQzFCLEtBQUssS0FBSyxJQUFJLGdCQUFnQjtDQUMvQjtDQUNBLFNBQVMsT0FBTyxZQUFZO0VBQzNCLElBQUksS0FBSyxHQUFHLFdBQVcsS0FBSyxHQUFHO0VBQy9CLElBQUksQ0FBQyxZQUFZLGFBQWEsS0FBSyxtQkFBbUIsS0FBSztFQUMzRCxLQUFLLEdBQUcsSUFBSSxZQUFZLEtBQUs7Q0FDOUI7Q0FDQSxRQUFRO0VBQ1AsS0FBSyxHQUFHLE1BQU07Q0FDZjtDQUNBLGNBQWMsT0FBTztFQUNwQixPQUFPLEtBQUssR0FBRyxXQUFXLEtBQUs7Q0FDaEM7Q0FDQSxTQUFTLFlBQVk7RUFDcEIsT0FBTyxLQUFLLEdBQUcsU0FBUyxVQUFVO0NBQ25DO0FBQ0Q7QUFHQSxJQUFJLGdCQUFnQixjQUFjLFNBQVM7Q0FDMUMsY0FBYztFQUNiLE9BQU8sTUFBTSxFQUFFLElBQUk7RUFDbkIsS0FBSyxzQ0FBc0MsSUFBSSxJQUFJO0NBQ3BEO0NBQ0EsU0FBUyxPQUFPLFNBQVM7RUFDeEIsSUFBSSxPQUFPLFlBQVksVUFBVTtHQUNoQyxJQUFJLFFBQVEsWUFBWSxLQUFLLG9CQUFvQixJQUFJLE9BQU8sUUFBUSxVQUFVO0dBQzlFLE1BQU0sU0FBUyxPQUFPLFFBQVEsVUFBVTtFQUN6QyxPQUFPLE1BQU0sU0FBUyxPQUFPLE9BQU87Q0FDckM7Q0FDQSxnQkFBZ0IsT0FBTztFQUN0QixPQUFPLEtBQUssb0JBQW9CLElBQUksS0FBSztDQUMxQztBQUNEO0FBR0EsU0FBUyxZQUFZLFFBQVE7Q0FDNUIsSUFBSSxZQUFZLFFBQVEsT0FBTyxPQUFPLE9BQU8sTUFBTTtDQUNuRCxNQUFNLFNBQVMsQ0FBQztDQUNoQixLQUFLLE1BQU0sT0FBTyxRQUFRLElBQUksT0FBTyxlQUFlLEdBQUcsR0FBRyxPQUFPLEtBQUssT0FBTyxJQUFJO0NBQ2pGLE9BQU87QUFDUjtBQUNBLFNBQVMsS0FBSyxRQUFRLFdBQVc7Q0FDaEMsTUFBTSxTQUFTLFlBQVksTUFBTTtDQUNqQyxJQUFJLFVBQVUsUUFBUSxPQUFPLE9BQU8sS0FBSyxTQUFTO0NBQ2xELE1BQU0saUJBQWlCO0NBQ3ZCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxlQUFlLFFBQVEsS0FBSztFQUMvQyxNQUFNLFFBQVEsZUFBZTtFQUM3QixJQUFJLFVBQVUsS0FBSyxHQUFHLE9BQU87Q0FDOUI7QUFDRDtBQUNBLFNBQVMsUUFBUSxRQUFRLEtBQUs7Q0FDN0IsT0FBTyxRQUFRLE1BQU0sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxLQUFLLFdBQVcsSUFBSSxPQUFPLEdBQUcsQ0FBQztBQUNqRTtBQUNBLFNBQVMsU0FBUyxLQUFLLE9BQU87Q0FDN0IsT0FBTyxJQUFJLFFBQVEsS0FBSyxNQUFNO0FBQy9CO0FBQ0EsU0FBUyxRQUFRLFFBQVEsV0FBVztDQUNuQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxRQUFRLEtBQUs7RUFDdkMsTUFBTSxRQUFRLE9BQU87RUFDckIsSUFBSSxVQUFVLEtBQUssR0FBRyxPQUFPO0NBQzlCO0FBQ0Q7QUFHQSxJQUFJLDRCQUE0QixNQUFNO0NBQ3JDLGNBQWM7RUFDYixLQUFLLGNBQWMsQ0FBQztDQUNyQjtDQUNBLFNBQVMsYUFBYTtFQUNyQixLQUFLLFlBQVksWUFBWSxRQUFRO0NBQ3RDO0NBQ0EsZUFBZSxHQUFHO0VBQ2pCLE9BQU8sS0FBSyxLQUFLLGNBQWMsZ0JBQWdCLFlBQVksYUFBYSxDQUFDLENBQUM7Q0FDM0U7Q0FDQSxXQUFXLE1BQU07RUFDaEIsT0FBTyxLQUFLLFlBQVk7Q0FDekI7QUFDRDtBQUdBLElBQU0sYUFBYSxZQUFZLE9BQU8sVUFBVSxTQUFTLEtBQUssT0FBTyxDQUFDLENBQUMsTUFBTSxHQUFHLEVBQUU7QUFDbEYsSUFBTSxpQkFBaUIsWUFBWSxPQUFPLFlBQVk7QUFDdEQsSUFBTSxZQUFZLFlBQVksWUFBWTtBQUMxQyxJQUFNLG1CQUFtQixZQUFZO0NBQ3BDLElBQUksT0FBTyxZQUFZLFlBQVksWUFBWSxNQUFNLE9BQU87Q0FDNUQsSUFBSSxZQUFZLE9BQU8sV0FBVyxPQUFPO0NBQ3pDLElBQUksT0FBTyxlQUFlLE9BQU8sTUFBTSxNQUFNLE9BQU87Q0FDcEQsT0FBTyxPQUFPLGVBQWUsT0FBTyxNQUFNLE9BQU87QUFDbEQ7QUFDQSxJQUFNLGlCQUFpQixZQUFZLGdCQUFnQixPQUFPLEtBQUssT0FBTyxLQUFLLE9BQU8sQ0FBQyxDQUFDLFdBQVc7QUFDL0YsSUFBTSxhQUFhLFlBQVksTUFBTSxRQUFRLE9BQU87QUFDcEQsSUFBTSxZQUFZLFlBQVksT0FBTyxZQUFZO0FBQ2pELElBQU0sWUFBWSxZQUFZLE9BQU8sWUFBWSxZQUFZLENBQUMsTUFBTSxPQUFPO0FBQzNFLElBQU0sYUFBYSxZQUFZLE9BQU8sWUFBWTtBQUNsRCxJQUFNLFlBQVksWUFBWSxtQkFBbUI7QUFDakQsSUFBTSxTQUFTLFlBQVksbUJBQW1CO0FBQzlDLElBQU0sU0FBUyxZQUFZLG1CQUFtQjtBQUM5QyxJQUFNLFlBQVksWUFBWSxVQUFVLE9BQU8sTUFBTTtBQUNyRCxJQUFNLFVBQVUsWUFBWSxtQkFBbUIsUUFBUSxDQUFDLE1BQU0sUUFBUSxRQUFRLENBQUM7QUFDL0UsSUFBTSxXQUFXLFlBQVksbUJBQW1CO0FBQ2hELElBQU0sY0FBYyxZQUFZLE9BQU8sWUFBWSxZQUFZLE1BQU0sT0FBTztBQUM1RSxJQUFNLGVBQWUsWUFBWSxVQUFVLE9BQU8sS0FBSyxTQUFTLE9BQU8sS0FBSyxjQUFjLE9BQU8sS0FBSyxTQUFTLE9BQU8sS0FBSyxTQUFTLE9BQU8sS0FBSyxTQUFTLE9BQU87QUFDaEssSUFBTSxZQUFZLFlBQVksT0FBTyxZQUFZO0FBQ2pELElBQU0sY0FBYyxZQUFZLFlBQVksWUFBWSxZQUFZO0FBQ3BFLElBQU0sZ0JBQWdCLFlBQVksWUFBWSxPQUFPLE9BQU8sS0FBSyxFQUFFLG1CQUFtQjtBQUN0RixJQUFNLFNBQVMsWUFBWSxtQkFBbUI7QUFHOUMsSUFBTSxhQUFhLFFBQVEsSUFBSSxRQUFRLE9BQU8sS0FBSztBQUNuRCxJQUFNLGlCQUFpQixTQUFTLEtBQUssSUFBSSxNQUFNLENBQUMsQ0FBQyxJQUFJLFNBQVMsQ0FBQyxDQUFDLEtBQUssR0FBRztBQUN4RSxJQUFNLGFBQWEsV0FBVztDQUM3QixNQUFNLFNBQVMsQ0FBQztDQUNoQixJQUFJLFVBQVU7Q0FDZCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxRQUFRLEtBQUs7RUFDdkMsSUFBSSxPQUFPLE9BQU8sT0FBTyxDQUFDO0VBQzFCLElBQUksU0FBUyxRQUFRLE9BQU8sT0FBTyxJQUFJLENBQUMsTUFBTSxLQUFLO0dBQ2xELFdBQVc7R0FDWDtHQUNBO0VBQ0Q7RUFDQSxJQUFJLFNBQVMsS0FBSztHQUNqQixPQUFPLEtBQUssT0FBTztHQUNuQixVQUFVO0dBQ1Y7RUFDRDtFQUNBLFdBQVc7Q0FDWjtDQUNBLE1BQU0sY0FBYztDQUNwQixPQUFPLEtBQUssV0FBVztDQUN2QixPQUFPO0FBQ1I7QUFHQSxTQUFTLHFCQUFxQixjQUFjLFlBQVksV0FBVyxhQUFhO0NBQy9FLE9BQU87RUFDTjtFQUNBO0VBQ0E7RUFDQTtDQUNEO0FBQ0Q7QUFDQSxJQUFNLGNBQWM7Q0FDbkIscUJBQXFCLGVBQWUsbUJBQW1CLFlBQVksS0FBSyxDQUFDO0NBQ3pFLHFCQUFxQixVQUFVLFdBQVcsTUFBTSxFQUFFLFNBQVMsSUFBSSxNQUFNO0VBQ3BFLElBQUksT0FBTyxXQUFXLGFBQWEsT0FBTyxPQUFPLENBQUM7RUFDbEQsUUFBUSxNQUFNLCtCQUErQjtFQUM3QyxPQUFPO0NBQ1IsQ0FBQztDQUNELHFCQUFxQixRQUFRLFNBQVMsTUFBTSxFQUFFLFlBQVksSUFBSSxNQUFNLElBQUksS0FBSyxDQUFDLENBQUM7Q0FDL0UscUJBQXFCLFNBQVMsVUFBVSxHQUFHLGNBQWM7RUFDeEQsTUFBTSxZQUFZO0dBQ2pCLE1BQU0sRUFBRTtHQUNSLFNBQVMsRUFBRTtFQUNaO0VBQ0EsVUFBVSxrQkFBa0IsU0FBUyxTQUFTO0dBQzdDLFVBQVUsUUFBUSxFQUFFO0VBQ3JCLENBQUM7RUFDRCxPQUFPO0NBQ1IsSUFBSSxHQUFHLGNBQWM7RUFDcEIsTUFBTSxJQUFJLElBQUksTUFBTSxFQUFFLE9BQU87RUFDN0IsRUFBRSxPQUFPLEVBQUU7RUFDWCxFQUFFLFFBQVEsRUFBRTtFQUNaLFVBQVUsa0JBQWtCLFNBQVMsU0FBUztHQUM3QyxFQUFFLFFBQVEsRUFBRTtFQUNiLENBQUM7RUFDRCxPQUFPO0NBQ1IsQ0FBQztDQUNELHFCQUFxQixVQUFVLFdBQVcsTUFBTSxLQUFLLElBQUksVUFBVTtFQUNsRSxNQUFNLE9BQU8sTUFBTSxNQUFNLEdBQUcsTUFBTSxZQUFZLEdBQUcsQ0FBQztFQUNsRCxNQUFNLFFBQVEsTUFBTSxNQUFNLE1BQU0sWUFBWSxHQUFHLElBQUksQ0FBQztFQUNwRCxPQUFPLElBQUksT0FBTyxNQUFNLEtBQUs7Q0FDOUIsQ0FBQztDQUNELHFCQUFxQixPQUFPLFFBQVEsTUFBTSxDQUFDLEdBQUcsRUFBRSxPQUFPLENBQUMsSUFBSSxNQUFNLElBQUksSUFBSSxDQUFDLENBQUM7Q0FDNUUscUJBQXFCLE9BQU8sUUFBUSxNQUFNLENBQUMsR0FBRyxFQUFFLFFBQVEsQ0FBQyxJQUFJLE1BQU0sSUFBSSxJQUFJLENBQUMsQ0FBQztDQUM3RSxzQkFBc0IsTUFBTSxXQUFXLENBQUMsS0FBSyxXQUFXLENBQUMsR0FBRyxXQUFXLE1BQU07RUFDNUUsSUFBSSxXQUFXLENBQUMsR0FBRyxPQUFPO0VBQzFCLElBQUksSUFBSSxHQUFHLE9BQU87T0FDYixPQUFPO0NBQ2IsR0FBRyxNQUFNO0NBQ1Qsc0JBQXNCLE1BQU0sTUFBTSxLQUFLLElBQUksTUFBTSxXQUFXLGdCQUFnQjtFQUMzRSxPQUFPO0NBQ1IsR0FBRyxNQUFNO0NBQ1QscUJBQXFCLE9BQU8sUUFBUSxNQUFNLEVBQUUsU0FBUyxJQUFJLE1BQU0sSUFBSSxJQUFJLENBQUMsQ0FBQztBQUMxRTtBQUNBLFNBQVMsd0JBQXdCLGNBQWMsWUFBWSxXQUFXLGFBQWE7Q0FDbEYsT0FBTztFQUNOO0VBQ0E7RUFDQTtFQUNBO0NBQ0Q7QUFDRDtBQUNBLElBQU0sYUFBYSx5QkFBeUIsR0FBRyxjQUFjO0NBQzVELElBQUksU0FBUyxDQUFDLEdBQUcsT0FBTyxDQUFDLENBQUMsVUFBVSxlQUFlLGNBQWMsQ0FBQztDQUNsRSxPQUFPO0FBQ1IsSUFBSSxHQUFHLGNBQWM7Q0FDcEIsT0FBTyxDQUFDLFVBQVUsVUFBVSxlQUFlLGNBQWMsQ0FBQyxDQUFDO0FBQzVELElBQUksTUFBTSxFQUFFLGNBQWMsR0FBRyxHQUFHLGNBQWM7Q0FDN0MsTUFBTSxRQUFRLFVBQVUsZUFBZSxTQUFTLEVBQUUsRUFBRTtDQUNwRCxJQUFJLENBQUMsT0FBTyxNQUFNLElBQUksTUFBTSxzQ0FBc0M7Q0FDbEUsT0FBTztBQUNSLENBQUM7QUFDRCxJQUFNLG9CQUFvQjtDQUN6QjtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7QUFDRCxDQUFDLENBQUMsUUFBUSxLQUFLLFNBQVM7Q0FDdkIsSUFBSSxLQUFLLFFBQVE7Q0FDakIsT0FBTztBQUNSLEdBQUcsQ0FBQyxDQUFDO0FBQ0wsSUFBTSxpQkFBaUIsd0JBQXdCLGVBQWUsTUFBTSxDQUFDLGVBQWUsRUFBRSxZQUFZLElBQUksSUFBSSxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksR0FBRyxNQUFNO0NBQ2pJLE1BQU0sT0FBTyxrQkFBa0IsRUFBRTtDQUNqQyxJQUFJLENBQUMsTUFBTSxNQUFNLElBQUksTUFBTSwyQ0FBMkM7Q0FDdEUsT0FBTyxJQUFJLEtBQUssQ0FBQztBQUNsQixDQUFDO0FBQ0QsU0FBUyw0QkFBNEIsZ0JBQWdCLFdBQVc7Q0FDL0QsSUFBSSxnQkFBZ0IsYUFBYSxPQUFPLENBQUMsQ0FBQyxVQUFVLGNBQWMsY0FBYyxlQUFlLFdBQVc7Q0FDMUcsT0FBTztBQUNSO0FBQ0EsSUFBTSxZQUFZLHdCQUF3Qiw4QkFBOEIsT0FBTyxjQUFjO0NBQzVGLE9BQU8sQ0FBQyxTQUFTLFVBQVUsY0FBYyxjQUFjLE1BQU0sV0FBVyxDQUFDO0FBQzFFLElBQUksT0FBTyxjQUFjO0NBQ3hCLE1BQU0sZUFBZSxVQUFVLGNBQWMsZ0JBQWdCLE1BQU0sV0FBVztDQUM5RSxJQUFJLENBQUMsY0FBYyxPQUFPLEVBQUUsR0FBRyxNQUFNO0NBQ3JDLE1BQU0sU0FBUyxDQUFDO0NBQ2hCLGFBQWEsU0FBUyxTQUFTO0VBQzlCLE9BQU8sUUFBUSxNQUFNO0NBQ3RCLENBQUM7Q0FDRCxPQUFPO0FBQ1IsSUFBSSxHQUFHLEdBQUcsY0FBYztDQUN2QixNQUFNLFFBQVEsVUFBVSxjQUFjLFNBQVMsRUFBRSxFQUFFO0NBQ25ELElBQUksQ0FBQyxPQUFPLE1BQU0sSUFBSSxNQUFNLHdDQUF3QyxFQUFFLEdBQUcsa0ZBQWtGO0NBQzNKLE9BQU8sT0FBTyxPQUFPLE9BQU8sT0FBTyxNQUFNLFNBQVMsR0FBRyxDQUFDO0FBQ3ZELENBQUM7QUFDRCxJQUFNLGFBQWEseUJBQXlCLE9BQU8sY0FBYztDQUNoRSxPQUFPLENBQUMsQ0FBQyxVQUFVLDBCQUEwQixlQUFlLEtBQUs7QUFDbEUsSUFBSSxPQUFPLGNBQWM7Q0FDeEIsT0FBTyxDQUFDLFVBQVUsVUFBVSwwQkFBMEIsZUFBZSxLQUFLLENBQUMsQ0FBQyxJQUFJO0FBQ2pGLElBQUksT0FBTyxjQUFjO0NBQ3hCLE9BQU8sVUFBVSwwQkFBMEIsZUFBZSxLQUFLLENBQUMsQ0FBQyxVQUFVLEtBQUs7QUFDakYsSUFBSSxHQUFHLEdBQUcsY0FBYztDQUN2QixNQUFNLGNBQWMsVUFBVSwwQkFBMEIsV0FBVyxFQUFFLEVBQUU7Q0FDdkUsSUFBSSxDQUFDLGFBQWEsTUFBTSxJQUFJLE1BQU0sNENBQTRDO0NBQzlFLE9BQU8sWUFBWSxZQUFZLENBQUM7QUFDakMsQ0FBQztBQUNELElBQU0saUJBQWlCO0NBQ3RCO0NBQ0E7Q0FDQTtDQUNBO0FBQ0Q7QUFDQSxJQUFNLGtCQUFrQixPQUFPLGNBQWM7Q0FDNUMsTUFBTSwwQkFBMEIsUUFBUSxpQkFBaUIsU0FBUyxLQUFLLGFBQWEsT0FBTyxTQUFTLENBQUM7Q0FDckcsSUFBSSx5QkFBeUIsT0FBTztFQUNuQyxPQUFPLHdCQUF3QixVQUFVLE9BQU8sU0FBUztFQUN6RCxNQUFNLHdCQUF3QixXQUFXLE9BQU8sU0FBUztDQUMxRDtDQUNBLE1BQU0sdUJBQXVCLFFBQVEsY0FBYyxTQUFTLEtBQUssYUFBYSxPQUFPLFNBQVMsQ0FBQztDQUMvRixJQUFJLHNCQUFzQixPQUFPO0VBQ2hDLE9BQU8scUJBQXFCLFVBQVUsT0FBTyxTQUFTO0VBQ3RELE1BQU0scUJBQXFCO0NBQzVCO0FBQ0Q7QUFDQSxJQUFNLDBCQUEwQixDQUFDO0FBQ2pDLFlBQVksU0FBUyxTQUFTO0NBQzdCLHdCQUF3QixLQUFLLGNBQWM7QUFDNUMsQ0FBQztBQUNELElBQU0sb0JBQW9CLE1BQU0sTUFBTSxjQUFjO0NBQ25ELElBQUksVUFBVSxJQUFJLEdBQUcsUUFBUSxLQUFLLElBQWI7RUFDcEIsS0FBSyxVQUFVLE9BQU8sV0FBVyxZQUFZLE1BQU0sTUFBTSxTQUFTO0VBQ2xFLEtBQUssU0FBUyxPQUFPLFVBQVUsWUFBWSxNQUFNLE1BQU0sU0FBUztFQUNoRSxLQUFLLFVBQVUsT0FBTyxXQUFXLFlBQVksTUFBTSxNQUFNLFNBQVM7RUFDbEUsS0FBSyxlQUFlLE9BQU8sZUFBZSxZQUFZLE1BQU0sTUFBTSxTQUFTO0VBQzNFLFNBQVMsTUFBTSxJQUFJLE1BQU0sNkJBQTZCLElBQUk7Q0FDM0Q7TUFDSztFQUNKLE1BQU0saUJBQWlCLHdCQUF3QjtFQUMvQyxJQUFJLENBQUMsZ0JBQWdCLE1BQU0sSUFBSSxNQUFNLDZCQUE2QixJQUFJO0VBQ3RFLE9BQU8sZUFBZSxZQUFZLE1BQU0sU0FBUztDQUNsRDtBQUNEO0FBR0EsSUFBTSxhQUFhLE9BQU8sTUFBTTtDQUMvQixJQUFJLElBQUksTUFBTSxNQUFNLE1BQU0sSUFBSSxNQUFNLHFCQUFxQjtDQUN6RCxNQUFNLE9BQU8sTUFBTSxLQUFLO0NBQ3hCLE9BQU8sSUFBSSxHQUFHO0VBQ2IsS0FBSyxLQUFLO0VBQ1Y7Q0FDRDtDQUNBLE9BQU8sS0FBSyxLQUFLLENBQUMsQ0FBQztBQUNwQjtBQUNBLFNBQVMsYUFBYSxNQUFNO0NBQzNCLElBQUksU0FBUyxNQUFNLFdBQVcsR0FBRyxNQUFNLElBQUksTUFBTSx3Q0FBd0M7Q0FDekYsSUFBSSxTQUFTLE1BQU0sV0FBVyxHQUFHLE1BQU0sSUFBSSxNQUFNLHdDQUF3QztDQUN6RixJQUFJLFNBQVMsTUFBTSxhQUFhLEdBQUcsTUFBTSxJQUFJLE1BQU0sMENBQTBDO0FBQzlGO0FBQ0EsSUFBTSxXQUFXLFFBQVEsU0FBUztDQUNqQyxhQUFhLElBQUk7Q0FDakIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxLQUFLO0VBQ3JDLE1BQU0sTUFBTSxLQUFLO0VBQ2pCLElBQUksTUFBTSxNQUFNLEdBQUcsU0FBUyxVQUFVLFFBQVEsQ0FBQyxHQUFHO09BQzdDLElBQUksTUFBTSxNQUFNLEdBQUc7R0FDdkIsTUFBTSxNQUFNLENBQUM7R0FDYixNQUFNLE9BQU8sQ0FBQyxLQUFLLEVBQUUsT0FBTyxJQUFJLFFBQVE7R0FDeEMsTUFBTSxXQUFXLFVBQVUsUUFBUSxHQUFHO0dBQ3RDLFFBQVEsTUFBUjtJQUNDLEtBQUs7S0FDSixTQUFTO0tBQ1Q7SUFDRCxLQUFLLFNBQ0osU0FBUyxPQUFPLElBQUksUUFBUTtHQUU5QjtFQUNELE9BQU8sU0FBUyxPQUFPO0NBQ3hCO0NBQ0EsT0FBTztBQUNSO0FBQ0EsSUFBTSxXQUFXLFFBQVEsTUFBTSxXQUFXO0NBQ3pDLGFBQWEsSUFBSTtDQUNqQixJQUFJLEtBQUssV0FBVyxHQUFHLE9BQU8sT0FBTyxNQUFNO0NBQzNDLElBQUksU0FBUztDQUNiLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLFNBQVMsR0FBRyxLQUFLO0VBQ3pDLE1BQU0sTUFBTSxLQUFLO0VBQ2pCLElBQUksVUFBVSxNQUFNLEdBQUc7R0FDdEIsTUFBTSxRQUFRLENBQUM7R0FDZixTQUFTLE9BQU87RUFDakIsT0FBTyxJQUFJLGdCQUFnQixNQUFNLEdBQUcsU0FBUyxPQUFPO09BQy9DLElBQUksTUFBTSxNQUFNLEdBQUc7R0FDdkIsTUFBTSxNQUFNLENBQUM7R0FDYixTQUFTLFVBQVUsUUFBUSxHQUFHO0VBQy9CLE9BQU8sSUFBSSxNQUFNLE1BQU0sR0FBRztHQUN6QixJQUFJLE1BQU0sS0FBSyxTQUFTLEdBQUc7R0FDM0IsTUFBTSxNQUFNLENBQUM7R0FDYixNQUFNLE9BQU8sQ0FBQyxLQUFLLEVBQUUsT0FBTyxJQUFJLFFBQVE7R0FDeEMsTUFBTSxXQUFXLFVBQVUsUUFBUSxHQUFHO0dBQ3RDLFFBQVEsTUFBUjtJQUNDLEtBQUs7S0FDSixTQUFTO0tBQ1Q7SUFDRCxLQUFLLFNBQ0osU0FBUyxPQUFPLElBQUksUUFBUTtHQUU5QjtFQUNEO0NBQ0Q7Q0FDQSxNQUFNLFVBQVUsS0FBSyxLQUFLLFNBQVM7Q0FDbkMsSUFBSSxVQUFVLE1BQU0sR0FBRyxPQUFPLENBQUMsV0FBVyxPQUFPLE9BQU8sQ0FBQyxRQUFRO01BQzVELElBQUksZ0JBQWdCLE1BQU0sR0FBRyxPQUFPLFdBQVcsT0FBTyxPQUFPLFFBQVE7Q0FDMUUsSUFBSSxNQUFNLE1BQU0sR0FBRztFQUNsQixNQUFNLFdBQVcsVUFBVSxRQUFRLENBQUMsT0FBTztFQUMzQyxNQUFNLFdBQVcsT0FBTyxRQUFRO0VBQ2hDLElBQUksYUFBYSxVQUFVO0dBQzFCLE9BQU8sT0FBTyxRQUFRO0dBQ3RCLE9BQU8sSUFBSSxRQUFRO0VBQ3BCO0NBQ0Q7Q0FDQSxJQUFJLE1BQU0sTUFBTSxHQUFHO0VBQ2xCLE1BQU0sTUFBTSxDQUFDLEtBQUssS0FBSyxTQUFTO0VBQ2hDLE1BQU0sV0FBVyxVQUFVLFFBQVEsR0FBRztFQUN0QyxRQUFRLENBQUMsWUFBWSxJQUFJLFFBQVEsU0FBakM7R0FDQyxLQUFLLE9BQU87SUFDWCxNQUFNLFNBQVMsT0FBTyxRQUFRO0lBQzlCLE9BQU8sSUFBSSxRQUFRLE9BQU8sSUFBSSxRQUFRLENBQUM7SUFDdkMsSUFBSSxXQUFXLFVBQVUsT0FBTyxPQUFPLFFBQVE7SUFDL0M7R0FDRDtHQUNBLEtBQUssU0FDSixPQUFPLElBQUksVUFBVSxPQUFPLE9BQU8sSUFBSSxRQUFRLENBQUMsQ0FBQztFQUVuRDtDQUNEO0NBQ0EsT0FBTztBQUNSO0FBR0EsU0FBUyxTQUFTLE1BQU0sUUFBUSxTQUFTLENBQUMsR0FBRztDQUM1QyxJQUFJLENBQUMsTUFBTTtDQUNYLElBQUksQ0FBQyxVQUFVLElBQUksR0FBRztFQUNyQixRQUFRLE9BQU8sU0FBUyxRQUFRLFNBQVMsU0FBUyxRQUFRLENBQUMsR0FBRyxRQUFRLEdBQUcsVUFBVSxHQUFHLENBQUMsQ0FBQyxDQUFDO0VBQ3pGO0NBQ0Q7Q0FDQSxNQUFNLENBQUMsV0FBVyxZQUFZO0NBQzlCLElBQUksVUFBVSxRQUFRLFdBQVcsT0FBTyxRQUFRO0VBQy9DLFNBQVMsT0FBTyxRQUFRLENBQUMsR0FBRyxRQUFRLEdBQUcsVUFBVSxHQUFHLENBQUMsQ0FBQztDQUN2RCxDQUFDO0NBQ0QsT0FBTyxXQUFXLE1BQU07QUFDekI7QUFDQSxTQUFTLHNCQUFzQixPQUFPLGFBQWEsV0FBVztDQUM3RCxTQUFTLGNBQWMsTUFBTSxTQUFTO0VBQ3JDLFFBQVEsUUFBUSxPQUFPLE9BQU8sTUFBTSxpQkFBaUIsR0FBRyxNQUFNLFNBQVMsQ0FBQztDQUN6RSxDQUFDO0NBQ0QsT0FBTztBQUNSO0FBQ0EsU0FBUyxvQ0FBb0MsT0FBTyxhQUFhO0NBQ2hFLFNBQVMsTUFBTSxnQkFBZ0IsTUFBTTtFQUNwQyxNQUFNLFNBQVMsUUFBUSxPQUFPLFVBQVUsSUFBSSxDQUFDO0VBQzdDLGVBQWUsSUFBSSxTQUFTLENBQUMsQ0FBQyxTQUFTLHdCQUF3QjtHQUM5RCxRQUFRLFFBQVEsT0FBTywyQkFBMkIsTUFBTTtFQUN6RCxDQUFDO0NBQ0Y7Q0FDQSxJQUFJLFVBQVUsV0FBVyxHQUFHO0VBQzNCLE1BQU0sQ0FBQyxNQUFNLFNBQVM7RUFDdEIsS0FBSyxTQUFTLGtCQUFrQjtHQUMvQixRQUFRLFFBQVEsT0FBTyxVQUFVLGFBQWEsU0FBUyxLQUFLO0VBQzdELENBQUM7RUFDRCxJQUFJLE9BQU8sUUFBUSxPQUFPLEtBQUs7Q0FDaEMsT0FBTyxRQUFRLGFBQWEsS0FBSztDQUNqQyxPQUFPO0FBQ1I7QUFDQSxJQUFNLFVBQVUsUUFBUSxjQUFjLGdCQUFnQixNQUFNLEtBQUssVUFBVSxNQUFNLEtBQUssTUFBTSxNQUFNLEtBQUssTUFBTSxNQUFNLEtBQUssNEJBQTRCLFFBQVEsU0FBUztBQUNySyxTQUFTLFlBQVksUUFBUSxNQUFNLFlBQVk7Q0FDOUMsTUFBTSxjQUFjLFdBQVcsSUFBSSxNQUFNO0NBQ3pDLElBQUksYUFBYSxZQUFZLEtBQUssSUFBSTtNQUNqQyxXQUFXLElBQUksUUFBUSxDQUFDLElBQUksQ0FBQztBQUNuQztBQUNBLFNBQVMsdUNBQXVDLGFBQWEsUUFBUTtDQUNwRSxNQUFNLFNBQVMsQ0FBQztDQUNoQixJQUFJLG9CQUFvQixLQUFLO0NBQzdCLFlBQVksU0FBUyxVQUFVO0VBQzlCLElBQUksTUFBTSxVQUFVLEdBQUc7RUFDdkIsSUFBSSxDQUFDLFFBQVEsUUFBUSxNQUFNLEtBQUssU0FBUyxLQUFLLElBQUksTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUcsTUFBTSxFQUFFLFNBQVMsRUFBRSxNQUFNO0VBQzdGLE1BQU0sQ0FBQyxvQkFBb0IsR0FBRyxrQkFBa0I7RUFDaEQsSUFBSSxtQkFBbUIsV0FBVyxHQUFHLG9CQUFvQixlQUFlLElBQUksYUFBYTtPQUNwRixPQUFPLGNBQWMsa0JBQWtCLEtBQUssZUFBZSxJQUFJLGFBQWE7Q0FDbEYsQ0FBQztDQUNELElBQUksbUJBQW1CLElBQUksY0FBYyxNQUFNLEdBQUcsT0FBTyxDQUFDLGlCQUFpQjtNQUN0RSxPQUFPLENBQUMsbUJBQW1CLE1BQU07TUFDakMsT0FBTyxjQUFjLE1BQU0sSUFBSSxLQUFLLElBQUk7QUFDOUM7QUFDQSxJQUFNLFVBQVUsUUFBUSxZQUFZLFdBQVcsUUFBUSxPQUFPLENBQUMsR0FBRyxvQkFBb0IsQ0FBQyxHQUFHLDhCQUE4QixJQUFJLElBQUksTUFBTTtDQUNySSxNQUFNLFlBQVksWUFBWSxNQUFNO0NBQ3BDLElBQUksQ0FBQyxXQUFXO0VBQ2YsWUFBWSxRQUFRLE1BQU0sVUFBVTtFQUNwQyxNQUFNLE9BQU8sWUFBWSxJQUFJLE1BQU07RUFDbkMsSUFBSSxNQUFNLE9BQU8sU0FBUyxFQUFFLGtCQUFrQixLQUFLLElBQUk7Q0FDeEQ7Q0FDQSxJQUFJLENBQUMsT0FBTyxRQUFRLFNBQVMsR0FBRztFQUMvQixNQUFNLGNBQWMsZUFBZSxRQUFRLFNBQVM7RUFDcEQsTUFBTSxTQUFTLGNBQWM7R0FDNUIsa0JBQWtCLFlBQVk7R0FDOUIsYUFBYSxDQUFDLFlBQVksSUFBSTtFQUMvQixJQUFJLEVBQUUsa0JBQWtCLE9BQU87RUFDL0IsSUFBSSxDQUFDLFdBQVcsWUFBWSxJQUFJLFFBQVEsTUFBTTtFQUM5QyxPQUFPO0NBQ1I7Q0FDQSxJQUFJLFNBQVMsbUJBQW1CLE1BQU0sR0FBRyxPQUFPLEVBQUUsa0JBQWtCLEtBQUs7Q0FDekUsTUFBTSx1QkFBdUIsZUFBZSxRQUFRLFNBQVM7Q0FDN0QsTUFBTSxjQUFjLHNCQUFzQixTQUFTO0NBQ25ELE1BQU0sbUJBQW1CLFVBQVUsV0FBVyxJQUFJLENBQUMsSUFBSSxDQUFDO0NBQ3hELE1BQU0sbUJBQW1CLENBQUM7Q0FDMUIsUUFBUSxjQUFjLE9BQU8sVUFBVTtFQUN0QyxJQUFJLFVBQVUsZUFBZSxVQUFVLGlCQUFpQixVQUFVLGFBQWEsTUFBTSxJQUFJLE1BQU0scUJBQXFCLE1BQU0seUVBQXlFO0VBQ25NLE1BQU0sa0JBQWtCLE9BQU8sT0FBTyxZQUFZLFdBQVcsUUFBUSxDQUFDLEdBQUcsTUFBTSxLQUFLLEdBQUcsQ0FBQyxHQUFHLG1CQUFtQixNQUFNLEdBQUcsV0FBVztFQUNsSSxpQkFBaUIsU0FBUyxnQkFBZ0I7RUFDMUMsSUFBSSxVQUFVLGdCQUFnQixXQUFXLEdBQUcsaUJBQWlCLFNBQVMsZ0JBQWdCO09BQ2pGLElBQUksZ0JBQWdCLGdCQUFnQixXQUFXLEdBQUcsUUFBUSxnQkFBZ0IsY0FBYyxNQUFNLFFBQVE7R0FDMUcsaUJBQWlCLFVBQVUsS0FBSyxJQUFJLE1BQU0sT0FBTztFQUNsRCxDQUFDO0NBQ0YsQ0FBQztDQUNELE1BQU0sU0FBUyxjQUFjLGdCQUFnQixJQUFJO0VBQ2hEO0VBQ0EsYUFBYSxDQUFDLENBQUMsdUJBQXVCLENBQUMscUJBQXFCLElBQUksSUFBSSxLQUFLO0NBQzFFLElBQUk7RUFDSDtFQUNBLGFBQWEsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLHFCQUFxQixNQUFNLGdCQUFnQixJQUFJO0NBQ3ZGO0NBQ0EsSUFBSSxDQUFDLFdBQVcsWUFBWSxJQUFJLFFBQVEsTUFBTTtDQUM5QyxPQUFPO0FBQ1I7QUFHQSxTQUFTLFFBQVEsU0FBUztDQUN6QixPQUFPLE9BQU8sVUFBVSxTQUFTLEtBQUssT0FBTyxDQUFDLENBQUMsTUFBTSxHQUFHLEVBQUU7QUFDM0Q7QUFDQSxTQUFTLFVBQVUsU0FBUztDQUMzQixPQUFPLFFBQVEsT0FBTyxNQUFNO0FBQzdCO0FBQ0EsU0FBUyxnQkFBZ0IsU0FBUztDQUNqQyxJQUFJLFFBQVEsT0FBTyxNQUFNLFVBQVUsT0FBTztDQUMxQyxNQUFNLFlBQVksT0FBTyxlQUFlLE9BQU87Q0FDL0MsT0FBTyxDQUFDLENBQUMsYUFBYSxVQUFVLGdCQUFnQixVQUFVLGNBQWMsT0FBTztBQUNoRjtBQWFBLFNBQVMsV0FBVyxPQUFPLEtBQUssUUFBUSxnQkFBZ0Isc0JBQXNCO0NBQzdFLE1BQU0sV0FBVyxDQUFDLEVBQUUscUJBQXFCLEtBQUssZ0JBQWdCLEdBQUcsSUFBSSxlQUFlO0NBQ3BGLElBQUksYUFBYSxjQUFjLE1BQU0sT0FBTztDQUM1QyxJQUFJLHdCQUF3QixhQUFhLGlCQUFpQixPQUFPLGVBQWUsT0FBTyxLQUFLO0VBQzNGLE9BQU87RUFDUCxZQUFZO0VBQ1osVUFBVTtFQUNWLGNBQWM7Q0FDZixDQUFDO0FBQ0Y7QUFDQSxTQUFTLEtBQUssUUFBUSxVQUFVLENBQUMsR0FBRztDQUNuQyxJQUFJLFVBQVUsTUFBTSxHQUFHLE9BQU8sT0FBTyxLQUFLLFNBQVMsS0FBSyxNQUFNLE9BQU8sQ0FBQztDQUN0RSxJQUFJLENBQUMsZ0JBQWdCLE1BQU0sR0FBRyxPQUFPO0NBQ3JDLE1BQU0sUUFBUSxPQUFPLG9CQUFvQixNQUFNO0NBQy9DLE1BQU0sVUFBVSxPQUFPLHNCQUFzQixNQUFNO0NBQ25ELE9BQU8sQ0FBQyxHQUFHLE9BQU8sR0FBRyxPQUFPLENBQUMsQ0FBQyxRQUFRLE9BQU8sUUFBUTtFQUNwRCxJQUFJLFVBQVUsUUFBUSxLQUFLLEtBQUssQ0FBQyxRQUFRLE1BQU0sU0FBUyxHQUFHLEdBQUcsT0FBTztFQUNyRSxNQUFNLE1BQU0sT0FBTztFQUNuQixXQUFXLE9BQU8sS0FBSyxLQUFLLEtBQUssT0FBTyxHQUFHLFFBQVEsUUFBUSxhQUFhO0VBQ3hFLE9BQU87Q0FDUixHQUFHLENBQUMsQ0FBQztBQUNOO0FBR0EsSUFBSSxZQUFZLE1BQU07Ozs7Q0FJckIsWUFBWSxFQUFFLFNBQVMsVUFBVSxDQUFDLEdBQUc7RUFDcEMsS0FBSyxnQkFBZ0IsSUFBSSxjQUFjO0VBQ3ZDLEtBQUssaUJBQWlCLElBQUksVUFBVSxNQUFNLEVBQUUsZUFBZSxFQUFFO0VBQzdELEtBQUssNEJBQTRCLElBQUksMEJBQTBCO0VBQy9ELEtBQUssb0JBQW9CLENBQUM7RUFDMUIsS0FBSyxTQUFTO0NBQ2Y7Q0FDQSxVQUFVLFFBQVE7RUFDakIsTUFBTSw2QkFBNkIsSUFBSSxJQUFJO0VBQzNDLE1BQU0sU0FBUyxPQUFPLFFBQVEsWUFBWSxNQUFNLEtBQUssTUFBTTtFQUMzRCxNQUFNLE1BQU0sRUFBRSxNQUFNLE9BQU8saUJBQWlCO0VBQzVDLElBQUksT0FBTyxhQUFhLElBQUksT0FBTztHQUNsQyxHQUFHLElBQUk7R0FDUCxRQUFRLE9BQU87RUFDaEI7RUFDQSxNQUFNLHNCQUFzQix1Q0FBdUMsWUFBWSxLQUFLLE1BQU07RUFDMUYsSUFBSSxxQkFBcUIsSUFBSSxPQUFPO0dBQ25DLEdBQUcsSUFBSTtHQUNQLHVCQUF1QjtFQUN4QjtFQUNBLE9BQU87Q0FDUjtDQUNBLFlBQVksU0FBUztFQUNwQixNQUFNLEVBQUUsTUFBTSxTQUFTO0VBQ3ZCLElBQUksU0FBUyxLQUFLLElBQUk7RUFDdEIsSUFBSSxNQUFNLFFBQVEsU0FBUyxzQkFBc0IsUUFBUSxLQUFLLFFBQVEsSUFBSTtFQUMxRSxJQUFJLE1BQU0sdUJBQXVCLFNBQVMsb0NBQW9DLFFBQVEsS0FBSyxxQkFBcUI7RUFDaEgsT0FBTztDQUNSO0NBQ0EsVUFBVSxRQUFRO0VBQ2pCLE9BQU8sS0FBSyxVQUFVLEtBQUssVUFBVSxNQUFNLENBQUM7Q0FDN0M7Q0FDQSxNQUFNLFFBQVE7RUFDYixPQUFPLEtBQUssWUFBWSxLQUFLLE1BQU0sTUFBTSxDQUFDO0NBQzNDO0NBQ0EsY0FBYyxHQUFHLFNBQVM7RUFDekIsS0FBSyxjQUFjLFNBQVMsR0FBRyxPQUFPO0NBQ3ZDO0NBQ0EsZUFBZSxHQUFHLFlBQVk7RUFDN0IsS0FBSyxlQUFlLFNBQVMsR0FBRyxVQUFVO0NBQzNDO0NBQ0EsZUFBZSxhQUFhLE1BQU07RUFDakMsS0FBSywwQkFBMEIsU0FBUztHQUN2QztHQUNBLEdBQUc7RUFDSixDQUFDO0NBQ0Y7Q0FDQSxnQkFBZ0IsR0FBRyxPQUFPO0VBQ3pCLEtBQUssa0JBQWtCLEtBQUssR0FBRyxLQUFLO0NBQ3JDO0FBQ0Q7QUFDQSxVQUFVLGtCQUFrQixJQUFJLFVBQVU7QUFDMUMsVUFBVSxZQUFZLFVBQVUsZ0JBQWdCLFVBQVUsS0FBSyxVQUFVLGVBQWU7QUFDeEYsVUFBVSxjQUFjLFVBQVUsZ0JBQWdCLFlBQVksS0FBSyxVQUFVLGVBQWU7QUFDNUYsVUFBVSxZQUFZLFVBQVUsZ0JBQWdCLFVBQVUsS0FBSyxVQUFVLGVBQWU7QUFDeEYsVUFBVSxRQUFRLFVBQVUsZ0JBQWdCLE1BQU0sS0FBSyxVQUFVLGVBQWU7QUFDaEYsVUFBVSxnQkFBZ0IsVUFBVSxnQkFBZ0IsY0FBYyxLQUFLLFVBQVUsZUFBZTtBQUNoRyxVQUFVLGlCQUFpQixVQUFVLGdCQUFnQixlQUFlLEtBQUssVUFBVSxlQUFlO0FBQ2xHLFVBQVUsaUJBQWlCLFVBQVUsZ0JBQWdCLGVBQWUsS0FBSyxVQUFVLGVBQWU7QUFDbEcsVUFBVSxrQkFBa0IsVUFBVSxnQkFBZ0IsZ0JBQWdCLEtBQUssVUFBVSxlQUFlO0FBQ3BHLFVBQVU7QUFDVixVQUFVO0FBQ1YsVUFBVTtBQUNWLFVBQVU7QUFDVixVQUFVO0FBQ1YsVUFBVTtBQUNWLFVBQVU7QUFDVixVQUFVO0FBNlNWLE9BQU8sMENBQTBDLENBQUM7QUFDbEQsT0FBTyxvQ0FBb0M7QUFDM0MsT0FBTyxvQ0FBb0M7QUFDM0MsT0FBTyx5Q0FBeUM7QUFDaEQsT0FBTyx5Q0FBeUM7QUFDaEQsT0FBTyw4Q0FBOEM7Ozs7Ozs7O0FDdGxLckQsSUFBTSxZQUFZLE9BQU8sYUFBYTs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBb0J0QyxJQUFNLFVBQVU7QUFDaEIsSUFBTSxlQUFlO0FBQ3JCLElBQU0sV0FBVztBQUNqQixJQUFNLFdBQVc7QUFDakIsSUFBTSxRQUFRO0FBQ2QsSUFBTSxVQUFVOzs7Ozs7Ozs7Ozs7Ozs7QUFlaEIsSUFBTSxzQkFBc0I7QUFDNUIsSUFBTSx1QkFBdUI7QUFDN0IsSUFBTSxlQUFlO0FBQ3JCLElBQU0sa0JBQWtCO0FBQ3hCLElBQU0sb0JBQW9CO0FBQzFCLElBQU0sY0FBYztBQUNwQixJQUFNLHFCQUFxQjtBQUMzQixJQUFNLGVBQWU7Ozs7Ozs7OztBQVNyQixTQUFTLGFBQWEsTUFBTTtDQUMzQixPQUFPLFFBQVEsT0FBTyxLQUFLLFVBQVUsS0FBSyxJQUFJLENBQUMsQ0FBQyxRQUFRLGFBQWEsR0FBRyxDQUFDLENBQUMsUUFBUSxxQkFBcUIsR0FBRyxDQUFDLENBQUMsUUFBUSxzQkFBc0IsR0FBRztBQUM5STs7Ozs7OztBQU9BLFNBQVMsV0FBVyxNQUFNO0NBQ3pCLE9BQU8sYUFBYSxJQUFJLENBQUMsQ0FBQyxRQUFRLG1CQUFtQixHQUFHLENBQUMsQ0FBQyxRQUFRLG9CQUFvQixHQUFHLENBQUMsQ0FBQyxRQUFRLGNBQWMsR0FBRztBQUNySDs7Ozs7Ozs7QUFRQSxTQUFTLGlCQUFpQixNQUFNO0NBQy9CLE9BQU8sYUFBYSxJQUFJLENBQUMsQ0FBQyxRQUFRLFNBQVMsS0FBSyxDQUFDLENBQUMsUUFBUSxjQUFjLEdBQUcsQ0FBQyxDQUFDLFFBQVEsU0FBUyxLQUFLLENBQUMsQ0FBQyxRQUFRLGNBQWMsS0FBSyxDQUFDLENBQUMsUUFBUSxpQkFBaUIsR0FBRyxDQUFDLENBQUMsUUFBUSxtQkFBbUIsR0FBRyxDQUFDLENBQUMsUUFBUSxvQkFBb0IsR0FBRyxDQUFDLENBQUMsUUFBUSxjQUFjLEdBQUc7QUFDM1A7Ozs7OztBQU1BLFNBQVMsZUFBZSxNQUFNO0NBQzdCLE9BQU8saUJBQWlCLElBQUksQ0FBQyxDQUFDLFFBQVEsVUFBVSxLQUFLO0FBQ3REOzs7Ozs7O0FBT0EsU0FBUyxXQUFXLE1BQU07Q0FDekIsT0FBTyxhQUFhLElBQUksQ0FBQyxDQUFDLFFBQVEsU0FBUyxLQUFLLENBQUMsQ0FBQyxRQUFRLE9BQU8sS0FBSztBQUN2RTs7Ozs7Ozs7OztBQVVBLFNBQVMsWUFBWSxNQUFNO0NBQzFCLE9BQU8sV0FBVyxJQUFJLENBQUMsQ0FBQyxRQUFRLFVBQVUsS0FBSztBQUNoRDtBQUNBLFNBQVMsT0FBTyxNQUFNO0NBQ3JCLElBQUksUUFBUSxNQUFNLE9BQU87Q0FDekIsSUFBSTtFQUNILE9BQU8sbUJBQW1CLEtBQUssSUFBSTtDQUNwQyxRQUFRO0VBQ1AsWUFBcUQsaUJBQWlCLEVBQUUsTUFBTSxLQUFLLEtBQUssQ0FBQztDQUMxRjtDQUNBLE9BQU8sS0FBSztBQUNiO0FBR0EsSUFBTSxvQkFBb0I7QUFDMUIsSUFBTSx1QkFBdUIsU0FBUyxLQUFLLFFBQVEsbUJBQW1CLEVBQUU7Ozs7Ozs7Ozs7QUFVeEUsU0FBUyxTQUFTLFlBQVksVUFBVSxrQkFBa0IsS0FBSztDQUM5RCxJQUFJLE1BQU0sUUFBUSxDQUFDLEdBQUcsZUFBZSxJQUFJLE9BQU87Q0FDaEQsTUFBTSxVQUFVLFNBQVMsUUFBUSxHQUFHO0NBQ3BDLElBQUksWUFBWSxTQUFTLFFBQVEsR0FBRztDQUNwQyxZQUFZLFdBQVcsS0FBSyxZQUFZLFVBQVUsS0FBSztDQUN2RCxJQUFJLGFBQWEsR0FBRztFQUNuQixPQUFPLFNBQVMsTUFBTSxHQUFHLFNBQVM7RUFDbEMsZUFBZSxTQUFTLE1BQU0sV0FBVyxVQUFVLElBQUksVUFBVSxTQUFTLE1BQU07RUFDaEYsUUFBUSxXQUFXLGFBQWEsTUFBTSxDQUFDLENBQUM7Q0FDekM7Q0FDQSxJQUFJLFdBQVcsR0FBRztFQUNqQixPQUFPLFFBQVEsU0FBUyxNQUFNLEdBQUcsT0FBTztFQUN4QyxPQUFPLFNBQVMsTUFBTSxTQUFTLFNBQVMsTUFBTTtDQUMvQztDQUNBLE9BQU8sb0JBQW9CLFFBQVEsT0FBTyxPQUFPLFVBQVUsZUFBZTtDQUMxRSxPQUFPO0VBQ04sVUFBVSxPQUFPLGVBQWU7RUFDaEM7RUFDQTtFQUNBLE1BQU0sT0FBTyxJQUFJO0NBQ2xCO0FBQ0Q7Ozs7Ozs7QUFXQSxTQUFTLGFBQWEsZ0JBQWdCLFVBQVU7Q0FDL0MsTUFBTSxRQUFRLFNBQVMsUUFBUSxlQUFlLFNBQVMsS0FBSyxJQUFJO0NBQ2hFLE9BQU8sU0FBUyxRQUFRLFNBQVMsT0FBTyxTQUFTLFNBQVMsUUFBUTtBQUNuRTs7Ozs7OztBQU9BLFNBQVMsVUFBVSxVQUFVLE1BQU07Q0FDbEMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLFlBQVksQ0FBQyxDQUFDLFdBQVcsS0FBSyxZQUFZLENBQUMsR0FBRyxPQUFPO0NBQzVFLE9BQU8sU0FBUyxNQUFNLEtBQUssTUFBTSxLQUFLO0FBQ3ZDOzs7Ozs7Ozs7O0FBVUEsU0FBUyxvQkFBb0IsZ0JBQWdCLEdBQUcsR0FBRztDQUNsRCxNQUFNLGFBQWEsRUFBRSxRQUFRLFNBQVM7Q0FDdEMsTUFBTSxhQUFhLEVBQUUsUUFBUSxTQUFTO0NBQ3RDLE9BQU8sYUFBYSxNQUFNLGVBQWUsY0FBYyxrQkFBa0IsRUFBRSxRQUFRLGFBQWEsRUFBRSxRQUFRLFdBQVcsS0FBSywwQkFBMEIsRUFBRSxRQUFRLEVBQUUsTUFBTSxLQUFLLGVBQWUsRUFBRSxLQUFLLE1BQU0sZUFBZSxFQUFFLEtBQUssS0FBSyxFQUFFLFNBQVMsRUFBRTtBQUNoUDs7Ozs7Ozs7QUFRQSxTQUFTLGtCQUFrQixHQUFHLEdBQUc7Q0FDaEMsUUFBUSxFQUFFLFdBQVcsUUFBUSxFQUFFLFdBQVc7QUFDM0M7QUFDQSxTQUFTLDBCQUEwQixHQUFHLEdBQUc7Q0FDeEMsSUFBSSxPQUFPLEtBQUssQ0FBQyxDQUFDLENBQUMsV0FBVyxPQUFPLEtBQUssQ0FBQyxDQUFDLENBQUMsUUFBUSxPQUFPO0NBQzVELEtBQUssSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLCtCQUErQixFQUFFLE1BQU0sRUFBRSxJQUFJLEdBQUcsT0FBTztDQUMvRSxPQUFPO0FBQ1I7QUFDQSxTQUFTLCtCQUErQixHQUFHLEdBQUc7Q0FDN0MsT0FBTyxRQUFRLENBQUMsSUFBSSxrQkFBa0IsR0FBRyxDQUFDLElBQUksUUFBUSxDQUFDLElBQUksa0JBQWtCLEdBQUcsQ0FBQyxLQUFLLEtBQUssRUFBRSxRQUFRLFFBQVEsS0FBSyxFQUFFLFFBQVE7QUFDN0g7Ozs7Ozs7O0FBUUEsU0FBUyxrQkFBa0IsR0FBRyxHQUFHO0NBQ2hDLE9BQU8sUUFBUSxDQUFDLElBQUksRUFBRSxXQUFXLEVBQUUsVUFBVSxFQUFFLE9BQU8sT0FBTyxNQUFNLFVBQVUsRUFBRSxFQUFFLElBQUksRUFBRSxXQUFXLEtBQUssRUFBRSxPQUFPO0FBQ2pIOzs7Ozs7O0FBT0EsU0FBUyxvQkFBb0IsSUFBSSxNQUFNO0NBQ3RDLElBQUksZUFBZSxFQUFFLEdBQUcsT0FBTztDQUMvQixJQUE2QyxDQUFDLGVBQWUsSUFBSSxHQUFHO0VBQ25FLFlBQVksaUJBQWlCO0dBQzVCO0dBQ0E7RUFDRCxDQUFDO0VBQ0QsT0FBTztDQUNSO0NBQ0EsSUFBSSxDQUFDLElBQUksT0FBTztDQUNoQixNQUFNLGVBQWUsS0FBSyxNQUFNLEdBQUc7Q0FDbkMsTUFBTSxhQUFhLEdBQUcsTUFBTSxHQUFHO0NBQy9CLE1BQU0sZ0JBQWdCLFdBQVcsV0FBVyxTQUFTO0NBQ3JELElBQUksa0JBQWtCLFFBQVEsa0JBQWtCLEtBQUssV0FBVyxLQUFLLEVBQUU7Q0FDdkUsSUFBSSxXQUFXLGFBQWEsU0FBUztDQUNyQyxJQUFJO0NBQ0osSUFBSTtDQUNKLEtBQUssYUFBYSxHQUFHLGFBQWEsV0FBVyxRQUFRLGNBQWM7RUFDbEUsVUFBVSxXQUFXO0VBQ3JCLElBQUksWUFBWSxLQUFLO0VBQ3JCLElBQUksWUFBWSxNQUNYO09BQUEsV0FBVyxHQUFHO0VBQUEsT0FDWjtDQUNSO0NBQ0EsT0FBTyxhQUFhLE1BQU0sR0FBRyxRQUFRLENBQUMsQ0FBQyxLQUFLLEdBQUcsSUFBSSxNQUFNLFdBQVcsTUFBTSxVQUFVLENBQUMsQ0FBQyxLQUFLLEdBQUc7QUFDL0Y7Ozs7Ozs7Ozs7Ozs7Ozs7QUFnQkEsSUFBTSw0QkFBNEI7Q0FDakMsTUFBTTtDQUNOLE1BQU0sS0FBSztDQUNYLFFBQVEsQ0FBQztDQUNULE9BQU8sQ0FBQztDQUNSLE1BQU07Q0FDTixVQUFVO0NBQ1YsU0FBUyxDQUFDO0NBQ1YsTUFBTSxDQUFDO0NBQ1AsZ0JBQWdCLEtBQUs7QUFDdEI7Ozs7Ozs7QUFTQSxTQUFTLGNBQWMsTUFBTTtDQUM1QixJQUFJLENBQUMsTUFBTTtFQUNWLElBQUksV0FBVztHQUNkLE1BQU0sU0FBUyxTQUFTLGNBQWMsTUFBTTtHQUM1QyxPQUFPLFVBQVUsT0FBTyxhQUFhLE1BQU0sS0FBSztHQUNoRCxPQUFPLEtBQUssUUFBUSxrQkFBa0IsRUFBRTtFQUN6QyxPQUFPLE9BQU87Q0FDZjtDQUNBLElBQUksS0FBSyxPQUFPLE9BQU8sS0FBSyxPQUFPLEtBQUssT0FBTyxNQUFNO0NBQ3JELE9BQU8sb0JBQW9CLElBQUk7QUFDaEM7QUFDQSxJQUFNLGlCQUFpQjtBQUN2QixTQUFTLFdBQVcsTUFBTSxVQUFVO0NBQ25DLE9BQU8sS0FBSyxRQUFRLGdCQUFnQixHQUFHLElBQUk7QUFDNUM7QUFHQSxTQUFTLG1CQUFtQixJQUFJLFFBQVE7Q0FDdkMsTUFBTSxVQUFVLFNBQVMsZ0JBQWdCLHNCQUFzQjtDQUMvRCxNQUFNLFNBQVMsR0FBRyxzQkFBc0I7Q0FDeEMsT0FBTztFQUNOLFVBQVUsT0FBTztFQUNqQixNQUFNLE9BQU8sT0FBTyxRQUFRLFFBQVEsT0FBTyxRQUFRO0VBQ25ELEtBQUssT0FBTyxNQUFNLFFBQVEsT0FBTyxPQUFPLE9BQU87Q0FDaEQ7QUFDRDtBQUNBLElBQU0sOEJBQThCLFFBQVEsc0JBQXNCLFdBQVc7Q0FDNUUsTUFBTSxPQUFPO0NBQ2IsS0FBSyxPQUFPO0FBQ2IsSUFBSTtBQUNKLFNBQVMsaUJBQWlCLFVBQVU7Q0FDbkMsSUFBSTtDQUNKLElBQUksUUFBUSxVQUFVO0VBQ3JCLE1BQU0sYUFBYSxTQUFTO0VBQzVCLE1BQU0sZUFBZSxPQUFPLGVBQWUsWUFBWSxXQUFXLFdBQVcsR0FBRzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQXNCaEYsSUFBNkMsT0FBTyxTQUFTLE9BQU8sVUFDL0Q7T0FBQSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsZUFBZSxTQUFTLEdBQUcsTUFBTSxDQUFDLENBQUMsR0FBRyxJQUFJO0lBQ3hFLE1BQU0sVUFBVSxTQUFTLGNBQWMsU0FBUyxFQUFFO0lBQ2xELElBQUksZ0JBQWdCLFNBQVM7S0FDNUIsWUFBWSxpQkFBaUIsRUFBRSxJQUFJLFNBQVMsR0FBRyxDQUFDO0tBQ2hEO0lBQ0Q7R0FDRCxRQUFRO0lBQ1AsWUFBWSxpQkFBaUIsRUFBRSxJQUFJLFNBQVMsR0FBRyxDQUFDO0lBQ2hEO0dBQ0Q7O0VBRUQsTUFBTSxLQUFLLE9BQU8sZUFBZSxXQUFXLGVBQWUsU0FBUyxlQUFlLFdBQVcsTUFBTSxDQUFDLENBQUMsSUFBSSxTQUFTLGNBQWMsVUFBVSxJQUFJO0VBQy9JLElBQUksQ0FBQyxJQUFJO0dBQ1IsWUFBcUQsaUJBQWlCLEVBQUUsSUFBSSxTQUFTLEdBQUcsQ0FBQztHQUN6RjtFQUNEO0VBQ0Esa0JBQWtCLG1CQUFtQixJQUFJLFFBQVE7Q0FDbEQsT0FBTyxrQkFBa0I7Q0FDekIsSUFBSSxvQkFBb0IsU0FBUyxnQkFBZ0IsT0FBTyxPQUFPLFNBQVMsZUFBZTtNQUNsRixPQUFPLFNBQVMsZ0JBQWdCLFFBQVEsT0FBTyxnQkFBZ0IsT0FBTyxPQUFPLFNBQVMsZ0JBQWdCLE9BQU8sT0FBTyxnQkFBZ0IsTUFBTSxPQUFPLE9BQU87QUFDOUo7QUFDQSxTQUFTLGFBQWEsTUFBTSxPQUFPO0NBQ2xDLFFBQVEsUUFBUSxRQUFRLFFBQVEsTUFBTSxXQUFXLFFBQVEsTUFBTTtBQUNoRTtBQUNBLElBQU0sa0NBQWtDLElBQUksSUFBSTtBQUNoRCxTQUFTLG1CQUFtQixLQUFLO0NBQ2hDLGdCQUFnQixJQUFJLEtBQUssc0JBQXNCLENBQUM7QUFDakQ7QUFDQSxTQUFTLHVCQUF1QixLQUFLO0NBQ3BDLE1BQU0sU0FBUyxnQkFBZ0IsSUFBSSxHQUFHO0NBQ3RDLGdCQUFnQixPQUFPLEdBQUc7Q0FDMUIsT0FBTztBQUNSOzs7OztBQU9BLFNBQVMsZ0JBQWdCLE9BQU87Q0FDL0IsT0FBTyxPQUFPLFVBQVUsWUFBWSxTQUFTLE9BQU8sVUFBVTtBQUMvRDtBQUNBLFNBQVMsWUFBWSxNQUFNO0NBQzFCLE9BQU8sT0FBTyxTQUFTLFlBQVksT0FBTyxTQUFTO0FBQ3BEOzs7Ozs7Ozs7O0FBWUEsU0FBUyxXQUFXLFFBQVE7Q0FDM0IsTUFBTSxRQUFRLENBQUM7Q0FDZixJQUFJLFdBQVcsTUFBTSxXQUFXLEtBQUssT0FBTztDQUM1QyxNQUFNLGdCQUFnQixPQUFPLE9BQU8sTUFBTSxPQUFPLE1BQU0sQ0FBQyxJQUFJLFFBQVEsTUFBTSxHQUFHO0NBQzdFLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxhQUFhLFFBQVEsRUFBRSxHQUFHO0VBQzdDLE1BQU0sY0FBYyxhQUFhLEVBQUUsQ0FBQyxRQUFRLFNBQVMsR0FBRztFQUN4RCxNQUFNLFFBQVEsWUFBWSxRQUFRLEdBQUc7RUFDckMsTUFBTSxNQUFNLE9BQU8sUUFBUSxJQUFJLGNBQWMsWUFBWSxNQUFNLEdBQUcsS0FBSyxDQUFDO0VBQ3hFLE1BQU0sUUFBUSxRQUFRLElBQUksT0FBTyxPQUFPLFlBQVksTUFBTSxRQUFRLENBQUMsQ0FBQztFQUNwRSxJQUFJLE9BQU8sT0FBTztHQUNqQixJQUFJLGVBQWUsTUFBTTtHQUN6QixJQUFJLENBQUMsUUFBUSxZQUFZLEdBQUcsZUFBZSxNQUFNLE9BQU8sQ0FBQyxZQUFZO0dBQ3JFLGFBQWEsS0FBSyxLQUFLO0VBQ3hCLE9BQU8sTUFBTSxPQUFPO0NBQ3JCO0NBQ0EsT0FBTztBQUNSOzs7Ozs7Ozs7O0FBVUEsU0FBUyxlQUFlLE9BQU87Q0FDOUIsSUFBSSxTQUFTO0NBQ2IsS0FBSyxJQUFJLE9BQU8sT0FBTztFQUN0QixNQUFNLFFBQVEsTUFBTTtFQUNwQixNQUFNLGVBQWUsR0FBRztFQUN4QixJQUFJLFNBQVMsTUFBTTtHQUNsQixJQUFJLFVBQVUsS0FBSyxHQUFHLFdBQVcsT0FBTyxTQUFTLE1BQU0sTUFBTTtHQUM3RDtFQUNEO0VBQ0EsQ0FBQyxRQUFRLEtBQUssSUFBSSxNQUFNLEtBQUssTUFBTSxLQUFLLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsaUJBQWlCLEtBQUssQ0FBQyxHQUFHLFNBQVMsVUFBVTtHQUNySCxJQUFJLFVBQVUsS0FBSyxHQUFHO0lBQ3JCLFdBQVcsT0FBTyxTQUFTLE1BQU0sTUFBTTtJQUN2QyxJQUFJLFNBQVMsTUFBTSxVQUFVLE1BQU07R0FDcEM7RUFDRCxDQUFDO0NBQ0Y7Q0FDQSxPQUFPO0FBQ1I7Ozs7Ozs7OztBQVNBLFNBQVMsZUFBZSxPQUFPO0NBQzlCLE1BQU0sa0JBQWtCLENBQUM7Q0FDekIsS0FBSyxNQUFNLE9BQU8sT0FBTztFQUN4QixNQUFNLFFBQVEsTUFBTTtFQUNwQixJQUFJLFVBQVUsS0FBSyxHQUFHLGdCQUFnQixPQUFPLFFBQVEsS0FBSyxJQUFJLE1BQU0sS0FBSyxNQUFNLEtBQUssT0FBTyxPQUFPLEtBQUssQ0FBQyxJQUFJLFNBQVMsT0FBTyxRQUFRLEtBQUs7Q0FDMUk7Q0FDQSxPQUFPO0FBQ1I7Ozs7QUFNQSxTQUFTLGVBQWU7Q0FDdkIsSUFBSSxXQUFXLENBQUM7Q0FDaEIsU0FBUyxJQUFJLFNBQVM7RUFDckIsU0FBUyxLQUFLLE9BQU87RUFDckIsYUFBYTtHQUNaLE1BQU0sSUFBSSxTQUFTLFFBQVEsT0FBTztHQUNsQyxJQUFJLElBQUksSUFBSSxTQUFTLE9BQU8sR0FBRyxDQUFDO0VBQ2pDO0NBQ0Q7Q0FDQSxTQUFTLFFBQVE7RUFDaEIsV0FBVyxDQUFDO0NBQ2I7Q0FDQSxPQUFPO0VBQ047RUFDQSxZQUFZLFNBQVMsTUFBTTtFQUMzQjtDQUNEO0FBQ0Q7QUFHQSxTQUFTLGNBQWMsaUJBQWlCLE1BQU0sT0FBTztDQUNwRCxNQUFNLFNBQVMsZ0JBQWdCO0NBQy9CLElBQUksQ0FBQyxRQUFRO0VBQytCO0dBQzFDLE1BQU0sU0FBUyxTQUFTLGlCQUFpQix3QkFBd0I7R0FDakUsWUFBWSxpQkFBaUIsRUFBRSxJQUFJLE9BQU8sQ0FBQztFQUM1QztFQUNBO0NBQ0Q7Q0FDQSxJQUFJLGdCQUFnQjtDQUNwQixNQUFNLHVCQUF1QjtFQUM1QixjQUFjLEtBQUssQ0FBQyxPQUFPLEtBQUs7Q0FDakM7Q0FDQSxZQUFZLGNBQWM7Q0FDMUIsY0FBYyxjQUFjO0NBQzVCLGtCQUFrQjtFQUNqQixNQUFNLFlBQVksZ0JBQWdCO0VBQ2xDLElBQTZDLENBQUMsV0FBVyxZQUFZLGlCQUFpQjtFQUN0RixJQUFJLFdBQVcsZ0JBQWdCO0VBQy9CLGNBQWMsS0FBSyxDQUFDLElBQUksS0FBSztDQUM5QixDQUFDO0NBQ0QsY0FBYyxLQUFLLENBQUMsSUFBSSxLQUFLO0FBQzlCOzs7Ozs7OztBQVFBLFNBQVMsbUJBQW1CLFlBQVk7Q0FDdkMsSUFBNkMsQ0FBQyxtQkFBbUIsR0FBRztFQUNuRSxZQUFZLGlCQUFpQixFQUFFLElBQUkscUJBQXFCLENBQUM7RUFDekQ7Q0FDRDtDQUNBLGNBQWMsT0FBTyxpQkFBaUIsQ0FBQyxDQUFDLEdBQUcsZUFBZSxVQUFVO0FBQ3JFOzs7Ozs7OztBQVFBLFNBQVMsb0JBQW9CLGFBQWE7Q0FDekMsSUFBNkMsQ0FBQyxtQkFBbUIsR0FBRztFQUNuRSxZQUFZLGlCQUFpQixFQUFFLElBQUksc0JBQXNCLENBQUM7RUFDMUQ7Q0FDRDtDQUNBLGNBQWMsT0FBTyxpQkFBaUIsQ0FBQyxDQUFDLEdBQUcsZ0JBQWdCLFdBQVc7QUFDdkU7QUFDQSxTQUFTLGlCQUFpQixPQUFPLElBQUksTUFBTSxRQUFRLE1BQU0sa0JBQWtCLE9BQU8sR0FBRyxHQUFHO0NBQ3ZGLE1BQU0scUJBQXFCLFdBQVcsT0FBTyxlQUFlLFFBQVEsT0FBTyxlQUFlLFNBQVMsQ0FBQztDQUNwRyxhQUFhLElBQUksU0FBUyxTQUFTLFdBQVc7RUFDN0MsTUFBTSxRQUFRLFVBQVU7R0FDdkIsSUFBSSxVQUFVLE9BQU8sT0FBTyxrQkFBa0IsR0FBRztJQUNoRDtJQUNBO0dBQ0QsQ0FBQyxDQUFDO1FBQ0csSUFBSSxpQkFBaUIsT0FBTyxPQUFPLEtBQUs7UUFDeEMsSUFBSSxnQkFBZ0IsS0FBSyxHQUFHLE9BQU8sa0JBQWtCLEdBQUc7SUFDNUQsTUFBTTtJQUNOLElBQUk7R0FDTCxDQUFDLENBQUM7UUFDRztJQUNKLElBQUksc0JBQXNCLE9BQU8sZUFBZSxVQUFVLHNCQUFzQixPQUFPLFVBQVUsWUFBWSxtQkFBbUIsS0FBSyxLQUFLO0lBQzFJLFFBQVE7R0FDVDtFQUNEO0VBQ0EsTUFBTSxjQUFjLHFCQUFxQixNQUFNLEtBQUssVUFBVSxPQUFPLFVBQVUsT0FBTyxJQUFJLE1BQThDLHVCQUF1QixvQkFBb0IsTUFBTSxJQUFJLElBQUksQ0FBQyxDQUFRLENBQUM7RUFDM00sSUFBSSxZQUFZLFFBQVEsUUFBUSxXQUFXO0VBQzNDLElBQUksTUFBTSxTQUFTLEdBQUcsWUFBWSxVQUFVLEtBQUssSUFBSTtFQUNyRCxJQUE2QyxNQUFNLFNBQVMsR0FBRztHQUM5RCxNQUFNLFlBQVk7SUFDakIsTUFBTSxNQUFNO0lBQ1osT0FBTyxNQUFNLFNBQVM7R0FDdkI7R0FDQSxJQUFJLE9BQU8sZ0JBQWdCLFlBQVksVUFBVSxhQUFhLFlBQVksVUFBVSxNQUFNLGtCQUFrQjtJQUMzRyxJQUFJLENBQUMsS0FBSyxTQUFTO0tBQ2xCLFlBQVksaUJBQWlCLFNBQVM7S0FDdEMsT0FBTyxRQUFRLHVCQUF1QixJQUFJLE1BQU0sMEJBQTBCLENBQUM7SUFDNUU7SUFDQSxPQUFPO0dBQ1IsQ0FBQztRQUNJLElBQUksZ0JBQWdCLEtBQUssR0FDekI7UUFBQSxDQUFDLEtBQUssU0FBUztLQUNsQixZQUFZLGlCQUFpQixTQUFTO0tBQ3RDLHVCQUF1QixJQUFJLE1BQU0sMEJBQTBCLENBQUM7S0FDNUQ7SUFDRDs7RUFFRjtFQUNBLFVBQVUsT0FBTyxRQUFRLE9BQU8sR0FBRyxDQUFDO0NBQ3JDLENBQUM7QUFDRjs7Ozs7Ozs7QUFRQSxTQUFTLHVCQUF1QixNQUFNO0NBQ3JDLElBQUksU0FBUztDQUNiLE9BQU8sV0FBVztFQUNqQixJQUFJLENBQUMsUUFBUTtHQUNaLFNBQVM7R0FDVCxZQUFZLGlCQUFpQjtFQUM5QjtFQUNBLE9BQU8sS0FBSyxNQUFNLE1BQU0sU0FBUztDQUNsQztBQUNEO0FBQ0EsU0FBUyxvQkFBb0IsTUFBTSxJQUFJLE1BQU07Q0FDNUMsSUFBSSxTQUFTO0NBQ2IsT0FBTyxXQUFXO0VBQ2pCLElBQUksYUFBYSxHQUFHLFlBQVksaUJBQWlCO0dBQ2hELE1BQU0sS0FBSztHQUNYLElBQUksR0FBRztFQUNSLENBQUM7RUFDRCxLQUFLLFVBQVU7RUFDZixJQUFJLFdBQVcsR0FBRyxLQUFLLE1BQU0sTUFBTSxTQUFTO0NBQzdDO0FBQ0Q7QUFDQSxTQUFTLHdCQUF3QixTQUFTLFdBQVcsSUFBSSxNQUFNLGtCQUFrQixPQUFPLEdBQUcsR0FBRztDQUM3RixNQUFNLFNBQVMsQ0FBQztDQUNoQixLQUFLLE1BQU0sVUFBVSxTQUFTO0VBQzdCLElBQTZDLENBQUMsT0FBTyxjQUFjLE9BQU8sWUFBWSxDQUFDLE9BQU8sU0FBUyxRQUFRLFlBQVksaUJBQWlCLEVBQUUsTUFBTSxPQUFPLEtBQUssQ0FBQztFQUNqSyxLQUFLLE1BQU0sUUFBUSxPQUFPLFlBQVk7R0FDckMsSUFBSSxlQUFlLE9BQU8sV0FBVztHQUVwQyxJQUFJLENBQUMsZ0JBQWdCLE9BQU8saUJBQWlCLFlBQVksT0FBTyxpQkFBaUIsWUFBWTtJQUM1RixZQUFZLGlCQUFpQjtLQUM1QjtLQUNBLE1BQU0sT0FBTztLQUNiLFVBQVUsT0FBTyxZQUFZO0lBQzlCLENBQUM7SUFDRCxNQUFNLElBQUksTUFBTSx5QkFBeUI7R0FDMUMsT0FBTyxJQUFJLFVBQVUsY0FBYztJQUNsQyxZQUFZLGlCQUFpQjtLQUM1QjtLQUNBLE1BQU0sT0FBTztJQUNkLENBQUM7SUFDRCxNQUFNLFVBQVU7SUFDaEIscUJBQXFCO0dBQ3RCLE9BQU8sSUFBSSxhQUFhLGlCQUFpQixDQUFDLGFBQWEscUJBQXFCO0lBQzNFLGFBQWEsc0JBQXNCO0lBQ25DLFlBQVksaUJBQWlCO0tBQzVCO0tBQ0EsTUFBTSxPQUFPO0lBQ2QsQ0FBQztHQUNGO0dBRUQsSUFBSSxjQUFjLHNCQUFzQixDQUFDLE9BQU8sVUFBVSxPQUFPO0dBQ2pFLElBQUksaUJBQWlCLFlBQVksR0FBRztJQUNuQyxNQUFNLFNBQVMsYUFBYSxhQUFhLGNBQWM7SUFDdkQsU0FBUyxPQUFPLEtBQUssaUJBQWlCLE9BQU8sSUFBSSxNQUFNLFFBQVEsTUFBTSxjQUFjLENBQUM7R0FDckYsT0FBTztJQUNOLElBQUksbUJBQW1CLGFBQWE7SUFDcEMsSUFBNkMsRUFBRSxXQUFXLG1CQUFtQjtLQUM1RSxZQUFZLGlCQUFpQjtNQUM1QjtNQUNBLE1BQU0sT0FBTztLQUNkLENBQUM7S0FDRCxtQkFBbUIsUUFBUSxRQUFRLGdCQUFnQjtJQUNwRDtJQUNBLE9BQU8sV0FBVyxpQkFBaUIsTUFBTSxhQUFhO0tBQ3JELElBQUksQ0FBQyxVQUFVLE1BQU0sSUFBSSxNQUFNLCtCQUErQixLQUFLLFFBQVEsT0FBTyxLQUFLLEVBQUU7S0FDekYsTUFBTSxvQkFBb0IsV0FBVyxRQUFRLElBQUksU0FBUyxVQUFVO0tBQ3BFLE9BQU8sS0FBSyxRQUFRO0tBQ3BCLE9BQU8sV0FBVyxRQUFRO0tBQzFCLE1BQU0sU0FBUyxrQkFBa0IsYUFBYSxtQkFBbUI7S0FDakUsT0FBTyxTQUFTLGlCQUFpQixPQUFPLElBQUksTUFBTSxRQUFRLE1BQU0sY0FBYyxDQUFDLENBQUM7SUFDakYsQ0FBQyxDQUFDO0dBQ0g7RUFDRDtDQUNEO0NBQ0EsT0FBTztBQUNSOzs7Ozs7QUFNQSxTQUFTLGtCQUFrQixPQUFPO0NBQ2pDLE9BQU8sTUFBTSxRQUFRLE9BQU8sV0FBVyxPQUFPLFFBQVEsSUFBSSxRQUFRLHVCQUF1QixJQUFJLE1BQU0scUNBQXFDLENBQUMsSUFBSSxRQUFRLElBQUksTUFBTSxRQUFRLEtBQUssV0FBVyxPQUFPLGNBQWMsUUFBUSxJQUFJLE9BQU8sS0FBSyxPQUFPLFVBQVUsQ0FBQyxDQUFDLFFBQVEsVUFBVSxTQUFTO0VBQ2pSLE1BQU0sZUFBZSxPQUFPLFdBQVc7RUFDdkMsSUFBSSxPQUFPLGlCQUFpQixjQUFjLEVBQUUsaUJBQWlCLGVBQWUsU0FBUyxLQUFLLGFBQWEsQ0FBQyxDQUFDLE1BQU0sYUFBYTtHQUMzSCxJQUFJLENBQUMsVUFBVSxPQUFPLFFBQVEsdUJBQXVCLElBQUksTUFBTSwrQkFBK0IsS0FBSyxRQUFRLE9BQU8sS0FBSyx3REFBd0QsQ0FBQztHQUNoTCxNQUFNLG9CQUFvQixXQUFXLFFBQVEsSUFBSSxTQUFTLFVBQVU7R0FDcEUsT0FBTyxLQUFLLFFBQVE7R0FDcEIsT0FBTyxXQUFXLFFBQVE7RUFDM0IsQ0FBQyxDQUFDO0VBQ0YsT0FBTztDQUNSLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLEtBQUs7QUFDM0I7Ozs7Ozs7O0FBUUEsU0FBUyx1QkFBdUIsSUFBSSxNQUFNO0NBQ3pDLE1BQU0saUJBQWlCLENBQUM7Q0FDeEIsTUFBTSxrQkFBa0IsQ0FBQztDQUN6QixNQUFNLGtCQUFrQixDQUFDO0NBQ3pCLE1BQU0sTUFBTSxLQUFLLElBQUksS0FBSyxRQUFRLFFBQVEsR0FBRyxRQUFRLE1BQU07Q0FDM0QsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssS0FBSztFQUM3QixNQUFNLGFBQWEsS0FBSyxRQUFRO0VBQ2hDLElBQUksWUFBWTtHQUNmLElBQUksR0FBRyxRQUFRLE1BQU0sV0FBVyxrQkFBa0IsUUFBUSxVQUFVLENBQUMsR0FBRyxnQkFBZ0IsS0FBSyxVQUFVO1FBQ2xHLGVBQWUsS0FBSyxVQUFVO0VBQ3BDO0VBQ0EsTUFBTSxXQUFXLEdBQUcsUUFBUTtFQUM1QixJQUFJLFVBQ0M7T0FBQSxDQUFDLEtBQUssUUFBUSxNQUFNLFdBQVcsa0JBQWtCLFFBQVEsUUFBUSxDQUFDLEdBQUcsZ0JBQWdCLEtBQUssUUFBUTtFQUFBO0NBRXhHO0NBQ0EsT0FBTztFQUNOO0VBQ0E7RUFDQTtDQUNEO0FBQ0Q7Ozs7Ozs7O0FBVUEsU0FBUyxvQkFBb0IsZUFBZSxTQUFTO0NBQ3BELE1BQU0sT0FBTyxPQUFPLENBQUMsR0FBRyxlQUFlLEVBQUUsU0FBUyxjQUFjLFFBQVEsS0FBSyxZQUFZLEtBQUssU0FBUztFQUN0RztFQUNBO0VBQ0E7Q0FDRCxDQUFDLENBQUMsRUFBRSxDQUFDO0NBQ0wsT0FBTyxFQUFFLFNBQVM7RUFDakIsTUFBTTtFQUNOLFVBQVU7RUFDVixTQUFTLGNBQWM7RUFDdkI7RUFDQSxPQUFPO0NBQ1IsRUFBRTtBQUNIO0FBQ0EsU0FBUyxjQUFjLFNBQVM7Q0FDL0IsT0FBTyxFQUFFLFNBQVMsRUFBRSxRQUFRLEVBQUU7QUFDL0I7QUFDQSxJQUFJLFdBQVc7QUFDZixTQUFTLFlBQVksS0FBSyxRQUFRLFNBQVM7Q0FDMUMsSUFBSSxPQUFPLGVBQWU7Q0FDMUIsT0FBTyxnQkFBZ0I7Q0FDdkIsTUFBTSxLQUFLO0NBQ1gsb0JBQW9CO0VBQ25CLElBQUksc0JBQXNCLEtBQUssTUFBTSxLQUFLO0VBQzFDLE9BQU87RUFDUCxhQUFhO0VBQ2IsVUFBVTtFQUNWLE1BQU07RUFDTixxQkFBcUIsQ0FBQyxTQUFTO0VBQy9CO0NBQ0QsSUFBSSxRQUFRO0VBQ1gsSUFBSSxHQUFHLGtCQUFrQixZQUFZO0dBQ3BDLElBQUksUUFBUSxjQUFjLFFBQVEsYUFBYSxNQUFNLEtBQUs7SUFDekQsTUFBTTtJQUNOLEtBQUs7SUFDTCxVQUFVO0lBQ1YsT0FBTyxvQkFBb0IsT0FBTyxhQUFhLE9BQU8sZUFBZTtHQUN0RSxDQUFDO0VBQ0YsQ0FBQztFQUNELElBQUksR0FBRyxvQkFBb0IsRUFBRSxVQUFVLE1BQU0sd0JBQXdCO0dBQ3BFLElBQUksa0JBQWtCLGdCQUFnQjtJQUNyQyxNQUFNLE9BQU8sa0JBQWtCO0lBQy9CLEtBQUssS0FBSyxLQUFLO0tBQ2QsUUFBUSxLQUFLLE9BQU8sR0FBRyxLQUFLLEtBQUssU0FBUyxFQUFFLE1BQU0sTUFBTSxLQUFLO0tBQzdELFdBQVc7S0FDWCxTQUFTO0tBQ1QsaUJBQWlCO0lBQ2xCLENBQUM7R0FDRjtHQUNBLElBQUksUUFBUSxrQkFBa0IsY0FBYyxHQUFHO0lBQzlDLGtCQUFrQixnQkFBZ0I7SUFDbEMsa0JBQWtCLGVBQWUsU0FBUyxpQkFBaUI7S0FDMUQsSUFBSSxRQUFRLGFBQWEsTUFBTTtLQUMvQixJQUFJLGtCQUFrQjtLQUN0QixJQUFJLFVBQVU7S0FDZCxJQUFJLFlBQVk7S0FDaEIsSUFBSSxhQUFhLE9BQU87TUFDdkIsUUFBUSxhQUFhO01BQ3JCLGtCQUFrQjtNQUNsQixZQUFZO0tBQ2IsT0FBTyxJQUFJLGFBQWEsZUFBZTtNQUN0QyxrQkFBa0I7TUFDbEIsVUFBVTtLQUNYLE9BQU8sSUFBSSxhQUFhLFVBQVU7TUFDakMsa0JBQWtCO01BQ2xCLFVBQVU7S0FDWDtLQUNBLEtBQUssS0FBSyxLQUFLO01BQ2Q7TUFDQTtNQUNBO01BQ0E7S0FDRCxDQUFDO0lBQ0YsQ0FBQztHQUNGO0VBQ0QsQ0FBQztFQUNELE1BQU0sT0FBTyxvQkFBb0I7R0FDaEMsa0JBQWtCO0dBQ2xCLElBQUksc0JBQXNCO0dBQzFCLElBQUksa0JBQWtCLGlCQUFpQjtHQUN2QyxJQUFJLG1CQUFtQixpQkFBaUI7RUFDekMsQ0FBQztFQUNELE1BQU0scUJBQXFCLHdCQUF3QjtFQUNuRCxJQUFJLGlCQUFpQjtHQUNwQixJQUFJO0dBQ0osT0FBTyxTQUFTLEtBQUssTUFBTSxLQUFLLEdBQUc7R0FDbkMsT0FBTztFQUNSLENBQUM7RUFDRCxPQUFPLFNBQVMsT0FBTyxPQUFPO0dBQzdCLElBQUksaUJBQWlCO0lBQ3BCLFNBQVM7SUFDVCxPQUFPO0tBQ04sT0FBTztLQUNQLFVBQVUsR0FBRztLQUNiLFNBQVM7S0FDVCxNQUFNLElBQUksSUFBSTtLQUNkLE1BQU0sRUFBRSxNQUFNO0tBQ2QsU0FBUyxHQUFHLEtBQUs7SUFDbEI7R0FDRCxDQUFDO0VBQ0YsQ0FBQztFQUNELElBQUksZUFBZTtFQUNuQixPQUFPLFlBQVksSUFBSSxTQUFTO0dBQy9CLE1BQU0sT0FBTztJQUNaLE9BQU8sY0FBYyxZQUFZO0lBQ2pDLE1BQU0sb0JBQW9CLE1BQU0seUNBQXlDO0lBQ3pFLElBQUksb0JBQW9CLElBQUksaUJBQWlCO0dBQzlDO0dBQ0EsT0FBTyxlQUFlLEdBQUcsTUFBTSxrQkFBa0IsRUFBRSxPQUFPLGVBQWUsQ0FBQztHQUMxRSxJQUFJLGlCQUFpQjtJQUNwQixTQUFTO0lBQ1QsT0FBTztLQUNOLE1BQU0sSUFBSSxJQUFJO0tBQ2QsT0FBTztLQUNQLFVBQVUsR0FBRztLQUNiO0tBQ0EsU0FBUyxHQUFHLEtBQUs7SUFDbEI7R0FDRCxDQUFDO0VBQ0YsQ0FBQztFQUNELE9BQU8sV0FBVyxJQUFJLE1BQU0sWUFBWTtHQUN2QyxNQUFNLE9BQU8sRUFBRSxPQUFPLGNBQWMsV0FBVyxFQUFFO0dBQ2pELElBQUksU0FBUztJQUNaLEtBQUssVUFBVSxFQUFFLFNBQVM7S0FDekIsTUFBTTtLQUNOLFVBQVU7S0FDVixTQUFTLFVBQVUsUUFBUSxVQUFVO0tBQ3JDLFNBQVM7S0FDVCxPQUFPO0lBQ1IsRUFBRTtJQUNGLEtBQUssU0FBUyxjQUFjLEdBQUc7R0FDaEMsT0FBTyxLQUFLLFNBQVMsY0FBYyxHQUFHO0dBQ3RDLEtBQUssT0FBTyxvQkFBb0IsTUFBTSx5Q0FBeUM7R0FDL0UsS0FBSyxLQUFLLG9CQUFvQixJQUFJLGlCQUFpQjtHQUNuRCxJQUFJLGlCQUFpQjtJQUNwQixTQUFTO0lBQ1QsT0FBTztLQUNOLE9BQU87S0FDUCxVQUFVLEdBQUc7S0FDYixNQUFNLElBQUksSUFBSTtLQUNkO0tBQ0EsU0FBUyxVQUFVLFlBQVk7S0FDL0IsU0FBUyxHQUFHLEtBQUs7SUFDbEI7R0FDRCxDQUFDO0VBQ0YsQ0FBQzs7OztFQUlELE1BQU0sb0JBQW9CLHNCQUFzQjtFQUNoRCxJQUFJLGFBQWE7R0FDaEIsSUFBSTtHQUNKLE9BQU8sWUFBWSxLQUFLLE1BQU0sS0FBSztHQUNuQyxNQUFNO0dBQ04sdUJBQXVCO0VBQ3hCLENBQUM7RUFDRCxTQUFTLG9CQUFvQjtHQUM1QixJQUFJLENBQUMscUJBQXFCO0dBQzFCLE1BQU0sVUFBVTtHQUNoQixJQUFJLFNBQVMsUUFBUSxVQUFVLENBQUMsQ0FBQyxRQUFRLFVBQVUsQ0FBQyxNQUFNLFVBQVUsQ0FBQyxNQUFNLE9BQU8sT0FBTyxVQUFVO0dBQ25HLE9BQU8sUUFBUSw0QkFBNEI7R0FDM0MsSUFBSSxRQUFRLFFBQVEsU0FBUyxPQUFPLFFBQVEsVUFBVSxnQkFBZ0IsT0FBTyxRQUFRLE9BQU8sWUFBWSxDQUFDLENBQUM7R0FDMUcsT0FBTyxTQUFTLFVBQVUsc0JBQXNCLE9BQU8sT0FBTyxhQUFhLEtBQUssQ0FBQztHQUNqRixRQUFRLFlBQVksT0FBTyxJQUFJLDZCQUE2QjtFQUM3RDtFQUNBLElBQUk7RUFDSixJQUFJLEdBQUcsa0JBQWtCLFlBQVk7R0FDcEMsc0JBQXNCO0dBQ3RCLElBQUksUUFBUSxRQUFRLE9BQU8sUUFBUSxnQkFBZ0IsbUJBQW1CLGtCQUFrQjtFQUN6RixDQUFDOzs7O0VBSUQsSUFBSSxHQUFHLG1CQUFtQixZQUFZO0dBQ3JDLElBQUksUUFBUSxRQUFRLE9BQU8sUUFBUSxnQkFBZ0IsbUJBQW1CO0lBQ3JFLE1BQU0sUUFBUSxRQUFRLFVBQVUsQ0FBQyxDQUFDLE1BQU0sVUFBVSxNQUFNLE9BQU8sWUFBWSxRQUFRLE1BQU07SUFDekYsSUFBSSxPQUFPLFFBQVEsUUFBUSxFQUFFLFNBQVMsMENBQTBDLEtBQUssRUFBRTtHQUN4RjtFQUNELENBQUM7RUFDRCxJQUFJLGtCQUFrQixpQkFBaUI7RUFDdkMsSUFBSSxtQkFBbUIsaUJBQWlCO0NBQ3pDLENBQUM7QUFDRjtBQUNBLFNBQVMsZUFBZSxLQUFLO0NBQzVCLElBQUksSUFBSSxVQUFVLE9BQU8sSUFBSSxhQUFhLE1BQU07TUFDM0MsT0FBTyxJQUFJLGFBQWEsTUFBTTtBQUNwQztBQUNBLFNBQVMsMENBQTBDLE9BQU87Q0FDekQsTUFBTSxFQUFFLFdBQVc7Q0FDbkIsTUFBTSxTQUFTLENBQUM7RUFDZixVQUFVO0VBQ1YsS0FBSztFQUNMLE9BQU8sT0FBTztDQUNmLENBQUM7Q0FDRCxJQUFJLE9BQU8sUUFBUSxNQUFNLE9BQU8sS0FBSztFQUNwQyxVQUFVO0VBQ1YsS0FBSztFQUNMLE9BQU8sT0FBTztDQUNmLENBQUM7Q0FDRCxPQUFPLEtBQUs7RUFDWCxVQUFVO0VBQ1YsS0FBSztFQUNMLE9BQU8sTUFBTTtDQUNkLENBQUM7Q0FDRCxJQUFJLE1BQU0sS0FBSyxRQUFRLE9BQU8sS0FBSztFQUNsQyxVQUFVO0VBQ1YsS0FBSztFQUNMLE9BQU8sRUFBRSxTQUFTO0dBQ2pCLE1BQU07R0FDTixVQUFVO0dBQ1YsU0FBUyxNQUFNLEtBQUssS0FBSyxRQUFRLEdBQUcsSUFBSSxPQUFPLGVBQWUsR0FBRyxHQUFHLENBQUMsQ0FBQyxLQUFLLEdBQUc7R0FDOUUsU0FBUztHQUNULE9BQU8sTUFBTTtFQUNkLEVBQUU7Q0FDSCxDQUFDO0NBQ0QsSUFBSSxPQUFPLFlBQVksTUFBTSxPQUFPLEtBQUs7RUFDeEMsVUFBVTtFQUNWLEtBQUs7RUFDTCxPQUFPLE9BQU87Q0FDZixDQUFDO0NBQ0QsSUFBSSxNQUFNLE1BQU0sUUFBUSxPQUFPLEtBQUs7RUFDbkMsVUFBVTtFQUNWLEtBQUs7RUFDTCxPQUFPLE1BQU0sTUFBTSxLQUFLLFVBQVUsTUFBTSxPQUFPLElBQUk7Q0FDcEQsQ0FBQztDQUNELElBQUksT0FBTyxLQUFLLE1BQU0sT0FBTyxJQUFJLENBQUMsQ0FBQyxRQUFRLE9BQU8sS0FBSztFQUN0RCxVQUFVO0VBQ1YsS0FBSztFQUNMLE9BQU8sTUFBTSxPQUFPO0NBQ3JCLENBQUM7Q0FDRCxPQUFPLEtBQUs7RUFDWCxLQUFLO0VBQ0wsVUFBVTtFQUNWLE9BQU8sRUFBRSxTQUFTO0dBQ2pCLE1BQU07R0FDTixVQUFVO0dBQ1YsU0FBUyxNQUFNLE1BQU0sS0FBSyxVQUFVLE1BQU0sS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSztHQUNoRSxTQUFTO0dBQ1QsT0FBTyxNQUFNO0VBQ2QsRUFBRTtDQUNILENBQUM7Q0FDRCxPQUFPO0FBQ1I7Ozs7QUFJQSxJQUFNLFdBQVc7QUFDakIsSUFBTSxXQUFXO0FBQ2pCLElBQU0sV0FBVztBQUNqQixJQUFNLFdBQVc7QUFDakIsSUFBTSxhQUFhO0FBQ25CLElBQU0sT0FBTztBQUNiLElBQU0sVUFBVTtBQUNoQixJQUFNLFVBQVU7QUFDaEIsU0FBUyw4QkFBOEIsT0FBTztDQUM3QyxNQUFNLE9BQU8sQ0FBQztDQUNkLE1BQU0sRUFBRSxXQUFXO0NBQ25CLElBQUksT0FBTyxRQUFRLE1BQU0sS0FBSyxLQUFLO0VBQ2xDLE9BQU8sT0FBTyxPQUFPLElBQUk7RUFDekIsV0FBVztFQUNYLGlCQUFpQjtDQUNsQixDQUFDO0NBQ0QsSUFBSSxPQUFPLFNBQVMsS0FBSyxLQUFLO0VBQzdCLE9BQU87RUFDUCxXQUFXO0VBQ1gsaUJBQWlCO0NBQ2xCLENBQUM7Q0FDRCxJQUFJLE1BQU0sWUFBWSxLQUFLLEtBQUs7RUFDL0IsT0FBTztFQUNQLFdBQVc7RUFDWCxpQkFBaUI7Q0FDbEIsQ0FBQztDQUNELElBQUksTUFBTSxrQkFBa0IsS0FBSyxLQUFLO0VBQ3JDLE9BQU87RUFDUCxXQUFXO0VBQ1gsaUJBQWlCO0NBQ2xCLENBQUM7Q0FDRCxJQUFJLE1BQU0sYUFBYSxLQUFLLEtBQUs7RUFDaEMsT0FBTztFQUNQLFdBQVc7RUFDWCxpQkFBaUI7Q0FDbEIsQ0FBQztDQUNELElBQUksT0FBTyxVQUFVLEtBQUssS0FBSztFQUM5QixPQUFPLE9BQU8sT0FBTyxhQUFhLFdBQVcsYUFBYSxPQUFPLGFBQWE7RUFDOUUsV0FBVztFQUNYLGlCQUFpQjtDQUNsQixDQUFDO0NBQ0QsSUFBSSxLQUFLLE9BQU87Q0FDaEIsSUFBSSxNQUFNLE1BQU07RUFDZixLQUFLLE9BQU8sZUFBZTtFQUMzQixPQUFPLFVBQVU7Q0FDbEI7Q0FDQSxPQUFPO0VBQ047RUFDQSxPQUFPLE9BQU87RUFDZDtFQUNBLFVBQVUsTUFBTSxTQUFTLElBQUksNkJBQTZCO0NBQzNEO0FBQ0Q7QUFDQSxJQUFJLGdCQUFnQjtBQUNwQixJQUFNLG9CQUFvQjtBQUMxQixTQUFTLHNCQUFzQixPQUFPLGNBQWM7Q0FDbkQsTUFBTSxnQkFBZ0IsYUFBYSxRQUFRLFVBQVUsa0JBQWtCLGFBQWEsUUFBUSxhQUFhLFFBQVEsU0FBUyxJQUFJLE1BQU0sTUFBTTtDQUMxSSxNQUFNLG1CQUFtQixNQUFNLGNBQWM7Q0FDN0MsSUFBSSxDQUFDLGVBQWUsTUFBTSxjQUFjLGFBQWEsUUFBUSxNQUFNLFVBQVUsa0JBQWtCLE9BQU8sTUFBTSxNQUFNLENBQUM7Q0FDbkgsTUFBTSxTQUFTLFNBQVMsZUFBZSxzQkFBc0IsWUFBWSxZQUFZLENBQUM7QUFDdkY7QUFDQSxTQUFTLDZCQUE2QixPQUFPO0NBQzVDLE1BQU0sYUFBYTtDQUNuQixNQUFNLFNBQVMsUUFBUSw0QkFBNEI7QUFDcEQ7QUFDQSxTQUFTLGdCQUFnQixPQUFPLFFBQVE7Q0FDdkMsTUFBTSxRQUFRLE9BQU8sTUFBTSxFQUFFLENBQUMsQ0FBQyxNQUFNLGlCQUFpQjtDQUN0RCxNQUFNLGFBQWE7Q0FDbkIsSUFBSSxDQUFDLFNBQVMsTUFBTSxTQUFTLEdBQUcsT0FBTztDQUN2QyxJQUFJLElBQUksT0FBTyxNQUFNLEVBQUUsQ0FBQyxRQUFRLE9BQU8sRUFBRSxHQUFHLE1BQU0sRUFBRSxDQUFDLENBQUMsS0FBSyxNQUFNLEdBQUc7RUFDbkUsTUFBTSxTQUFTLFNBQVMsVUFBVSxnQkFBZ0IsT0FBTyxNQUFNLENBQUM7RUFDaEUsSUFBSSxNQUFNLE9BQU8sU0FBUyxPQUFPLFdBQVcsS0FBSztHQUNoRCxNQUFNLGFBQWEsTUFBTSxHQUFHLEtBQUssTUFBTTtHQUN2QyxPQUFPO0VBQ1I7RUFDQSxPQUFPO0NBQ1I7Q0FDQSxNQUFNLE9BQU8sTUFBTSxPQUFPLEtBQUssWUFBWTtDQUMzQyxNQUFNLGNBQWMsT0FBTyxJQUFJO0NBQy9CLElBQUksQ0FBQyxlQUFlLE1BQU0sTUFBTSxZQUFZLFNBQVMsTUFBTSxLQUFLLEtBQUssU0FBUyxNQUFNLElBQUksT0FBTztDQUMvRixJQUFJLFlBQVksV0FBVyxNQUFNLEtBQUssS0FBSyxXQUFXLE1BQU0sR0FBRyxPQUFPO0NBQ3RFLElBQUksTUFBTSxPQUFPLFFBQVEsT0FBTyxNQUFNLE9BQU8sSUFBSSxDQUFDLENBQUMsU0FBUyxNQUFNLEdBQUcsT0FBTztDQUM1RSxPQUFPLE1BQU0sU0FBUyxNQUFNLFVBQVUsZ0JBQWdCLE9BQU8sTUFBTSxDQUFDO0FBQ3JFO0FBQ0EsU0FBUyxLQUFLLEtBQUssTUFBTTtDQUN4QixNQUFNLE1BQU0sQ0FBQztDQUNiLEtBQUssTUFBTSxPQUFPLEtBQUssSUFBSSxDQUFDLEtBQUssU0FBUyxHQUFHLEdBQUcsSUFBSSxPQUFPLElBQUk7Q0FDL0QsT0FBTztBQUNSOzs7Ozs7OztBQ3hoQ0EsSUFBSSwyQkFBMkIsU0FBUyxXQUFXLE9BQU8sU0FBUzs7Ozs7O0FBTW5FLFNBQVMsc0JBQXNCLE1BQU0sVUFBVTtDQUM5QyxNQUFNLEVBQUUsVUFBVSxRQUFRLFNBQVM7Q0FDbkMsTUFBTSxVQUFVLEtBQUssUUFBUSxHQUFHO0NBQ2hDLElBQUksVUFBVSxJQUFJO0VBQ2pCLElBQUksV0FBVyxLQUFLLFNBQVMsS0FBSyxNQUFNLE9BQU8sQ0FBQyxJQUFJLEtBQUssTUFBTSxPQUFPLENBQUMsQ0FBQyxTQUFTO0VBQ2pGLElBQUksZUFBZSxLQUFLLE1BQU0sUUFBUTtFQUN0QyxJQUFJLGFBQWEsT0FBTyxLQUFLLGVBQWUsTUFBTTtFQUNsRCxPQUFPLFVBQVUsY0FBYyxFQUFFO0NBQ2xDO0NBQ0EsT0FBTyxVQUFVLFVBQVUsSUFBSSxJQUFJLFNBQVM7QUFDN0M7QUFDQSxTQUFTLG9CQUFvQixNQUFNLGNBQWMsaUJBQWlCLFNBQVM7Q0FDMUUsSUFBSSxZQUFZLENBQUM7Q0FDakIsSUFBSSxZQUFZLENBQUM7Q0FDakIsSUFBSSxhQUFhO0NBQ2pCLE1BQU0sbUJBQW1CLEVBQUUsWUFBWTtFQUN0QyxNQUFNLEtBQUssc0JBQXNCLE1BQU0sUUFBUTtFQUMvQyxNQUFNLE9BQU8sZ0JBQWdCO0VBQzdCLE1BQU0sWUFBWSxhQUFhO0VBQy9CLElBQUksUUFBUTtFQUNaLElBQUksT0FBTztHQUNWLGdCQUFnQixRQUFRO0dBQ3hCLGFBQWEsUUFBUTtHQUNyQixJQUFJLGNBQWMsZUFBZSxNQUFNO0lBQ3RDLGFBQWE7SUFDYjtHQUNEO0dBQ0EsUUFBUSxZQUFZLE1BQU0sV0FBVyxVQUFVLFdBQVc7RUFDM0QsT0FBTyxRQUFRLEVBQUU7RUFDakIsVUFBVSxTQUFTLGFBQWE7R0FDL0IsU0FBUyxnQkFBZ0IsT0FBTyxNQUFNO0lBQ3JDO0lBQ0EsTUFBTTtJQUNOLFdBQVcsUUFBUSxRQUFRLElBQUksWUFBWSxTQUFTO0dBQ3JELENBQUM7RUFDRixDQUFDO0NBQ0Y7Q0FDQSxTQUFTLGlCQUFpQjtFQUN6QixhQUFhLGdCQUFnQjtDQUM5QjtDQUNBLFNBQVMsT0FBTyxVQUFVO0VBQ3pCLFVBQVUsS0FBSyxRQUFRO0VBQ3ZCLE1BQU0saUJBQWlCO0dBQ3RCLE1BQU0sUUFBUSxVQUFVLFFBQVEsUUFBUTtHQUN4QyxJQUFJLFFBQVEsSUFBSSxVQUFVLE9BQU8sT0FBTyxDQUFDO0VBQzFDO0VBQ0EsVUFBVSxLQUFLLFFBQVE7RUFDdkIsT0FBTztDQUNSO0NBQ0EsU0FBUyx1QkFBdUI7RUFDL0IsTUFBTSxFQUFFLFlBQVk7RUFDcEIsSUFBSSxDQUFDLFFBQVEsT0FBTztFQUNwQixRQUFRLGFBQWEsT0FBTyxDQUFDLEdBQUcsUUFBUSxPQUFPLEVBQUUsUUFBUSxzQkFBc0IsRUFBRSxDQUFDLEdBQUcsRUFBRTtDQUN4RjtDQUNBLFNBQVMsVUFBVTtFQUNsQixLQUFLLE1BQU0sWUFBWSxXQUFXLFNBQVM7RUFDM0MsWUFBWSxDQUFDO0VBQ2IsT0FBTyxvQkFBb0IsWUFBWSxlQUFlO0VBQ3RELE9BQU8sb0JBQW9CLFlBQVksb0JBQW9CO0NBQzVEO0NBQ0EsT0FBTyxpQkFBaUIsWUFBWSxlQUFlO0NBQ25ELE9BQU8saUJBQWlCLFlBQVksb0JBQW9CO0NBQ3hELE9BQU87RUFDTjtFQUNBO0VBQ0E7Q0FDRDtBQUNEOzs7O0FBSUEsU0FBUyxXQUFXLE1BQU0sU0FBUyxTQUFTLFdBQVcsT0FBTztDQUM3RCxPQUFPO0VBQ047RUFDQTtFQUNBO0VBQ0E7RUFDQSxVQUFVLE9BQU8sUUFBUTtFQUN6QixRQUFRO0NBQ1Q7QUFDRDtBQUNBLFNBQVMsMEJBQTBCLE1BQU07Q0FDeEMsTUFBTSxFQUFFLFNBQVMsYUFBYTtDQUM5QixNQUFNLGtCQUFrQixFQUFFLE9BQU8sc0JBQXNCLE1BQU0sUUFBUSxFQUFFO0NBQ3ZFLE1BQU0sZUFBZSxFQUFFLE9BQU8sUUFBUSxNQUFNO0NBQzVDLElBQUksQ0FBQyxhQUFhLE9BQU8sZUFBZSxnQkFBZ0IsT0FBTztFQUM5RCxNQUFNO0VBQ04sU0FBUyxnQkFBZ0I7RUFDekIsU0FBUztFQUNULFVBQVUsUUFBUSxTQUFTO0VBQzNCLFVBQVU7RUFDVixRQUFRO0NBQ1QsR0FBRyxJQUFJO0NBQ1AsU0FBUyxlQUFlLElBQUksT0FBTyxTQUFTOzs7Ozs7Ozs7O0VBVTNDLE1BQU0sWUFBWSxLQUFLLFFBQVEsR0FBRztFQUNsQyxNQUFNLE1BQU0sWUFBWSxNQUFNLFNBQVMsUUFBUSxTQUFTLGNBQWMsTUFBTSxJQUFJLE9BQU8sS0FBSyxNQUFNLFNBQVMsS0FBSyxLQUFLLG1CQUFtQixJQUFJLE9BQU87RUFDbkosSUFBSTtHQUNILFFBQVEsVUFBVSxpQkFBaUIsWUFBWSxDQUFDLE9BQU8sSUFBSSxHQUFHO0dBQzlELGFBQWEsUUFBUTtFQUN0QixTQUFTLEtBQUs7R0FDOEIsWUFBWSxpQkFBaUIsRUFBRSxPQUFPLElBQUksQ0FBQztHQUV0RixTQUFTLFVBQVUsWUFBWSxTQUFTLENBQUMsR0FBRztFQUM3QztDQUNEO0NBQ0EsU0FBUyxRQUFRLElBQUksTUFBTTtFQUMxQixlQUFlLElBQUksT0FBTyxDQUFDLEdBQUcsUUFBUSxPQUFPLFdBQVcsYUFBYSxNQUFNLE1BQU0sSUFBSSxhQUFhLE1BQU0sU0FBUyxJQUFJLEdBQUcsTUFBTSxFQUFFLFVBQVUsYUFBYSxNQUFNLFNBQVMsQ0FBQyxHQUFHLElBQUk7RUFDOUssZ0JBQWdCLFFBQVE7Q0FDekI7Q0FDQSxTQUFTLEtBQUssSUFBSSxNQUFNO0VBQ3ZCLE1BQU0sZUFBZSxPQUFPLENBQUMsR0FBRyxhQUFhLE9BQU8sUUFBUSxPQUFPO0dBQ2xFLFNBQVM7R0FDVCxRQUFRLHNCQUFzQjtFQUMvQixDQUFDO0VBQ0QsSUFBNkMsQ0FBQyxRQUFRLE9BQU8sWUFBWSxpQkFBaUI7RUFDMUYsZUFBZSxhQUFhLFNBQVMsY0FBYyxJQUFJO0VBQ3ZELGVBQWUsSUFBSSxPQUFPLENBQUMsR0FBRyxXQUFXLGdCQUFnQixPQUFPLElBQUksSUFBSSxHQUFHLEVBQUUsVUFBVSxhQUFhLFdBQVcsRUFBRSxHQUFHLElBQUksR0FBRyxLQUFLO0VBQ2hJLGdCQUFnQixRQUFRO0NBQ3pCO0NBQ0EsT0FBTztFQUNOLFVBQVU7RUFDVixPQUFPO0VBQ1A7RUFDQTtDQUNEO0FBQ0Q7Ozs7OztBQU1BLFNBQVMsaUJBQWlCLE1BQU07Q0FDL0IsT0FBTyxjQUFjLElBQUk7Q0FDekIsTUFBTSxvQkFBb0IsMEJBQTBCLElBQUk7Q0FDeEQsTUFBTSxtQkFBbUIsb0JBQW9CLE1BQU0sa0JBQWtCLE9BQU8sa0JBQWtCLFVBQVUsa0JBQWtCLE9BQU87Q0FDakksU0FBUyxHQUFHLE9BQU8sbUJBQW1CLE1BQU07RUFDM0MsSUFBSSxDQUFDLGtCQUFrQixpQkFBaUIsZUFBZTtFQUN2RCxRQUFRLEdBQUcsS0FBSztDQUNqQjtDQUNBLE1BQU0sZ0JBQWdCLE9BQU87RUFDNUIsVUFBVTtFQUNWO0VBQ0E7RUFDQSxZQUFZLFdBQVcsS0FBSyxNQUFNLElBQUk7Q0FDdkMsR0FBRyxtQkFBbUIsZ0JBQWdCO0NBQ3RDLE9BQU8sZUFBZSxlQUFlLFlBQVk7RUFDaEQsWUFBWTtFQUNaLFdBQVcsa0JBQWtCLFNBQVM7Q0FDdkMsQ0FBQztDQUNELE9BQU8sZUFBZSxlQUFlLFNBQVM7RUFDN0MsWUFBWTtFQUNaLFdBQVcsa0JBQWtCLE1BQU07Q0FDcEMsQ0FBQztDQUNELE9BQU87QUFDUjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQTJCQSxTQUFTLHFCQUFxQixNQUFNO0NBQ25DLE9BQU8sU0FBUyxPQUFPLFFBQVEsU0FBUyxXQUFXLFNBQVMsU0FBUztDQUNyRSxJQUFJLENBQUMsS0FBSyxTQUFTLEdBQUcsR0FBRyxRQUFRO0NBQ2pDLElBQTZDLENBQUMsS0FBSyxTQUFTLElBQUksS0FBSyxDQUFDLEtBQUssU0FBUyxHQUFHLEdBQUcsWUFBWSxpQkFBaUI7RUFDdEg7RUFDQSxZQUFZLEtBQUssUUFBUSxRQUFRLEdBQUc7Q0FDckMsQ0FBQztDQUNELE9BQU8saUJBQWlCLElBQUk7QUFDN0I7Ozs7Ozs7O0FBVUEsU0FBUyxvQkFBb0IsT0FBTyxJQUFJO0NBQ3ZDLElBQUksWUFBWSxDQUFDO0NBQ2pCLElBQUksUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztDQUNyQixJQUFJLFdBQVc7Q0FDZixPQUFPLGNBQWMsSUFBSTtDQUN6QixTQUFTLFlBQVksVUFBVSxRQUFRLENBQUMsR0FBRztFQUMxQztFQUNBLElBQUksYUFBYSxNQUFNLFFBQVEsTUFBTSxPQUFPLFFBQVE7RUFDcEQsTUFBTSxLQUFLLENBQUMsVUFBVSxLQUFLLENBQUM7Q0FDN0I7Q0FDQSxTQUFTLGlCQUFpQixJQUFJLE1BQU0sRUFBRSxXQUFXLFNBQVM7RUFDekQsTUFBTSxPQUFPO0dBQ1o7R0FDQTtHQUNBLE1BQU07RUFDUDtFQUNBLEtBQUssTUFBTSxZQUFZLFdBQVcsU0FBUyxJQUFJLE1BQU0sSUFBSTtDQUMxRDtDQUNBLE1BQU0sZ0JBQWdCO0VBQ3JCLFVBQVU7RUFDVixPQUFPLENBQUM7RUFDUjtFQUNBLFlBQVksV0FBVyxLQUFLLE1BQU0sSUFBSTtFQUN0QyxRQUFRLElBQUksT0FBTztHQUNsQixNQUFNLE9BQU8sWUFBWSxDQUFDO0dBQzFCLFlBQVksSUFBSSxLQUFLO0VBQ3RCO0VBQ0EsS0FBSyxJQUFJLE9BQU87R0FDZixZQUFZLElBQUksS0FBSztFQUN0QjtFQUNBLE9BQU8sVUFBVTtHQUNoQixVQUFVLEtBQUssUUFBUTtHQUN2QixhQUFhO0lBQ1osTUFBTSxRQUFRLFVBQVUsUUFBUSxRQUFRO0lBQ3hDLElBQUksUUFBUSxJQUFJLFVBQVUsT0FBTyxPQUFPLENBQUM7R0FDMUM7RUFDRDtFQUNBLFVBQVU7R0FDVCxZQUFZLENBQUM7R0FDYixRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0dBQ2pCLFdBQVc7RUFDWjtFQUNBLEdBQUcsT0FBTyxnQkFBZ0IsTUFBTTtHQUMvQixNQUFNLE9BQU8sS0FBSztHQUNsQixNQUFNLFlBQVksUUFBUSxJQUFJLFNBQVM7R0FDdkMsV0FBVyxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksV0FBVyxPQUFPLE1BQU0sU0FBUyxDQUFDLENBQUM7R0FDbkUsSUFBSSxlQUFlLGlCQUFpQixLQUFLLFVBQVUsTUFBTTtJQUN4RDtJQUNBO0dBQ0QsQ0FBQztFQUNGO0NBQ0Q7Q0FDQSxPQUFPLGVBQWUsZUFBZSxZQUFZO0VBQ2hELFlBQVk7RUFDWixXQUFXLE1BQU0sU0FBUyxDQUFDO0NBQzVCLENBQUM7Q0FDRCxPQUFPLGVBQWUsZUFBZSxTQUFTO0VBQzdDLFlBQVk7RUFDWixXQUFXLE1BQU0sU0FBUyxDQUFDO0NBQzVCLENBQUM7Q0FDRCxPQUFPO0FBQ1I7QUFHQSxJQUFNLGFBQWE7Q0FDbEIsTUFBTTtDQUNOLE9BQU87QUFDUjtBQUNBLElBQU0saUJBQWlCO0FBQ3ZCLFNBQVMsYUFBYSxNQUFNO0NBQzNCLElBQUksQ0FBQyxNQUFNLE9BQU8sQ0FBQyxDQUFDLENBQUM7Q0FDckIsSUFBSSxTQUFTLEtBQUssT0FBTyxDQUFDLENBQUMsVUFBVSxDQUFDO0NBQ3RDLElBQUksQ0FBQyxlQUFlLElBQUksR0FBRyxNQUFNLElBQUksTUFBOEMseUNBQXlDLEtBQUssZ0JBQWdCLEtBQUssR0FBOEI7Q0FDcEwsU0FBUyxNQUFNLFNBQVM7RUFDdkIsTUFBTSxJQUFJLE1BQU0sUUFBUSxNQUFNLEtBQUssT0FBTyxLQUFLLFNBQVM7Q0FDekQ7Q0FDQSxJQUFJLFFBQVE7Q0FDWixJQUFJLGdCQUFnQjtDQUNwQixNQUFNLFNBQVMsQ0FBQztDQUNoQixJQUFJO0NBQ0osU0FBUyxrQkFBa0I7RUFDMUIsSUFBSSxTQUFTLE9BQU8sS0FBSyxPQUFPO0VBQ2hDLFVBQVUsQ0FBQztDQUNaO0NBQ0EsSUFBSSxJQUFJO0NBQ1IsSUFBSTtDQUNKLElBQUksU0FBUztDQUNiLElBQUksV0FBVztDQUNmLFNBQVMsZ0JBQWdCO0VBQ3hCLElBQUksQ0FBQyxRQUFRO0VBQ2IsSUFBSSxVQUFVLEdBQUcsUUFBUSxLQUFLO0dBQzdCLE1BQU07R0FDTixPQUFPO0VBQ1IsQ0FBQztPQUNJLElBQUksVUFBVSxLQUFLLFVBQVUsS0FBSyxVQUFVLEdBQUc7R0FDbkQsSUFBSSxRQUFRLFNBQVMsTUFBTSxTQUFTLE9BQU8sU0FBUyxNQUFNLE1BQU0sdUJBQXVCLE9BQU8sNkNBQTZDO0dBQzNJLFFBQVEsS0FBSztJQUNaLE1BQU07SUFDTixPQUFPO0lBQ1AsUUFBUTtJQUNSLFlBQVksU0FBUyxPQUFPLFNBQVM7SUFDckMsVUFBVSxTQUFTLE9BQU8sU0FBUztHQUNwQyxDQUFDO0VBQ0YsT0FBTyxNQUFNLGlDQUFpQztFQUM5QyxTQUFTO0NBQ1Y7Q0FDQSxTQUFTLGtCQUFrQjtFQUMxQixVQUFVO0NBQ1g7Q0FDQSxPQUFPLElBQUksS0FBSyxRQUFRO0VBQ3ZCLE9BQU8sS0FBSztFQUNaLFFBQVEsT0FBUjtHQUNDLEtBQUs7SUFDSixJQUFJLFNBQVMsTUFBTTtLQUNsQixnQkFBZ0I7S0FDaEIsUUFBUTtJQUNULE9BQU8sSUFBSSxTQUFTLEtBQUs7S0FDeEIsSUFBSSxRQUFRLGNBQWM7S0FDMUIsZ0JBQWdCO0lBQ2pCLE9BQU8sSUFBSSxTQUFTLEtBQUs7S0FDeEIsY0FBYztLQUNkLFFBQVE7SUFDVCxPQUFPLGdCQUFnQjtJQUN2QjtHQUNELEtBQUs7SUFDSixnQkFBZ0I7SUFDaEIsUUFBUTtJQUNSO0dBQ0QsS0FBSztJQUNKLElBQUksU0FBUyxLQUFLLFFBQVE7U0FDckIsSUFBSSxlQUFlLEtBQUssSUFBSSxHQUFHLGdCQUFnQjtTQUMvQztLQUNKLGNBQWM7S0FDZCxRQUFRO0tBQ1IsSUFBSSxTQUFTLE9BQU8sU0FBUyxPQUFPLFNBQVMsS0FBSztJQUNuRDtJQUNBO0dBQ0QsS0FBSztJQUNKLElBQUksU0FBUyxLQUFLO0tBQ2pCLElBQUksU0FBUyxTQUFTLFNBQVMsTUFBTSxNQUFNLFdBQVcsU0FBUyxNQUFNLEdBQUcsRUFBRSxJQUFJO1VBQ3pFLFFBQVE7SUFDZCxPQUFPLFlBQVk7SUFDbkI7R0FDRCxLQUFLO0lBQ0osY0FBYztJQUNkLFFBQVE7SUFDUixJQUFJLFNBQVMsT0FBTyxTQUFTLE9BQU8sU0FBUyxLQUFLO0lBQ2xELFdBQVc7SUFDWDtHQUNELFNBQVMsTUFBTSxlQUFlO0VBQy9CO0NBQ0Q7Q0FDQSxJQUFJLFVBQVUsR0FBRyxNQUFNLHVDQUF1QyxPQUFPLEVBQUU7Q0FDdkUsY0FBYztDQUNkLGdCQUFnQjtDQUNoQixPQUFPO0FBQ1I7QUFHQSxJQUFNLHFCQUFxQjtBQUMzQixJQUFNLDJCQUEyQjtDQUNoQyxXQUFXO0NBQ1gsUUFBUTtDQUNSLE9BQU87Q0FDUCxLQUFLO0FBQ047QUFDQSxJQUFNLGlCQUFpQjs7Ozs7Ozs7QUFRdkIsU0FBUyxlQUFlLFVBQVUsY0FBYztDQUMvQyxNQUFNLFVBQVUsT0FBTyxDQUFDLEdBQUcsMEJBQTBCLFlBQVk7Q0FDakUsTUFBTSxRQUFRLENBQUM7Q0FDZixJQUFJLFVBQVUsUUFBUSxRQUFRLE1BQU07Q0FDcEMsTUFBTSxPQUFPLENBQUM7Q0FDZCxLQUFLLE1BQU0sV0FBVyxVQUFVO0VBQy9CLE1BQU0sZ0JBQWdCLFFBQVEsU0FBUyxDQUFDLElBQUksQ0FBQyxFQUFFO0VBQy9DLElBQUksUUFBUSxVQUFVLENBQUMsUUFBUSxRQUFRLFdBQVc7RUFDbEQsS0FBSyxJQUFJLGFBQWEsR0FBRyxhQUFhLFFBQVEsUUFBUSxjQUFjO0dBQ25FLE1BQU0sUUFBUSxRQUFRO0dBQ3RCLElBQUksa0JBQWtCLE1BQU0sUUFBUSxZQUFZLE1BQU07R0FDdEQsSUFBSSxNQUFNLFNBQVMsR0FBRztJQUNyQixJQUFJLENBQUMsWUFBWSxXQUFXO0lBQzVCLFdBQVcsTUFBTSxNQUFNLFFBQVEsZ0JBQWdCLE1BQU07SUFDckQsbUJBQW1CO0dBQ3BCLE9BQU8sSUFBSSxNQUFNLFNBQVMsR0FBRztJQUM1QixNQUFNLEVBQUUsT0FBTyxZQUFZLFVBQVUsV0FBVztJQUNoRCxLQUFLLEtBQUs7S0FDVCxNQUFNO0tBQ047S0FDQTtJQUNELENBQUM7SUFDRCxNQUFNLEtBQUssU0FBUyxTQUFTO0lBQzdCLElBQUksT0FBTyxvQkFBb0I7S0FDOUIsbUJBQW1CO0tBQ25CLElBQUk7TUFDSCxJQUFJLE9BQU8sSUFBSSxHQUFHLEVBQUU7S0FDckIsU0FBUyxLQUFLO01BQ2IsTUFBTSxJQUFJLE1BQU0sb0NBQW9DLE1BQU0sS0FBSyxHQUFHLE9BQU8sSUFBSSxPQUFPO0tBQ3JGO0lBQ0Q7SUFDQSxJQUFJLGFBQWEsYUFBYSxPQUFPLEdBQUcsVUFBVSxHQUFHLFFBQVEsSUFBSSxHQUFHO0lBQ3BFLElBQUksQ0FBQyxZQUFZLGFBQWEsWUFBWSxRQUFRLFNBQVMsSUFBSSxPQUFPLFdBQVcsS0FBSyxNQUFNO0lBQzVGLElBQUksVUFBVSxjQUFjO0lBQzVCLFdBQVc7SUFDWCxtQkFBbUI7SUFDbkIsSUFBSSxVQUFVLG1CQUFtQjtJQUNqQyxJQUFJLFlBQVksbUJBQW1CO0lBQ25DLElBQUksT0FBTyxNQUFNLG1CQUFtQjtHQUNyQztHQUNBLGNBQWMsS0FBSyxlQUFlO0VBQ25DO0VBQ0EsTUFBTSxLQUFLLGFBQWE7Q0FDekI7Q0FDQSxJQUFJLFFBQVEsVUFBVSxRQUFRLEtBQUs7RUFDbEMsTUFBTSxJQUFJLE1BQU0sU0FBUztFQUN6QixNQUFNLEVBQUUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxTQUFTLE1BQU07Q0FDbEM7Q0FDQSxJQUFJLENBQUMsUUFBUSxRQUFRLFdBQVc7Q0FDaEMsSUFBSSxRQUFRLEtBQUssV0FBVztNQUN2QixJQUFJLFFBQVEsVUFBVSxDQUFDLFFBQVEsU0FBUyxHQUFHLEdBQUcsV0FBVztDQUM5RCxNQUFNLEtBQUssSUFBSSxPQUFPLFNBQVMsUUFBUSxZQUFZLEtBQUssR0FBRztDQUMzRCxTQUFTLE1BQU0sTUFBTTtFQUNwQixNQUFNLFFBQVEsS0FBSyxNQUFNLEVBQUU7RUFDM0IsTUFBTSxTQUFTLENBQUM7RUFDaEIsSUFBSSxDQUFDLE9BQU8sT0FBTztFQUNuQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRLEtBQUs7R0FDdEMsTUFBTSxRQUFRLE1BQU0sTUFBTTtHQUMxQixNQUFNLE1BQU0sS0FBSyxJQUFJO0dBQ3JCLE9BQU8sSUFBSSxRQUFRLFNBQVMsSUFBSSxhQUFhLE1BQU0sTUFBTSxHQUFHLElBQUk7RUFDakU7RUFDQSxPQUFPO0NBQ1I7Q0FDQSxTQUFTLFVBQVUsUUFBUTtFQUMxQixJQUFJLE9BQU87RUFDWCxJQUFJLHVCQUF1QjtFQUMzQixLQUFLLE1BQU0sV0FBVyxVQUFVO0dBQy9CLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxLQUFLLFNBQVMsR0FBRyxHQUFHLFFBQVE7R0FDMUQsdUJBQXVCO0dBQ3ZCLEtBQUssTUFBTSxTQUFTLFNBQVMsSUFBSSxNQUFNLFNBQVMsR0FBRyxRQUFRLE1BQU07UUFDNUQsSUFBSSxNQUFNLFNBQVMsR0FBRztJQUMxQixNQUFNLEVBQUUsT0FBTyxZQUFZLGFBQWE7SUFDeEMsTUFBTSxRQUFRLFNBQVMsU0FBUyxPQUFPLFNBQVM7SUFDaEQsSUFBSSxRQUFRLEtBQUssS0FBSyxDQUFDLFlBQVksTUFBTSxJQUFJLE1BQU0sbUJBQW1CLE1BQU0sMERBQTBEO0lBQ3RJLE1BQU0sT0FBTyxRQUFRLEtBQUssSUFBSSxNQUFNLEtBQUssR0FBRyxJQUFJO0lBQ2hELElBQUksQ0FBQyxNQUFNO0tBQ1YsSUFBSSxVQUNDO1VBQUEsUUFBUSxTQUFTLEdBQUc7T0FDdkIsSUFBSSxLQUFLLFNBQVMsR0FBRyxHQUFHLE9BQU8sS0FBSyxNQUFNLEdBQUcsRUFBRTtZQUMxQyx1QkFBdUI7TUFDN0I7WUFDTSxNQUFNLElBQUksTUFBTSwyQkFBMkIsTUFBTSxFQUFFO0lBQzNEO0lBQ0EsUUFBUTtHQUNUO0VBQ0Q7RUFDQSxPQUFPLFFBQVE7Q0FDaEI7Q0FDQSxPQUFPO0VBQ047RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNEO0FBQ0Q7Ozs7Ozs7Ozs7QUFVQSxTQUFTLGtCQUFrQixHQUFHLEdBQUc7Q0FDaEMsSUFBSSxJQUFJO0NBQ1IsT0FBTyxJQUFJLEVBQUUsVUFBVSxJQUFJLEVBQUUsUUFBUTtFQUNwQyxNQUFNLE9BQU8sRUFBRSxLQUFLLEVBQUU7RUFDdEIsSUFBSSxNQUFNLE9BQU87RUFDakI7Q0FDRDtDQUNBLElBQUksRUFBRSxTQUFTLEVBQUUsUUFBUSxPQUFPLEVBQUUsV0FBVyxLQUFLLEVBQUUsT0FBTyxLQUFLLEtBQUs7TUFDaEUsSUFBSSxFQUFFLFNBQVMsRUFBRSxRQUFRLE9BQU8sRUFBRSxXQUFXLEtBQUssRUFBRSxPQUFPLEtBQUssSUFBSTtDQUN6RSxPQUFPO0FBQ1I7Ozs7Ozs7O0FBUUEsU0FBUyx1QkFBdUIsR0FBRyxHQUFHO0NBQ3JDLElBQUksSUFBSTtDQUNSLE1BQU0sU0FBUyxFQUFFO0NBQ2pCLE1BQU0sU0FBUyxFQUFFO0NBQ2pCLE9BQU8sSUFBSSxPQUFPLFVBQVUsSUFBSSxPQUFPLFFBQVE7RUFDOUMsTUFBTSxPQUFPLGtCQUFrQixPQUFPLElBQUksT0FBTyxFQUFFO0VBQ25ELElBQUksTUFBTSxPQUFPO0VBQ2pCO0NBQ0Q7Q0FDQSxJQUFJLEtBQUssSUFBSSxPQUFPLFNBQVMsT0FBTyxNQUFNLE1BQU0sR0FBRztFQUNsRCxJQUFJLG9CQUFvQixNQUFNLEdBQUcsT0FBTztFQUN4QyxJQUFJLG9CQUFvQixNQUFNLEdBQUcsT0FBTztDQUN6QztDQUNBLE9BQU8sT0FBTyxTQUFTLE9BQU87QUFDL0I7Ozs7Ozs7QUFPQSxTQUFTLG9CQUFvQixPQUFPO0NBQ25DLE1BQU0sT0FBTyxNQUFNLE1BQU0sU0FBUztDQUNsQyxPQUFPLE1BQU0sU0FBUyxLQUFLLEtBQUssS0FBSyxTQUFTLEtBQUs7QUFDcEQ7QUFDQSxJQUFNLCtCQUErQjtDQUNwQyxRQUFRO0NBQ1IsS0FBSztDQUNMLFdBQVc7QUFDWjtBQUdBLFNBQVMseUJBQXlCLFFBQVEsUUFBUSxTQUFTO0NBQzFELE1BQU0sU0FBUyxlQUFlLGFBQWEsT0FBTyxJQUFJLEdBQUcsT0FBTztDQUNyQjtFQUMxQyxNQUFNLCtCQUErQixJQUFJLElBQUk7RUFDN0MsS0FBSyxNQUFNLE9BQU8sT0FBTyxNQUFNO0dBQzlCLElBQUksYUFBYSxJQUFJLElBQUksSUFBSSxHQUFHLFlBQVksaUJBQWlCO0lBQzVELE1BQU0sSUFBSTtJQUNWLE1BQU0sT0FBTztHQUNkLENBQUM7R0FDRCxhQUFhLElBQUksSUFBSSxJQUFJO0VBQzFCO0NBQ0Q7Q0FDQSxNQUFNLFVBQVUsT0FBTyxRQUFRO0VBQzlCO0VBQ0E7RUFDQSxVQUFVLENBQUM7RUFDWCxPQUFPLENBQUM7Q0FDVCxDQUFDO0NBQ0QsSUFBSSxRQUNDO01BQUEsQ0FBQyxRQUFRLE9BQU8sWUFBWSxDQUFDLE9BQU8sT0FBTyxTQUFTLE9BQU8sU0FBUyxLQUFLLE9BQU87Q0FBQTtDQUVyRixPQUFPO0FBQ1I7Ozs7Ozs7O0FBVUEsU0FBUyxvQkFBb0IsUUFBUSxlQUFlO0NBQ25ELE1BQU0sV0FBVyxDQUFDO0NBQ2xCLE1BQU0sNkJBQTZCLElBQUksSUFBSTtDQUMzQyxnQkFBZ0IsYUFBYSw4QkFBOEIsYUFBYTtDQUN4RSxTQUFTLGlCQUFpQixNQUFNO0VBQy9CLE9BQU8sV0FBVyxJQUFJLElBQUk7Q0FDM0I7Q0FDQSxTQUFTLFNBQVMsUUFBUSxRQUFRLGdCQUFnQjtFQUNqRCxNQUFNLFlBQVksQ0FBQztFQUNuQixNQUFNLHVCQUF1QixxQkFBcUIsTUFBTTtFQUNiLG1DQUFtQyxzQkFBc0IsTUFBTTtFQUMxRyxxQkFBcUIsVUFBVSxrQkFBa0IsZUFBZTtFQUNoRSxNQUFNLFVBQVUsYUFBYSxlQUFlLE1BQU07RUFDbEQsTUFBTSxvQkFBb0IsQ0FBQyxvQkFBb0I7RUFDL0MsSUFBSSxXQUFXLFFBQVE7R0FDdEIsTUFBTSxVQUFVLE9BQU8sT0FBTyxVQUFVLFdBQVcsQ0FBQyxPQUFPLEtBQUssSUFBSSxPQUFPO0dBQzNFLEtBQUssTUFBTSxTQUFTLFNBQVMsa0JBQWtCLEtBQUsscUJBQXFCLE9BQU8sQ0FBQyxHQUFHLHNCQUFzQjtJQUN6RyxZQUFZLGlCQUFpQixlQUFlLE9BQU8sYUFBYSxxQkFBcUI7SUFDckYsTUFBTTtJQUNOLFNBQVMsaUJBQWlCLGVBQWUsU0FBUztHQUNuRCxDQUFDLENBQUMsQ0FBQztFQUNKO0VBQ0EsSUFBSTtFQUNKLElBQUk7RUFDSixLQUFLLE1BQU0sb0JBQW9CLG1CQUFtQjtHQUNqRCxNQUFNLEVBQUUsU0FBUztHQUNqQixJQUFJLFVBQVUsQ0FBQyxlQUFlLElBQUksR0FBRztJQUNwQyxNQUFNLGFBQWEsT0FBTyxPQUFPO0lBQ2pDLE1BQU0sa0JBQWtCLFdBQVcsV0FBVyxTQUFTLE9BQU8sTUFBTSxLQUFLO0lBQ3pFLGlCQUFpQixPQUFPLE9BQU8sT0FBTyxRQUFRLFFBQVEsa0JBQWtCO0dBQ3pFO0dBQ0EsSUFBNkMsaUJBQWlCLFNBQVMsS0FBSyxNQUFNLElBQUksTUFBTSwyS0FBMks7R0FDdlEsVUFBVSx5QkFBeUIsa0JBQWtCLFFBQVEsT0FBTztHQUNwRSxJQUE2QyxVQUFVLGVBQWUsSUFBSSxHQUFHLGlDQUFpQyxTQUFTLE1BQU07R0FDN0gsSUFBSSxnQkFBZ0I7SUFDbkIsZUFBZSxNQUFNLEtBQUssT0FBTztJQUNVLGdCQUFnQixnQkFBZ0IsT0FBTztHQUNuRixPQUFPO0lBQ04sa0JBQWtCLG1CQUFtQjtJQUNyQyxJQUFJLG9CQUFvQixTQUFTLGdCQUFnQixNQUFNLEtBQUssT0FBTztJQUNuRSxJQUFJLGFBQWEsT0FBTyxRQUFRLENBQUMsY0FBYyxPQUFPLEdBQUc7S0FDYix3QkFBd0IsUUFBUSxNQUFNO0tBQ2pGLFlBQVksT0FBTyxJQUFJO0lBQ3hCO0dBQ0Q7R0FDQSxJQUFJLFlBQVksT0FBTyxHQUFHLGNBQWMsT0FBTztHQUMvQyxJQUFJLHFCQUFxQixVQUFVO0lBQ2xDLE1BQU0sV0FBVyxxQkFBcUI7SUFDdEMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFNBQVMsUUFBUSxLQUFLLFNBQVMsU0FBUyxJQUFJLFNBQVMsa0JBQWtCLGVBQWUsU0FBUyxFQUFFO0dBQ3RIO0dBQ0EsaUJBQWlCLGtCQUFrQjtFQUNwQztFQUNBLE9BQU8sd0JBQXdCO0dBQzlCLFlBQVksZUFBZTtFQUM1QixJQUFJO0NBQ0w7Q0FDQSxTQUFTLFlBQVksWUFBWTtFQUNoQyxJQUFJLFlBQVksVUFBVSxHQUFHO0dBQzVCLE1BQU0sVUFBVSxXQUFXLElBQUksVUFBVTtHQUN6QyxJQUFJLFNBQVM7SUFDWixXQUFXLE9BQU8sVUFBVTtJQUM1QixTQUFTLE9BQU8sU0FBUyxRQUFRLE9BQU8sR0FBRyxDQUFDO0lBQzVDLFFBQVEsU0FBUyxRQUFRLFdBQVc7SUFDcEMsUUFBUSxNQUFNLFFBQVEsV0FBVztHQUNsQztFQUNELE9BQU87R0FDTixNQUFNLFFBQVEsU0FBUyxRQUFRLFVBQVU7R0FDekMsSUFBSSxRQUFRLElBQUk7SUFDZixTQUFTLE9BQU8sT0FBTyxDQUFDO0lBQ3hCLElBQUksV0FBVyxPQUFPLE1BQU0sV0FBVyxPQUFPLFdBQVcsT0FBTyxJQUFJO0lBQ3BFLFdBQVcsU0FBUyxRQUFRLFdBQVc7SUFDdkMsV0FBVyxNQUFNLFFBQVEsV0FBVztHQUNyQztFQUNEO0NBQ0Q7Q0FDQSxTQUFTLFlBQVk7RUFDcEIsT0FBTztDQUNSO0NBQ0EsU0FBUyxjQUFjLFNBQVM7RUFDL0IsTUFBTSxRQUFRLG1CQUFtQixTQUFTLFFBQVE7RUFDbEQsU0FBUyxPQUFPLE9BQU8sR0FBRyxPQUFPO0VBQ2pDLElBQUksUUFBUSxPQUFPLFFBQVEsQ0FBQyxjQUFjLE9BQU8sR0FBRyxXQUFXLElBQUksUUFBUSxPQUFPLE1BQU0sT0FBTztDQUNoRztDQUNBLFNBQVMsUUFBUSxVQUFVLGlCQUFpQjtFQUMzQyxJQUFJO0VBQ0osSUFBSSxTQUFTLENBQUM7RUFDZCxJQUFJO0VBQ0osSUFBSTtFQUNKLElBQUksVUFBVSxZQUFZLFNBQVMsTUFBTTtHQUN4QyxVQUFVLFdBQVcsSUFBSSxTQUFTLElBQUk7R0FDdEMsSUFBSSxDQUFDLFNBQVMsTUFBTSxrQkFBa0IsR0FBRyxFQUFFLFNBQVMsQ0FBQztHQUNWO0lBQzFDLE1BQU0sZ0JBQWdCLE9BQU8sS0FBSyxTQUFTLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLGNBQWMsQ0FBQyxRQUFRLEtBQUssTUFBTSxNQUFNLEVBQUUsU0FBUyxTQUFTLENBQUM7SUFDOUgsSUFBSSxjQUFjLFFBQVE7S0FDekIsTUFBTSxjQUFjLENBQUMsUUFBUSxLQUFLLFVBQVUsY0FBYyxNQUFNLFNBQVMsUUFBUSxnQkFBZ0IsTUFBTTtLQUN2RyxZQUFZLGlCQUFpQjtNQUM1QixRQUFRLGNBQWMsS0FBSyxRQUFRO01BQ25DLFdBQVcsY0FBYywySUFBMkk7S0FDckssQ0FBQztJQUNGO0dBQ0Q7R0FDQSxPQUFPLFFBQVEsT0FBTztHQUN0QixTQUFTLE9BQU8sV0FBVyxnQkFBZ0IsUUFBUSxRQUFRLEtBQUssUUFBUSxNQUFNLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQyxPQUFPLFFBQVEsU0FBUyxRQUFRLE9BQU8sS0FBSyxRQUFRLE1BQU0sRUFBRSxRQUFRLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLE1BQU0sRUFBRSxJQUFJLENBQUMsR0FBRyxTQUFTLFVBQVUsV0FBVyxTQUFTLFFBQVEsUUFBUSxLQUFLLEtBQUssTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDO0dBQzNRLE9BQU8sUUFBUSxVQUFVLE1BQU07RUFDaEMsT0FBTyxJQUFJLFNBQVMsUUFBUSxNQUFNO0dBQ2pDLE9BQU8sU0FBUztHQUNoQixJQUE2QyxDQUFDLGVBQWUsSUFBSSxHQUFHLFlBQVksaUJBQWlCLEVBQUUsS0FBSyxDQUFDO0dBQ3pHLFVBQVUsU0FBUyxNQUFNLE1BQU0sRUFBRSxHQUFHLEtBQUssSUFBSSxDQUFDO0dBQzlDLElBQUksU0FBUztJQUNaLFNBQVMsUUFBUSxNQUFNLElBQUk7SUFDM0IsT0FBTyxRQUFRLE9BQU87SUFDdEIsUUFBUSxLQUFLLFNBQVMsUUFBUTtLQUM3QixJQUFJLElBQUksWUFBWSxDQUFDLE9BQU8sSUFBSSxPQUFPLE9BQU8sT0FBTyxJQUFJO0lBQzFELENBQUM7R0FDRjtFQUNELE9BQU87R0FDTixVQUFVLGdCQUFnQixPQUFPLFdBQVcsSUFBSSxnQkFBZ0IsSUFBSSxJQUFJLFNBQVMsTUFBTSxNQUFNLEVBQUUsR0FBRyxLQUFLLGdCQUFnQixJQUFJLENBQUM7R0FDNUgsSUFBSSxDQUFDLFNBQVMsTUFBTSxrQkFBa0IsR0FBRztJQUN4QztJQUNBO0dBQ0QsQ0FBQztHQUNELE9BQU8sUUFBUSxPQUFPO0dBQ3RCLFNBQVMsT0FBTyxDQUFDLEdBQUcsZ0JBQWdCLFFBQVEsU0FBUyxNQUFNO0dBQzNELE9BQU8sUUFBUSxVQUFVLE1BQU07RUFDaEM7RUFDQSxNQUFNLFVBQVUsQ0FBQztFQUNqQixJQUFJLGdCQUFnQjtFQUNwQixPQUFPLGVBQWU7R0FDckIsUUFBUSxRQUFRLGNBQWMsTUFBTTtHQUNwQyxnQkFBZ0IsY0FBYztFQUMvQjtFQUNBLE9BQU87R0FDTjtHQUNBO0dBQ0E7R0FDQTtHQUNBLE1BQU0sZ0JBQWdCLE9BQU87RUFDOUI7Q0FDRDtDQUNBLE9BQU8sU0FBUyxVQUFVLFNBQVMsS0FBSyxDQUFDO0NBQ3pDLFNBQVMsY0FBYztFQUN0QixTQUFTLFNBQVM7RUFDbEIsV0FBVyxNQUFNO0NBQ2xCO0NBQ0EsT0FBTztFQUNOO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNEO0FBQ0Q7Ozs7Ozs7QUFPQSxTQUFTLFdBQVcsUUFBUSxNQUFNO0NBQ2pDLE1BQU0sWUFBWSxDQUFDO0NBQ25CLEtBQUssTUFBTSxPQUFPLE1BQU0sSUFBSSxPQUFPLFFBQVEsVUFBVSxPQUFPLE9BQU87Q0FDbkUsT0FBTztBQUNSOzs7Ozs7O0FBT0EsU0FBUyxxQkFBcUIsUUFBUTtDQUNyQyxNQUFNLGFBQWE7RUFDbEIsTUFBTSxPQUFPO0VBQ2IsVUFBVSxPQUFPO0VBQ2pCLE1BQU0sT0FBTztFQUNiLE1BQU0sT0FBTyxRQUFRLENBQUM7RUFDdEIsU0FBUyxPQUFPO0VBQ2hCLGFBQWEsT0FBTztFQUNwQixPQUFPLHFCQUFxQixNQUFNO0VBQ2xDLFVBQVUsT0FBTyxZQUFZLENBQUM7RUFDOUIsV0FBVyxDQUFDO0VBQ1osNkJBQTZCLElBQUksSUFBSTtFQUNyQyw4QkFBOEIsSUFBSSxJQUFJO0VBQ3RDLGdCQUFnQixDQUFDO0VBQ2pCLFlBQVksZ0JBQWdCLFNBQVMsT0FBTyxjQUFjLE9BQU8sT0FBTyxhQUFhLEVBQUUsU0FBUyxPQUFPLFVBQVU7Q0FDbEg7Q0FDQSxPQUFPLGVBQWUsWUFBWSxRQUFRLEVBQUUsT0FBTyxDQUFDLEVBQUUsQ0FBQztDQUN2RCxPQUFPO0FBQ1I7Ozs7OztBQU1BLFNBQVMscUJBQXFCLFFBQVE7Q0FDckMsTUFBTSxjQUFjLENBQUM7Q0FDckIsTUFBTSxRQUFRLE9BQU8sU0FBUztDQUM5QixJQUFJLGVBQWUsUUFBUSxZQUFZLFVBQVU7TUFDNUMsS0FBSyxNQUFNLFFBQVEsT0FBTyxZQUFZLFlBQVksUUFBUSxPQUFPLFVBQVUsV0FBVyxNQUFNLFFBQVE7Q0FDekcsT0FBTztBQUNSOzs7OztBQUtBLFNBQVMsY0FBYyxRQUFRO0NBQzlCLE9BQU8sUUFBUTtFQUNkLElBQUksT0FBTyxPQUFPLFNBQVMsT0FBTztFQUNsQyxTQUFTLE9BQU87Q0FDakI7Q0FDQSxPQUFPO0FBQ1I7Ozs7OztBQU1BLFNBQVMsZ0JBQWdCLFNBQVM7Q0FDakMsT0FBTyxRQUFRLFFBQVEsTUFBTSxXQUFXLE9BQU8sTUFBTSxPQUFPLElBQUksR0FBRyxDQUFDLENBQUM7QUFDdEU7QUFDQSxTQUFTLFlBQVksR0FBRyxHQUFHO0NBQzFCLE9BQU8sRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFLGFBQWEsRUFBRSxZQUFZLEVBQUUsZUFBZSxFQUFFO0FBQzdFOzs7Ozs7O0FBT0EsU0FBUyxnQkFBZ0IsR0FBRyxHQUFHO0NBQzlCLEtBQUssTUFBTSxPQUFPLEVBQUUsTUFBTSxJQUFJLENBQUMsSUFBSSxZQUFZLENBQUMsRUFBRSxLQUFLLEtBQUssWUFBWSxLQUFLLE1BQU0sR0FBRyxDQUFDLEdBQUc7RUFDekYsWUFBWSxpQkFBaUI7R0FDNUIsT0FBTyxFQUFFLE9BQU87R0FDaEIsVUFBVSxFQUFFLE9BQU87R0FDbkIsTUFBTSxJQUFJO0VBQ1gsQ0FBQztFQUNEO0NBQ0Q7Q0FDQSxLQUFLLE1BQU0sT0FBTyxFQUFFLE1BQU0sSUFBSSxDQUFDLElBQUksWUFBWSxDQUFDLEVBQUUsS0FBSyxLQUFLLFlBQVksS0FBSyxNQUFNLEdBQUcsQ0FBQyxHQUFHO0VBQ3pGLFlBQVksaUJBQWlCO0dBQzVCLE9BQU8sRUFBRSxPQUFPO0dBQ2hCLFVBQVUsRUFBRSxPQUFPO0dBQ25CLE1BQU0sSUFBSTtFQUNYLENBQUM7RUFDRDtDQUNEO0FBQ0Q7Ozs7Ozs7QUFPQSxTQUFTLG1DQUFtQyxzQkFBc0IsUUFBUTtDQUN6RSxJQUFJLFVBQVUsT0FBTyxPQUFPLFFBQVEsQ0FBQyxxQkFBcUIsUUFBUSxDQUFDLHFCQUFxQixRQUFRLHFCQUFxQixTQUFTLFdBQVcsR0FBRyxZQUFZLGlCQUFpQixFQUFFLE1BQU0sT0FBTyxPQUFPLE9BQU8sSUFBSSxFQUFFLENBQUM7QUFDOU07QUFDQSxTQUFTLHdCQUF3QixRQUFRLFFBQVE7Q0FDaEQsS0FBSyxJQUFJLFdBQVcsUUFBUSxVQUFVLFdBQVcsU0FBUyxRQUFRLElBQUksU0FBUyxPQUFPLFNBQVMsT0FBTyxNQUFNLE1BQU0sSUFBSSxNQUFNLGtCQUFrQixPQUFPLE9BQU8sSUFBSSxFQUFFLHdCQUF3QixXQUFXLFdBQVcsVUFBVSxhQUFhLHVIQUF1SDtBQUMvVjtBQUNBLFNBQVMsaUNBQWlDLFFBQVEsUUFBUTtDQUN6RCxLQUFLLE1BQU0sT0FBTyxPQUFPLE1BQU0sSUFBSSxDQUFDLE9BQU8sS0FBSyxLQUFLLFlBQVksS0FBSyxNQUFNLEdBQUcsQ0FBQyxHQUFHO0VBQ2xGLFlBQVksaUJBQWlCO0dBQzVCLE1BQU0sT0FBTyxPQUFPO0dBQ3BCLE1BQU0sSUFBSTtHQUNWLFFBQVEsT0FBTyxPQUFPO0VBQ3ZCLENBQUM7RUFDRDtDQUNEO0FBQ0Q7Ozs7Ozs7Ozs7QUFVQSxTQUFTLG1CQUFtQixTQUFTLFVBQVU7Q0FDOUMsSUFBSSxRQUFRO0NBQ1osSUFBSSxRQUFRLFNBQVM7Q0FDckIsT0FBTyxVQUFVLE9BQU87RUFDdkIsTUFBTSxNQUFNLFFBQVEsU0FBUztFQUM3QixJQUFJLHVCQUF1QixTQUFTLFNBQVMsSUFBSSxJQUFJLEdBQUcsUUFBUTtPQUMzRCxRQUFRLE1BQU07Q0FDcEI7Q0FDQSxNQUFNLG9CQUFvQixxQkFBcUIsT0FBTztDQUN0RCxJQUFJLG1CQUFtQjtFQUN0QixRQUFRLFNBQVMsWUFBWSxtQkFBbUIsUUFBUSxDQUFDO0VBQ3pELElBQTZDLFFBQVEsR0FBRyxZQUFZLGlCQUFpQjtHQUNwRixVQUFVLGtCQUFrQixPQUFPO0dBQ25DLFFBQVEsUUFBUSxPQUFPO0VBQ3hCLENBQUM7Q0FDRjtDQUNBLE9BQU87QUFDUjtBQUNBLFNBQVMscUJBQXFCLFNBQVM7Q0FDdEMsSUFBSSxXQUFXO0NBQ2YsT0FBTyxXQUFXLFNBQVMsUUFBUSxJQUFJLFlBQVksUUFBUSxLQUFLLHVCQUF1QixTQUFTLFFBQVEsTUFBTSxHQUFHLE9BQU87QUFDekg7Ozs7Ozs7O0FBUUEsU0FBUyxZQUFZLEVBQUUsVUFBVTtDQUNoQyxPQUFPLENBQUMsRUFBRSxPQUFPLFFBQVEsT0FBTyxjQUFjLE9BQU8sS0FBSyxPQUFPLFVBQVUsQ0FBQyxDQUFDLFVBQVUsT0FBTztBQUMvRjs7Ozs7O0FBUUEsU0FBUyxRQUFRLE9BQU87Q0FDdkIsTUFBTSxTQUFTLE9BQU8sU0FBUztDQUMvQixNQUFNLGVBQWUsT0FBTyxnQkFBZ0I7Q0FDNUMsSUFBSSxjQUFjO0NBQ2xCLElBQUksYUFBYTtDQUNqQixNQUFNLFFBQVEsZUFBZTtFQUM1QixNQUFNLEtBQUssTUFBTSxNQUFNLEVBQUU7RUFDekIsSUFBOEMsQ0FBQyxlQUFlLE9BQU8sWUFBYTtHQUNqRixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsR0FBRyxZQUFZLGlCQUFpQixFQUFFLEdBQUcsQ0FBQztHQUM3RCxhQUFhO0dBQ2IsY0FBYztFQUNmO0VBQ0EsT0FBTyxPQUFPLFFBQVEsRUFBRTtDQUN6QixDQUFDO0NBQ0QsTUFBTSxvQkFBb0IsZUFBZTtFQUN4QyxNQUFNLEVBQUUsWUFBWSxNQUFNO0VBQzFCLE1BQU0sRUFBRSxXQUFXO0VBQ25CLE1BQU0sZUFBZSxRQUFRLFNBQVM7RUFDdEMsTUFBTSxpQkFBaUIsYUFBYTtFQUNwQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZUFBZSxRQUFRLE9BQU87RUFDcEQsTUFBTSxRQUFRLGVBQWUsVUFBVSxrQkFBa0IsS0FBSyxNQUFNLFlBQVksQ0FBQztFQUNqRixJQUFJLFFBQVEsSUFBSSxPQUFPO0VBQ3ZCLE1BQU0sbUJBQW1CLGdCQUFnQixRQUFRLFNBQVMsRUFBRTtFQUM1RCxPQUFPLFNBQVMsS0FBSyxnQkFBZ0IsWUFBWSxNQUFNLG9CQUFvQixlQUFlLGVBQWUsU0FBUyxFQUFFLENBQUMsU0FBUyxtQkFBbUIsZUFBZSxVQUFVLGtCQUFrQixLQUFLLE1BQU0sUUFBUSxTQUFTLEVBQUUsQ0FBQyxJQUFJO0NBQ2hPLENBQUM7Q0FDRCxNQUFNLFdBQVcsZUFBZSxrQkFBa0IsUUFBUSxNQUFNLGVBQWUsYUFBYSxRQUFRLE1BQU0sTUFBTSxNQUFNLENBQUM7Q0FDdkgsTUFBTSxnQkFBZ0IsZUFBZSxrQkFBa0IsUUFBUSxNQUFNLGtCQUFrQixVQUFVLGFBQWEsUUFBUSxTQUFTLEtBQUssMEJBQTBCLGFBQWEsUUFBUSxNQUFNLE1BQU0sTUFBTSxDQUFDO0NBQ3RNLFNBQVMsU0FBUyxJQUFJLENBQUMsR0FBRztFQUN6QixJQUFJLFdBQVcsQ0FBQyxHQUFHO0dBQ2xCLE1BQU0sSUFBSSxPQUFPLE1BQU0sTUFBTSxPQUFPLElBQUksWUFBWSxPQUFPLENBQUMsTUFBTSxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxJQUFJO0dBQ3ZGLElBQUksTUFBTSxrQkFBa0IsT0FBTyxhQUFhLGVBQWUseUJBQXlCLFVBQVUsU0FBUywwQkFBMEIsQ0FBQztHQUN0SSxPQUFPO0VBQ1I7RUFDQSxPQUFPLFFBQVEsUUFBUTtDQUN4QjtDQUNBLElBQXdFLFdBQVc7RUFDbEYsTUFBTSxXQUFXLG1CQUFtQjtFQUNwQyxJQUFJLFVBQVU7R0FDYixNQUFNLHNCQUFzQjtJQUMzQixPQUFPLE1BQU07SUFDYixVQUFVLFNBQVM7SUFDbkIsZUFBZSxjQUFjO0lBQzdCLE9BQU87R0FDUjtHQUNBLFNBQVMsaUJBQWlCLFNBQVMsa0JBQWtCLENBQUM7R0FDdEQsU0FBUyxlQUFlLEtBQUssbUJBQW1CO0dBQ2hELGtCQUFrQjtJQUNqQixvQkFBb0IsUUFBUSxNQUFNO0lBQ2xDLG9CQUFvQixXQUFXLFNBQVM7SUFDeEMsb0JBQW9CLGdCQUFnQixjQUFjO0lBQ2xELG9CQUFvQixRQUFRLGdCQUFnQixNQUFNLE1BQU0sRUFBRSxDQUFDLElBQUksT0FBTztHQUN2RSxHQUFHLEVBQUUsT0FBTyxPQUFPLENBQUM7RUFDckI7Q0FDRDs7OztDQUlBLE9BQU87RUFDTjtFQUNBLE1BQU0sZUFBZSxNQUFNLE1BQU0sSUFBSTtFQUNyQztFQUNBO0VBQ0E7Q0FDRDtBQUNEO0FBQ0EsU0FBUyxrQkFBa0IsUUFBUTtDQUNsQyxPQUFPLE9BQU8sV0FBVyxJQUFJLE9BQU8sS0FBSztBQUMxQzs7OztBQUlBLElBQU0sYUFBNkIsZ0NBQWdCO0NBQ2xELE1BQU07Q0FDTixjQUFjLEVBQUUsTUFBTSxFQUFFO0NBQ3hCLE9BQU87RUFDTixJQUFJO0dBQ0gsTUFBTSxDQUFDLFFBQVEsTUFBTTtHQUNyQixVQUFVO0VBQ1g7RUFDQSxTQUFTO0VBQ1QsYUFBYTtFQUNiLGtCQUFrQjtFQUNsQixRQUFRO0VBQ1Isa0JBQWtCO0dBQ2pCLE1BQU07R0FDTixTQUFTO0VBQ1Y7RUFDQSxnQkFBZ0I7Q0FDakI7Q0FDQTtDQUNBLE1BQU0sT0FBTyxFQUFFLFNBQVM7RUFDdkIsTUFBTSxPQUFPLFNBQVMsUUFBUSxLQUFLLENBQUM7RUFDcEMsTUFBTSxFQUFFLFlBQVksT0FBTyxTQUFTO0VBQ3BDLE1BQU0sVUFBVSxnQkFBZ0I7SUFDOUIsYUFBYSxNQUFNLGFBQWEsUUFBUSxpQkFBaUIsb0JBQW9CLElBQUksS0FBSztJQUN0RixhQUFhLE1BQU0sa0JBQWtCLFFBQVEsc0JBQXNCLDBCQUEwQixJQUFJLEtBQUs7RUFDeEcsRUFBRTtFQUNGLGFBQWE7R0FDWixNQUFNLFdBQVcsTUFBTSxXQUFXLGtCQUFrQixNQUFNLFFBQVEsSUFBSSxDQUFDO0dBQ3ZFLE9BQU8sTUFBTSxTQUFTLFdBQVcsRUFBRSxLQUFLO0lBQ3ZDLGdCQUFnQixLQUFLLGdCQUFnQixNQUFNLG1CQUFtQjtJQUM5RCxNQUFNLEtBQUs7SUFDWCxTQUFTLEtBQUs7SUFDZCxPQUFPLFFBQVE7R0FDaEIsR0FBRyxRQUFRO0VBQ1o7Q0FDRDtBQUNELENBQUM7QUFDRCxTQUFTLFdBQVcsR0FBRztDQUN0QixJQUFJLEVBQUUsV0FBVyxFQUFFLFVBQVUsRUFBRSxXQUFXLEVBQUUsVUFBVTtDQUN0RCxJQUFJLEVBQUUsa0JBQWtCO0NBQ3hCLElBQUksRUFBRSxXQUFXLEtBQUssS0FBSyxFQUFFLFdBQVcsR0FBRztDQUMzQyxJQUFJLEVBQUUsaUJBQWlCLEVBQUUsY0FBYyxjQUFjO0VBQ3BELE1BQU0sU0FBUyxFQUFFLGNBQWMsYUFBYSxRQUFRO0VBQ3BELElBQUksY0FBYyxLQUFLLE1BQU0sR0FBRztDQUNqQztDQUNBLElBQUksRUFBRSxnQkFBZ0IsRUFBRSxlQUFlO0NBQ3ZDLE9BQU87QUFDUjtBQUNBLFNBQVMsZUFBZSxPQUFPLE9BQU87Q0FDckMsS0FBSyxNQUFNLE9BQU8sT0FBTztFQUN4QixNQUFNLGFBQWEsTUFBTTtFQUN6QixNQUFNLGFBQWEsTUFBTTtFQUN6QixJQUFJLFFBQVEsVUFBVSxHQUNqQjtPQUFBLENBQUMsUUFBUSxVQUFVLEtBQUssV0FBVyxXQUFXLFdBQVcsVUFBVSxXQUFXLE1BQU0sT0FBTyxNQUFNLE1BQU0sUUFBUSxNQUFNLFdBQVcsRUFBRSxDQUFDLFFBQVEsQ0FBQyxHQUFHLE9BQU87RUFBQSxPQUNwSixJQUFJLGVBQWUsWUFBWSxPQUFPO0NBQzlDO0NBQ0EsT0FBTztBQUNSOzs7OztBQUtBLFNBQVMsZ0JBQWdCLFFBQVE7Q0FDaEMsT0FBTyxTQUFTLE9BQU8sVUFBVSxPQUFPLFFBQVEsT0FBTyxPQUFPLE9BQU87QUFDdEU7Ozs7Ozs7QUFPQSxJQUFNLGdCQUFnQixXQUFXLGFBQWEsaUJBQWlCLGFBQWEsT0FBTyxZQUFZLGVBQWUsT0FBTyxjQUFjO0FBR25JLElBQU0saUJBQStCLDhCQUFnQjtDQUNwRCxNQUFNO0NBQ04sY0FBYztDQUNkLE9BQU87RUFDTixNQUFNO0dBQ0wsTUFBTTtHQUNOLFNBQVM7RUFDVjtFQUNBLE9BQU87Q0FDUjtDQUNBLGNBQWMsRUFBRSxNQUFNLEVBQUU7Q0FDeEIsTUFBTSxPQUFPLEVBQUUsT0FBTyxTQUFTO0VBQzlCLG9CQUE2RDtFQUM3RCxNQUFNLGdCQUFnQixPQUFPLHFCQUFxQjtFQUNsRCxNQUFNLGlCQUFpQixlQUFlLE1BQU0sU0FBUyxjQUFjLEtBQUs7RUFDeEUsTUFBTSxnQkFBZ0IsT0FBTyxjQUFjLENBQUM7RUFDNUMsTUFBTSxRQUFRLGVBQWU7R0FDNUIsSUFBSSxlQUFlLE1BQU0sYUFBYTtHQUN0QyxNQUFNLEVBQUUsWUFBWSxlQUFlO0dBQ25DLElBQUk7R0FDSixRQUFRLGVBQWUsUUFBUSxrQkFBa0IsQ0FBQyxhQUFhLFlBQVk7R0FDM0UsT0FBTztFQUNSLENBQUM7RUFDRCxNQUFNLGtCQUFrQixlQUFlLGVBQWUsTUFBTSxRQUFRLE1BQU0sTUFBTTtFQUNoRixRQUFRLGNBQWMsZUFBZSxNQUFNLFFBQVEsQ0FBQyxDQUFDO0VBQ3JELFFBQVEsaUJBQWlCLGVBQWU7RUFDeEMsUUFBUSx1QkFBdUIsY0FBYztFQUM3QyxNQUFNLFVBQVUsSUFBSTtFQUNwQixZQUFZO0dBQ1gsUUFBUTtHQUNSLGdCQUFnQjtHQUNoQixNQUFNO0VBQ1AsSUFBSSxDQUFDLFVBQVUsSUFBSSxPQUFPLENBQUMsYUFBYSxNQUFNLGNBQWM7R0FDM0QsSUFBSSxJQUFJO0lBQ1AsR0FBRyxVQUFVLFFBQVE7SUFDckIsSUFBSSxRQUFRLFNBQVMsTUFBTSxZQUFZLGFBQWEsYUFBYTtLQUNoRSxJQUFJLENBQUMsR0FBRyxZQUFZLE1BQU0sR0FBRyxjQUFjLEtBQUs7S0FDaEQsSUFBSSxDQUFDLEdBQUcsYUFBYSxNQUFNLEdBQUcsZUFBZSxLQUFLO0lBQ25EO0dBQ0Q7R0FDQSxJQUFJLFlBQVksT0FBTyxDQUFDLFFBQVEsQ0FBQyxrQkFBa0IsSUFBSSxJQUFJLEtBQUssQ0FBQyxjQUFjLENBQUMsR0FBRyxlQUFlLFNBQVMsQ0FBQyxHQUFHLFNBQVMsYUFBYSxTQUFTLFFBQVEsQ0FBQztFQUN4SixHQUFHLEVBQUUsT0FBTyxPQUFPLENBQUM7RUFDcEIsYUFBYTtHQUNaLE1BQU0sUUFBUSxlQUFlO0dBQzdCLE1BQU0sY0FBYyxNQUFNO0dBQzFCLE1BQU0sZUFBZSxnQkFBZ0I7R0FDckMsTUFBTSxnQkFBZ0IsZ0JBQWdCLGFBQWEsV0FBVztHQUM5RCxJQUFJLENBQUMsZUFBZSxPQUFPLGNBQWMsTUFBTSxTQUFTO0lBQ3ZELFdBQVc7SUFDWDtHQUNELENBQUM7R0FDRCxNQUFNLG1CQUFtQixhQUFhLE1BQU07R0FDNUMsTUFBTSxhQUFhLG1CQUFtQixxQkFBcUIsT0FBTyxNQUFNLFNBQVMsT0FBTyxxQkFBcUIsYUFBYSxpQkFBaUIsS0FBSyxJQUFJLG1CQUFtQjtHQUN2SyxNQUFNLG9CQUFvQixVQUFVO0lBQ25DLElBQUksTUFBTSxVQUFVLGFBQWEsYUFBYSxVQUFVLGVBQWU7R0FDeEU7R0FDQSxNQUFNLFlBQVksRUFBRSxlQUFlLE9BQU8sQ0FBQyxHQUFHLFlBQVksT0FBTztJQUNoRTtJQUNBLEtBQUs7R0FDTixDQUFDLENBQUM7R0FDRixJQUF3RSxhQUFhLFVBQVUsS0FBSztJQUNuRyxNQUFNLE9BQU87S0FDWixPQUFPLE1BQU07S0FDYixNQUFNLGFBQWE7S0FDbkIsTUFBTSxhQUFhO0tBQ25CLE1BQU0sYUFBYTtJQUNwQjtJQUNBLENBQUMsUUFBUSxVQUFVLEdBQUcsSUFBSSxVQUFVLElBQUksS0FBSyxNQUFNLEVBQUUsQ0FBQyxJQUFJLENBQUMsVUFBVSxJQUFJLENBQUMsR0FBRyxTQUFTLGFBQWE7S0FDbEcsSUFBSSxVQUFVLFNBQVMsaUJBQWlCO0lBQ3pDLENBQUM7R0FDRjtHQUNBLE9BQU8sY0FBYyxNQUFNLFNBQVM7SUFDbkMsV0FBVztJQUNYO0dBQ0QsQ0FBQyxLQUFLO0VBQ1A7Q0FDRDtBQUNELENBQUM7QUFDRCxTQUFTLGNBQWMsTUFBTSxNQUFNO0NBQ2xDLElBQUksQ0FBQyxNQUFNLE9BQU87Q0FDbEIsTUFBTSxjQUFjLEtBQUssSUFBSTtDQUM3QixPQUFPLFlBQVksV0FBVyxJQUFJLFlBQVksS0FBSztBQUNwRDs7OztBQUlBLElBQU0sYUFBYTtBQUNuQixTQUFTLHNCQUFzQjtDQUM5QixNQUFNLFdBQVcsbUJBQW1CO0NBQ3BDLE1BQU0sYUFBYSxTQUFTLFVBQVUsU0FBUyxPQUFPLEtBQUs7Q0FDM0QsTUFBTSxvQkFBb0IsU0FBUyxVQUFVLFNBQVMsT0FBTyxXQUFXLFNBQVMsT0FBTyxRQUFRO0NBQ2hHLElBQUksZUFBZSxlQUFlLGVBQWUsV0FBVyxTQUFTLFlBQVksTUFBTSxPQUFPLHNCQUFzQixZQUFZLGtCQUFrQixTQUFTLGNBQWM7RUFDeEssTUFBTSxPQUFPLGVBQWUsY0FBYyxlQUFlO0VBQ3pELFlBQVksaUJBQWlCLEVBQUUsS0FBSyxDQUFDO0NBQ3RDO0FBQ0Q7Ozs7OztBQVFBLFNBQVMsYUFBYSxTQUFTO0NBQzlCLE1BQU0sVUFBVSxvQkFBb0IsUUFBUSxRQUFRLE9BQU87Q0FDM0QsTUFBTSxlQUFlLFFBQVEsY0FBYztDQUMzQyxNQUFNLG1CQUFtQixRQUFRLGtCQUFrQjtDQUNuRCxNQUFNLGdCQUFnQixRQUFRO0NBQzlCLElBQTZDLENBQUMsZUFBZSxNQUFNLElBQUksTUFBTSxvSUFBb0k7Q0FDak4sTUFBTSxlQUFlLGFBQWE7Q0FDbEMsTUFBTSxzQkFBc0IsYUFBYTtDQUN6QyxNQUFNLGNBQWMsYUFBYTtDQUNqQyxNQUFNLGVBQWUsV0FBVyx5QkFBeUI7Q0FDekQsTUFBTSxnQkFBZ0IsV0FBVyxDQUFDO0NBQ2xDLElBQUksa0JBQWtCO0NBQ3RCLElBQUksYUFBYSxRQUFRLGtCQUFrQix1QkFBdUIsU0FBUyxRQUFRLG9CQUFvQjtDQUN2RyxNQUFNLGtCQUFrQixjQUFjLEtBQUssT0FBTyxlQUFlLEtBQUssVUFBVTtDQUNoRixNQUFNLGVBQWUsY0FBYyxLQUFLLE1BQU0sV0FBVztDQUN6RCxNQUFNLGVBQWUsY0FBYyxLQUFLLE1BQU0sTUFBTTtDQUNwRCxTQUFTLFNBQVMsZUFBZSxPQUFPO0VBQ3ZDLElBQUk7RUFDSixJQUFJO0VBQ0osSUFBSSxZQUFZLGFBQWEsR0FBRztHQUMvQixTQUFTLFFBQVEsaUJBQWlCLGFBQWE7R0FDL0MsSUFBNkMsQ0FBQyxRQUFRLFlBQVksaUJBQWlCLEVBQUUsTUFBTSxPQUFPLGFBQWEsRUFBRSxDQUFDO0dBQ2xILFNBQVM7RUFDVixPQUFPLFNBQVM7RUFDaEIsTUFBTSxjQUFjLFFBQVEsU0FBUyxRQUFRLE1BQU07RUFDbkQsY0FBYztFQUNkLGFBQWE7R0FDWixZQUFZO0dBQ1osY0FBYztFQUNmO0NBQ0Q7Q0FDQSxTQUFTLFlBQVksTUFBTTtFQUMxQixNQUFNLGdCQUFnQixRQUFRLGlCQUFpQixJQUFJO0VBQ25ELElBQUksZUFBZTtHQUNsQixRQUFRLFlBQVksYUFBYTtHQUNqQyxjQUFjO0VBQ2YsT0FBa0QsWUFBWSxpQkFBaUIsRUFBRSxNQUFNLE9BQU8sSUFBSSxFQUFFLENBQUM7Q0FDdEc7Q0FDQSxTQUFTLGNBQWM7RUFDdEIsUUFBUSxZQUFZO0VBQ3BCLGNBQWM7Q0FDZjtDQUNBLFNBQVMsWUFBWTtFQUNwQixPQUFPLFFBQVEsVUFBVSxDQUFDLENBQUMsS0FBSyxpQkFBaUIsYUFBYSxNQUFNO0NBQ3JFO0NBQ0EsU0FBUyxTQUFTLE1BQU07RUFDdkIsT0FBTyxDQUFDLENBQUMsUUFBUSxpQkFBaUIsSUFBSTtDQUN2QztDQUNBLFNBQVMsUUFBUSxhQUFhLGlCQUFpQjtFQUM5QyxjQUFjO0VBQ2QsSUFBSSxPQUFPLGdCQUFnQixVQUFVO0dBQ3BDLGtCQUFrQixvQkFBb0IsWUFBWSxXQUFXLEdBQUcsSUFBSSw0QkFBNEIsYUFBYTtHQUM3RyxNQUFNLHFCQUFxQixTQUFTLGNBQWMsYUFBYSxnQkFBZ0IsSUFBSTtHQUNuRixNQUFNLGVBQWUsUUFBUSxRQUFRLEVBQUUsTUFBTSxtQkFBbUIsS0FBSyxHQUFHLGVBQWU7R0FDdkYsTUFBTSxPQUFPLGNBQWMsV0FBVyxtQkFBbUIsUUFBUTtHQUVoRSxJQUFJLEtBQUssV0FBVyxJQUFJLEdBQUcsWUFBWSxpQkFBaUI7SUFDdkQsVUFBVTtJQUNWO0dBQ0QsQ0FBQztRQUNJLElBQUksQ0FBQyxhQUFhLFFBQVEsUUFBUSxZQUFZLGlCQUFpQixFQUFFLE1BQU0sWUFBWSxDQUFDO0dBRTFGLE9BQU8sT0FBTyxvQkFBb0IsY0FBYztJQUMvQyxRQUFRLGFBQWEsYUFBYSxNQUFNO0lBQ3hDLGdCQUFnQixLQUFLO0lBQ3JCO0dBQ0QsQ0FBQztFQUNGO0VBQ0EsSUFBNkMsQ0FBQyxnQkFBZ0IsV0FBVyxHQUFHO0dBQzNFLFlBQVksaUJBQWlCLEVBQUUsWUFBWSxDQUFDO0dBQzVDLE9BQU8sUUFBUSxDQUFDLENBQUM7RUFDbEI7RUFDQSxrQkFBa0IsT0FBTyxDQUFDLEdBQUcsb0JBQW9CLFlBQVksUUFBUSxRQUFRLFlBQVksS0FBSyxXQUFXLEdBQUcsS0FBSyxFQUFFLFVBQVUsZUFBZSxZQUFZLFFBQVEsNEJBQTRCLGFBQWEsTUFBTTtFQUMvTSxJQUFJO0VBQ0osSUFBSSxZQUFZLFFBQVEsTUFBTTtHQUM3QixJQUE2QyxZQUFZLGVBQWUsRUFBRSxVQUFVLGdCQUFnQixPQUFPLEtBQUssWUFBWSxNQUFNLENBQUMsQ0FBQyxRQUFRLFlBQVksaUJBQWlCLEVBQUUsTUFBTSxZQUFZLEtBQUssQ0FBQztHQUNuTSxrQkFBa0IsT0FBTyxDQUFDLEdBQUcsYUFBYSxFQUFFLE1BQU0sU0FBUyxjQUFjLFlBQVksTUFBTSxnQkFBZ0IsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDO0VBQ3hILE9BQU87R0FDTixNQUFNLGVBQWUsT0FBTyxDQUFDLEdBQUcsWUFBWSxNQUFNO0dBQ2xELEtBQUssTUFBTSxPQUFPLGNBQWMsSUFBSSxhQUFhLFFBQVEsTUFBTSxPQUFPLGFBQWE7R0FDbkYsa0JBQWtCLE9BQU8sQ0FBQyxHQUFHLGFBQWEsRUFBRSxRQUFRLGFBQWEsWUFBWSxFQUFFLENBQUM7R0FDaEYsZ0JBQWdCLFNBQVMsYUFBYSxnQkFBZ0IsTUFBTTtFQUM3RDtFQUNBLE1BQU0sZUFBZSxRQUFRLFFBQVEsaUJBQWlCLGVBQWU7RUFDckUsTUFBTSxPQUFPLFlBQVksUUFBUTtFQUNqQyxJQUE2QyxRQUFRLENBQUMsS0FBSyxXQUFXLEdBQUcsR0FBRyxZQUFZLGlCQUFpQixFQUFFLEtBQUssQ0FBQztFQUNqSCxhQUFhLFNBQVMsZ0JBQWdCLGFBQWEsYUFBYSxNQUFNLENBQUM7RUFDdkUsTUFBTSxXQUFXLGFBQWEsa0JBQWtCLE9BQU8sQ0FBQyxHQUFHLGFBQWE7R0FDdkUsTUFBTSxXQUFXLElBQUk7R0FDckIsTUFBTSxhQUFhO0VBQ3BCLENBQUMsQ0FBQztFQUNGLE1BQU0sT0FBTyxjQUFjLFdBQVcsUUFBUTtFQUU3QyxJQUFJLEtBQUssV0FBVyxJQUFJLEdBQUcsWUFBWSxpQkFBaUI7R0FDdkQsVUFBVTtHQUNWO0VBQ0QsQ0FBQztPQUNJLElBQUksQ0FBQyxhQUFhLFFBQVEsUUFBUSxZQUFZLGlCQUFpQixFQUFFLE1BQU0sWUFBWSxRQUFRLE9BQU8sWUFBWSxPQUFPLFlBQVksQ0FBQztFQUV4SSxPQUFPLE9BQU87R0FDYjtHQUNBO0dBQ0EsT0FBTyxxQkFBcUIsaUJBQWlCLGVBQWUsWUFBWSxLQUFLLElBQUksWUFBWSxTQUFTLENBQUM7RUFDeEcsR0FBRyxjQUFjO0dBQ2hCLGdCQUFnQixLQUFLO0dBQ3JCO0VBQ0QsQ0FBQztDQUNGO0NBQ0EsU0FBUyxpQkFBaUIsSUFBSTtFQUM3QixPQUFPLE9BQU8sT0FBTyxXQUFXLFNBQVMsY0FBYyxJQUFJLGFBQWEsTUFBTSxJQUFJLElBQUksT0FBTyxDQUFDLEdBQUcsRUFBRTtDQUNwRztDQUNBLFNBQVMsd0JBQXdCLElBQUksTUFBTTtFQUMxQyxJQUFJLG9CQUFvQixJQUFJLE9BQU8sa0JBQWtCLEdBQUc7R0FDdkQ7R0FDQTtFQUNELENBQUM7Q0FDRjtDQUNBLFNBQVMsS0FBSyxJQUFJO0VBQ2pCLE9BQU8saUJBQWlCLEVBQUU7Q0FDM0I7Q0FDQSxTQUFTLFFBQVEsSUFBSTtFQUNwQixPQUFPLEtBQUssT0FBTyxpQkFBaUIsRUFBRSxHQUFHLEVBQUUsU0FBUyxLQUFLLENBQUMsQ0FBQztDQUM1RDtDQUNBLFNBQVMscUJBQXFCLElBQUksTUFBTTtFQUN2QyxNQUFNLGNBQWMsR0FBRyxRQUFRLEdBQUcsUUFBUSxTQUFTO0VBQ25ELElBQUksZUFBZSxZQUFZLFVBQVU7R0FDeEMsTUFBTSxFQUFFLGFBQWE7R0FDckIsSUFBSSxvQkFBb0IsT0FBTyxhQUFhLGFBQWEsU0FBUyxJQUFJLElBQUksSUFBSTtHQUM5RSxJQUFJLE9BQU8sc0JBQXNCLFVBQVU7SUFDMUMsb0JBQW9CLGtCQUFrQixTQUFTLEdBQUcsS0FBSyxrQkFBa0IsU0FBUyxHQUFHLElBQUksb0JBQW9CLGlCQUFpQixpQkFBaUIsSUFBSSxFQUFFLE1BQU0sa0JBQWtCO0lBQzdLLGtCQUFrQixTQUFTLENBQUM7R0FDN0I7R0FDQSxJQUE2QyxrQkFBa0IsUUFBUSxRQUFRLEVBQUUsVUFBVSxvQkFBb0I7SUFDOUcsWUFBWSxpQkFBaUI7S0FDNUIsUUFBUSxLQUFLLFVBQVUsbUJBQW1CLE1BQU0sQ0FBQztLQUNqRCxJQUFJLEdBQUc7SUFDUixDQUFDO0lBQ0QsTUFBTSxJQUFJLE1BQU0sa0JBQWtCO0dBQ25DO0dBQ0EsT0FBTyxPQUFPO0lBQ2IsT0FBTyxHQUFHO0lBQ1YsTUFBTSxHQUFHO0lBQ1QsUUFBUSxrQkFBa0IsUUFBUSxPQUFPLENBQUMsSUFBSSxHQUFHO0dBQ2xELEdBQUcsaUJBQWlCO0VBQ3JCO0NBQ0Q7Q0FDQSxTQUFTLGlCQUFpQixJQUFJLGdCQUFnQjtFQUM3QyxNQUFNLGlCQUFpQixrQkFBa0IsUUFBUSxFQUFFO0VBQ25ELE1BQU0sT0FBTyxhQUFhO0VBQzFCLE1BQU0sT0FBTyxHQUFHO0VBQ2hCLE1BQU0sUUFBUSxHQUFHO0VBQ2pCLE1BQU0sVUFBVSxHQUFHLFlBQVk7RUFDL0IsTUFBTSxpQkFBaUIscUJBQXFCLGdCQUFnQixJQUFJO0VBQ2hFLElBQUksZ0JBQWdCLE9BQU8saUJBQWlCLE9BQU8saUJBQWlCLGNBQWMsR0FBRztHQUNwRixPQUFPLE9BQU8sbUJBQW1CLFdBQVcsT0FBTyxDQUFDLEdBQUcsTUFBTSxlQUFlLEtBQUssSUFBSTtHQUNyRjtHQUNBO0VBQ0QsQ0FBQyxHQUFHLGtCQUFrQixjQUFjO0VBQ3BDLE1BQU0sYUFBYTtFQUNuQixXQUFXLGlCQUFpQjtFQUM1QixJQUFJO0VBQ0osSUFBSSxDQUFDLFNBQVMsb0JBQW9CLGtCQUFrQixNQUFNLGNBQWMsR0FBRztHQUMxRSxVQUFVLGtCQUFrQixJQUFJO0lBQy9CLElBQUk7SUFDSjtHQUNELENBQUM7R0FDRCxhQUFhLE1BQU0sTUFBTSxNQUFNLEtBQUs7RUFDckM7RUFDQSxRQUFRLFVBQVUsUUFBUSxRQUFRLE9BQU8sSUFBSSxTQUFTLFlBQVksSUFBSSxHQUFHLE9BQU8sVUFBVSxvQkFBb0IsS0FBSyxJQUFJLG9CQUFvQixPQUFPLENBQUMsSUFBSSxRQUFRLFlBQVksS0FBSyxJQUFJLGFBQWEsT0FBTyxZQUFZLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxZQUFZO0dBQzVPLElBQUksU0FDQztRQUFBLG9CQUFvQixTQUFTLENBQUMsR0FBRztLQUNwQyxJQUE2QyxvQkFBb0Isa0JBQWtCLFFBQVEsUUFBUSxFQUFFLEdBQUcsVUFBVSxLQUFLLG1CQUFtQixlQUFlLFNBQVMsZUFBZSxTQUFTLGVBQWUsU0FBUyxJQUFJLEtBQUssSUFBSTtNQUM5TixZQUFZLGlCQUFpQjtPQUM1QixNQUFNLEtBQUs7T0FDWCxJQUFJLFdBQVc7TUFDaEIsQ0FBQztNQUNELE9BQU8sUUFBUSx1QkFBdUIsSUFBSSxNQUFNLHVDQUF1QyxDQUFDO0tBQ3pGO0tBQ0EsT0FBTyxpQkFBaUIsT0FBTyxFQUFFLFFBQVEsR0FBRyxpQkFBaUIsUUFBUSxFQUFFLEdBQUc7TUFDekUsT0FBTyxPQUFPLFFBQVEsT0FBTyxXQUFXLE9BQU8sQ0FBQyxHQUFHLE1BQU0sUUFBUSxHQUFHLEtBQUssSUFBSTtNQUM3RTtLQUNELENBQUMsR0FBRyxrQkFBa0IsVUFBVTtJQUNqQztVQUNNLFVBQVUsbUJBQW1CLFlBQVksTUFBTSxNQUFNLFNBQVMsSUFBSTtHQUN6RSxpQkFBaUIsWUFBWSxNQUFNLE9BQU87R0FDMUMsT0FBTztFQUNSLENBQUM7Q0FDRjs7Ozs7O0NBTUEsU0FBUyxpQ0FBaUMsSUFBSSxNQUFNO0VBQ25ELE1BQU0sUUFBUSx3QkFBd0IsSUFBSSxJQUFJO0VBQzlDLE9BQU8sUUFBUSxRQUFRLE9BQU8sS0FBSyxJQUFJLFFBQVEsUUFBUTtDQUN4RDtDQUNBLFNBQVMsZUFBZSxJQUFJO0VBQzNCLE1BQU0sTUFBTSxjQUFjLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0VBQzFDLE9BQU8sT0FBTyxPQUFPLElBQUksbUJBQW1CLGFBQWEsSUFBSSxlQUFlLEVBQUUsSUFBSSxHQUFHO0NBQ3RGO0NBQ0EsU0FBUyxTQUFTLElBQUksTUFBTTtFQUMzQixJQUFJO0VBQ0osTUFBTSxDQUFDLGdCQUFnQixpQkFBaUIsbUJBQW1CLHVCQUF1QixJQUFJLElBQUk7RUFDMUYsU0FBUyx3QkFBd0IsZUFBZSxRQUFRLEdBQUcsb0JBQW9CLElBQUksSUFBSTtFQUN2RixLQUFLLE1BQU0sVUFBVSxnQkFBZ0IsT0FBTyxZQUFZLFNBQVMsVUFBVTtHQUMxRSxPQUFPLEtBQUssaUJBQWlCLE9BQU8sSUFBSSxJQUFJLENBQUM7RUFDOUMsQ0FBQztFQUNELE1BQU0sMEJBQTBCLGlDQUFpQyxLQUFLLE1BQU0sSUFBSSxJQUFJO0VBQ3BGLE9BQU8sS0FBSyx1QkFBdUI7RUFDbkMsT0FBTyxjQUFjLE1BQU0sQ0FBQyxDQUFDLFdBQVc7R0FDdkMsU0FBUyxDQUFDO0dBQ1YsS0FBSyxNQUFNLFNBQVMsYUFBYSxLQUFLLEdBQUcsT0FBTyxLQUFLLGlCQUFpQixPQUFPLElBQUksSUFBSSxDQUFDO0dBQ3RGLE9BQU8sS0FBSyx1QkFBdUI7R0FDbkMsT0FBTyxjQUFjLE1BQU07RUFDNUIsQ0FBQyxDQUFDLENBQUMsV0FBVztHQUNiLFNBQVMsd0JBQXdCLGlCQUFpQixxQkFBcUIsSUFBSSxJQUFJO0dBQy9FLEtBQUssTUFBTSxVQUFVLGlCQUFpQixPQUFPLGFBQWEsU0FBUyxVQUFVO0lBQzVFLE9BQU8sS0FBSyxpQkFBaUIsT0FBTyxJQUFJLElBQUksQ0FBQztHQUM5QyxDQUFDO0dBQ0QsT0FBTyxLQUFLLHVCQUF1QjtHQUNuQyxPQUFPLGNBQWMsTUFBTTtFQUM1QixDQUFDLENBQUMsQ0FBQyxXQUFXO0dBQ2IsU0FBUyxDQUFDO0dBQ1YsS0FBSyxNQUFNLFVBQVUsaUJBQWlCLElBQUksT0FBTyxhQUFhO0lBQzdELElBQUksUUFBUSxPQUFPLFdBQVcsR0FBRyxLQUFLLE1BQU0sZUFBZSxPQUFPLGFBQWEsT0FBTyxLQUFLLGlCQUFpQixhQUFhLElBQUksSUFBSSxDQUFDO1NBQzdILE9BQU8sS0FBSyxpQkFBaUIsT0FBTyxhQUFhLElBQUksSUFBSSxDQUFDO0dBQ2hFO0dBQ0EsT0FBTyxLQUFLLHVCQUF1QjtHQUNuQyxPQUFPLGNBQWMsTUFBTTtFQUM1QixDQUFDLENBQUMsQ0FBQyxXQUFXO0dBQ2IsR0FBRyxRQUFRLFNBQVMsV0FBVyxPQUFPLGlCQUFpQixDQUFDLENBQUM7R0FDekQsU0FBUyx3QkFBd0IsaUJBQWlCLG9CQUFvQixJQUFJLE1BQU0sY0FBYztHQUM5RixPQUFPLEtBQUssdUJBQXVCO0dBQ25DLE9BQU8sY0FBYyxNQUFNO0VBQzVCLENBQUMsQ0FBQyxDQUFDLFdBQVc7R0FDYixTQUFTLENBQUM7R0FDVixLQUFLLE1BQU0sU0FBUyxvQkFBb0IsS0FBSyxHQUFHLE9BQU8sS0FBSyxpQkFBaUIsT0FBTyxJQUFJLElBQUksQ0FBQztHQUM3RixPQUFPLEtBQUssdUJBQXVCO0dBQ25DLE9BQU8sY0FBYyxNQUFNO0VBQzVCLENBQUMsQ0FBQyxDQUFDLE9BQU8sUUFBUSxvQkFBb0IsS0FBSyxDQUFDLElBQUksTUFBTSxRQUFRLE9BQU8sR0FBRyxDQUFDO0NBQzFFO0NBQ0EsU0FBUyxpQkFBaUIsSUFBSSxNQUFNLFNBQVM7RUFDNUMsWUFBWSxLQUFLLENBQUMsQ0FBQyxTQUFTLFVBQVUscUJBQXFCLE1BQU0sSUFBSSxNQUFNLE9BQU8sQ0FBQyxDQUFDO0NBQ3JGOzs7Ozs7Q0FNQSxTQUFTLG1CQUFtQixZQUFZLE1BQU0sUUFBUSxTQUFTLE1BQU07RUFDcEUsTUFBTSxRQUFRLHdCQUF3QixZQUFZLElBQUk7RUFDdEQsSUFBSSxPQUFPLE9BQU87RUFDbEIsTUFBTSxvQkFBb0IsU0FBUztFQUNuQyxNQUFNLFFBQVEsQ0FBQyxZQUFZLENBQUMsSUFBSSxRQUFRO0VBQ3hDLElBQUksUUFBUTtHQUNYLElBQUksV0FBVyxtQkFBbUIsY0FBYyxRQUFRLFdBQVcsVUFBVSxPQUFPLEVBQUUsUUFBUSxxQkFBcUIsU0FBUyxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUM7UUFDNUksY0FBYyxLQUFLLFdBQVcsVUFBVSxJQUFJO0VBQ2xEO0VBQ0EsYUFBYSxRQUFRO0VBQ3JCLGFBQWEsWUFBWSxNQUFNLFFBQVEsaUJBQWlCO0VBQ3hELFlBQVk7Q0FDYjtDQUNBLElBQUk7Q0FDSixTQUFTLGlCQUFpQjtFQUN6QixJQUFJLHVCQUF1QjtFQUMzQix3QkFBd0IsY0FBYyxRQUFRLElBQUksT0FBTyxTQUFTO0dBQ2pFLElBQUksQ0FBQyxPQUFPLFdBQVc7R0FDdkIsTUFBTSxhQUFhLFFBQVEsRUFBRTtHQUM3QixNQUFNLGlCQUFpQixxQkFBcUIsWUFBWSxPQUFPLGFBQWEsS0FBSztHQUNqRixJQUFJLGdCQUFnQjtJQUNuQixpQkFBaUIsT0FBTyxnQkFBZ0I7S0FDdkMsU0FBUztLQUNULE9BQU87SUFDUixDQUFDLEdBQUcsVUFBVSxDQUFDLENBQUMsTUFBTSxJQUFJO0lBQzFCO0dBQ0Q7R0FDQSxrQkFBa0I7R0FDbEIsTUFBTSxPQUFPLGFBQWE7R0FDMUIsSUFBSSxhQUFhLEtBQUssT0FBTyxtQkFBbUIsYUFBYSxLQUFLLFVBQVUsS0FBSyxLQUFLLENBQUM7R0FDdkYsU0FBUyxZQUFZLElBQUksQ0FBQyxDQUFDLE9BQU8sVUFBVTtJQUMzQyxJQUFJLG9CQUFvQixPQUFPLEVBQUUsR0FBRyxPQUFPO0lBQzNDLElBQUksb0JBQW9CLE9BQU8sQ0FBQyxHQUFHO0tBQ2xDLGlCQUFpQixPQUFPLGlCQUFpQixNQUFNLEVBQUUsR0FBRyxFQUFFLE9BQU8sS0FBSyxDQUFDLEdBQUcsVUFBVSxDQUFDLENBQUMsTUFBTSxZQUFZO01BQ25HLElBQUksb0JBQW9CLFNBQVMsRUFBRSxLQUFLLENBQUMsS0FBSyxTQUFTLEtBQUssU0FBUyxPQUFPLGNBQWMsR0FBRyxJQUFJLEtBQUs7S0FDdkcsQ0FBQyxDQUFDLENBQUMsTUFBTSxJQUFJO0tBQ2IsT0FBTyxRQUFRLE9BQU87SUFDdkI7SUFDQSxJQUFJLEtBQUssT0FBTyxjQUFjLEdBQUcsQ0FBQyxLQUFLLE9BQU8sS0FBSztJQUNuRCxPQUFPLGFBQWEsT0FBTyxZQUFZLElBQUk7R0FDNUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxZQUFZO0lBQ3BCLFVBQVUsV0FBVyxtQkFBbUIsWUFBWSxNQUFNLEtBQUs7SUFDL0QsSUFBSSxTQUFTO0tBQ1osSUFBSSxLQUFLLFNBQVMsQ0FBQyxvQkFBb0IsU0FBUyxDQUFDLEdBQUcsY0FBYyxHQUFHLENBQUMsS0FBSyxPQUFPLEtBQUs7VUFDbEYsSUFBSSxLQUFLLFNBQVMsU0FBUyxvQkFBb0IsU0FBUyxFQUFFLEdBQUcsY0FBYyxHQUFHLElBQUksS0FBSztJQUM3RjtJQUNBLGlCQUFpQixZQUFZLE1BQU0sT0FBTztHQUMzQyxDQUFDLENBQUMsQ0FBQyxNQUFNLElBQUk7RUFDZCxDQUFDO0NBQ0Y7Q0FDQSxJQUFJLGdCQUFnQixhQUFhO0NBQ2pDLElBQUksaUJBQWlCLGFBQWE7Q0FDbEMsSUFBSTs7Ozs7Ozs7O0NBU0osU0FBUyxhQUFhLE9BQU8sSUFBSSxNQUFNO0VBQ3RDLFlBQVksS0FBSztFQUNqQixNQUFNLE9BQU8sZUFBZSxLQUFLO0VBQ2pDLElBQUksS0FBSyxRQUFRLEtBQUssU0FBUyxZQUFZLFFBQVEsT0FBTyxJQUFJLElBQUksQ0FBQztPQUM5RDtHQUN1QyxZQUFZLGlCQUFpQjtHQUN4RSxRQUFRLE1BQU0sS0FBSztFQUNwQjtFQUNBLE9BQU8sUUFBUSxPQUFPLEtBQUs7Q0FDNUI7Q0FDQSxTQUFTLFVBQVU7RUFDbEIsSUFBSSxTQUFTLGFBQWEsVUFBVSwyQkFBMkIsT0FBTyxRQUFRLFFBQVE7RUFDdEYsT0FBTyxJQUFJLFNBQVMsU0FBUyxXQUFXO0dBQ3ZDLGNBQWMsSUFBSSxDQUFDLFNBQVMsTUFBTSxDQUFDO0VBQ3BDLENBQUM7Q0FDRjtDQUNBLFNBQVMsWUFBWSxLQUFLO0VBQ3pCLElBQUksQ0FBQyxPQUFPO0dBQ1gsUUFBUSxDQUFDO0dBQ1QsZUFBZTtHQUNmLGNBQWMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLFNBQVMsWUFBWSxNQUFNLE9BQU8sR0FBRyxJQUFJLFFBQVEsQ0FBQztHQUNqRixjQUFjLE1BQU07RUFDckI7RUFDQSxPQUFPO0NBQ1I7Q0FDQSxTQUFTLGFBQWEsSUFBSSxNQUFNLFFBQVEsbUJBQW1CO0VBQzFELE1BQU0sRUFBRSxtQkFBbUI7RUFDM0IsSUFBSSxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsT0FBTyxRQUFRLFFBQVE7RUFDMUQsTUFBTSxpQkFBaUIsQ0FBQyxVQUFVLHVCQUF1QixhQUFhLEdBQUcsVUFBVSxDQUFDLENBQUMsTUFBTSxxQkFBcUIsQ0FBQyxXQUFXLFFBQVEsU0FBUyxRQUFRLE1BQU0sVUFBVTtFQUNySyxPQUFPLFNBQVMsQ0FBQyxDQUFDLFdBQVcsZUFBZSxJQUFJLE1BQU0sY0FBYyxDQUFDLENBQUMsQ0FBQyxNQUFNLGFBQWEsT0FBTyxhQUFhLFNBQVMsWUFBWSxpQkFBaUIsUUFBUSxDQUFDLENBQUMsQ0FBQyxPQUFPLFFBQVEsT0FBTyxhQUFhLFNBQVMsYUFBYSxLQUFLLElBQUksSUFBSSxDQUFDO0NBQ3ZPO0NBQ0EsTUFBTSxNQUFNLFVBQVUsY0FBYyxHQUFHLEtBQUs7Q0FDNUMsSUFBSTtDQUNKLE1BQU0sZ0NBQWdDLElBQUksSUFBSTtDQUM5QyxNQUFNLFNBQVM7RUFDZDtFQUNBLFdBQVc7RUFDWDtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLFlBQVksR0FBRyxFQUFFO0VBQ2pCLGVBQWUsR0FBRyxDQUFDO0VBQ25CLFlBQVksYUFBYTtFQUN6QixlQUFlLG9CQUFvQjtFQUNuQyxXQUFXLFlBQVk7RUFDdkIsU0FBUyxlQUFlO0VBQ3hCO0VBQ0EsUUFBUSxLQUFLO0dBQ1osSUFBSSxVQUFVLGNBQWMsVUFBVTtHQUN0QyxJQUFJLFVBQVUsY0FBYyxVQUFVO0dBQ3RDLElBQUksT0FBTyxpQkFBaUIsVUFBVTtHQUN0QyxPQUFPLGVBQWUsSUFBSSxPQUFPLGtCQUFrQixVQUFVO0lBQzVELFlBQVk7SUFDWixXQUFXLE1BQU0sWUFBWTtHQUM5QixDQUFDO0dBQ0QsSUFBSSxhQUFhLENBQUMsV0FBVyxhQUFhLFVBQVUsMkJBQTJCO0lBQzlFLFVBQVU7SUFDVixLQUFLLGNBQWMsUUFBUSxDQUFDLENBQUMsT0FBTyxRQUFRO0tBQ0EsWUFBWSxpQkFBaUIsRUFBRSxPQUFPLElBQUksQ0FBQztJQUN2RixDQUFDO0dBQ0Y7R0FDQSxNQUFNLGdCQUFnQixDQUFDO0dBQ3ZCLEtBQUssTUFBTSxPQUFPLDJCQUEyQixPQUFPLGVBQWUsZUFBZSxLQUFLO0lBQ3RGLFdBQVcsYUFBYSxNQUFNO0lBQzlCLFlBQVk7R0FDYixDQUFDO0dBQ0QsSUFBSSxRQUFRLFdBQVcsTUFBTTtHQUM3QixJQUFJLFFBQVEsa0JBQWtCLGdCQUFnQixhQUFhLENBQUM7R0FDNUQsSUFBSSxRQUFRLHVCQUF1QixZQUFZO0dBQy9DLE1BQU0sYUFBYSxJQUFJO0dBQ3ZCLGNBQWMsSUFBSSxHQUFHO0dBQ3JCLElBQUksVUFBVSxXQUFXO0lBQ3hCLGNBQWMsT0FBTyxHQUFHO0lBQ3hCLElBQUksY0FBYyxPQUFPLEdBQUc7S0FDM0Isa0JBQWtCO0tBQ2xCLHlCQUF5QixzQkFBc0I7S0FDL0Msd0JBQXdCO0tBQ3hCLGFBQWEsUUFBUTtLQUNyQixVQUFVO0tBQ1YsUUFBUTtJQUNUO0lBQ0EsV0FBVztHQUNaO0dBQ0EsSUFBd0UsYUFBYSxNQUFNLFlBQVksS0FBSyxRQUFRLE9BQU87RUFDNUg7Q0FDRDtDQUNBLFNBQVMsY0FBYyxRQUFRO0VBQzlCLE9BQU8sT0FBTyxRQUFRLFNBQVMsVUFBVSxRQUFRLFdBQVcsZUFBZSxLQUFLLENBQUMsR0FBRyxRQUFRLFFBQVEsQ0FBQztDQUN0RztDQUNBLE9BQU87QUFDUiIsIm5hbWVzIjpbIl9fY3JlYXRlIiwiX19kZWZQcm9wIiwiX19nZXRPd25Qcm9wRGVzYyIsIl9fZ2V0T3duUHJvcE5hbWVzIiwiX19nZXRQcm90b09mIiwiX19oYXNPd25Qcm9wIiwiX19jb21tb25KU01pbiIsIl9fY29weVByb3BzIiwiX190b0VTTSIsImlzQnJvd3NlciJdLCJpZ25vcmVMaXN0IjpbMiwzLDZdLCJzb3VyY2VzIjpbIi4uLy4uL25vc3RpY3MvZGlzdC9pbmRleC5tanMiLCIuLi8uLi92dWUtcm91dGVyL2Rpc3QvdXNlQXBpLUJQdUk2WlI5LmpzIiwiLi4vLi4vdnVlLXJvdXRlci9ub2RlX21vZHVsZXMvQHZ1ZS9kZXZ0b29scy1zaGFyZWQvZGlzdC9pbmRleC5qcyIsIi4uLy4uL3Z1ZS1yb3V0ZXIvbm9kZV9tb2R1bGVzL3BlcmZlY3QtZGVib3VuY2UvZGlzdC9pbmRleC5tanMiLCIuLi8uLi9ob29rYWJsZS9kaXN0L2luZGV4Lm1qcyIsIi4uLy4uL2JpcnBjL2Rpc3QvaW5kZXgubWpzIiwiLi4vLi4vdnVlLXJvdXRlci9ub2RlX21vZHVsZXMvQHZ1ZS9kZXZ0b29scy1raXQvZGlzdC9pbmRleC5qcyIsIi4uLy4uL3Z1ZS1yb3V0ZXIvZGlzdC9kZXZ0b29scy1DTjV1V0phSC5qcyIsIi4uLy4uL3Z1ZS1yb3V0ZXIvZGlzdC92dWUtcm91dGVyLmpzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vI3JlZ2lvbiBzcmMvZm9ybWF0dGVycy9wbGFpbi50c1xuLyoqXG4qIFJlbmRlcnMgYSBkaWFnbm9zdGljIGludG8gYSBtdWx0aS1saW5lLCB1bmljb2RlLWRlY29yYXRlZCBzdHJpbmcgc3VpdGFibGVcbiogZm9yIHRlcm1pbmFsIG91dHB1dC4gVGhlIGZpcnN0IGxpbmUgaXMgYFs8bmFtZT5dIDxtZXNzYWdlPmA7IG9wdGlvbmFsXG4qIGRldGFpbHMgKGBmaXhgLCBgc291cmNlc2AsIGBkb2NzYCkgZm9sbG93IHdpdGggYOKUnOKWtmAvYOKVsOKWtmAgY29ubmVjdG9ycy5cbiovXG5mdW5jdGlvbiBmb3JtYXREaWFnbm9zdGljKGRpYWdub3N0aWMpIHtcblx0Y29uc3QgaGVhZGVyID0gYFske2RpYWdub3N0aWMubmFtZX1dICR7ZGlhZ25vc3RpYy5tZXNzYWdlfWA7XG5cdGNvbnN0IGRldGFpbHMgPSBbXTtcblx0aWYgKGRpYWdub3N0aWMuZml4KSBkZXRhaWxzLnB1c2goYGZpeDogJHtkaWFnbm9zdGljLmZpeH1gKTtcblx0aWYgKGRpYWdub3N0aWMuc291cmNlcz8ubGVuZ3RoKSBkZXRhaWxzLnB1c2goYHNvdXJjZXM6ICR7ZGlhZ25vc3RpYy5zb3VyY2VzLmpvaW4oXCIsIFwiKX1gKTtcblx0aWYgKGRpYWdub3N0aWMuZG9jcykgZGV0YWlscy5wdXNoKGBzZWU6ICR7ZGlhZ25vc3RpYy5kb2NzfWApO1xuXHRpZiAoZGV0YWlscy5sZW5ndGggPT09IDApIHJldHVybiBoZWFkZXI7XG5cdHJldHVybiBbaGVhZGVyLCAuLi5kZXRhaWxzLm1hcCgoZGV0YWlsLCBpKSA9PiB7XG5cdFx0cmV0dXJuIGAke2kgPCBkZXRhaWxzLmxlbmd0aCAtIDEgPyBcIuKUnOKWtlwiIDogXCLilbDilrZcIn0gJHtkZXRhaWx9YDtcblx0fSldLmpvaW4oXCJcXG5cIik7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvdXRpbHMudHNcbi8qKlxuKiBUcmFuc2Zvcm1zIGEgdmFsdWUgb3IgYSBmdW5jdGlvbiB0aGF0IHJldHVybnMgYSB2YWx1ZSB0byBhIHZhbHVlLlxuKlxuKiBAcGFyYW0gdmFsRm4gZWl0aGVyIGEgdmFsdWUgb3IgYSBmdW5jdGlvbiB0aGF0IHJldHVybnMgYSB2YWx1ZVxuKiBAcGFyYW0gYXJncyAgYXJndW1lbnRzIHRvIHBhc3MgdG8gdGhlIGZ1bmN0aW9uIGlmIGB2YWxGbmAgaXMgYSBmdW5jdGlvblxuKlxuKiBAaW50ZXJuYWxcbiovXG5mdW5jdGlvbiB0b1ZhbHVlV2l0aEFyZ3ModmFsRm4sIC4uLmFyZ3MpIHtcblx0cmV0dXJuIHR5cGVvZiB2YWxGbiA9PT0gXCJmdW5jdGlvblwiID8gdmFsRm4oLi4uYXJncykgOiB2YWxGbjtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9kaWFnbm9zdGljLnRzXG4vKipcbiogQ3JlYXRlcyBhIGNvbnNvbGUgcmVwb3J0ZXIgdGhhdCByZW5kZXJzIGVhY2ggZGlhZ25vc3RpYyB3aXRoIGBmb3JtYXR0ZXJgIGFuZFxuKiBwcmludHMgdGhlIHJlc3VsdCB2aWEgYGNvbnNvbGVbbWV0aG9kXWAuIEJvdGggZGVmYXVsdCBzZW5zaWJseSAoYCd3YXJuJ2AgYW5kXG4qIHtAbGluayBmb3JtYXREaWFnbm9zdGljfSk7IGBtZXRob2RgIGNhbiBhbHNvIGJlIG92ZXJyaWRkZW4gcGVyIGNhbGwgdGhyb3VnaFxuKiB0aGUgcmVwb3J0ZXIgb3B0aW9ucy5cbiovXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gY3JlYXRlQ29uc29sZVJlcG9ydGVyKHsgbWV0aG9kOiBkZWZhdWx0TWV0aG9kID0gXCJ3YXJuXCIsIGZvcm1hdHRlciA9IGZvcm1hdERpYWdub3N0aWMgfSA9IHt9KSB7XG5cdHJldHVybiAoZGlhZ25vc3RpYywgeyBtZXRob2QgPSBkZWZhdWx0TWV0aG9kIH0gPSB7fSkgPT4ge1xuXHRcdGNvbnNvbGVbbWV0aG9kXShmb3JtYXR0ZXIoZGlhZ25vc3RpYykpO1xuXHR9O1xufVxuY29uc3QgY2FwdHVyZVN0YWNrVHJhY2UgPSBFcnJvci5jYXB0dXJlU3RhY2tUcmFjZTtcbnZhciBEaWFnbm9zdGljID0gY2xhc3MgRGlhZ25vc3RpYyBleHRlbmRzIEVycm9yIHtcblx0bmFtZTtcblx0LyoqXG5cdCogVGhlIGRpYWdub3N0aWMgY29kZSwgZS5nLiBgTUFUSF9FMDAxYC5cblx0KiBBbHNvIGFwcGVhcnMgYXMgdGhlIGBuYW1lYCBwcm9wZXJ0eS5cblx0Ki9cblx0Y29kZTtcblx0LyoqXG5cdCogVVJMIHRvIGV4dGVuZGVkIGRvY3VtZW50YXRpb24gZm9yIHRoaXMgZGlhZ25vc3RpYyBjb2RlLlxuXHQqIEF1dG8tZ2VuZXJhdGVkIGZyb20ge0BsaW5rIERlZmluZURpYWdub3N0aWNzT3B0aW9ucy5kb2NzQmFzZX0uXG5cdCovXG5cdGRvY3M7XG5cdC8qKlxuXHQqIE9wdGlvbmFsIGFjdGlvbmFibGUgaW5zdHJ1Y3Rpb25zIG9uIGhvdyB0byByZXNvbHZlIHRoZSBwcm9ibGVtLlxuXHQqL1xuXHRmaXg7XG5cdC8qKlxuXHQqIExvY2F0aW9ucyBpbiB1c2VyIGNvZGUgdGhhdCBjb250cmlidXRlZCB0byB0aGlzIGRpYWdub3N0aWMsIGluXG5cdCogYGZpbGU6bGluZTpjb2x1bW5gIGZvcm1hdC4gUmVsZXZhbnQgd2hlbiB0aGUgc3RhY2sgdHJhY2UgZG9lc24ndCByZWZsZWN0XG5cdCogdGhlIHVzZXIncyBzb3VyY2UgKGUuZy4gY29tcGlsZXJzLCBidW5kbGVycyksIG90aGVyd2lzZSByZWR1bmRhbnQgd2l0aCB0aGVcblx0KiBzdGFjayBhbmQgc2hvdWxkIGJlIG9taXR0ZWQuXG5cdCovXG5cdHNvdXJjZXM7XG5cdC8qKlxuXHQqIEFsaWFzIGZvciB7QGxpbmsgRXJyb3IubWVzc2FnZX06IHRoZSByZWFzb24gdGhpcyBkaWFnbm9zdGljIHdhcyByYWlzZWQuXG5cdCovXG5cdGdldCB3aHkoKSB7XG5cdFx0cmV0dXJuIHRoaXMubWVzc2FnZTtcblx0fVxuXHQvKipcblx0KiBAcGFyYW0gaW5pdCAgICAgICAgc3RydWN0dXJlZCBpbml0aWFsaXplcjsgYHdoeWAgaXMgcmVxdWlyZWRcblx0KiBAcGFyYW0gY2FwdHVyZUZyb20gVjggc3RhY2stY3V0b2ZmIGZyYW1lLiBEZWZhdWx0cyB0byB7QGxpbmsgRGlhZ25vc3RpY31cblx0KiBzbyB0aGUgdG9wIG9mIHRoZSB0cmFjZSBpcyB0aGUgYG5ldyBEaWFnbm9zdGljKC4uLilgIGNhbGwgc2l0ZS5cblx0KiBgZGVmaW5lRGlhZ25vc3RpY3NgIHBhc3NlcyBpdHMgYWN0aW9uIG1ldGhvZCB0byBzdHJpcCBpdHMgb3duIGZyYW1lcyB0b28uXG5cdCogSWdub3JlZCBvbiBlbmdpbmVzIHdpdGhvdXQgYEVycm9yLmNhcHR1cmVTdGFja1RyYWNlYC5cblx0Ki9cblx0Y29uc3RydWN0b3IoaW5pdCwgY2FwdHVyZUZyb20gPSBEaWFnbm9zdGljKSB7XG5cdFx0c3VwZXIoaW5pdC53aHksIHsgY2F1c2U6IGluaXQuY2F1c2UgfSk7XG5cdFx0dGhpcy5jb2RlID0gdGhpcy5uYW1lID0gaW5pdC5jb2RlO1xuXHRcdHRoaXMuZml4ID0gaW5pdC5maXg7XG5cdFx0dGhpcy5kb2NzID0gaW5pdC5kb2NzO1xuXHRcdHRoaXMuc291cmNlcyA9IGluaXQuc291cmNlcztcblx0XHRjYXB0dXJlU3RhY2tUcmFjZT8uKHRoaXMsIGNhcHR1cmVGcm9tKTtcblx0fVxuXHQvKipcblx0KiBDb252ZXJ0cyB0aGUgZGlhZ25vc3RpYyBpbnRvIGEgc2VyaWFsaXphYmxlIHN0cnVjdHVyZWQgb2JqZWN0LlxuXHQqL1xuXHR0b0pTT04oKSB7XG5cdFx0cmV0dXJuIHtcblx0XHRcdG5hbWU6IHRoaXMubmFtZSxcblx0XHRcdHdoeTogdGhpcy53aHksXG5cdFx0XHRmaXg6IHRoaXMuZml4LFxuXHRcdFx0ZG9jczogdGhpcy5kb2NzLFxuXHRcdFx0c291cmNlczogdGhpcy5zb3VyY2VzLFxuXHRcdFx0Y2F1c2U6IHRoaXMuY2F1c2UsXG5cdFx0XHRzdGFjazogdGhpcy5zdGFja1xuXHRcdH07XG5cdH1cbn07XG4vKipcbiogUmVzb2x2ZXMgdGhlIGRvY3MgVVJMIGZvciBhIGNvZGUgZnJvbSBhIGBkb2NzQmFzZWAgKHN0cmluZyB0ZW1wbGF0ZSBvclxuKiByZXNvbHZlciBmdW5jdGlvbikuIFNoYXJlZCBieSB7QGxpbmsgZGVmaW5lRGlhZ25vc3RpY3N9IGFuZFxuKiB7QGxpbmsgZGVmaW5lUHJvZERpYWdub3N0aWNzfS4gUGVyLWNvZGUgYGRvY3NgIG92ZXJyaWRlcyBhcmUgaGFuZGxlZCBieSB0aGVcbiogY2FsbGVyOyB0aGlzIG9ubHkgY292ZXJzIHRoZSBgZG9jc0Jhc2VgLWRlcml2ZWQgY2FzZS5cbipcbiogQGludGVybmFsXG4qL1xuZnVuY3Rpb24gZGVyaXZlRG9jcyhkb2NzQmFzZSwgY29kZSkge1xuXHRyZXR1cm4gdHlwZW9mIGRvY3NCYXNlID09PSBcInN0cmluZ1wiID8gYCR7ZG9jc0Jhc2V9LyR7Y29kZS50b0xvd2VyQ2FzZSgpfWAgOiBkb2NzQmFzZT8uKGNvZGUpO1xufVxuLyoqXG4qIENyZWF0ZXMgYSB0eXBlZCBkaWFnbm9zdGljcyBvYmplY3QgZnJvbSBhIHNldCBvZiBjb2RlIGRlZmluaXRpb25zLiBFYWNoXG4qIGNvZGUgYmVjb21lcyBhIGNhbGxhYmxlIHtAbGluayBEaWFnbm9zdGljSGFuZGxlfTogaW52b2tlIHRvIHJlcG9ydCwgb3JcbiogYHRocm93YCB0aGUgcmVzdWx0IHRvIHJhaXNlLiBObyBgbmV3YCByZXF1aXJlZCwgbm8gcHJveHkuXG4qL1xuLyogQF9fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGRlZmluZURpYWdub3N0aWNzKG9wdGlvbnMpIHtcblx0Y29uc3QgcmVwb3J0ZXJzID0gb3B0aW9ucy5yZXBvcnRlcnMgPz8gW107XG5cdGNvbnN0IHJlc3VsdCA9IHt9O1xuXHRjb25zdCB7IGRvY3NCYXNlIH0gPSBvcHRpb25zO1xuXHRmb3IgKGNvbnN0IGNvZGUgb2YgT2JqZWN0LmtleXMob3B0aW9ucy5jb2RlcykpIHtcblx0XHRjb25zdCBkZWYgPSBvcHRpb25zLmNvZGVzW2NvZGVdO1xuXHRcdGNvbnN0IGRvY3MgPSBkZWYuZG9jcyA9PT0gZmFsc2UgPyB2b2lkIDAgOiBkZWYuZG9jcyB8fCBkZXJpdmVEb2NzKGRvY3NCYXNlLCBjb2RlKTtcblx0XHRjb25zdCBoYW5kbGUgPSAocGFyYW1zID0ge30sIHJlcG9ydGVyT3B0aW9ucyA9IHt9KSA9PiB7XG5cdFx0XHRjb25zdCBkaWFnbm9zdGljID0gbmV3IERpYWdub3N0aWMoe1xuXHRcdFx0XHRjb2RlLFxuXHRcdFx0XHR3aHk6IHRvVmFsdWVXaXRoQXJncyhkZWYud2h5LCBwYXJhbXMpLFxuXHRcdFx0XHRmaXg6IHRvVmFsdWVXaXRoQXJncyhkZWYuZml4LCBwYXJhbXMpLFxuXHRcdFx0XHRkb2NzLFxuXHRcdFx0XHRjYXVzZTogcGFyYW1zLmNhdXNlLFxuXHRcdFx0XHRzb3VyY2VzOiBwYXJhbXMuc291cmNlc1xuXHRcdFx0fSwgaGFuZGxlKTtcblx0XHRcdGZvciAoY29uc3QgcmVwb3J0ZXIgb2YgcmVwb3J0ZXJzKSByZXBvcnRlcihkaWFnbm9zdGljLCByZXBvcnRlck9wdGlvbnMpO1xuXHRcdFx0cmV0dXJuIGRpYWdub3N0aWM7XG5cdFx0fTtcblx0XHRyZXN1bHRbY29kZV0gPSBoYW5kbGU7XG5cdH1cblx0cmV0dXJuIHJlc3VsdDtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9wcm9kLWRpYWdub3N0aWNzLnRzXG4vKipcbiogUHJvZHVjdGlvbiBjb3VudGVycGFydCB0byB7QGxpbmsgZGVmaW5lRGlhZ25vc3RpY3N9LiBSZXR1cm5zIGEgYFByb3h5YCB0aGF0XG4qIGJ1aWxkcyBhIG1pbmltYWwge0BsaW5rIERpYWdub3N0aWN9IGZvciBhbnkgYWNjZXNzZWQgY29kZTogdGhlIGNvZGUgYmVjb21lc1xuKiB0aGUgaW5zdGFuY2UgYG5hbWVgLCBgZG9jc2AgaXMgZGVyaXZlZCBmcm9tIGBkb2NzQmFzZWAsIGFuZCBgd2h5YCBwb2ludHMgdG9cbiogdGhlIGRvY3MgVVJMIHdoZW4gb25lIGV4aXN0cyAoZW1wdHkgb3RoZXJ3aXNlLCBzbyB0aGUgdGhyb3duIGhlYWRlciBpcyBqdXN0XG4qIHRoZSBjb2RlKS4gSXQgY2FycmllcyBubyBjYXRhbG9nIHRleHQsIHNvIGl0IHN0YXlzIHRpbnkgaW4gYSBidW5kbGUuXG4qXG4qIFRoZSBzdHJpcCBwbHVnaW4gKGBAbm9zdGljcy91bnBsdWdpbmApIGNhbiByZXdyaXRlIGEgYGRlZmluZURpYWdub3N0aWNzKClgXG4qIGNhbGwgaW50byBhIGBwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gJ3Byb2R1Y3Rpb24nYCB0ZXJuYXJ5IHRoYXQgc2VsZWN0cyB0aGlzXG4qIGZhY3RvcnkgaW4gcHJvZHVjdGlvbiwgZHJvcHBpbmcgZXZlcnkgYHdoeWAvYGZpeGAgc3RyaW5nIGZyb20gdGhlIGJ1bmRsZS5cbipcbiogQGV4YW1wbGVcbiogYGBgdHNcbiogY29uc3QgZGlhZ25vc3RpY3MgPSBkZWZpbmVQcm9kRGlhZ25vc3RpY3MoeyBkb2NzQmFzZTogJ2h0dHBzOi8vZG9jcy5leGFtcGxlLmNvbScgfSlcbiogdGhyb3cgZGlhZ25vc3RpY3MuTlVYVF9CMjAxMSgpIC8vIE5VWFRfQjIwMTE6IGh0dHBzOi8vZG9jcy5leGFtcGxlLmNvbS9udXh0X2IyMDExXG4qIGBgYFxuKi9cbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBkZWZpbmVQcm9kRGlhZ25vc3RpY3Mob3B0aW9ucyA9IHt9KSB7XG5cdGNvbnN0IHsgZG9jc0Jhc2UsIHJlcG9ydGVycyA9IFtdIH0gPSBvcHRpb25zO1xuXHRyZXR1cm4gbmV3IFByb3h5KHt9LCB7IGdldChfdGFyZ2V0LCBjb2RlKSB7XG5cdFx0aWYgKHR5cGVvZiBjb2RlICE9PSBcInN0cmluZ1wiKSByZXR1cm4gdm9pZCAwO1xuXHRcdGNvbnN0IGhhbmRsZSA9IChwYXJhbXMgPSB7fSwgcmVwb3J0ZXJPcHRpb25zID0ge30pID0+IHtcblx0XHRcdGNvbnN0IGRvY3MgPSBkZXJpdmVEb2NzKGRvY3NCYXNlLCBjb2RlKTtcblx0XHRcdGNvbnN0IGRpYWdub3N0aWMgPSBuZXcgRGlhZ25vc3RpYyh7XG5cdFx0XHRcdGNvZGUsXG5cdFx0XHRcdHdoeTogZG9jcyA/PyBcIlwiLFxuXHRcdFx0XHRkb2NzLFxuXHRcdFx0XHRjYXVzZTogcGFyYW1zLmNhdXNlLFxuXHRcdFx0XHRzb3VyY2VzOiBwYXJhbXMuc291cmNlc1xuXHRcdFx0fSwgaGFuZGxlKTtcblx0XHRcdGZvciAoY29uc3QgcmVwb3J0ZXIgb2YgcmVwb3J0ZXJzKSByZXBvcnRlcihkaWFnbm9zdGljLCByZXBvcnRlck9wdGlvbnMpO1xuXHRcdFx0cmV0dXJuIGRpYWdub3N0aWM7XG5cdFx0fTtcblx0XHRyZXR1cm4gaGFuZGxlO1xuXHR9IH0pO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBEaWFnbm9zdGljLCBjcmVhdGVDb25zb2xlUmVwb3J0ZXIsIGRlZmluZURpYWdub3N0aWNzLCBkZWZpbmVQcm9kRGlhZ25vc3RpY3MsIGZvcm1hdERpYWdub3N0aWMgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5kZXgubWpzLm1hcCIsIi8qIVxuKiB2dWUtcm91dGVyIHY1LjMuMVxuKiAoYykgMjAyNiBFZHVhcmRvIFNhbiBNYXJ0aW4gTW9yb3RlXG4qIEBsaWNlbnNlIE1JVFxuKi9cbmltcG9ydCB7IGNyZWF0ZUNvbnNvbGVSZXBvcnRlciwgZGVmaW5lRGlhZ25vc3RpY3MgfSBmcm9tIFwibm9zdGljc1wiO1xuaW1wb3J0IHsgaW5qZWN0IH0gZnJvbSBcInZ1ZVwiO1xuLy8jcmVnaW9uIHNyYy91dGlscy9pbmRleC50c1xuLyoqXG4qIElkZW50aXR5IGZ1bmN0aW9uIHRoYXQgcmV0dXJucyB0aGUgdmFsdWUgYXMgaXMuXG4qXG4qIEBwYXJhbSB2IC0gdGhlIHZhbHVlIHRvIHJldHVyblxuKlxuKiBAaW50ZXJuYWxcbiovXG5jb25zdCBpZGVudGl0eUZuID0gKHYpID0+IHY7XG4vKipcbiogQ2hlY2tzIGlmIGEgcGF0aCBpcyBhYnNvbHV0ZSwgbWVhbmluZyBpdCBzdGFydHMgd2l0aCBhIGAvYC5cbipcbiogQHBhcmFtIHBhdGggLSBwYXRoIHRvIGNoZWNrXG4qXG4qIEBpbnRlcm5hbFxuKi9cbmNvbnN0IGlzQWJzb2x1dGVQYXRoID0gKHBhdGgpID0+IHBhdGguc3RhcnRzV2l0aChcIi9cIik7XG4vKipcbiogQWxsb3dzIGRpZmZlcmVudGlhdGluZyBsYXp5IGNvbXBvbmVudHMgZnJvbSBmdW5jdGlvbmFsIGNvbXBvbmVudHMgYW5kIHZ1ZS1jbGFzcy1jb21wb25lbnRcbiogQGludGVybmFsXG4qXG4qIEBwYXJhbSBjb21wb25lbnRcbiovXG5mdW5jdGlvbiBpc1JvdXRlQ29tcG9uZW50KGNvbXBvbmVudCkge1xuXHRyZXR1cm4gdHlwZW9mIGNvbXBvbmVudCA9PT0gXCJvYmplY3RcIiB8fCBcImRpc3BsYXlOYW1lXCIgaW4gY29tcG9uZW50IHx8IFwicHJvcHNcIiBpbiBjb21wb25lbnQgfHwgXCJfX3ZjY09wdHNcIiBpbiBjb21wb25lbnQ7XG59XG5mdW5jdGlvbiBpc0VTTW9kdWxlKG9iaikge1xuXHRyZXR1cm4gb2JqLl9fZXNNb2R1bGUgfHwgb2JqW1N5bWJvbC50b1N0cmluZ1RhZ10gPT09IFwiTW9kdWxlXCIgfHwgb2JqLmRlZmF1bHQgJiYgaXNSb3V0ZUNvbXBvbmVudChvYmouZGVmYXVsdCk7XG59XG5jb25zdCBhc3NpZ24gPSBPYmplY3QuYXNzaWduO1xuZnVuY3Rpb24gYXBwbHlUb1BhcmFtcyhmbiwgcGFyYW1zKSB7XG5cdGNvbnN0IG5ld1BhcmFtcyA9IHt9O1xuXHRmb3IgKGNvbnN0IGtleSBpbiBwYXJhbXMpIHtcblx0XHRjb25zdCB2YWx1ZSA9IHBhcmFtc1trZXldO1xuXHRcdG5ld1BhcmFtc1trZXldID0gaXNBcnJheSh2YWx1ZSkgPyB2YWx1ZS5tYXAoZm4pIDogZm4odmFsdWUpO1xuXHR9XG5cdHJldHVybiBuZXdQYXJhbXM7XG59XG5jb25zdCBub29wID0gKCkgPT4ge307XG4vKipcbiogVHlwZXNhZmUgYWx0ZXJuYXRpdmUgdG8gQXJyYXkuaXNBcnJheVxuKiBodHRwczovL2dpdGh1Yi5jb20vbWljcm9zb2Z0L1R5cGVTY3JpcHQvcHVsbC80ODIyOFxuKlxuKiBAaW50ZXJuYWxcbiovXG5jb25zdCBpc0FycmF5ID0gQXJyYXkuaXNBcnJheTtcbmZ1bmN0aW9uIG1lcmdlT3B0aW9ucyhkZWZhdWx0cywgcGFydGlhbE9wdGlvbnMpIHtcblx0Y29uc3Qgb3B0aW9ucyA9IHt9O1xuXHRmb3IgKGNvbnN0IGtleSBpbiBkZWZhdWx0cykgb3B0aW9uc1trZXldID0ga2V5IGluIHBhcnRpYWxPcHRpb25zID8gcGFydGlhbE9wdGlvbnNba2V5XSA6IGRlZmF1bHRzW2tleV07XG5cdHJldHVybiBvcHRpb25zO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2Vycm9ycy50c1xuY29uc3QgTmF2aWdhdGlvbkZhaWx1cmVTeW1ib2wgPSBTeW1ib2wocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gXCJuYXZpZ2F0aW9uIGZhaWx1cmVcIiA6IFwiXCIpO1xuLyoqXG4qIEVudW1lcmF0aW9uIHdpdGggYWxsIHBvc3NpYmxlIHR5cGVzIGZvciBuYXZpZ2F0aW9uIGZhaWx1cmVzLiBDYW4gYmUgcGFzc2VkIHRvXG4qIHtAbGluayBpc05hdmlnYXRpb25GYWlsdXJlfSB0byBjaGVjayBmb3Igc3BlY2lmaWMgZmFpbHVyZXMuXG4qL1xubGV0IE5hdmlnYXRpb25GYWlsdXJlVHlwZSA9IC8qIEBfX1BVUkVfXyAqLyBmdW5jdGlvbihOYXZpZ2F0aW9uRmFpbHVyZVR5cGUpIHtcblx0LyoqXG5cdCogQW4gYWJvcnRlZCBuYXZpZ2F0aW9uIGlzIGEgbmF2aWdhdGlvbiB0aGF0IGZhaWxlZCBiZWNhdXNlIGEgbmF2aWdhdGlvblxuXHQqIGd1YXJkIHJldHVybmVkIGBmYWxzZWAgb3IgY2FsbGVkIGBuZXh0KGZhbHNlKWBcblx0Ki9cblx0TmF2aWdhdGlvbkZhaWx1cmVUeXBlW05hdmlnYXRpb25GYWlsdXJlVHlwZVtcImFib3J0ZWRcIl0gPSA0XSA9IFwiYWJvcnRlZFwiO1xuXHQvKipcblx0KiBBIGNhbmNlbGxlZCBuYXZpZ2F0aW9uIGlzIGEgbmF2aWdhdGlvbiB0aGF0IGZhaWxlZCBiZWNhdXNlIGEgbW9yZSByZWNlbnRcblx0KiBuYXZpZ2F0aW9uIGZpbmlzaGVkIHN0YXJ0ZWQgKG5vdCBuZWNlc3NhcmlseSBmaW5pc2hlZCkuXG5cdCovXG5cdE5hdmlnYXRpb25GYWlsdXJlVHlwZVtOYXZpZ2F0aW9uRmFpbHVyZVR5cGVbXCJjYW5jZWxsZWRcIl0gPSA4XSA9IFwiY2FuY2VsbGVkXCI7XG5cdC8qKlxuXHQqIEEgZHVwbGljYXRlZCBuYXZpZ2F0aW9uIGlzIGEgbmF2aWdhdGlvbiB0aGF0IGZhaWxlZCBiZWNhdXNlIGl0IHdhc1xuXHQqIGluaXRpYXRlZCB3aGlsZSBhbHJlYWR5IGJlaW5nIGF0IHRoZSBleGFjdCBzYW1lIGxvY2F0aW9uLlxuXHQqL1xuXHROYXZpZ2F0aW9uRmFpbHVyZVR5cGVbTmF2aWdhdGlvbkZhaWx1cmVUeXBlW1wiZHVwbGljYXRlZFwiXSA9IDE2XSA9IFwiZHVwbGljYXRlZFwiO1xuXHRyZXR1cm4gTmF2aWdhdGlvbkZhaWx1cmVUeXBlO1xufSh7fSk7XG5jb25zdCBFcnJvclR5cGVNZXNzYWdlcyA9IHtcblx0WzFdKHsgbG9jYXRpb24sIGN1cnJlbnRMb2NhdGlvbiB9KSB7XG5cdFx0cmV0dXJuIGBObyBtYXRjaCBmb3JcXG4gJHtKU09OLnN0cmluZ2lmeShsb2NhdGlvbil9JHtjdXJyZW50TG9jYXRpb24gPyBcIlxcbndoaWxlIGJlaW5nIGF0XFxuXCIgKyBKU09OLnN0cmluZ2lmeShjdXJyZW50TG9jYXRpb24pIDogXCJcIn1gO1xuXHR9LFxuXHRbMl0oeyBmcm9tLCB0byB9KSB7XG5cdFx0cmV0dXJuIGBSZWRpcmVjdGVkIGZyb20gXCIke2Zyb20uZnVsbFBhdGh9XCIgdG8gXCIke3N0cmluZ2lmeVJvdXRlKHRvKX1cIiB2aWEgYSBuYXZpZ2F0aW9uIGd1YXJkLmA7XG5cdH0sXG5cdFs0XSh7IGZyb20sIHRvIH0pIHtcblx0XHRyZXR1cm4gYE5hdmlnYXRpb24gYWJvcnRlZCBmcm9tIFwiJHtmcm9tLmZ1bGxQYXRofVwiIHRvIFwiJHt0by5mdWxsUGF0aH1cIiB2aWEgYSBuYXZpZ2F0aW9uIGd1YXJkLmA7XG5cdH0sXG5cdFs4XSh7IGZyb20sIHRvIH0pIHtcblx0XHRyZXR1cm4gYE5hdmlnYXRpb24gY2FuY2VsbGVkIGZyb20gXCIke2Zyb20uZnVsbFBhdGh9XCIgdG8gXCIke3RvLmZ1bGxQYXRofVwiIHdpdGggYSBuZXcgbmF2aWdhdGlvbi5gO1xuXHR9LFxuXHRbMTZdKHsgZnJvbSwgdG86IF90byB9KSB7XG5cdFx0cmV0dXJuIGBBdm9pZGVkIHJlZHVuZGFudCBuYXZpZ2F0aW9uIHRvIGN1cnJlbnQgbG9jYXRpb246IFwiJHtmcm9tLmZ1bGxQYXRofVwiLmA7XG5cdH1cbn07XG4vKipcbiogQ3JlYXRlcyBhIHR5cGVkIE5hdmlnYXRpb25GYWlsdXJlIG9iamVjdC5cbiogQGludGVybmFsXG4qIEBwYXJhbSB0eXBlIC0gTmF2aWdhdGlvbkZhaWx1cmVUeXBlXG4qIEBwYXJhbSBwYXJhbXMgLSB7IGZyb20sIHRvIH1cbiovXG5mdW5jdGlvbiBjcmVhdGVSb3V0ZXJFcnJvcih0eXBlLCBwYXJhbXMpIHtcblx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiB8fCBmYWxzZSkgcmV0dXJuIGFzc2lnbihuZXcgRXJyb3IoRXJyb3JUeXBlTWVzc2FnZXNbdHlwZV0ocGFyYW1zKSksIHtcblx0XHR0eXBlLFxuXHRcdFtOYXZpZ2F0aW9uRmFpbHVyZVN5bWJvbF06IHRydWVcblx0fSwgcGFyYW1zKTtcblx0ZWxzZSByZXR1cm4gYXNzaWduKC8qIEBfX1BVUkVfXyAqLyBuZXcgRXJyb3IoKSwge1xuXHRcdHR5cGUsXG5cdFx0W05hdmlnYXRpb25GYWlsdXJlU3ltYm9sXTogdHJ1ZVxuXHR9LCBwYXJhbXMpO1xufVxuZnVuY3Rpb24gaXNOYXZpZ2F0aW9uRmFpbHVyZShlcnJvciwgdHlwZSkge1xuXHRyZXR1cm4gZXJyb3IgaW5zdGFuY2VvZiBFcnJvciAmJiBOYXZpZ2F0aW9uRmFpbHVyZVN5bWJvbCBpbiBlcnJvciAmJiAodHlwZSA9PSBudWxsIHx8ICEhKGVycm9yLnR5cGUgJiB0eXBlKSk7XG59XG5jb25zdCBwcm9wZXJ0aWVzVG9Mb2cgPSBbXG5cdFwicGFyYW1zXCIsXG5cdFwicXVlcnlcIixcblx0XCJoYXNoXCJcbl07XG4vKipcbiogU3RyaW5naWZpZXMgYSByYXcgbG9jYXRpb24gZm9yIGRpc3BsYXkgaW4gZGV2IHdhcm5pbmdzLlxuKlxuKiBAaW50ZXJuYWxcbiovXG5mdW5jdGlvbiBzdHJpbmdpZnlSb3V0ZSh0bykge1xuXHRpZiAoIXRvIHx8IHR5cGVvZiB0byA9PT0gXCJzdHJpbmdcIikgcmV0dXJuIHRvO1xuXHRpZiAodG8ucGF0aCAhPSBudWxsKSByZXR1cm4gdG8ucGF0aDtcblx0Y29uc3QgbG9jYXRpb24gPSB7fTtcblx0Zm9yIChjb25zdCBrZXkgb2YgcHJvcGVydGllc1RvTG9nKSBpZiAoa2V5IGluIHRvKSBsb2NhdGlvbltrZXldID0gdG9ba2V5XTtcblx0cmV0dXJuIEpTT04uc3RyaW5naWZ5KGxvY2F0aW9uLCBudWxsLCAyKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9kaWFnbm9zdGljcy50c1xuLyoqXG4qIFJ1bnRpbWUgZGlhZ25vc3RpY3MgY2F0YWxvZyBmb3IgVnVlIFJvdXRlci5cbipcbiogRXZlcnkgZW50cnkgaGFzIGEgc3RhYmxlIGBWVUVfUk9VVEVSX1IjIyMjYCBjb2RlLCBhIGB3aHlgIHRoYXQgc3RhdGVzIHRoZSBwcm9ibGVtXG4qICh0aGUgZGlhZ25vc2lzIG9ubHksIG5ldmVyIHRoZSByZW1lZHkpIGFuZCBhIGBmaXhgIHRoYXQgc3RhdGVzIHRoZSByZW1lZHlcbiogKG9ubHksIG5ldmVyIHRoZSBkaWFnbm9zaXMpLiBUaGV5IGFyZSBjb21wbGVtZW50YXJ5OiB0aGUgcmVwb3J0ZXIgcHJpbnRzXG4qIGJvdGgsIHNvIG5laXRoZXIgcmVwZWF0cyB0aGUgb3RoZXIuIFRoZSBkaWFnbm9zaXMgc3Vic3RyaW5ncyBhc3NlcnRlZCBieSB0aGVcbiogd2FybmluZyB0ZXN0cyBzdGF5IGluIGB3aHlgLiBBbGwgY2FsbCBzaXRlcyBzdGF5IGJlaGluZCB0aGUgZXhpc3RpbmcgYF9fREVWX19gIChvclxuKiBgcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJ2ApIGd1YXJkcyBhbmQgcmVtYWluIGJhcmUgZXhwcmVzc2lvblxuKiBzdGF0ZW1lbnRzIHNvIHRoZXkgdHJlZS1zaGFrZSBvdXQgb2YgcHJvZHVjdGlvbiBidWlsZHMuXG4qXG4qIENvZGVzIGFyZSBwZXJtYW5lbnQ6IG5ldmVyIHJlbmFtZSBvciByZXVzZSBvbmUuXG4qIC0gYFZVRV9ST1VURVJfUjAjIyNgIGNvcmUgcnVudGltZSB3YXJuaW5nc1xuKiAtIGBWVUVfUk9VVEVSX1IxIyMjYCBleHBlcmltZW50YWwgZGF0YS1sb2FkZXJzXG4qL1xuY29uc3QgZGlhZ25vc3RpY3MgPSAvKiNfX1BVUkVfXyovIGRlZmluZURpYWdub3N0aWNzKHtcblx0cmVwb3J0ZXJzOiBbLyojX19QVVJFX18qLyBjcmVhdGVDb25zb2xlUmVwb3J0ZXIoKV0sXG5cdGNvZGVzOiB7XG5cdFx0VlVFX1JPVVRFUl9SMDAwMToge1xuXHRcdFx0d2h5OiAocCkgPT4gYFBhcmVudCByb3V0ZSBcIiR7cC5uYW1lfVwiIG5vdCBmb3VuZCB3aGVuIGFkZGluZyBjaGlsZCByb3V0ZWAsXG5cdFx0XHRmaXg6IFwiQWRkIHRoZSBwYXJlbnQgcm91dGUgYmVmb3JlIGl0cyBjaGlsZHJlbiwgb3IgY2hlY2sgdGhlIHBhcmVudCBuYW1lIGZvciB0eXBvcy5cIixcblx0XHRcdGRvY3M6IFwiaHR0cHM6Ly9yb3V0ZXIudnVlanMub3JnL2d1aWRlL2FkdmFuY2VkL2R5bmFtaWMtcm91dGluZy5odG1sI0FkZGluZy1uZXN0ZWQtcm91dGVzXCJcblx0XHR9LFxuXHRcdFZVRV9ST1VURVJfUjAwMDI6IHtcblx0XHRcdHdoeTogKHApID0+IGBDYW5ub3QgcmVtb3ZlIG5vbi1leGlzdGVudCByb3V0ZSBcIiR7cC5uYW1lfVwiYCxcblx0XHRcdGZpeDogXCJDaGVjayB0aGUgcm91dGUgbmFtZTsgaXQgbWF5IGFscmVhZHkgaGF2ZSBiZWVuIHJlbW92ZWQgb3Igd2FzIG5ldmVyIGFkZGVkLlwiLFxuXHRcdFx0ZG9jczogXCJodHRwczovL3JvdXRlci52dWVqcy5vcmcvZ3VpZGUvYWR2YW5jZWQvZHluYW1pYy1yb3V0aW5nLmh0bWwjUmVtb3Zpbmctcm91dGVzXCJcblx0XHR9LFxuXHRcdFZVRV9ST1VURVJfUjAwMDM6IHtcblx0XHRcdHdoeTogKHApID0+IGBMb2NhdGlvbiBcIiR7c3RyaW5naWZ5Um91dGUocC5sb2NhdGlvbil9XCIgcmVzb2x2ZWQgdG8gXCIke3AuaHJlZn1cIi4gQSByZXNvbHZlZCBsb2NhdGlvbiBjYW5ub3Qgc3RhcnQgd2l0aCBtdWx0aXBsZSBzbGFzaGVzLmAsXG5cdFx0XHRmaXg6IFwiUmVtb3ZlIHRoZSBsZWFkaW5nIHNsYXNoZXMgZnJvbSB0aGUgbG9jYXRpb24gb3IgZml4IHRoZSByb3V0ZSBjb25maWd1cmF0aW9uLlwiXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IwMDA0OiB7XG5cdFx0XHR3aHk6IChwKSA9PiBgTm8gbWF0Y2ggZm91bmQgZm9yIGxvY2F0aW9uIHdpdGggcGF0aCBcIiR7c3RyaW5naWZ5Um91dGUocC5wYXRoKX1cImAsXG5cdFx0XHRmaXg6IFwiQWRkIGEgcm91dGUgbWF0Y2hpbmcgdGhpcyBwYXRoIG9yIGNoZWNrIGZvciB0eXBvcyBpbiB0aGUgbG9jYXRpb24uXCIsXG5cdFx0XHRkb2NzOiBcImh0dHBzOi8vcm91dGVyLnZ1ZWpzLm9yZy9ndWlkZS9lc3NlbnRpYWxzL2R5bmFtaWMtbWF0Y2hpbmcuaHRtbCNDYXRjaC1hbGwtNDA0LU5vdC1mb3VuZC1Sb3V0ZVwiXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IwMDA1OiB7XG5cdFx0XHR3aHk6IChwKSA9PiBgcm91dGVyLnJlc29sdmUoKSB3YXMgcGFzc2VkIGFuIGludmFsaWQgbG9jYXRpb24uIFRoaXMgd2lsbCBmYWlsIGluIHByb2R1Y3Rpb24uXFxuTG9jYXRpb246ICR7c3RyaW5naWZ5Um91dGUocC5yYXdMb2NhdGlvbil9YCxcblx0XHRcdGZpeDogXCJQYXNzIGEgdmFsaWQgcm91dGUgbG9jYXRpb246IGEgc3RyaW5nIHBhdGggb3IgYW4gb2JqZWN0IHdpdGggYHBhdGhgIG9yIGBuYW1lYC5cIlxuXHRcdH0sXG5cdFx0VlVFX1JPVVRFUl9SMDAwNjoge1xuXHRcdFx0d2h5OiAocCkgPT4gYFBhdGggXCIke3AucGF0aH1cIiB3YXMgcGFzc2VkIHdpdGggcGFyYW1zIGJ1dCB0aGV5IHdpbGwgYmUgaWdub3JlZCBiZWNhdXNlIGEgXCJwYXRoXCIgd2FzIHBhc3NlZC5gLFxuXHRcdFx0Zml4OiBcIlVzZSBhIG5hbWVkIHJvdXRlIGB7IG5hbWUsIHBhcmFtcyB9YCBpbnN0ZWFkIG9mIGB7IHBhdGgsIHBhcmFtcyB9YC5cIixcblx0XHRcdGRvY3M6IFwiaHR0cHM6Ly9yb3V0ZXIudnVlanMub3JnL2d1aWRlL2Vzc2VudGlhbHMvbmF2aWdhdGlvbi5odG1sI05hdmlnYXRlLXRvLWEtZGlmZmVyZW50LWxvY2F0aW9uXCJcblx0XHR9LFxuXHRcdFZVRV9ST1VURVJfUjAwMDc6IHtcblx0XHRcdHdoeTogKHApID0+IGBBIFxcYGhhc2hcXGAgc2hvdWxkIGFsd2F5cyBzdGFydCB3aXRoIHRoZSBjaGFyYWN0ZXIgXCIjXCIgYnV0IHJlY2VpdmVkIFwiJHtwLmhhc2h9XCIuYCxcblx0XHRcdGZpeDogKHApID0+IGBQcmVwZW5kIFwiI1wiIHRvIHRoZSBoYXNoIGluIHlvdXIgcm91dGUgbG9jYXRpb246IHVzZSBcIiMke3AuaGFzaH1cIi5gXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IwMDA4OiB7XG5cdFx0XHR3aHk6IChwKSA9PiBgSW52YWxpZCByZWRpcmVjdCBmb3VuZDpcXG4ke3AudGFyZ2V0fVxcbiB3aGVuIG5hdmlnYXRpbmcgdG8gXCIke3AudG99XCIuXFxuVGhpcyB3aWxsIGJyZWFrIGluIHByb2R1Y3Rpb24uYCxcblx0XHRcdGZpeDogXCJBIHJlZGlyZWN0IG11c3QgcmVzb2x2ZSB0byBhIGxvY2F0aW9uIHdpdGggYSBgbmFtZWAgb3IgYHBhdGhgOyByZXR1cm4gb25lIG9mIHRob3NlIChvciBhIHN0cmluZyBwYXRoKSBmcm9tIGByZWRpcmVjdGAuXCIsXG5cdFx0XHRkb2NzOiBcImh0dHBzOi8vcm91dGVyLnZ1ZWpzLm9yZy9ndWlkZS9lc3NlbnRpYWxzL3JlZGlyZWN0LWFuZC1hbGlhcy5odG1sI1JlZGlyZWN0XCJcblx0XHR9LFxuXHRcdFZVRV9ST1VURVJfUjAwMDk6IHtcblx0XHRcdHdoeTogKHApID0+IGBEZXRlY3RlZCBhIHBvc3NpYmx5IGluZmluaXRlIHJlZGlyZWN0aW9uIGluIGEgbmF2aWdhdGlvbiBndWFyZCB3aGVuIGdvaW5nIGZyb20gXCIke3AuZnJvbX1cIiB0byBcIiR7cC50b31cIi4gQWJvcnRpbmcgdG8gYXZvaWQgYSBTdGFjayBPdmVyZmxvdy4gVGhpcyBtaWdodCBicmVhayBpbiBwcm9kdWN0aW9uIGlmIG5vdCBmaXhlZC5gLFxuXHRcdFx0Zml4OiBcIkEgZ3VhcmQgaXMgcmV0dXJuaW5nIGEgbmV3IGxvY2F0aW9uIG9uIGV2ZXJ5IGNhbGw7IG1ha2UgdGhhdCByZXR1cm4gY29uZGl0aW9uYWwgc28gaXQgb25seSByZWRpcmVjdHMgd2hlbiBhY3R1YWxseSBuZWVkZWQuXCIsXG5cdFx0XHRkb2NzOiBcImh0dHBzOi8vcm91dGVyLnZ1ZWpzLm9yZy9ndWlkZS9hZHZhbmNlZC9uYXZpZ2F0aW9uLWd1YXJkcy5odG1sI0dsb2JhbC1CZWZvcmUtR3VhcmRzXCJcblx0XHR9LFxuXHRcdFZVRV9ST1VURVJfUjAwMTA6IHtcblx0XHRcdHdoeTogXCJVbmNhdWdodCBlcnJvciBkdXJpbmcgcm91dGUgbmF2aWdhdGlvblwiLFxuXHRcdFx0Zml4OiBcIlJlZ2lzdGVyIGFuIGVycm9yIGhhbmRsZXIgd2l0aCBgcm91dGVyLm9uRXJyb3IoKWAgdG8gaGFuZGxlIG5hdmlnYXRpb24gZXJyb3JzLlwiXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IwMDExOiB7XG5cdFx0XHR3aHk6IFwiVW5leHBlY3RlZCBlcnJvciB3aGVuIHN0YXJ0aW5nIHRoZSByb3V0ZXI6XCIsXG5cdFx0XHRmaXg6IFwiSW5zcGVjdCB0aGUgYWN0dWFsIGNhdXNlOyBhIG5hdmlnYXRpb24gZ3VhcmQgb3IgYXN5bmMgY29tcG9uZW50IGxpa2VseSB0aHJldyBkdXJpbmcgdGhlIGluaXRpYWwgbmF2aWdhdGlvbi5cIlxuXHRcdH0sXG5cdFx0VlVFX1JPVVRFUl9SMDAyMDoge1xuXHRcdFx0d2h5OiAocCkgPT4gYE5vIGFjdGl2ZSByb3V0ZSByZWNvcmQgd2FzIGZvdW5kIHdoZW4gY2FsbGluZyBcXGAke3AuZm59KClcXGAuIE1heWJlIHlvdSBjYWxsZWQgaXQgaW5zaWRlIG9mIEFwcC52dWU/YCxcblx0XHRcdGZpeDogXCJDYWxsIGl0IGZyb20gYSBjb21wb25lbnQgcmVuZGVyZWQgaW5zaWRlIDxyb3V0ZXItdmlldz4gKGEgcGFnZSBjb21wb25lbnQgb3Igb25lIG9mIGl0cyBjaGlsZHJlbiksIG5vdCBmcm9tIEFwcC52dWUuXCIsXG5cdFx0XHRkb2NzOiBcImh0dHBzOi8vcm91dGVyLnZ1ZWpzLm9yZy9ndWlkZS9hZHZhbmNlZC9jb21wb3NpdGlvbi1hcGkuaHRtbCNOYXZpZ2F0aW9uLUd1YXJkc1wiXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IwMDIxOiB7XG5cdFx0XHR3aHk6IFwiTm8gYWN0aXZlIHJvdXRlIHJlY29yZCB3YXMgZm91bmQgd2hlbiByZWFjdGl2YXRpbmcgY29tcG9uZW50IHdpdGggbmF2aWdhdGlvbiBndWFyZC4gVGhpcyBpcyBsaWtlbHkgYSBidWcgaW4gdnVlLXJvdXRlci5cIixcblx0XHRcdGZpeDogXCJSZXBvcnQgd2l0aCBhIG1pbmltYWwgcmVwcm9kdWN0aW9uIGF0IGh0dHBzOi8vZ2l0aHViLmNvbS92dWVqcy9yb3V0ZXIvaXNzdWVzL25ldy9jaG9vc2UuXCJcblx0XHR9LFxuXHRcdFZVRV9ST1VURVJfUjAwMjI6IHtcblx0XHRcdHdoeTogKHApID0+IGAke3AuZm59KCkgd2FzIGNhbGxlZCBvdXRzaWRlIG9mIGNvbXBvbmVudCBzZXR1cCBidXQgaXQgbXVzdCBiZSBjYWxsZWQgYXQgdGhlIHRvcCBvZiBhIHNldHVwIGZ1bmN0aW9uYCxcblx0XHRcdGZpeDogXCJDYWxsIGl0IHN5bmNocm9ub3VzbHkgYXQgdGhlIHRvcCBvZiBgc2V0dXAoKWAsIGJlZm9yZSBhbnkgYGF3YWl0YC5cIixcblx0XHRcdGRvY3M6IFwiaHR0cHM6Ly9yb3V0ZXIudnVlanMub3JnL2d1aWRlL2FkdmFuY2VkL2NvbXBvc2l0aW9uLWFwaS5odG1sI05hdmlnYXRpb24tR3VhcmRzXCJcblx0XHR9LFxuXHRcdFZVRV9ST1VURVJfUjAwMjM6IHtcblx0XHRcdHdoeTogKHApID0+IGBUaGUgXCJuZXh0XCIgY2FsbGJhY2sgd2FzIG5ldmVyIGNhbGxlZCBpbnNpZGUgb2YgJHtwLm5hbWUgPyBgXCIke3AubmFtZX1cImAgOiBcIlwifTpcXG4ke3AuZ3VhcmR9YCxcblx0XHRcdGZpeDogXCJNYWtlIHN1cmUgYG5leHQoKWAgcnVucyBvbiBldmVyeSBicmFuY2gsIGluY2x1ZGluZyBlYXJseSByZXR1cm5zIGFuZCBhc3luYyBwYXRocywgb3IgZHJvcCB0aGUgYG5leHRgIHBhcmFtZXRlciBhbmQgcmV0dXJuIHRoZSB2YWx1ZSBpbnN0ZWFkLlwiLFxuXHRcdFx0ZG9jczogXCJodHRwczovL3JvdXRlci52dWVqcy5vcmcvZ3VpZGUvYWR2YW5jZWQvbmF2aWdhdGlvbi1ndWFyZHMuaHRtbCNPcHRpb25hbC10aGlyZC1hcmd1bWVudC1uZXh0XCJcblx0XHR9LFxuXHRcdFZVRV9ST1VURVJfUjAwMjQ6IHtcblx0XHRcdHdoeTogKHApID0+IGBUaGUgXCJuZXh0XCIgY2FsbGJhY2sgd2FzIGNhbGxlZCBtb3JlIHRoYW4gb25jZSBpbiBvbmUgbmF2aWdhdGlvbiBndWFyZCB3aGVuIGdvaW5nIGZyb20gXCIke3AuZnJvbX1cIiB0byBcIiR7cC50b31cIi4gVGhpcyB3aWxsIGZhaWwgaW4gcHJvZHVjdGlvbi5gLFxuXHRcdFx0Zml4OiBcIkNhbGwgYG5leHQoKWAgZXhhY3RseSBvbmNlIHBlciBndWFyZDogcmVtb3ZlIHRoZSBleHRyYSBjYWxsLCBvciBtaWdyYXRlIHRvIHJldHVybmluZyB0aGUgdmFsdWUgeW91IHBhc3NlZCB0byBgbmV4dCgpYC5cIixcblx0XHRcdGRvY3M6IFwiaHR0cHM6Ly9yb3V0ZXIudnVlanMub3JnL2d1aWRlL2FkdmFuY2VkL25hdmlnYXRpb24tZ3VhcmRzLmh0bWwjT3B0aW9uYWwtdGhpcmQtYXJndW1lbnQtbmV4dFwiXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IwMDI1OiB7XG5cdFx0XHR3aHk6IFwiVGhlIGBuZXh0KClgIGNhbGxiYWNrIGluIG5hdmlnYXRpb24gZ3VhcmRzIGlzIGRlcHJlY2F0ZWQuXCIsXG5cdFx0XHRmaXg6IFwiUmV0dXJuIHRoZSB2YWx1ZSBpbnN0ZWFkOiBgbmV4dCgpYCBiZWNvbWVzIGByZXR1cm5gLCBgbmV4dChmYWxzZSlgIGJlY29tZXMgYHJldHVybiBmYWxzZWAsIGBuZXh0KFxcXCIvcGF0aFxcXCIpYCBiZWNvbWVzIGByZXR1cm4gXFxcIi9wYXRoXFxcImAuXCIsXG5cdFx0XHRkb2NzOiBcImh0dHBzOi8vcm91dGVyLnZ1ZWpzLm9yZy9ndWlkZS9hZHZhbmNlZC9uYXZpZ2F0aW9uLWd1YXJkcy5odG1sI09wdGlvbmFsLXRoaXJkLWFyZ3VtZW50LW5leHRcIlxuXHRcdH0sXG5cdFx0VlVFX1JPVVRFUl9SMDAyNjoge1xuXHRcdFx0d2h5OiAocCkgPT4gYFJlY29yZCB3aXRoIHBhdGggXCIke3AucGF0aH1cIiBpcyBlaXRoZXIgbWlzc2luZyBhIFwiY29tcG9uZW50KHMpXCIgb3IgXCJjaGlsZHJlblwiIHByb3BlcnR5LmAsXG5cdFx0XHRmaXg6IFwiQWRkIGEgYGNvbXBvbmVudGAsIGBjb21wb25lbnRzYCwgb3IgYGNoaWxkcmVuYCB0byB0aGUgcm91dGUgcmVjb3JkLlwiLFxuXHRcdFx0ZG9jczogXCJodHRwczovL3JvdXRlci52dWVqcy5vcmcvZ3VpZGUvZXNzZW50aWFscy9uZXN0ZWQtcm91dGVzLmh0bWxcIlxuXHRcdH0sXG5cdFx0VlVFX1JPVVRFUl9SMDAyNzoge1xuXHRcdFx0d2h5OiAocCkgPT4gYENvbXBvbmVudCBcIiR7cC5uYW1lfVwiIGluIHJlY29yZCB3aXRoIHBhdGggXCIke3AucGF0aH1cIiBpcyBub3QgYSB2YWxpZCBjb21wb25lbnQuIFJlY2VpdmVkIFwiJHtwLnJlY2VpdmVkfVwiLmAsXG5cdFx0XHRmaXg6IFwiUGFzcyBhIGNvbXBvbmVudCBvciBhIGZ1bmN0aW9uIHJldHVybmluZyBhIFByb21pc2UgdGhhdCByZXNvbHZlcyB0byBvbmUuXCJcblx0XHR9LFxuXHRcdFZVRV9ST1VURVJfUjAwMjg6IHtcblx0XHRcdHdoeTogKHApID0+IGBDb21wb25lbnQgXCIke3AubmFtZX1cIiBpbiByZWNvcmQgd2l0aCBwYXRoIFwiJHtwLnBhdGh9XCIgaXMgYSBQcm9taXNlIGluc3RlYWQgb2YgYSBmdW5jdGlvbiB0aGF0IHJldHVybnMgYSBQcm9taXNlLiBUaGlzIHdpbGwgYnJlYWsgaW4gcHJvZHVjdGlvbiBpZiBub3QgZml4ZWQuYCxcblx0XHRcdGZpeDogYERlZmVyIHRoZSBpbXBvcnQgaW4gYW4gYXJyb3cgZnVuY3Rpb24gc28gaXQgbG9hZHMgbGF6aWx5OiB3cml0ZSBcIigpID0+IGltcG9ydCgnLi9NeVBhZ2UudnVlJylcIiwgbm90IFwiaW1wb3J0KCcuL015UGFnZS52dWUnKVwiLmAsXG5cdFx0XHRkb2NzOiBcImh0dHBzOi8vcm91dGVyLnZ1ZWpzLm9yZy9ndWlkZS9hZHZhbmNlZC9sYXp5LWxvYWRpbmcuaHRtbFwiXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IwMDI5OiB7XG5cdFx0XHR3aHk6IChwKSA9PiBgQ29tcG9uZW50IFwiJHtwLm5hbWV9XCIgaW4gcmVjb3JkIHdpdGggcGF0aCBcIiR7cC5wYXRofVwiIGlzIGRlZmluZWQgdXNpbmcgXCJkZWZpbmVBc3luY0NvbXBvbmVudCgpXCIuYCxcblx0XHRcdGZpeDogYERyb3AgdGhlIHdyYXBwZXIgYW5kIHBhc3MgXCIoKSA9PiBpbXBvcnQoJy4vTXlQYWdlLnZ1ZScpXCIgZGlyZWN0bHk7IHRoZSByb3V0ZXIgaGFuZGxlcyBsYXp5IGNvbXBvbmVudHMgaXRzZWxmLmAsXG5cdFx0XHRkb2NzOiBcImh0dHBzOi8vcm91dGVyLnZ1ZWpzLm9yZy9ndWlkZS9hZHZhbmNlZC9sYXp5LWxvYWRpbmcuaHRtbCNSZWxhdGlvbnNoaXAtdG8tYXN5bmMtY29tcG9uZW50c1wiXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IwMDMwOiB7XG5cdFx0XHR3aHk6IChwKSA9PiBgQ29tcG9uZW50IFwiJHtwLm5hbWV9XCIgaW4gcmVjb3JkIHdpdGggcGF0aCBcIiR7cC5wYXRofVwiIGlzIGEgZnVuY3Rpb24gdGhhdCBkb2VzIG5vdCByZXR1cm4gYSBQcm9taXNlLiBUaGlzIHdpbGwgYnJlYWsgaW4gcHJvZHVjdGlvbiBpZiBub3QgZml4ZWQuYCxcblx0XHRcdGZpeDogXCJSZXR1cm4gYSBkeW5hbWljIGltcG9ydCAoYCgpID0+IGltcG9ydChcXFwiLi9NeVBhZ2UudnVlXFxcIilgKSBmcm9tIHRoZSBmdW5jdGlvbiwgb3IgYWRkIGEgYGRpc3BsYXlOYW1lYCBpZiBpdCBpcyBhIGZ1bmN0aW9uYWwgY29tcG9uZW50LlwiLFxuXHRcdFx0ZG9jczogXCJodHRwczovL3JvdXRlci52dWVqcy5vcmcvZ3VpZGUvYWR2YW5jZWQvbGF6eS1sb2FkaW5nLmh0bWxcIlxuXHRcdH0sXG5cdFx0VlVFX1JPVVRFUl9SMDA0MDoge1xuXHRcdFx0d2h5OiAocCkgPT4gYEJlY2F1c2UgXCIke3AuZWx9XCIgc3RhcnRzIHdpdGggXCIjXCIsIHNjcm9sbEJlaGF2aW9yIHJlc29sdmVzIGl0IGFzIGFuIGVsZW1lbnQgaWQgdmlhIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiJHtwLmVsLnNsaWNlKDEpfVwiKSwgbm90IGFzIGEgQ1NTIHNlbGVjdG9yLiBObyBlbGVtZW50IGhhcyB0aGF0IGlkLCBidXQgXCIke3AuZWx9XCIgZG9lcyBtYXRjaCBhbiBlbGVtZW50IHdpdGggZG9jdW1lbnQucXVlcnlTZWxlY3RvcigpLmAsXG5cdFx0XHRmaXg6IChwKSA9PiBgUmVzb2x2ZSB0aGUgZWxlbWVudCB5b3Vyc2VsZiBhbmQgcmV0dXJuIHRoZSBub2RlOiBlbDogZG9jdW1lbnQucXVlcnlTZWxlY3RvcignJHtwLmVsfScpLmAsXG5cdFx0XHRkb2NzOiBcImh0dHBzOi8vcm91dGVyLnZ1ZWpzLm9yZy9ndWlkZS9hZHZhbmNlZC9zY3JvbGwtYmVoYXZpb3IuaHRtbFwiXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IwMDQxOiB7XG5cdFx0XHR3aHk6IChwKSA9PiBgVGhlIHNlbGVjdG9yIFwiJHtwLmVsfVwiIGlzIGludmFsaWQuIFNlZSBodHRwczovL21hdGhpYXNieW5lbnMuYmUvbm90ZXMvY3NzLWVzY2FwZXMgb3IgQ1NTLmVzY2FwZSAoaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvQVBJL0NTUy9lc2NhcGUpIGZvciB0aGUgZXNjYXBpbmcgcnVsZXMuYCxcblx0XHRcdGZpeDogXCJCdWlsZCBhbiBpZCBzZWxlY3RvciBhcyBgIyR7Q1NTLmVzY2FwZShpZCl9YCBzbyBzcGVjaWFsIGNoYXJhY3RlcnMgaW4gdGhlIGlkIGFyZSBlc2NhcGVkLlwiLFxuXHRcdFx0ZG9jczogXCJodHRwczovL3JvdXRlci52dWVqcy5vcmcvZ3VpZGUvYWR2YW5jZWQvc2Nyb2xsLWJlaGF2aW9yLmh0bWxcIlxuXHRcdH0sXG5cdFx0VlVFX1JPVVRFUl9SMDA0Mjoge1xuXHRcdFx0d2h5OiAocCkgPT4gYENvdWxkbid0IGZpbmQgZWxlbWVudCB1c2luZyBzZWxlY3RvciBcIiR7cC5lbH1cIiByZXR1cm5lZCBieSBzY3JvbGxCZWhhdmlvci5gLFxuXHRcdFx0Zml4OiBcIlJldHVybiBhIHNlbGVjdG9yIHRoYXQgbWF0Y2hlcyBhbiBleGlzdGluZyBlbGVtZW50LCBvciBndWFyZCBhZ2FpbnN0IG1pc3NpbmcgZWxlbWVudHMuXCIsXG5cdFx0XHRkb2NzOiBcImh0dHBzOi8vcm91dGVyLnZ1ZWpzLm9yZy9ndWlkZS9hZHZhbmNlZC9zY3JvbGwtYmVoYXZpb3IuaHRtbFwiXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IwMDUwOiB7XG5cdFx0XHR3aHk6IChwKSA9PiB7XG5cdFx0XHRcdGxldCB0bztcblx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHR0byA9IHAudG8gPT09IHZvaWQgMCA/IFwidW5kZWZpbmVkXCIgOiBKU09OLnN0cmluZ2lmeShwLnRvKTtcblx0XHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdFx0dG8gPSBTdHJpbmcocC50byk7XG5cdFx0XHRcdH1cblx0XHRcdFx0cmV0dXJuIGBJbnZhbGlkIHZhbHVlIGZvciBwcm9wIFwidG9cIiBpbiB1c2VMaW5rKClcXG4tIHRvOiAke3RvfWA7XG5cdFx0XHR9LFxuXHRcdFx0Zml4OiBcIlBhc3MgYSB2YWxpZCByb3V0ZSBsb2NhdGlvbiAoYSBzdHJpbmcgcGF0aCBvciBhbiBvYmplY3QpIHRvIHRoZSBcXFwidG9cXFwiIHByb3AuXCJcblx0XHR9LFxuXHRcdFZVRV9ST1VURVJfUjAwNjA6IHtcblx0XHRcdHdoeTogKHApID0+IGA8cm91dGVyLXZpZXc+IGNhbiBubyBsb25nZXIgYmUgdXNlZCBkaXJlY3RseSBpbnNpZGUgPCR7cC5jb21wfT4uYCxcblx0XHRcdGZpeDogKHApID0+IGBXcmFwIHRoZSBzbG90J3MgcmVzb2x2ZWQgY29tcG9uZW50IHdpdGggPCR7cC5jb21wfT4gaW5zdGVhZCBvZiBuZXN0aW5nIDxyb3V0ZXItdmlldz4gaW4gaXQ6XFxuXFxuPHJvdXRlci12aWV3IHYtc2xvdD1cInsgQ29tcG9uZW50IH1cIj5cXG4gIDwke3AuY29tcH0+XFxuICAgIDxjb21wb25lbnQgOmlzPVwiQ29tcG9uZW50XCIgLz5cXG4gIDwvJHtwLmNvbXB9Plxcbjwvcm91dGVyLXZpZXc+YCxcblx0XHRcdGRvY3M6IFwiaHR0cHM6Ly9yb3V0ZXIudnVlanMub3JnL2d1aWRlL2FkdmFuY2VkL3JvdXRlci12aWV3LXNsb3QuaHRtbCNLZWVwQWxpdmUtVHJhbnNpdGlvblwiXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IwMDcwOiB7XG5cdFx0XHR3aHk6IChwKSA9PiBgQ2Fubm90IHJlc29sdmUgYSByZWxhdGl2ZSBsb2NhdGlvbiB3aXRob3V0IGFuIGFic29sdXRlIHBhdGguIFRyeWluZyB0byByZXNvbHZlIFwiJHtwLnRvfVwiIGZyb20gXCIke3AuZnJvbX1cIi5gLFxuXHRcdFx0Zml4OiAocCkgPT4gYFJlc29sdmUgZnJvbSBhbiBhYnNvbHV0ZSBcXGBmcm9tXFxgIHBhdGggdGhhdCBzdGFydHMgd2l0aCBcIi9cIiwgZS5nLiBcIi8ke3AuZnJvbX1cIi5gXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IwMDgwOiB7XG5cdFx0XHR3aHk6IChwKSA9PiBgRXJyb3IgZGVjb2RpbmcgXCIke3AudGV4dH1cIi4gVXNpbmcgb3JpZ2luYWwgdmFsdWVgLFxuXHRcdFx0Zml4OiBcIkVuc3VyZSB0aGUgdmFsdWUgaXMgY29ycmVjdGx5IHBlcmNlbnQtZW5jb2RlZC5cIlxuXHRcdH0sXG5cdFx0VlVFX1JPVVRFUl9SMDA5MDoge1xuXHRcdFx0d2h5OiAocCkgPT4gYEZvdW5kIGR1cGxpY2F0ZWQgcGFyYW1zIHdpdGggbmFtZSBcIiR7cC5uYW1lfVwiIGZvciBwYXRoIFwiJHtwLnBhdGh9XCIuIE9ubHkgdGhlIGxhc3Qgb25lIHdpbGwgYmUgYXZhaWxhYmxlIG9uIFwiJHJvdXRlLnBhcmFtc1wiLmAsXG5cdFx0XHRmaXg6IFwiR2l2ZSBlYWNoIHBhcmFtIGEgdW5pcXVlIG5hbWUgd2l0aGluIHRoZSBwYXRoLlwiLFxuXHRcdFx0ZG9jczogXCJodHRwczovL3JvdXRlci52dWVqcy5vcmcvZ3VpZGUvZXNzZW50aWFscy9yb3V0ZS1tYXRjaGluZy1zeW50YXguaHRtbFwiXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IwMTAwOiB7XG5cdFx0XHR3aHk6IChwKSA9PiBgRGlzY2FyZGVkIGludmFsaWQgcGFyYW0ocykgXCIke3AucGFyYW1zfVwiIHdoZW4gbmF2aWdhdGluZy5gICsgcC5pbmhlcml0ZWQgKyBgIFNlZSBodHRwczovL2dpdGh1Yi5jb20vdnVlanMvcm91dGVyL2NvbW1pdC9lODg3NTcwIGZvciBtb3JlIGRldGFpbHMuYCxcblx0XHRcdGZpeDogXCJPbmx5IHBhc3MgcGFyYW1zIHRoYXQgZXhpc3Qgb24gdGhlIHRhcmdldCByb3V0ZS5cIlxuXHRcdH0sXG5cdFx0VlVFX1JPVVRFUl9SMDEwMToge1xuXHRcdFx0d2h5OiAocCkgPT4gYFRoZSBNYXRjaGVyIGNhbm5vdCByZXNvbHZlIHJlbGF0aXZlIHBhdGhzIGJ1dCByZWNlaXZlZCBcIiR7cC5wYXRofVwiLiBVbmxlc3MgeW91IGRpcmVjdGx5IGNhbGxlZCBcXGBtYXRjaGVyLnJlc29sdmUoXCIke3AucGF0aH1cIilcXGAsIHRoaXMgaXMgcHJvYmFibHkgYSBidWcgaW4gdnVlLXJvdXRlci4gUGxlYXNlIG9wZW4gYW4gaXNzdWUgYXQgaHR0cHM6Ly9naXRodWIuY29tL3Z1ZWpzL3JvdXRlci9pc3N1ZXMvbmV3L2Nob29zZS5gLFxuXHRcdFx0Zml4OiBcIlBhc3MgYW4gYWJzb2x1dGUgcGF0aCAoc3RhcnRpbmcgd2l0aCBcXFwiL1xcXCIpIHRvIHRoZSBtYXRjaGVyLlwiXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IwMTAyOiB7XG5cdFx0XHR3aHk6IChwKSA9PiBgQWxpYXMgXCIke3AuYWxpYXN9XCIgYW5kIHRoZSBvcmlnaW5hbCByZWNvcmQ6IFwiJHtwLm9yaWdpbmFsfVwiIG11c3QgaGF2ZSB0aGUgZXhhY3Qgc2FtZSBwYXJhbSBuYW1lZCBcIiR7cC5uYW1lfVwiYCxcblx0XHRcdGZpeDogXCJVc2UgdGhlIHNhbWUgcGFyYW0gbmFtZXMgaW4gdGhlIGFsaWFzIGFzIGluIHRoZSBvcmlnaW5hbCByb3V0ZS5cIixcblx0XHRcdGRvY3M6IFwiaHR0cHM6Ly9yb3V0ZXIudnVlanMub3JnL2d1aWRlL2Vzc2VudGlhbHMvcmVkaXJlY3QtYW5kLWFsaWFzLmh0bWwjQWxpYXNcIlxuXHRcdH0sXG5cdFx0VlVFX1JPVVRFUl9SMDEwMzoge1xuXHRcdFx0d2h5OiAocCkgPT4gYFRoZSByb3V0ZSBuYW1lZCBcIiR7cC5uYW1lfVwiIGhhcyBhIGNoaWxkIHdpdGhvdXQgYSBuYW1lLCBhbiBlbXB0eSBwYXRoLCBhbmQgbm8gY2hpbGRyZW4uIFVzaW5nIHRoYXQgbmFtZSB3b24ndCByZW5kZXIgdGhlIGVtcHR5IHBhdGggY2hpbGQsIHNvIHRoaXMgaXMgcHJvYmFibHkgYSBtaXN0YWtlLmAsXG5cdFx0XHRmaXg6IFwiTW92ZSB0aGUgYG5hbWVgIG9udG8gdGhlIGVtcHR5LXBhdGggY2hpbGQ7IG9yLCBpZiBpbnRlbnRpb25hbCwgZ2l2ZSB0aGUgY2hpbGQgaXRzIG93biBuYW1lIHRvIHNpbGVuY2UgdGhpcy5cIixcblx0XHRcdGRvY3M6IFwiaHR0cHM6Ly9yb3V0ZXIudnVlanMub3JnL2d1aWRlL2Vzc2VudGlhbHMvbmVzdGVkLXJvdXRlcy5odG1sI05lc3RlZC1OYW1lZC1Sb3V0ZXNcIlxuXHRcdH0sXG5cdFx0VlVFX1JPVVRFUl9SMDEwNDoge1xuXHRcdFx0d2h5OiAocCkgPT4gYEFic29sdXRlIHBhdGggXCIke3AucGF0aH1cIiBtdXN0IGhhdmUgdGhlIGV4YWN0IHNhbWUgcGFyYW0gbmFtZWQgXCIke3AubmFtZX1cIiBhcyBpdHMgcGFyZW50IFwiJHtwLnBhcmVudH1cIi5gLFxuXHRcdFx0Zml4OiBcIkluY2x1ZGUgdGhlIHBhcmVudCByb3V0ZSBwYXJhbXMgaW4gdGhlIGFic29sdXRlIGNoaWxkIHBhdGguXCIsXG5cdFx0XHRkb2NzOiBcImh0dHBzOi8vcm91dGVyLnZ1ZWpzLm9yZy9ndWlkZS9lc3NlbnRpYWxzL25lc3RlZC1yb3V0ZXMuaHRtbFwiXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IwMTA1OiB7XG5cdFx0XHR3aHk6IChwKSA9PiBgRmluZGluZyBhbmNlc3RvciByb3V0ZSBcIiR7cC5hbmNlc3Rvcn1cIiBmYWlsZWQgZm9yIFwiJHtwLnJlY29yZH1cImAsXG5cdFx0XHRmaXg6IFwiUmVwb3J0IGEgcmVwcm9kdWN0aW9uIGF0IGh0dHBzOi8vZ2l0aHViLmNvbS92dWVqcy9yb3V0ZXIvaXNzdWVzL25ldy9jaG9vc2UuXCJcblx0XHR9LFxuXHRcdFZVRV9ST1VURVJfUjAxMTA6IHtcblx0XHRcdHdoeTogYEEgaGFzaCBiYXNlIG11c3QgZW5kIHdpdGggYSBcIiNcImAsXG5cdFx0XHRmaXg6IChwKSA9PiBgQXBwZW5kIFwiI1wiIHRvIHRoZSBcImJhc2VcIiBhcmd1bWVudCBwYXNzZWQgdG8gXCJjcmVhdGVXZWJIYXNoSGlzdG9yeSgpXCI6IFwiJHtwLmJhc2V9XCIgc2hvdWxkIGJlIFwiJHtwLnN1Z2dlc3Rpb259XCIuYFxuXHRcdH0sXG5cdFx0VlVFX1JPVVRFUl9SMDEyMDoge1xuXHRcdFx0d2h5OiBcIkVycm9yIHdpdGggcHVzaC9yZXBsYWNlIFN0YXRlXCIsXG5cdFx0XHRmaXg6IFwiVGhlIGJyb3dzZXIgcmVqZWN0ZWQgdGhlIGhpc3RvcnkgQVBJIGNhbGw7IGNoZWNrIGZvciBjcm9zcy1vcmlnaW4gb3IgcmF0ZS1saW1pdCBpc3N1ZXMuXCJcblx0XHR9LFxuXHRcdFZVRV9ST1VURVJfUjAxMjE6IHtcblx0XHRcdHdoeTogXCJoaXN0b3J5LnN0YXRlIHNlZW1zIHRvIGhhdmUgYmVlbiBtYW51YWxseSByZXBsYWNlZCB3aXRob3V0IHByZXNlcnZpbmcgdGhlIG5lY2Vzc2FyeSB2YWx1ZXMuXFxuWW91IGNhbiBmaW5kIG1vcmUgaW5mb3JtYXRpb24gYXQgaHR0cHM6Ly9yb3V0ZXIudnVlanMub3JnL2d1aWRlL21pZ3JhdGlvbi8jVXNhZ2Utb2YtaGlzdG9yeS1zdGF0ZVwiLFxuXHRcdFx0Zml4OiBcIk1lcmdlIHRoZSByb3V0ZXIncyBzdGF0ZSBpbnRvIHlvdXIgb3duIHdoZW4gY2FsbGluZyBpdCBtYW51YWxseTogYGhpc3RvcnkucmVwbGFjZVN0YXRlKHsgLi4uaGlzdG9yeS5zdGF0ZSwgLi4ueW91clN0YXRlIH0sICcnLCB1cmwpYC5cIixcblx0XHRcdGRvY3M6IFwiaHR0cHM6Ly9yb3V0ZXIudnVlanMub3JnL2d1aWRlL21pZ3JhdGlvbi5odG1sI1VzYWdlLW9mLWhpc3Rvcnktc3RhdGVcIlxuXHRcdH0sXG5cdFx0VlVFX1JPVVRFUl9SMTAwMToge1xuXHRcdFx0d2h5OiAocCkgPT4gYERhdGEgbG9hZGVyIFwiJHtTdHJpbmcocC5rZXkpfVwiIGhhcyBhIGRpZmZlcmVudCBwYXJlbnQgdGhhbiB0aGUgY3VycmVudCBjb250ZXh0LiBUaGlzIHNob3VsZG4ndCBiZSBoYXBwZW5pbmcuYCxcblx0XHRcdGZpeDogXCJSZXBvcnQgYSBidWcgd2l0aCBhIG1pbmltYWwgcmVwcm9kdWN0aW9uIGF0IGh0dHBzOi8vZ2l0aHViLmNvbS92dWVqcy9yb3V0ZXIvLlwiXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IxMDAyOiB7XG5cdFx0XHR3aHk6IFwiUmV0dXJuaW5nIGEgTmF2aWdhdGlvblJlc3VsdCBpcyBkZXByZWNhdGVkLlwiLFxuXHRcdFx0Zml4OiBcIlJlcGxhY2UgYHJldHVybiBuZXcgTmF2aWdhdGlvblJlc3VsdCh0bylgIHdpdGggYHJlcm91dGUodG8pYCwgd2hpY2ggdGhyb3dzIGludGVybmFsbHkgdG8gcmVyb3V0ZS5cIixcblx0XHRcdGRvY3M6IFwiaHR0cHM6Ly9yb3V0ZXIudnVlanMub3JnL2RhdGEtbG9hZGVycy9uYXZpZ2F0aW9uLWF3YXJlLmh0bWwjQ29udHJvbGxpbmctdGhlLW5hdmlnYXRpb24td2l0aC1yZXJvdXRlLVwiXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IxMDAzOiB7XG5cdFx0XHR3aHk6IChwKSA9PiBgTG9hZGVyIFwiJHtwLmtleX1cIidzIFwiY29tbWl0KClcIiB3YXMgY2FsbGVkIGJ1dCB0aGVyZSBpcyBubyBzdGFnZWQgZGF0YS5gLFxuXHRcdFx0Zml4OiBcIkVuc3VyZSB0aGUgbG9hZGVyIHJlc29sdmVkIGJlZm9yZSBjYWxsaW5nIGBjb21taXQoKWAuXCIsXG5cdFx0XHRkb2NzOiBcImh0dHBzOi8vcm91dGVyLnZ1ZWpzLm9yZy9kYXRhLWxvYWRlcnMvZGVmaW5pbmctbG9hZGVycy5odG1sI0RlbGF5aW5nLWRhdGEtdXBkYXRlcy13aXRoLWNvbW1pdFwiXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IxMDA0OiB7XG5cdFx0XHR3aHk6IChwKSA9PiBcIkEgbG9hZGVyIHJldHVybmVkIGEgTmF2aWdhdGlvblJlc3VsdCBidXQgaXMgbm90IHJlZ2lzdGVyZWQgb24gdGhlIHJvdXRlLlwiICsgcC5rZXksXG5cdFx0XHRmaXg6IFwiRXhwb3J0IHRoZSBsb2FkZXIgZnJvbSB0aGUgcGFnZSBjb21wb25lbnQgc28gaXQgZ2V0cyByZWdpc3RlcmVkLCBlLmcuIGBleHBvcnQgY29uc3QgdXNlVXNlckRhdGEgPSBkZWZpbmVMb2FkZXIoLi4uKWAuXCIsXG5cdFx0XHRkb2NzOiBcImh0dHBzOi8vcm91dGVyLnZ1ZWpzLm9yZy9kYXRhLWxvYWRlcnMvb3JnYW5pemF0aW9uLmh0bWxcIlxuXHRcdH0sXG5cdFx0VlVFX1JPVVRFUl9SMTAwNToge1xuXHRcdFx0d2h5OiAocCkgPT4gYERhdGEgbG9hZGVyIFwiJHtwLmtleX1cIiBoYXMgaXRzZWxmIGFzIHBhcmVudC4gVGhpcyBzaG91bGRuJ3QgYmUgaGFwcGVuaW5nLmAsXG5cdFx0XHRmaXg6IFwiUmVwb3J0IGEgYnVnIHdpdGggYSBtaW5pbWFsIHJlcHJvZHVjdGlvbiBhdCBodHRwczovL2dpdGh1Yi5jb20vdnVlanMvcm91dGVyLy5cIlxuXHRcdH0sXG5cdFx0VlVFX1JPVVRFUl9SMTAwNjoge1xuXHRcdFx0d2h5OiAocCkgPT4gYEEgcXVlcnkgd2FzIGRlZmluZWQgd2l0aCB0aGUgc2FtZSBrZXkgYXMgdGhlIGxvYWRlciBcIlske3Aua2V5fV1cIi5cXG5TZWUgaHR0cHM6Ly9waW5pYS1jb2xhZGEuZXNtLmRldi8jVE9ET2AsXG5cdFx0XHRmaXg6IFwiSWYgdGhlIGtleSBpcyBtZWFudCB0byBtYXRjaCwgdXNlIHRoZSBkYXRhIGxvYWRlciBkaXJlY3RseTsgb3RoZXJ3aXNlIHJlbmFtZSB0aGUgYHVzZVF1ZXJ5KClgIGtleSBzbyBpdCBubyBsb25nZXIgY29sbGlkZXMuXCIsXG5cdFx0XHRkb2NzOiBcImh0dHBzOi8vcm91dGVyLnZ1ZWpzLm9yZy9kYXRhLWxvYWRlcnMvY29sYWRhLmh0bWxcIlxuXHRcdH0sXG5cdFx0VlVFX1JPVVRFUl9SMTAwNzoge1xuXHRcdFx0d2h5OiBcIkRhdGEgTG9hZGVyIHdhcyBzZXR1cCB0d2ljZS5cIixcblx0XHRcdGZpeDogXCJSZWdpc3RlciBgRGF0YUxvYWRlclBsdWdpbmAgYSBzaW5nbGUgdGltZSB2aWEgYGFwcC51c2UoKWAuXCIsXG5cdFx0XHRkb2NzOiBcImh0dHBzOi8vcm91dGVyLnZ1ZWpzLm9yZy9kYXRhLWxvYWRlcnMuaHRtbCNJbnN0YWxsYXRpb25cIlxuXHRcdH0sXG5cdFx0VlVFX1JPVVRFUl9SMTAwODoge1xuXHRcdFx0d2h5OiBcIkRhdGEgTG9hZGVyIGlzIGV4cGVyaW1lbnRhbCBhbmQgc3ViamVjdCB0byBicmVha2luZyBjaGFuZ2VzIGluIHRoZSBmdXR1cmUuXCIsXG5cdFx0XHRkb2NzOiBcImh0dHBzOi8vcm91dGVyLnZ1ZWpzLm9yZy9kYXRhLWxvYWRlcnMuaHRtbFwiXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IxMDA5OiB7XG5cdFx0XHR3aHk6IFwiUmV0dXJuaW5nIGEgTmF2aWdhdGlvblJlc3VsdCBmcm9tIGEgbG9hZGVyIGlzIGRlcHJlY2F0ZWQuXCIsXG5cdFx0XHRmaXg6IFwiQ2FsbCBgcmVyb3V0ZSh0bylgIGluc2lkZSB0aGUgbG9hZGVyIGluc3RlYWQgb2YgcmV0dXJuaW5nIGBuZXcgTmF2aWdhdGlvblJlc3VsdCh0bylgOyBpdCB0aHJvd3MgaW50ZXJuYWxseSB0byByZXJvdXRlLlwiLFxuXHRcdFx0ZG9jczogXCJodHRwczovL3JvdXRlci52dWVqcy5vcmcvZGF0YS1sb2FkZXJzL25hdmlnYXRpb24tYXdhcmUuaHRtbCNDb250cm9sbGluZy10aGUtbmF2aWdhdGlvbi13aXRoLXJlcm91dGUtXCJcblx0XHR9XG5cdH1cbn0pO1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2luamVjdGlvblN5bWJvbHMudHNcbi8qKlxuKiBSb3V0ZVJlY29yZCBiZWluZyByZW5kZXJlZCBieSB0aGUgY2xvc2VzdCBhbmNlc3RvciBSb3V0ZXIgVmlldy4gVXNlZCBmb3JcbiogYG9uQmVmb3JlUm91dGVVcGRhdGVgIGFuZCBgb25CZWZvcmVSb3V0ZUxlYXZlYC4gcnZsbSBzdGFuZHMgZm9yIFJvdXRlciBWaWV3XG4qIExvY2F0aW9uIE1hdGNoZWRcbipcbiogQGludGVybmFsXG4qL1xuY29uc3QgbWF0Y2hlZFJvdXRlS2V5ID0gU3ltYm9sKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IFwicm91dGVyIHZpZXcgbG9jYXRpb24gbWF0Y2hlZFwiIDogXCJcIik7XG4vKipcbiogQWxsb3dzIG92ZXJyaWRpbmcgdGhlIHJvdXRlciB2aWV3IGRlcHRoIHRvIGNvbnRyb2wgd2hpY2ggY29tcG9uZW50IGluXG4qIGBtYXRjaGVkYCBpcyByZW5kZXJlZC4gcnZkIHN0YW5kcyBmb3IgUm91dGVyIFZpZXcgRGVwdGhcbipcbiogQGludGVybmFsXG4qL1xuY29uc3Qgdmlld0RlcHRoS2V5ID0gU3ltYm9sKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IFwicm91dGVyIHZpZXcgZGVwdGhcIiA6IFwiXCIpO1xuLyoqXG4qIEFsbG93cyBvdmVycmlkaW5nIHRoZSByb3V0ZXIgaW5zdGFuY2UgcmV0dXJuZWQgYnkgYHVzZVJvdXRlcmAgaW4gdGVzdHMuIHJcbiogc3RhbmRzIGZvciByb3V0ZXJcbipcbiogQGludGVybmFsXG4qL1xuY29uc3Qgcm91dGVyS2V5ID0gU3ltYm9sKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IFwicm91dGVyXCIgOiBcIlwiKTtcbi8qKlxuKiBBbGxvd3Mgb3ZlcnJpZGluZyB0aGUgY3VycmVudCByb3V0ZSByZXR1cm5lZCBieSBgdXNlUm91dGVgIGluIHRlc3RzLiBybFxuKiBzdGFuZHMgZm9yIHJvdXRlIGxvY2F0aW9uXG4qXG4qIEBpbnRlcm5hbFxuKi9cbmNvbnN0IHJvdXRlTG9jYXRpb25LZXkgPSBTeW1ib2wocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gXCJyb3V0ZSBsb2NhdGlvblwiIDogXCJcIik7XG4vKipcbiogQWxsb3dzIG92ZXJyaWRpbmcgdGhlIGN1cnJlbnQgcm91dGUgdXNlZCBieSByb3V0ZXItdmlldy4gSW50ZXJuYWxseSB0aGlzIGlzXG4qIHVzZWQgd2hlbiB0aGUgYHJvdXRlYCBwcm9wIGlzIHBhc3NlZC5cbipcbiogQGludGVybmFsXG4qL1xuY29uc3Qgcm91dGVyVmlld0xvY2F0aW9uS2V5ID0gU3ltYm9sKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IFwicm91dGVyIHZpZXcgbG9jYXRpb25cIiA6IFwiXCIpO1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3VzZUFwaS50c1xuLyoqXG4qIFJldHVybnMgdGhlIHJvdXRlciBpbnN0YW5jZS4gRXF1aXZhbGVudCB0byB1c2luZyBgJHJvdXRlcmAgaW5zaWRlXG4qIHRlbXBsYXRlcy5cbiovXG5mdW5jdGlvbiB1c2VSb3V0ZXIoKSB7XG5cdHJldHVybiBpbmplY3Qocm91dGVyS2V5KTtcbn1cbi8qKlxuKiBSZXR1cm5zIHRoZSBjdXJyZW50IHJvdXRlIGxvY2F0aW9uLiBFcXVpdmFsZW50IHRvIHVzaW5nIGAkcm91dGVgIGluc2lkZVxuKiB0ZW1wbGF0ZXMuXG4qL1xuZnVuY3Rpb24gdXNlUm91dGUoX25hbWUpIHtcblx0cmV0dXJuIGluamVjdChyb3V0ZUxvY2F0aW9uS2V5KTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgaXNFU01vZHVsZSBhcyBfLCByb3V0ZXJLZXkgYXMgYSwgbm9vcCBhcyBiLCBkaWFnbm9zdGljcyBhcyBjLCBpc05hdmlnYXRpb25GYWlsdXJlIGFzIGQsIGFwcGx5VG9QYXJhbXMgYXMgZiwgaXNBcnJheSBhcyBnLCBpc0Fic29sdXRlUGF0aCBhcyBoLCByb3V0ZUxvY2F0aW9uS2V5IGFzIGksIE5hdmlnYXRpb25GYWlsdXJlVHlwZSBhcyBsLCBpZGVudGl0eUZuIGFzIG0sIHVzZVJvdXRlciBhcyBuLCByb3V0ZXJWaWV3TG9jYXRpb25LZXkgYXMgbywgYXNzaWduIGFzIHAsIG1hdGNoZWRSb3V0ZUtleSBhcyByLCB2aWV3RGVwdGhLZXkgYXMgcywgdXNlUm91dGUgYXMgdCwgY3JlYXRlUm91dGVyRXJyb3IgYXMgdSwgaXNSb3V0ZUNvbXBvbmVudCBhcyB2LCBtZXJnZU9wdGlvbnMgYXMgeSB9O1xuIiwiLy8jcmVnaW9uIFxcMHJvbGxkb3duL3J1bnRpbWUuanNcbnZhciBfX2NyZWF0ZSA9IE9iamVjdC5jcmVhdGU7XG52YXIgX19kZWZQcm9wID0gT2JqZWN0LmRlZmluZVByb3BlcnR5O1xudmFyIF9fZ2V0T3duUHJvcERlc2MgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yO1xudmFyIF9fZ2V0T3duUHJvcE5hbWVzID0gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXM7XG52YXIgX19nZXRQcm90b09mID0gT2JqZWN0LmdldFByb3RvdHlwZU9mO1xudmFyIF9faGFzT3duUHJvcCA9IE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHk7XG52YXIgX19jb21tb25KU01pbiA9IChjYiwgbW9kKSA9PiAoKSA9PiAobW9kIHx8IGNiKChtb2QgPSB7IGV4cG9ydHM6IHt9IH0pLmV4cG9ydHMsIG1vZCksIG1vZC5leHBvcnRzKTtcbnZhciBfX2NvcHlQcm9wcyA9ICh0bywgZnJvbSwgZXhjZXB0LCBkZXNjKSA9PiB7XG5cdGlmIChmcm9tICYmIHR5cGVvZiBmcm9tID09PSBcIm9iamVjdFwiIHx8IHR5cGVvZiBmcm9tID09PSBcImZ1bmN0aW9uXCIpIGZvciAodmFyIGtleXMgPSBfX2dldE93blByb3BOYW1lcyhmcm9tKSwgaSA9IDAsIG4gPSBrZXlzLmxlbmd0aCwga2V5OyBpIDwgbjsgaSsrKSB7XG5cdFx0a2V5ID0ga2V5c1tpXTtcblx0XHRpZiAoIV9faGFzT3duUHJvcC5jYWxsKHRvLCBrZXkpICYmIGtleSAhPT0gZXhjZXB0KSBfX2RlZlByb3AodG8sIGtleSwge1xuXHRcdFx0Z2V0OiAoKGspID0+IGZyb21ba10pLmJpbmQobnVsbCwga2V5KSxcblx0XHRcdGVudW1lcmFibGU6ICEoZGVzYyA9IF9fZ2V0T3duUHJvcERlc2MoZnJvbSwga2V5KSkgfHwgZGVzYy5lbnVtZXJhYmxlXG5cdFx0fSk7XG5cdH1cblx0cmV0dXJuIHRvO1xufTtcbnZhciBfX3RvRVNNID0gKG1vZCwgaXNOb2RlTW9kZSwgdGFyZ2V0KSA9PiAodGFyZ2V0ID0gbW9kICE9IG51bGwgPyBfX2NyZWF0ZShfX2dldFByb3RvT2YobW9kKSkgOiB7fSwgX19jb3B5UHJvcHMoaXNOb2RlTW9kZSB8fCAhbW9kIHx8ICFtb2QuX19lc01vZHVsZSA/IF9fZGVmUHJvcCh0YXJnZXQsIFwiZGVmYXVsdFwiLCB7XG5cdHZhbHVlOiBtb2QsXG5cdGVudW1lcmFibGU6IHRydWVcbn0pIDogdGFyZ2V0LCBtb2QpKTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb25zdGFudHMudHNcbmNvbnN0IFZJRVdfTU9ERV9TVE9SQUdFX0tFWSA9IFwiX192dWUtZGV2dG9vbHMtdmlldy1tb2RlX19cIjtcbmNvbnN0IFZJVEVfUExVR0lOX0RFVEVDVEVEX1NUT1JBR0VfS0VZID0gXCJfX3Z1ZS1kZXZ0b29scy12aXRlLXBsdWdpbi1kZXRlY3RlZF9fXCI7XG5jb25zdCBWSVRFX1BMVUdJTl9DTElFTlRfVVJMX1NUT1JBR0VfS0VZID0gXCJfX3Z1ZS1kZXZ0b29scy12aXRlLXBsdWdpbi1jbGllbnQtdXJsX19cIjtcbmNvbnN0IEJST0FEQ0FTVF9DSEFOTkVMX05BTUUgPSBcIl9fdnVlLWRldnRvb2xzLWJyb2FkY2FzdC1jaGFubmVsX19cIjtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9lbnYudHNcbmNvbnN0IGlzQnJvd3NlciA9IHR5cGVvZiBuYXZpZ2F0b3IgIT09IFwidW5kZWZpbmVkXCI7XG5jb25zdCB0YXJnZXQgPSB0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiID8gd2luZG93IDogdHlwZW9mIGdsb2JhbFRoaXMgIT09IFwidW5kZWZpbmVkXCIgPyBnbG9iYWxUaGlzIDogdHlwZW9mIGdsb2JhbCAhPT0gXCJ1bmRlZmluZWRcIiA/IGdsb2JhbCA6IHt9O1xuY29uc3QgaXNJbkNocm9tZVBhbmVsID0gdHlwZW9mIHRhcmdldC5jaHJvbWUgIT09IFwidW5kZWZpbmVkXCIgJiYgISF0YXJnZXQuY2hyb21lLmRldnRvb2xzO1xuY29uc3QgaXNJbklmcmFtZSA9IGlzQnJvd3NlciAmJiB0YXJnZXQuc2VsZiAhPT0gdGFyZ2V0LnRvcDtcbmNvbnN0IGlzSW5FbGVjdHJvbiA9IHR5cGVvZiBuYXZpZ2F0b3IgIT09IFwidW5kZWZpbmVkXCIgJiYgbmF2aWdhdG9yLnVzZXJBZ2VudD8udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhcImVsZWN0cm9uXCIpO1xuY29uc3QgaXNOdXh0QXBwID0gdHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIiAmJiAhIXdpbmRvdy5fX05VWFRfXztcbmNvbnN0IGlzSW5TZXBhcmF0ZVdpbmRvdyA9ICFpc0luSWZyYW1lICYmICFpc0luQ2hyb21lUGFuZWwgJiYgIWlzSW5FbGVjdHJvbjtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9nZW5lcmFsLnRzXG52YXIgaW1wb3J0X3JmZGMgPSAvKiBAX19QVVJFX18gKi8gX190b0VTTSgoLyogQF9fUFVSRV9fICovIF9fY29tbW9uSlNNaW4oKChleHBvcnRzLCBtb2R1bGUpID0+IHtcblx0bW9kdWxlLmV4cG9ydHMgPSByZmRjO1xuXHRmdW5jdGlvbiBjb3B5QnVmZmVyKGN1cikge1xuXHRcdGlmIChjdXIgaW5zdGFuY2VvZiBCdWZmZXIpIHJldHVybiBCdWZmZXIuZnJvbShjdXIpO1xuXHRcdHJldHVybiBuZXcgY3VyLmNvbnN0cnVjdG9yKGN1ci5idWZmZXIuc2xpY2UoKSwgY3VyLmJ5dGVPZmZzZXQsIGN1ci5sZW5ndGgpO1xuXHR9XG5cdGZ1bmN0aW9uIHJmZGMob3B0cykge1xuXHRcdG9wdHMgPSBvcHRzIHx8IHt9O1xuXHRcdGlmIChvcHRzLmNpcmNsZXMpIHJldHVybiByZmRjQ2lyY2xlcyhvcHRzKTtcblx0XHRjb25zdCBjb25zdHJ1Y3RvckhhbmRsZXJzID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0XHRjb25zdHJ1Y3RvckhhbmRsZXJzLnNldChEYXRlLCAobykgPT4gbmV3IERhdGUobykpO1xuXHRcdGNvbnN0cnVjdG9ySGFuZGxlcnMuc2V0KE1hcCwgKG8sIGZuKSA9PiBuZXcgTWFwKGNsb25lQXJyYXkoQXJyYXkuZnJvbShvKSwgZm4pKSk7XG5cdFx0Y29uc3RydWN0b3JIYW5kbGVycy5zZXQoU2V0LCAobywgZm4pID0+IG5ldyBTZXQoY2xvbmVBcnJheShBcnJheS5mcm9tKG8pLCBmbikpKTtcblx0XHRpZiAob3B0cy5jb25zdHJ1Y3RvckhhbmRsZXJzKSBmb3IgKGNvbnN0IGhhbmRsZXIgb2Ygb3B0cy5jb25zdHJ1Y3RvckhhbmRsZXJzKSBjb25zdHJ1Y3RvckhhbmRsZXJzLnNldChoYW5kbGVyWzBdLCBoYW5kbGVyWzFdKTtcblx0XHRsZXQgaGFuZGxlciA9IG51bGw7XG5cdFx0cmV0dXJuIG9wdHMucHJvdG8gPyBjbG9uZVByb3RvIDogY2xvbmU7XG5cdFx0ZnVuY3Rpb24gY2xvbmVBcnJheShhLCBmbikge1xuXHRcdFx0Y29uc3Qga2V5cyA9IE9iamVjdC5rZXlzKGEpO1xuXHRcdFx0Y29uc3QgYTIgPSBuZXcgQXJyYXkoa2V5cy5sZW5ndGgpO1xuXHRcdFx0Zm9yIChsZXQgaSA9IDA7IGkgPCBrZXlzLmxlbmd0aDsgaSsrKSB7XG5cdFx0XHRcdGNvbnN0IGsgPSBrZXlzW2ldO1xuXHRcdFx0XHRjb25zdCBjdXIgPSBhW2tdO1xuXHRcdFx0XHRpZiAodHlwZW9mIGN1ciAhPT0gXCJvYmplY3RcIiB8fCBjdXIgPT09IG51bGwpIGEyW2tdID0gY3VyO1xuXHRcdFx0XHRlbHNlIGlmIChjdXIuY29uc3RydWN0b3IgIT09IE9iamVjdCAmJiAoaGFuZGxlciA9IGNvbnN0cnVjdG9ySGFuZGxlcnMuZ2V0KGN1ci5jb25zdHJ1Y3RvcikpKSBhMltrXSA9IGhhbmRsZXIoY3VyLCBmbik7XG5cdFx0XHRcdGVsc2UgaWYgKEFycmF5QnVmZmVyLmlzVmlldyhjdXIpKSBhMltrXSA9IGNvcHlCdWZmZXIoY3VyKTtcblx0XHRcdFx0ZWxzZSBhMltrXSA9IGZuKGN1cik7XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gYTI7XG5cdFx0fVxuXHRcdGZ1bmN0aW9uIGNsb25lKG8pIHtcblx0XHRcdGlmICh0eXBlb2YgbyAhPT0gXCJvYmplY3RcIiB8fCBvID09PSBudWxsKSByZXR1cm4gbztcblx0XHRcdGlmIChBcnJheS5pc0FycmF5KG8pKSByZXR1cm4gY2xvbmVBcnJheShvLCBjbG9uZSk7XG5cdFx0XHRpZiAoby5jb25zdHJ1Y3RvciAhPT0gT2JqZWN0ICYmIChoYW5kbGVyID0gY29uc3RydWN0b3JIYW5kbGVycy5nZXQoby5jb25zdHJ1Y3RvcikpKSByZXR1cm4gaGFuZGxlcihvLCBjbG9uZSk7XG5cdFx0XHRjb25zdCBvMiA9IHt9O1xuXHRcdFx0Zm9yIChjb25zdCBrIGluIG8pIHtcblx0XHRcdFx0aWYgKE9iamVjdC5oYXNPd25Qcm9wZXJ0eS5jYWxsKG8sIGspID09PSBmYWxzZSkgY29udGludWU7XG5cdFx0XHRcdGNvbnN0IGN1ciA9IG9ba107XG5cdFx0XHRcdGlmICh0eXBlb2YgY3VyICE9PSBcIm9iamVjdFwiIHx8IGN1ciA9PT0gbnVsbCkgbzJba10gPSBjdXI7XG5cdFx0XHRcdGVsc2UgaWYgKGN1ci5jb25zdHJ1Y3RvciAhPT0gT2JqZWN0ICYmIChoYW5kbGVyID0gY29uc3RydWN0b3JIYW5kbGVycy5nZXQoY3VyLmNvbnN0cnVjdG9yKSkpIG8yW2tdID0gaGFuZGxlcihjdXIsIGNsb25lKTtcblx0XHRcdFx0ZWxzZSBpZiAoQXJyYXlCdWZmZXIuaXNWaWV3KGN1cikpIG8yW2tdID0gY29weUJ1ZmZlcihjdXIpO1xuXHRcdFx0XHRlbHNlIG8yW2tdID0gY2xvbmUoY3VyKTtcblx0XHRcdH1cblx0XHRcdHJldHVybiBvMjtcblx0XHR9XG5cdFx0ZnVuY3Rpb24gY2xvbmVQcm90byhvKSB7XG5cdFx0XHRpZiAodHlwZW9mIG8gIT09IFwib2JqZWN0XCIgfHwgbyA9PT0gbnVsbCkgcmV0dXJuIG87XG5cdFx0XHRpZiAoQXJyYXkuaXNBcnJheShvKSkgcmV0dXJuIGNsb25lQXJyYXkobywgY2xvbmVQcm90byk7XG5cdFx0XHRpZiAoby5jb25zdHJ1Y3RvciAhPT0gT2JqZWN0ICYmIChoYW5kbGVyID0gY29uc3RydWN0b3JIYW5kbGVycy5nZXQoby5jb25zdHJ1Y3RvcikpKSByZXR1cm4gaGFuZGxlcihvLCBjbG9uZVByb3RvKTtcblx0XHRcdGNvbnN0IG8yID0ge307XG5cdFx0XHRmb3IgKGNvbnN0IGsgaW4gbykge1xuXHRcdFx0XHRjb25zdCBjdXIgPSBvW2tdO1xuXHRcdFx0XHRpZiAodHlwZW9mIGN1ciAhPT0gXCJvYmplY3RcIiB8fCBjdXIgPT09IG51bGwpIG8yW2tdID0gY3VyO1xuXHRcdFx0XHRlbHNlIGlmIChjdXIuY29uc3RydWN0b3IgIT09IE9iamVjdCAmJiAoaGFuZGxlciA9IGNvbnN0cnVjdG9ySGFuZGxlcnMuZ2V0KGN1ci5jb25zdHJ1Y3RvcikpKSBvMltrXSA9IGhhbmRsZXIoY3VyLCBjbG9uZVByb3RvKTtcblx0XHRcdFx0ZWxzZSBpZiAoQXJyYXlCdWZmZXIuaXNWaWV3KGN1cikpIG8yW2tdID0gY29weUJ1ZmZlcihjdXIpO1xuXHRcdFx0XHRlbHNlIG8yW2tdID0gY2xvbmVQcm90byhjdXIpO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIG8yO1xuXHRcdH1cblx0fVxuXHRmdW5jdGlvbiByZmRjQ2lyY2xlcyhvcHRzKSB7XG5cdFx0Y29uc3QgcmVmcyA9IFtdO1xuXHRcdGNvbnN0IHJlZnNOZXcgPSBbXTtcblx0XHRjb25zdCBjb25zdHJ1Y3RvckhhbmRsZXJzID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0XHRjb25zdHJ1Y3RvckhhbmRsZXJzLnNldChEYXRlLCAobykgPT4gbmV3IERhdGUobykpO1xuXHRcdGNvbnN0cnVjdG9ySGFuZGxlcnMuc2V0KE1hcCwgKG8sIGZuKSA9PiBuZXcgTWFwKGNsb25lQXJyYXkoQXJyYXkuZnJvbShvKSwgZm4pKSk7XG5cdFx0Y29uc3RydWN0b3JIYW5kbGVycy5zZXQoU2V0LCAobywgZm4pID0+IG5ldyBTZXQoY2xvbmVBcnJheShBcnJheS5mcm9tKG8pLCBmbikpKTtcblx0XHRpZiAob3B0cy5jb25zdHJ1Y3RvckhhbmRsZXJzKSBmb3IgKGNvbnN0IGhhbmRsZXIgb2Ygb3B0cy5jb25zdHJ1Y3RvckhhbmRsZXJzKSBjb25zdHJ1Y3RvckhhbmRsZXJzLnNldChoYW5kbGVyWzBdLCBoYW5kbGVyWzFdKTtcblx0XHRsZXQgaGFuZGxlciA9IG51bGw7XG5cdFx0cmV0dXJuIG9wdHMucHJvdG8gPyBjbG9uZVByb3RvIDogY2xvbmU7XG5cdFx0ZnVuY3Rpb24gY2xvbmVBcnJheShhLCBmbikge1xuXHRcdFx0Y29uc3Qga2V5cyA9IE9iamVjdC5rZXlzKGEpO1xuXHRcdFx0Y29uc3QgYTIgPSBuZXcgQXJyYXkoa2V5cy5sZW5ndGgpO1xuXHRcdFx0Zm9yIChsZXQgaSA9IDA7IGkgPCBrZXlzLmxlbmd0aDsgaSsrKSB7XG5cdFx0XHRcdGNvbnN0IGsgPSBrZXlzW2ldO1xuXHRcdFx0XHRjb25zdCBjdXIgPSBhW2tdO1xuXHRcdFx0XHRpZiAodHlwZW9mIGN1ciAhPT0gXCJvYmplY3RcIiB8fCBjdXIgPT09IG51bGwpIGEyW2tdID0gY3VyO1xuXHRcdFx0XHRlbHNlIGlmIChjdXIuY29uc3RydWN0b3IgIT09IE9iamVjdCAmJiAoaGFuZGxlciA9IGNvbnN0cnVjdG9ySGFuZGxlcnMuZ2V0KGN1ci5jb25zdHJ1Y3RvcikpKSBhMltrXSA9IGhhbmRsZXIoY3VyLCBmbik7XG5cdFx0XHRcdGVsc2UgaWYgKEFycmF5QnVmZmVyLmlzVmlldyhjdXIpKSBhMltrXSA9IGNvcHlCdWZmZXIoY3VyKTtcblx0XHRcdFx0ZWxzZSB7XG5cdFx0XHRcdFx0Y29uc3QgaW5kZXggPSByZWZzLmluZGV4T2YoY3VyKTtcblx0XHRcdFx0XHRpZiAoaW5kZXggIT09IC0xKSBhMltrXSA9IHJlZnNOZXdbaW5kZXhdO1xuXHRcdFx0XHRcdGVsc2UgYTJba10gPSBmbihjdXIpO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gYTI7XG5cdFx0fVxuXHRcdGZ1bmN0aW9uIGNsb25lKG8pIHtcblx0XHRcdGlmICh0eXBlb2YgbyAhPT0gXCJvYmplY3RcIiB8fCBvID09PSBudWxsKSByZXR1cm4gbztcblx0XHRcdGlmIChBcnJheS5pc0FycmF5KG8pKSByZXR1cm4gY2xvbmVBcnJheShvLCBjbG9uZSk7XG5cdFx0XHRpZiAoby5jb25zdHJ1Y3RvciAhPT0gT2JqZWN0ICYmIChoYW5kbGVyID0gY29uc3RydWN0b3JIYW5kbGVycy5nZXQoby5jb25zdHJ1Y3RvcikpKSByZXR1cm4gaGFuZGxlcihvLCBjbG9uZSk7XG5cdFx0XHRjb25zdCBvMiA9IHt9O1xuXHRcdFx0cmVmcy5wdXNoKG8pO1xuXHRcdFx0cmVmc05ldy5wdXNoKG8yKTtcblx0XHRcdGZvciAoY29uc3QgayBpbiBvKSB7XG5cdFx0XHRcdGlmIChPYmplY3QuaGFzT3duUHJvcGVydHkuY2FsbChvLCBrKSA9PT0gZmFsc2UpIGNvbnRpbnVlO1xuXHRcdFx0XHRjb25zdCBjdXIgPSBvW2tdO1xuXHRcdFx0XHRpZiAodHlwZW9mIGN1ciAhPT0gXCJvYmplY3RcIiB8fCBjdXIgPT09IG51bGwpIG8yW2tdID0gY3VyO1xuXHRcdFx0XHRlbHNlIGlmIChjdXIuY29uc3RydWN0b3IgIT09IE9iamVjdCAmJiAoaGFuZGxlciA9IGNvbnN0cnVjdG9ySGFuZGxlcnMuZ2V0KGN1ci5jb25zdHJ1Y3RvcikpKSBvMltrXSA9IGhhbmRsZXIoY3VyLCBjbG9uZSk7XG5cdFx0XHRcdGVsc2UgaWYgKEFycmF5QnVmZmVyLmlzVmlldyhjdXIpKSBvMltrXSA9IGNvcHlCdWZmZXIoY3VyKTtcblx0XHRcdFx0ZWxzZSB7XG5cdFx0XHRcdFx0Y29uc3QgaSA9IHJlZnMuaW5kZXhPZihjdXIpO1xuXHRcdFx0XHRcdGlmIChpICE9PSAtMSkgbzJba10gPSByZWZzTmV3W2ldO1xuXHRcdFx0XHRcdGVsc2UgbzJba10gPSBjbG9uZShjdXIpO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRyZWZzLnBvcCgpO1xuXHRcdFx0cmVmc05ldy5wb3AoKTtcblx0XHRcdHJldHVybiBvMjtcblx0XHR9XG5cdFx0ZnVuY3Rpb24gY2xvbmVQcm90byhvKSB7XG5cdFx0XHRpZiAodHlwZW9mIG8gIT09IFwib2JqZWN0XCIgfHwgbyA9PT0gbnVsbCkgcmV0dXJuIG87XG5cdFx0XHRpZiAoQXJyYXkuaXNBcnJheShvKSkgcmV0dXJuIGNsb25lQXJyYXkobywgY2xvbmVQcm90byk7XG5cdFx0XHRpZiAoby5jb25zdHJ1Y3RvciAhPT0gT2JqZWN0ICYmIChoYW5kbGVyID0gY29uc3RydWN0b3JIYW5kbGVycy5nZXQoby5jb25zdHJ1Y3RvcikpKSByZXR1cm4gaGFuZGxlcihvLCBjbG9uZVByb3RvKTtcblx0XHRcdGNvbnN0IG8yID0ge307XG5cdFx0XHRyZWZzLnB1c2gobyk7XG5cdFx0XHRyZWZzTmV3LnB1c2gobzIpO1xuXHRcdFx0Zm9yIChjb25zdCBrIGluIG8pIHtcblx0XHRcdFx0Y29uc3QgY3VyID0gb1trXTtcblx0XHRcdFx0aWYgKHR5cGVvZiBjdXIgIT09IFwib2JqZWN0XCIgfHwgY3VyID09PSBudWxsKSBvMltrXSA9IGN1cjtcblx0XHRcdFx0ZWxzZSBpZiAoY3VyLmNvbnN0cnVjdG9yICE9PSBPYmplY3QgJiYgKGhhbmRsZXIgPSBjb25zdHJ1Y3RvckhhbmRsZXJzLmdldChjdXIuY29uc3RydWN0b3IpKSkgbzJba10gPSBoYW5kbGVyKGN1ciwgY2xvbmVQcm90byk7XG5cdFx0XHRcdGVsc2UgaWYgKEFycmF5QnVmZmVyLmlzVmlldyhjdXIpKSBvMltrXSA9IGNvcHlCdWZmZXIoY3VyKTtcblx0XHRcdFx0ZWxzZSB7XG5cdFx0XHRcdFx0Y29uc3QgaSA9IHJlZnMuaW5kZXhPZihjdXIpO1xuXHRcdFx0XHRcdGlmIChpICE9PSAtMSkgbzJba10gPSByZWZzTmV3W2ldO1xuXHRcdFx0XHRcdGVsc2UgbzJba10gPSBjbG9uZVByb3RvKGN1cik7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdHJlZnMucG9wKCk7XG5cdFx0XHRyZWZzTmV3LnBvcCgpO1xuXHRcdFx0cmV0dXJuIG8yO1xuXHRcdH1cblx0fVxufSkpKSgpLCAxKTtcbmZ1bmN0aW9uIE5PT1AoKSB7fVxuY29uc3QgaXNOdW1lcmljID0gKHN0cikgPT4gYCR7K3N0cn1gID09PSBzdHI7XG5jb25zdCBpc01hY09TID0gKCkgPT4gbmF2aWdhdG9yPy5wbGF0Zm9ybSA/IG5hdmlnYXRvcj8ucGxhdGZvcm0udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhcIm1hY1wiKSA6IC9NYWNpbnRvc2gvLnRlc3QobmF2aWdhdG9yLnVzZXJBZ2VudCk7XG5jb25zdCBjbGFzc2lmeVJFID0gLyg/Ol58Wy1fL10pKFxcdykvZztcbmNvbnN0IGNhbWVsaXplUkUgPSAvLShcXHcpL2c7XG5jb25zdCBrZWJhYml6ZVJFID0gLyhbYS16MC05XSkoW0EtWl0pL2c7XG5mdW5jdGlvbiB0b1VwcGVyKF8sIGMpIHtcblx0cmV0dXJuIGMgPyBjLnRvVXBwZXJDYXNlKCkgOiBcIlwiO1xufVxuZnVuY3Rpb24gY2xhc3NpZnkoc3RyKSB7XG5cdHJldHVybiBzdHIgJiYgYCR7c3RyfWAucmVwbGFjZShjbGFzc2lmeVJFLCB0b1VwcGVyKTtcbn1cbmZ1bmN0aW9uIGNhbWVsaXplKHN0cikge1xuXHRyZXR1cm4gc3RyICYmIHN0ci5yZXBsYWNlKGNhbWVsaXplUkUsIHRvVXBwZXIpO1xufVxuZnVuY3Rpb24ga2ViYWJpemUoc3RyKSB7XG5cdHJldHVybiBzdHIgJiYgc3RyLnJlcGxhY2Uoa2ViYWJpemVSRSwgKF8sIGxvd2VyQ2FzZUNoYXJhY3RlciwgdXBwZXJDYXNlTGV0dGVyKSA9PiB7XG5cdFx0cmV0dXJuIGAke2xvd2VyQ2FzZUNoYXJhY3Rlcn0tJHt1cHBlckNhc2VMZXR0ZXJ9YDtcblx0fSkudG9Mb3dlckNhc2UoKTtcbn1cbmZ1bmN0aW9uIGJhc2VuYW1lKGZpbGVuYW1lLCBleHQpIHtcblx0bGV0IG5vcm1hbGl6ZWRGaWxlbmFtZSA9IGZpbGVuYW1lLnJlcGxhY2UoL15bYS16XTovaSwgXCJcIikucmVwbGFjZSgvXFxcXC9nLCBcIi9cIik7XG5cdGlmIChub3JtYWxpemVkRmlsZW5hbWUuZW5kc1dpdGgoYGluZGV4JHtleHR9YCkpIG5vcm1hbGl6ZWRGaWxlbmFtZSA9IG5vcm1hbGl6ZWRGaWxlbmFtZS5yZXBsYWNlKGAvaW5kZXgke2V4dH1gLCBleHQpO1xuXHRjb25zdCBsYXN0U2xhc2hJbmRleCA9IG5vcm1hbGl6ZWRGaWxlbmFtZS5sYXN0SW5kZXhPZihcIi9cIik7XG5cdGNvbnN0IGJhc2VOYW1lV2l0aEV4dCA9IG5vcm1hbGl6ZWRGaWxlbmFtZS5zdWJzdHJpbmcobGFzdFNsYXNoSW5kZXggKyAxKTtcblx0aWYgKGV4dCkge1xuXHRcdGNvbnN0IGV4dEluZGV4ID0gYmFzZU5hbWVXaXRoRXh0Lmxhc3RJbmRleE9mKGV4dCk7XG5cdFx0cmV0dXJuIGJhc2VOYW1lV2l0aEV4dC5zdWJzdHJpbmcoMCwgZXh0SW5kZXgpO1xuXHR9XG5cdHJldHVybiBcIlwiO1xufVxuZnVuY3Rpb24gc29ydEJ5S2V5KHN0YXRlKSB7XG5cdHJldHVybiBzdGF0ZSAmJiBzdGF0ZS5zbGljZSgpLnNvcnQoKGEsIGIpID0+IHtcblx0XHRpZiAoYS5rZXkgPCBiLmtleSkgcmV0dXJuIC0xO1xuXHRcdGlmIChhLmtleSA+IGIua2V5KSByZXR1cm4gMTtcblx0XHRyZXR1cm4gMDtcblx0fSk7XG59XG5jb25zdCBIVFRQX1VSTF9SRSA9IC9eaHR0cHM/OlxcL1xcLy87XG4vKipcbiogQ2hlY2sgYSBzdHJpbmcgaXMgc3RhcnQgd2l0aCBgL2Agb3IgYSB2YWxpZCBodHRwIHVybFxuKi9cbmZ1bmN0aW9uIGlzVXJsU3RyaW5nKHN0cikge1xuXHRyZXR1cm4gc3RyLnN0YXJ0c1dpdGgoXCIvXCIpIHx8IEhUVFBfVVJMX1JFLnRlc3Qoc3RyKTtcbn1cbi8qKlxuKiBAY29weXJpZ2h0IFtyZmRjXShodHRwczovL2dpdGh1Yi5jb20vZGF2aWRtYXJrY2xlbWVudHMvcmZkYylcbiogQGRlc2NyaXB0aW9uIEEgcmVhbGx5IGZhc3QgZGVlcCBjbG9uZSBhbHRlcm5hdGl2ZVxuKi9cbmNvbnN0IGRlZXBDbG9uZSA9ICgwLCBpbXBvcnRfcmZkYy5kZWZhdWx0KSh7IGNpcmNsZXM6IHRydWUgfSk7XG5mdW5jdGlvbiByYW5kb21TdHIoKSB7XG5cdHJldHVybiBNYXRoLnJhbmRvbSgpLnRvU3RyaW5nKDM2KS5zbGljZSgyKTtcbn1cbmZ1bmN0aW9uIGlzT2JqZWN0KHZhbHVlKSB7XG5cdHJldHVybiB0eXBlb2YgdmFsdWUgPT09IFwib2JqZWN0XCIgJiYgIUFycmF5LmlzQXJyYXkodmFsdWUpICYmIHZhbHVlICE9PSBudWxsO1xufVxuZnVuY3Rpb24gaXNBcnJheSh2YWx1ZSkge1xuXHRyZXR1cm4gQXJyYXkuaXNBcnJheSh2YWx1ZSk7XG59XG5mdW5jdGlvbiBpc1NldCh2YWx1ZSkge1xuXHRyZXR1cm4gdmFsdWUgaW5zdGFuY2VvZiBTZXQ7XG59XG5mdW5jdGlvbiBpc01hcCh2YWx1ZSkge1xuXHRyZXR1cm4gdmFsdWUgaW5zdGFuY2VvZiBNYXA7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IEJST0FEQ0FTVF9DSEFOTkVMX05BTUUsIE5PT1AsIFZJRVdfTU9ERV9TVE9SQUdFX0tFWSwgVklURV9QTFVHSU5fQ0xJRU5UX1VSTF9TVE9SQUdFX0tFWSwgVklURV9QTFVHSU5fREVURUNURURfU1RPUkFHRV9LRVksIGJhc2VuYW1lLCBjYW1lbGl6ZSwgY2xhc3NpZnksIGRlZXBDbG9uZSwgaXNBcnJheSwgaXNCcm93c2VyLCBpc0luQ2hyb21lUGFuZWwsIGlzSW5FbGVjdHJvbiwgaXNJbklmcmFtZSwgaXNJblNlcGFyYXRlV2luZG93LCBpc01hY09TLCBpc01hcCwgaXNOdW1lcmljLCBpc051eHRBcHAsIGlzT2JqZWN0LCBpc1NldCwgaXNVcmxTdHJpbmcsIGtlYmFiaXplLCByYW5kb21TdHIsIHNvcnRCeUtleSwgdGFyZ2V0IH07XG4iLCIvLyNyZWdpb24gc3JjL2luZGV4LnRzXG5jb25zdCBERUJPVU5DRV9ERUZBVUxUUyA9IHsgdHJhaWxpbmc6IHRydWUgfTtcbi8qKlxuRGVib3VuY2UgZnVuY3Rpb25zXG5AcGFyYW0gZm4gLSBQcm9taXNlLXJldHVybmluZy9hc3luYyBmdW5jdGlvbiB0byBkZWJvdW5jZS5cbkBwYXJhbSB3YWl0IC0gTWlsbGlzZWNvbmRzIHRvIHdhaXQgYmVmb3JlIGNhbGxpbmcgYGZuYC4gRGVmYXVsdCB2YWx1ZSBpcyAyNW1zXG5AcmV0dXJucyBBIGZ1bmN0aW9uIHRoYXQgZGVsYXlzIGNhbGxpbmcgYGZuYCB1bnRpbCBhZnRlciBgd2FpdGAgbWlsbGlzZWNvbmRzIGhhdmUgZWxhcHNlZCBzaW5jZSB0aGUgbGFzdCB0aW1lIGl0IHdhcyBjYWxsZWQuXG5AZXhhbXBsZVxuYGBgXG5pbXBvcnQgeyBkZWJvdW5jZSB9IGZyb20gJ3BlcmZlY3QtZGVib3VuY2UnO1xuY29uc3QgZXhwZW5zaXZlQ2FsbCA9IGFzeW5jIGlucHV0ID0+IGlucHV0O1xuY29uc3QgZGVib3VuY2VkRm4gPSBkZWJvdW5jZShleHBlbnNpdmVDYWxsLCAyMDApO1xuZm9yIChjb25zdCBudW1iZXIgb2YgWzEsIDIsIDNdKSB7XG5jb25zb2xlLmxvZyhhd2FpdCBkZWJvdW5jZWRGbihudW1iZXIpKTtcbn1cbi8vPT4gMVxuLy89PiAyXG4vLz0+IDNcbmBgYFxuKi9cbmZ1bmN0aW9uIGRlYm91bmNlKGZuLCB3YWl0ID0gMjUsIG9wdGlvbnMgPSB7fSkge1xuXHRvcHRpb25zID0ge1xuXHRcdC4uLkRFQk9VTkNFX0RFRkFVTFRTLFxuXHRcdC4uLm9wdGlvbnNcblx0fTtcblx0aWYgKCFOdW1iZXIuaXNGaW5pdGUod2FpdCkpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJFeHBlY3RlZCBgd2FpdGAgdG8gYmUgYSBmaW5pdGUgbnVtYmVyXCIpO1xuXHRsZXQgbGVhZGluZ1ZhbHVlO1xuXHRsZXQgdGltZW91dDtcblx0bGV0IHJlc29sdmVMaXN0ID0gW107XG5cdGxldCBjdXJyZW50UHJvbWlzZTtcblx0bGV0IHRyYWlsaW5nQXJncztcblx0Y29uc3QgYXBwbHlGbiA9IChfdGhpcywgYXJncykgPT4ge1xuXHRcdGN1cnJlbnRQcm9taXNlID0gX2FwcGx5UHJvbWlzZWQoZm4sIF90aGlzLCBhcmdzKTtcblx0XHRjdXJyZW50UHJvbWlzZS5maW5hbGx5KCgpID0+IHtcblx0XHRcdGN1cnJlbnRQcm9taXNlID0gbnVsbDtcblx0XHRcdGlmIChvcHRpb25zLnRyYWlsaW5nICYmIHRyYWlsaW5nQXJncyAmJiAhdGltZW91dCkge1xuXHRcdFx0XHRjb25zdCBwcm9taXNlID0gYXBwbHlGbihfdGhpcywgdHJhaWxpbmdBcmdzKTtcblx0XHRcdFx0dHJhaWxpbmdBcmdzID0gbnVsbDtcblx0XHRcdFx0cmV0dXJuIHByb21pc2U7XG5cdFx0XHR9XG5cdFx0fSk7XG5cdFx0cmV0dXJuIGN1cnJlbnRQcm9taXNlO1xuXHR9O1xuXHRjb25zdCBkZWJvdW5jZWQgPSBmdW5jdGlvbiguLi5hcmdzKSB7XG5cdFx0aWYgKG9wdGlvbnMudHJhaWxpbmcpIHRyYWlsaW5nQXJncyA9IGFyZ3M7XG5cdFx0aWYgKGN1cnJlbnRQcm9taXNlKSByZXR1cm4gY3VycmVudFByb21pc2U7XG5cdFx0cmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG5cdFx0XHRjb25zdCBzaG91bGRDYWxsTm93ID0gIXRpbWVvdXQgJiYgb3B0aW9ucy5sZWFkaW5nO1xuXHRcdFx0Y2xlYXJUaW1lb3V0KHRpbWVvdXQpO1xuXHRcdFx0dGltZW91dCA9IHNldFRpbWVvdXQoKCkgPT4ge1xuXHRcdFx0XHR0aW1lb3V0ID0gbnVsbDtcblx0XHRcdFx0Y29uc3QgcHJvbWlzZSA9IG9wdGlvbnMubGVhZGluZyA/IGxlYWRpbmdWYWx1ZSA6IGFwcGx5Rm4odGhpcywgYXJncyk7XG5cdFx0XHRcdHRyYWlsaW5nQXJncyA9IG51bGw7XG5cdFx0XHRcdGZvciAoY29uc3QgX3Jlc29sdmUgb2YgcmVzb2x2ZUxpc3QpIF9yZXNvbHZlKHByb21pc2UpO1xuXHRcdFx0XHRyZXNvbHZlTGlzdCA9IFtdO1xuXHRcdFx0fSwgd2FpdCk7XG5cdFx0XHRpZiAoc2hvdWxkQ2FsbE5vdykge1xuXHRcdFx0XHRsZWFkaW5nVmFsdWUgPSBhcHBseUZuKHRoaXMsIGFyZ3MpO1xuXHRcdFx0XHRyZXNvbHZlKGxlYWRpbmdWYWx1ZSk7XG5cdFx0XHR9IGVsc2UgcmVzb2x2ZUxpc3QucHVzaChyZXNvbHZlKTtcblx0XHR9KTtcblx0fTtcblx0Y29uc3QgX2NsZWFyVGltZW91dCA9ICh0aW1lcikgPT4ge1xuXHRcdGlmICh0aW1lcikge1xuXHRcdFx0Y2xlYXJUaW1lb3V0KHRpbWVyKTtcblx0XHRcdHRpbWVvdXQgPSBudWxsO1xuXHRcdH1cblx0fTtcblx0ZGVib3VuY2VkLmlzUGVuZGluZyA9ICgpID0+ICEhdGltZW91dDtcblx0ZGVib3VuY2VkLmNhbmNlbCA9ICgpID0+IHtcblx0XHRfY2xlYXJUaW1lb3V0KHRpbWVvdXQpO1xuXHRcdHJlc29sdmVMaXN0ID0gW107XG5cdFx0dHJhaWxpbmdBcmdzID0gbnVsbDtcblx0fTtcblx0ZGVib3VuY2VkLmZsdXNoID0gKCkgPT4ge1xuXHRcdF9jbGVhclRpbWVvdXQodGltZW91dCk7XG5cdFx0aWYgKCF0cmFpbGluZ0FyZ3MgfHwgY3VycmVudFByb21pc2UpIHJldHVybjtcblx0XHRjb25zdCBhcmdzID0gdHJhaWxpbmdBcmdzO1xuXHRcdHRyYWlsaW5nQXJncyA9IG51bGw7XG5cdFx0cmV0dXJuIGFwcGx5Rm4odGhpcywgYXJncyk7XG5cdH07XG5cdHJldHVybiBkZWJvdW5jZWQ7XG59XG5hc3luYyBmdW5jdGlvbiBfYXBwbHlQcm9taXNlZChmbiwgX3RoaXMsIGFyZ3MpIHtcblx0cmV0dXJuIGF3YWl0IGZuLmFwcGx5KF90aGlzLCBhcmdzKTtcbn1cblxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBkZWJvdW5jZSB9OyIsImZ1bmN0aW9uIGZsYXRIb29rcyhjb25maWdIb29rcywgaG9va3MgPSB7fSwgcGFyZW50TmFtZSkge1xuICBmb3IgKGNvbnN0IGtleSBpbiBjb25maWdIb29rcykge1xuICAgIGNvbnN0IHN1Ykhvb2sgPSBjb25maWdIb29rc1trZXldO1xuICAgIGNvbnN0IG5hbWUgPSBwYXJlbnROYW1lID8gYCR7cGFyZW50TmFtZX06JHtrZXl9YCA6IGtleTtcbiAgICBpZiAodHlwZW9mIHN1Ykhvb2sgPT09IFwib2JqZWN0XCIgJiYgc3ViSG9vayAhPT0gbnVsbCkge1xuICAgICAgZmxhdEhvb2tzKHN1Ykhvb2ssIGhvb2tzLCBuYW1lKTtcbiAgICB9IGVsc2UgaWYgKHR5cGVvZiBzdWJIb29rID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgIGhvb2tzW25hbWVdID0gc3ViSG9vaztcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGhvb2tzO1xufVxuZnVuY3Rpb24gbWVyZ2VIb29rcyguLi5ob29rcykge1xuICBjb25zdCBmaW5hbEhvb2tzID0ge307XG4gIGZvciAoY29uc3QgaG9vayBvZiBob29rcykge1xuICAgIGNvbnN0IGZsYXRlbkhvb2sgPSBmbGF0SG9va3MoaG9vayk7XG4gICAgZm9yIChjb25zdCBrZXkgaW4gZmxhdGVuSG9vaykge1xuICAgICAgaWYgKGZpbmFsSG9va3Nba2V5XSkge1xuICAgICAgICBmaW5hbEhvb2tzW2tleV0ucHVzaChmbGF0ZW5Ib29rW2tleV0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgZmluYWxIb29rc1trZXldID0gW2ZsYXRlbkhvb2tba2V5XV07XG4gICAgICB9XG4gICAgfVxuICB9XG4gIGZvciAoY29uc3Qga2V5IGluIGZpbmFsSG9va3MpIHtcbiAgICBpZiAoZmluYWxIb29rc1trZXldLmxlbmd0aCA+IDEpIHtcbiAgICAgIGNvbnN0IGFycmF5ID0gZmluYWxIb29rc1trZXldO1xuICAgICAgZmluYWxIb29rc1trZXldID0gKC4uLmFyZ3VtZW50c18pID0+IHNlcmlhbChhcnJheSwgKGZ1bmN0aW9uXykgPT4gZnVuY3Rpb25fKC4uLmFyZ3VtZW50c18pKTtcbiAgICB9IGVsc2Uge1xuICAgICAgZmluYWxIb29rc1trZXldID0gZmluYWxIb29rc1trZXldWzBdO1xuICAgIH1cbiAgfVxuICByZXR1cm4gZmluYWxIb29rcztcbn1cbmZ1bmN0aW9uIHNlcmlhbCh0YXNrcywgZnVuY3Rpb25fKSB7XG4gIHJldHVybiB0YXNrcy5yZWR1Y2UoXG4gICAgKHByb21pc2UsIHRhc2spID0+IHByb21pc2UudGhlbigoKSA9PiBmdW5jdGlvbl8odGFzaykpLFxuICAgIFByb21pc2UucmVzb2x2ZSgpXG4gICk7XG59XG5jb25zdCBkZWZhdWx0VGFzayA9IHsgcnVuOiAoZnVuY3Rpb25fKSA9PiBmdW5jdGlvbl8oKSB9O1xuY29uc3QgX2NyZWF0ZVRhc2sgPSAoKSA9PiBkZWZhdWx0VGFzaztcbmNvbnN0IGNyZWF0ZVRhc2sgPSB0eXBlb2YgY29uc29sZS5jcmVhdGVUYXNrICE9PSBcInVuZGVmaW5lZFwiID8gY29uc29sZS5jcmVhdGVUYXNrIDogX2NyZWF0ZVRhc2s7XG5mdW5jdGlvbiBzZXJpYWxUYXNrQ2FsbGVyKGhvb2tzLCBhcmdzKSB7XG4gIGNvbnN0IG5hbWUgPSBhcmdzLnNoaWZ0KCk7XG4gIGNvbnN0IHRhc2sgPSBjcmVhdGVUYXNrKG5hbWUpO1xuICByZXR1cm4gaG9va3MucmVkdWNlKFxuICAgIChwcm9taXNlLCBob29rRnVuY3Rpb24pID0+IHByb21pc2UudGhlbigoKSA9PiB0YXNrLnJ1bigoKSA9PiBob29rRnVuY3Rpb24oLi4uYXJncykpKSxcbiAgICBQcm9taXNlLnJlc29sdmUoKVxuICApO1xufVxuZnVuY3Rpb24gcGFyYWxsZWxUYXNrQ2FsbGVyKGhvb2tzLCBhcmdzKSB7XG4gIGNvbnN0IG5hbWUgPSBhcmdzLnNoaWZ0KCk7XG4gIGNvbnN0IHRhc2sgPSBjcmVhdGVUYXNrKG5hbWUpO1xuICByZXR1cm4gUHJvbWlzZS5hbGwoaG9va3MubWFwKChob29rKSA9PiB0YXNrLnJ1bigoKSA9PiBob29rKC4uLmFyZ3MpKSkpO1xufVxuZnVuY3Rpb24gc2VyaWFsQ2FsbGVyKGhvb2tzLCBhcmd1bWVudHNfKSB7XG4gIHJldHVybiBob29rcy5yZWR1Y2UoXG4gICAgKHByb21pc2UsIGhvb2tGdW5jdGlvbikgPT4gcHJvbWlzZS50aGVuKCgpID0+IGhvb2tGdW5jdGlvbiguLi5hcmd1bWVudHNfIHx8IFtdKSksXG4gICAgUHJvbWlzZS5yZXNvbHZlKClcbiAgKTtcbn1cbmZ1bmN0aW9uIHBhcmFsbGVsQ2FsbGVyKGhvb2tzLCBhcmdzKSB7XG4gIHJldHVybiBQcm9taXNlLmFsbChob29rcy5tYXAoKGhvb2spID0+IGhvb2soLi4uYXJncyB8fCBbXSkpKTtcbn1cbmZ1bmN0aW9uIGNhbGxFYWNoV2l0aChjYWxsYmFja3MsIGFyZzApIHtcbiAgZm9yIChjb25zdCBjYWxsYmFjayBvZiBbLi4uY2FsbGJhY2tzXSkge1xuICAgIGNhbGxiYWNrKGFyZzApO1xuICB9XG59XG5cbmNsYXNzIEhvb2thYmxlIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgdGhpcy5faG9va3MgPSB7fTtcbiAgICB0aGlzLl9iZWZvcmUgPSB2b2lkIDA7XG4gICAgdGhpcy5fYWZ0ZXIgPSB2b2lkIDA7XG4gICAgdGhpcy5fZGVwcmVjYXRlZE1lc3NhZ2VzID0gdm9pZCAwO1xuICAgIHRoaXMuX2RlcHJlY2F0ZWRIb29rcyA9IHt9O1xuICAgIHRoaXMuaG9vayA9IHRoaXMuaG9vay5iaW5kKHRoaXMpO1xuICAgIHRoaXMuY2FsbEhvb2sgPSB0aGlzLmNhbGxIb29rLmJpbmQodGhpcyk7XG4gICAgdGhpcy5jYWxsSG9va1dpdGggPSB0aGlzLmNhbGxIb29rV2l0aC5iaW5kKHRoaXMpO1xuICB9XG4gIGhvb2sobmFtZSwgZnVuY3Rpb25fLCBvcHRpb25zID0ge30pIHtcbiAgICBpZiAoIW5hbWUgfHwgdHlwZW9mIGZ1bmN0aW9uXyAhPT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgfTtcbiAgICB9XG4gICAgY29uc3Qgb3JpZ2luYWxOYW1lID0gbmFtZTtcbiAgICBsZXQgZGVwO1xuICAgIHdoaWxlICh0aGlzLl9kZXByZWNhdGVkSG9va3NbbmFtZV0pIHtcbiAgICAgIGRlcCA9IHRoaXMuX2RlcHJlY2F0ZWRIb29rc1tuYW1lXTtcbiAgICAgIG5hbWUgPSBkZXAudG87XG4gICAgfVxuICAgIGlmIChkZXAgJiYgIW9wdGlvbnMuYWxsb3dEZXByZWNhdGVkKSB7XG4gICAgICBsZXQgbWVzc2FnZSA9IGRlcC5tZXNzYWdlO1xuICAgICAgaWYgKCFtZXNzYWdlKSB7XG4gICAgICAgIG1lc3NhZ2UgPSBgJHtvcmlnaW5hbE5hbWV9IGhvb2sgaGFzIGJlZW4gZGVwcmVjYXRlZGAgKyAoZGVwLnRvID8gYCwgcGxlYXNlIHVzZSAke2RlcC50b31gIDogXCJcIik7XG4gICAgICB9XG4gICAgICBpZiAoIXRoaXMuX2RlcHJlY2F0ZWRNZXNzYWdlcykge1xuICAgICAgICB0aGlzLl9kZXByZWNhdGVkTWVzc2FnZXMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuICAgICAgfVxuICAgICAgaWYgKCF0aGlzLl9kZXByZWNhdGVkTWVzc2FnZXMuaGFzKG1lc3NhZ2UpKSB7XG4gICAgICAgIGNvbnNvbGUud2FybihtZXNzYWdlKTtcbiAgICAgICAgdGhpcy5fZGVwcmVjYXRlZE1lc3NhZ2VzLmFkZChtZXNzYWdlKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKCFmdW5jdGlvbl8ubmFtZSkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGZ1bmN0aW9uXywgXCJuYW1lXCIsIHtcbiAgICAgICAgICBnZXQ6ICgpID0+IFwiX1wiICsgbmFtZS5yZXBsYWNlKC9cXFcrL2csIFwiX1wiKSArIFwiX2hvb2tfY2JcIixcbiAgICAgICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICAgICAgfSk7XG4gICAgICB9IGNhdGNoIHtcbiAgICAgIH1cbiAgICB9XG4gICAgdGhpcy5faG9va3NbbmFtZV0gPSB0aGlzLl9ob29rc1tuYW1lXSB8fCBbXTtcbiAgICB0aGlzLl9ob29rc1tuYW1lXS5wdXNoKGZ1bmN0aW9uXyk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGlmIChmdW5jdGlvbl8pIHtcbiAgICAgICAgdGhpcy5yZW1vdmVIb29rKG5hbWUsIGZ1bmN0aW9uXyk7XG4gICAgICAgIGZ1bmN0aW9uXyA9IHZvaWQgMDtcbiAgICAgIH1cbiAgICB9O1xuICB9XG4gIGhvb2tPbmNlKG5hbWUsIGZ1bmN0aW9uXykge1xuICAgIGxldCBfdW5yZWc7XG4gICAgbGV0IF9mdW5jdGlvbiA9ICguLi5hcmd1bWVudHNfKSA9PiB7XG4gICAgICBpZiAodHlwZW9mIF91bnJlZyA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICAgIF91bnJlZygpO1xuICAgICAgfVxuICAgICAgX3VucmVnID0gdm9pZCAwO1xuICAgICAgX2Z1bmN0aW9uID0gdm9pZCAwO1xuICAgICAgcmV0dXJuIGZ1bmN0aW9uXyguLi5hcmd1bWVudHNfKTtcbiAgICB9O1xuICAgIF91bnJlZyA9IHRoaXMuaG9vayhuYW1lLCBfZnVuY3Rpb24pO1xuICAgIHJldHVybiBfdW5yZWc7XG4gIH1cbiAgcmVtb3ZlSG9vayhuYW1lLCBmdW5jdGlvbl8pIHtcbiAgICBpZiAodGhpcy5faG9va3NbbmFtZV0pIHtcbiAgICAgIGNvbnN0IGluZGV4ID0gdGhpcy5faG9va3NbbmFtZV0uaW5kZXhPZihmdW5jdGlvbl8pO1xuICAgICAgaWYgKGluZGV4ICE9PSAtMSkge1xuICAgICAgICB0aGlzLl9ob29rc1tuYW1lXS5zcGxpY2UoaW5kZXgsIDEpO1xuICAgICAgfVxuICAgICAgaWYgKHRoaXMuX2hvb2tzW25hbWVdLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICBkZWxldGUgdGhpcy5faG9va3NbbmFtZV07XG4gICAgICB9XG4gICAgfVxuICB9XG4gIGRlcHJlY2F0ZUhvb2sobmFtZSwgZGVwcmVjYXRlZCkge1xuICAgIHRoaXMuX2RlcHJlY2F0ZWRIb29rc1tuYW1lXSA9IHR5cGVvZiBkZXByZWNhdGVkID09PSBcInN0cmluZ1wiID8geyB0bzogZGVwcmVjYXRlZCB9IDogZGVwcmVjYXRlZDtcbiAgICBjb25zdCBfaG9va3MgPSB0aGlzLl9ob29rc1tuYW1lXSB8fCBbXTtcbiAgICBkZWxldGUgdGhpcy5faG9va3NbbmFtZV07XG4gICAgZm9yIChjb25zdCBob29rIG9mIF9ob29rcykge1xuICAgICAgdGhpcy5ob29rKG5hbWUsIGhvb2spO1xuICAgIH1cbiAgfVxuICBkZXByZWNhdGVIb29rcyhkZXByZWNhdGVkSG9va3MpIHtcbiAgICBPYmplY3QuYXNzaWduKHRoaXMuX2RlcHJlY2F0ZWRIb29rcywgZGVwcmVjYXRlZEhvb2tzKTtcbiAgICBmb3IgKGNvbnN0IG5hbWUgaW4gZGVwcmVjYXRlZEhvb2tzKSB7XG4gICAgICB0aGlzLmRlcHJlY2F0ZUhvb2sobmFtZSwgZGVwcmVjYXRlZEhvb2tzW25hbWVdKTtcbiAgICB9XG4gIH1cbiAgYWRkSG9va3MoY29uZmlnSG9va3MpIHtcbiAgICBjb25zdCBob29rcyA9IGZsYXRIb29rcyhjb25maWdIb29rcyk7XG4gICAgY29uc3QgcmVtb3ZlRm5zID0gT2JqZWN0LmtleXMoaG9va3MpLm1hcChcbiAgICAgIChrZXkpID0+IHRoaXMuaG9vayhrZXksIGhvb2tzW2tleV0pXG4gICAgKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgZm9yIChjb25zdCB1bnJlZyBvZiByZW1vdmVGbnMuc3BsaWNlKDAsIHJlbW92ZUZucy5sZW5ndGgpKSB7XG4gICAgICAgIHVucmVnKCk7XG4gICAgICB9XG4gICAgfTtcbiAgfVxuICByZW1vdmVIb29rcyhjb25maWdIb29rcykge1xuICAgIGNvbnN0IGhvb2tzID0gZmxhdEhvb2tzKGNvbmZpZ0hvb2tzKTtcbiAgICBmb3IgKGNvbnN0IGtleSBpbiBob29rcykge1xuICAgICAgdGhpcy5yZW1vdmVIb29rKGtleSwgaG9va3Nba2V5XSk7XG4gICAgfVxuICB9XG4gIHJlbW92ZUFsbEhvb2tzKCkge1xuICAgIGZvciAoY29uc3Qga2V5IGluIHRoaXMuX2hvb2tzKSB7XG4gICAgICBkZWxldGUgdGhpcy5faG9va3Nba2V5XTtcbiAgICB9XG4gIH1cbiAgY2FsbEhvb2sobmFtZSwgLi4uYXJndW1lbnRzXykge1xuICAgIGFyZ3VtZW50c18udW5zaGlmdChuYW1lKTtcbiAgICByZXR1cm4gdGhpcy5jYWxsSG9va1dpdGgoc2VyaWFsVGFza0NhbGxlciwgbmFtZSwgLi4uYXJndW1lbnRzXyk7XG4gIH1cbiAgY2FsbEhvb2tQYXJhbGxlbChuYW1lLCAuLi5hcmd1bWVudHNfKSB7XG4gICAgYXJndW1lbnRzXy51bnNoaWZ0KG5hbWUpO1xuICAgIHJldHVybiB0aGlzLmNhbGxIb29rV2l0aChwYXJhbGxlbFRhc2tDYWxsZXIsIG5hbWUsIC4uLmFyZ3VtZW50c18pO1xuICB9XG4gIGNhbGxIb29rV2l0aChjYWxsZXIsIG5hbWUsIC4uLmFyZ3VtZW50c18pIHtcbiAgICBjb25zdCBldmVudCA9IHRoaXMuX2JlZm9yZSB8fCB0aGlzLl9hZnRlciA/IHsgbmFtZSwgYXJnczogYXJndW1lbnRzXywgY29udGV4dDoge30gfSA6IHZvaWQgMDtcbiAgICBpZiAodGhpcy5fYmVmb3JlKSB7XG4gICAgICBjYWxsRWFjaFdpdGgodGhpcy5fYmVmb3JlLCBldmVudCk7XG4gICAgfVxuICAgIGNvbnN0IHJlc3VsdCA9IGNhbGxlcihcbiAgICAgIG5hbWUgaW4gdGhpcy5faG9va3MgPyBbLi4udGhpcy5faG9va3NbbmFtZV1dIDogW10sXG4gICAgICBhcmd1bWVudHNfXG4gICAgKTtcbiAgICBpZiAocmVzdWx0IGluc3RhbmNlb2YgUHJvbWlzZSkge1xuICAgICAgcmV0dXJuIHJlc3VsdC5maW5hbGx5KCgpID0+IHtcbiAgICAgICAgaWYgKHRoaXMuX2FmdGVyICYmIGV2ZW50KSB7XG4gICAgICAgICAgY2FsbEVhY2hXaXRoKHRoaXMuX2FmdGVyLCBldmVudCk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH1cbiAgICBpZiAodGhpcy5fYWZ0ZXIgJiYgZXZlbnQpIHtcbiAgICAgIGNhbGxFYWNoV2l0aCh0aGlzLl9hZnRlciwgZXZlbnQpO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xuICB9XG4gIGJlZm9yZUVhY2goZnVuY3Rpb25fKSB7XG4gICAgdGhpcy5fYmVmb3JlID0gdGhpcy5fYmVmb3JlIHx8IFtdO1xuICAgIHRoaXMuX2JlZm9yZS5wdXNoKGZ1bmN0aW9uXyk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGlmICh0aGlzLl9iZWZvcmUgIT09IHZvaWQgMCkge1xuICAgICAgICBjb25zdCBpbmRleCA9IHRoaXMuX2JlZm9yZS5pbmRleE9mKGZ1bmN0aW9uXyk7XG4gICAgICAgIGlmIChpbmRleCAhPT0gLTEpIHtcbiAgICAgICAgICB0aGlzLl9iZWZvcmUuc3BsaWNlKGluZGV4LCAxKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH07XG4gIH1cbiAgYWZ0ZXJFYWNoKGZ1bmN0aW9uXykge1xuICAgIHRoaXMuX2FmdGVyID0gdGhpcy5fYWZ0ZXIgfHwgW107XG4gICAgdGhpcy5fYWZ0ZXIucHVzaChmdW5jdGlvbl8pO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBpZiAodGhpcy5fYWZ0ZXIgIT09IHZvaWQgMCkge1xuICAgICAgICBjb25zdCBpbmRleCA9IHRoaXMuX2FmdGVyLmluZGV4T2YoZnVuY3Rpb25fKTtcbiAgICAgICAgaWYgKGluZGV4ICE9PSAtMSkge1xuICAgICAgICAgIHRoaXMuX2FmdGVyLnNwbGljZShpbmRleCwgMSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9O1xuICB9XG59XG5mdW5jdGlvbiBjcmVhdGVIb29rcygpIHtcbiAgcmV0dXJuIG5ldyBIb29rYWJsZSgpO1xufVxuXG5jb25zdCBpc0Jyb3dzZXIgPSB0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiO1xuZnVuY3Rpb24gY3JlYXRlRGVidWdnZXIoaG9va3MsIF9vcHRpb25zID0ge30pIHtcbiAgY29uc3Qgb3B0aW9ucyA9IHtcbiAgICBpbnNwZWN0OiBpc0Jyb3dzZXIsXG4gICAgZ3JvdXA6IGlzQnJvd3NlcixcbiAgICBmaWx0ZXI6ICgpID0+IHRydWUsXG4gICAgLi4uX29wdGlvbnNcbiAgfTtcbiAgY29uc3QgX2ZpbHRlciA9IG9wdGlvbnMuZmlsdGVyO1xuICBjb25zdCBmaWx0ZXIgPSB0eXBlb2YgX2ZpbHRlciA9PT0gXCJzdHJpbmdcIiA/IChuYW1lKSA9PiBuYW1lLnN0YXJ0c1dpdGgoX2ZpbHRlcikgOiBfZmlsdGVyO1xuICBjb25zdCBfdGFnID0gb3B0aW9ucy50YWcgPyBgWyR7b3B0aW9ucy50YWd9XSBgIDogXCJcIjtcbiAgY29uc3QgbG9nUHJlZml4ID0gKGV2ZW50KSA9PiBfdGFnICsgZXZlbnQubmFtZSArIFwiXCIucGFkRW5kKGV2ZW50Ll9pZCwgXCJcXDBcIik7XG4gIGNvbnN0IF9pZEN0ciA9IHt9O1xuICBjb25zdCB1bnN1YnNjcmliZUJlZm9yZSA9IGhvb2tzLmJlZm9yZUVhY2goKGV2ZW50KSA9PiB7XG4gICAgaWYgKGZpbHRlciAhPT0gdm9pZCAwICYmICFmaWx0ZXIoZXZlbnQubmFtZSkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgX2lkQ3RyW2V2ZW50Lm5hbWVdID0gX2lkQ3RyW2V2ZW50Lm5hbWVdIHx8IDA7XG4gICAgZXZlbnQuX2lkID0gX2lkQ3RyW2V2ZW50Lm5hbWVdKys7XG4gICAgY29uc29sZS50aW1lKGxvZ1ByZWZpeChldmVudCkpO1xuICB9KTtcbiAgY29uc3QgdW5zdWJzY3JpYmVBZnRlciA9IGhvb2tzLmFmdGVyRWFjaCgoZXZlbnQpID0+IHtcbiAgICBpZiAoZmlsdGVyICE9PSB2b2lkIDAgJiYgIWZpbHRlcihldmVudC5uYW1lKSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAob3B0aW9ucy5ncm91cCkge1xuICAgICAgY29uc29sZS5ncm91cENvbGxhcHNlZChldmVudC5uYW1lKTtcbiAgICB9XG4gICAgaWYgKG9wdGlvbnMuaW5zcGVjdCkge1xuICAgICAgY29uc29sZS50aW1lTG9nKGxvZ1ByZWZpeChldmVudCksIGV2ZW50LmFyZ3MpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zb2xlLnRpbWVFbmQobG9nUHJlZml4KGV2ZW50KSk7XG4gICAgfVxuICAgIGlmIChvcHRpb25zLmdyb3VwKSB7XG4gICAgICBjb25zb2xlLmdyb3VwRW5kKCk7XG4gICAgfVxuICAgIF9pZEN0cltldmVudC5uYW1lXS0tO1xuICB9KTtcbiAgcmV0dXJuIHtcbiAgICAvKiogU3RvcCBkZWJ1Z2dpbmcgYW5kIHJlbW92ZSBsaXN0ZW5lcnMgKi9cbiAgICBjbG9zZTogKCkgPT4ge1xuICAgICAgdW5zdWJzY3JpYmVCZWZvcmUoKTtcbiAgICAgIHVuc3Vic2NyaWJlQWZ0ZXIoKTtcbiAgICB9XG4gIH07XG59XG5cbmV4cG9ydCB7IEhvb2thYmxlLCBjcmVhdGVEZWJ1Z2dlciwgY3JlYXRlSG9va3MsIGZsYXRIb29rcywgbWVyZ2VIb29rcywgcGFyYWxsZWxDYWxsZXIsIHNlcmlhbCwgc2VyaWFsQ2FsbGVyIH07XG4iLCJjb25zdCBUWVBFX1JFUVVFU1QgPSBcInFcIjtcbmNvbnN0IFRZUEVfUkVTUE9OU0UgPSBcInNcIjtcbmNvbnN0IERFRkFVTFRfVElNRU9VVCA9IDZlNDtcbmZ1bmN0aW9uIGRlZmF1bHRTZXJpYWxpemUoaSkge1xuICByZXR1cm4gaTtcbn1cbmNvbnN0IGRlZmF1bHREZXNlcmlhbGl6ZSA9IGRlZmF1bHRTZXJpYWxpemU7XG5jb25zdCB7IGNsZWFyVGltZW91dCwgc2V0VGltZW91dCB9ID0gZ2xvYmFsVGhpcztcbmNvbnN0IHJhbmRvbSA9IE1hdGgucmFuZG9tLmJpbmQoTWF0aCk7XG5mdW5jdGlvbiBjcmVhdGVCaXJwYygkZnVuY3Rpb25zLCBvcHRpb25zKSB7XG4gIGNvbnN0IHtcbiAgICBwb3N0LFxuICAgIG9uLFxuICAgIG9mZiA9ICgpID0+IHtcbiAgICB9LFxuICAgIGV2ZW50TmFtZXMgPSBbXSxcbiAgICBzZXJpYWxpemUgPSBkZWZhdWx0U2VyaWFsaXplLFxuICAgIGRlc2VyaWFsaXplID0gZGVmYXVsdERlc2VyaWFsaXplLFxuICAgIHJlc29sdmVyLFxuICAgIGJpbmQgPSBcInJwY1wiLFxuICAgIHRpbWVvdXQgPSBERUZBVUxUX1RJTUVPVVRcbiAgfSA9IG9wdGlvbnM7XG4gIGxldCAkY2xvc2VkID0gZmFsc2U7XG4gIGNvbnN0IF9ycGNQcm9taXNlTWFwID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcbiAgbGV0IF9wcm9taXNlSW5pdDtcbiAgbGV0IHJwYztcbiAgYXN5bmMgZnVuY3Rpb24gX2NhbGwobWV0aG9kLCBhcmdzLCBldmVudCwgb3B0aW9uYWwpIHtcbiAgICBpZiAoJGNsb3NlZClcbiAgICAgIHRocm93IG5ldyBFcnJvcihgW2JpcnBjXSBycGMgaXMgY2xvc2VkLCBjYW5ub3QgY2FsbCBcIiR7bWV0aG9kfVwiYCk7XG4gICAgY29uc3QgcmVxID0geyBtOiBtZXRob2QsIGE6IGFyZ3MsIHQ6IFRZUEVfUkVRVUVTVCB9O1xuICAgIGlmIChvcHRpb25hbClcbiAgICAgIHJlcS5vID0gdHJ1ZTtcbiAgICBjb25zdCBzZW5kID0gYXN5bmMgKF9yZXEpID0+IHBvc3Qoc2VyaWFsaXplKF9yZXEpKTtcbiAgICBpZiAoZXZlbnQpIHtcbiAgICAgIGF3YWl0IHNlbmQocmVxKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKF9wcm9taXNlSW5pdCkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgYXdhaXQgX3Byb21pc2VJbml0O1xuICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgX3Byb21pc2VJbml0ID0gdm9pZCAwO1xuICAgICAgfVxuICAgIH1cbiAgICBsZXQgeyBwcm9taXNlLCByZXNvbHZlLCByZWplY3QgfSA9IGNyZWF0ZVByb21pc2VXaXRoUmVzb2x2ZXJzKCk7XG4gICAgY29uc3QgaWQgPSBuYW5vaWQoKTtcbiAgICByZXEuaSA9IGlkO1xuICAgIGxldCB0aW1lb3V0SWQ7XG4gICAgYXN5bmMgZnVuY3Rpb24gaGFuZGxlcihuZXdSZXEgPSByZXEpIHtcbiAgICAgIGlmICh0aW1lb3V0ID49IDApIHtcbiAgICAgICAgdGltZW91dElkID0gc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IGhhbmRsZVJlc3VsdCA9IG9wdGlvbnMub25UaW1lb3V0RXJyb3I/LmNhbGwocnBjLCBtZXRob2QsIGFyZ3MpO1xuICAgICAgICAgICAgaWYgKGhhbmRsZVJlc3VsdCAhPT0gdHJ1ZSlcbiAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBbYmlycGNdIHRpbWVvdXQgb24gY2FsbGluZyBcIiR7bWV0aG9kfVwiYCk7XG4gICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgcmVqZWN0KGUpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBfcnBjUHJvbWlzZU1hcC5kZWxldGUoaWQpO1xuICAgICAgICB9LCB0aW1lb3V0KTtcbiAgICAgICAgaWYgKHR5cGVvZiB0aW1lb3V0SWQgPT09IFwib2JqZWN0XCIpXG4gICAgICAgICAgdGltZW91dElkID0gdGltZW91dElkLnVucmVmPy4oKTtcbiAgICAgIH1cbiAgICAgIF9ycGNQcm9taXNlTWFwLnNldChpZCwgeyByZXNvbHZlLCByZWplY3QsIHRpbWVvdXRJZCwgbWV0aG9kIH0pO1xuICAgICAgYXdhaXQgc2VuZChuZXdSZXEpO1xuICAgICAgcmV0dXJuIHByb21pc2U7XG4gICAgfVxuICAgIHRyeSB7XG4gICAgICBpZiAob3B0aW9ucy5vblJlcXVlc3QpXG4gICAgICAgIGF3YWl0IG9wdGlvbnMub25SZXF1ZXN0LmNhbGwocnBjLCByZXEsIGhhbmRsZXIsIHJlc29sdmUpO1xuICAgICAgZWxzZVxuICAgICAgICBhd2FpdCBoYW5kbGVyKCk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgaWYgKG9wdGlvbnMub25HZW5lcmFsRXJyb3I/LmNhbGwocnBjLCBlKSAhPT0gdHJ1ZSlcbiAgICAgICAgdGhyb3cgZTtcbiAgICAgIHJldHVybjtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgY2xlYXJUaW1lb3V0KHRpbWVvdXRJZCk7XG4gICAgICBfcnBjUHJvbWlzZU1hcC5kZWxldGUoaWQpO1xuICAgIH1cbiAgICByZXR1cm4gcHJvbWlzZTtcbiAgfVxuICBjb25zdCAkY2FsbCA9IChtZXRob2QsIC4uLmFyZ3MpID0+IF9jYWxsKG1ldGhvZCwgYXJncywgZmFsc2UpO1xuICBjb25zdCAkY2FsbE9wdGlvbmFsID0gKG1ldGhvZCwgLi4uYXJncykgPT4gX2NhbGwobWV0aG9kLCBhcmdzLCBmYWxzZSwgdHJ1ZSk7XG4gIGNvbnN0ICRjYWxsRXZlbnQgPSAobWV0aG9kLCAuLi5hcmdzKSA9PiBfY2FsbChtZXRob2QsIGFyZ3MsIHRydWUpO1xuICBjb25zdCAkY2FsbFJhdyA9IChvcHRpb25zMikgPT4gX2NhbGwob3B0aW9uczIubWV0aG9kLCBvcHRpb25zMi5hcmdzLCBvcHRpb25zMi5ldmVudCwgb3B0aW9uczIub3B0aW9uYWwpO1xuICBjb25zdCBidWlsdGluTWV0aG9kcyA9IHtcbiAgICAkY2FsbCxcbiAgICAkY2FsbE9wdGlvbmFsLFxuICAgICRjYWxsRXZlbnQsXG4gICAgJGNhbGxSYXcsXG4gICAgJHJlamVjdFBlbmRpbmdDYWxscyxcbiAgICBnZXQgJGNsb3NlZCgpIHtcbiAgICAgIHJldHVybiAkY2xvc2VkO1xuICAgIH0sXG4gICAgZ2V0ICRtZXRhKCkge1xuICAgICAgcmV0dXJuIG9wdGlvbnMubWV0YTtcbiAgICB9LFxuICAgICRjbG9zZSxcbiAgICAkZnVuY3Rpb25zXG4gIH07XG4gIHJwYyA9IG5ldyBQcm94eSh7fSwge1xuICAgIGdldChfLCBtZXRob2QpIHtcbiAgICAgIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoYnVpbHRpbk1ldGhvZHMsIG1ldGhvZCkpXG4gICAgICAgIHJldHVybiBidWlsdGluTWV0aG9kc1ttZXRob2RdO1xuICAgICAgaWYgKG1ldGhvZCA9PT0gXCJ0aGVuXCIgJiYgIWV2ZW50TmFtZXMuaW5jbHVkZXMoXCJ0aGVuXCIpICYmICEoXCJ0aGVuXCIgaW4gJGZ1bmN0aW9ucykpXG4gICAgICAgIHJldHVybiB2b2lkIDA7XG4gICAgICBjb25zdCBzZW5kRXZlbnQgPSAoLi4uYXJncykgPT4gX2NhbGwobWV0aG9kLCBhcmdzLCB0cnVlKTtcbiAgICAgIGlmIChldmVudE5hbWVzLmluY2x1ZGVzKG1ldGhvZCkpIHtcbiAgICAgICAgc2VuZEV2ZW50LmFzRXZlbnQgPSBzZW5kRXZlbnQ7XG4gICAgICAgIHJldHVybiBzZW5kRXZlbnQ7XG4gICAgICB9XG4gICAgICBjb25zdCBzZW5kQ2FsbCA9ICguLi5hcmdzKSA9PiBfY2FsbChtZXRob2QsIGFyZ3MsIGZhbHNlKTtcbiAgICAgIHNlbmRDYWxsLmFzRXZlbnQgPSBzZW5kRXZlbnQ7XG4gICAgICByZXR1cm4gc2VuZENhbGw7XG4gICAgfVxuICB9KTtcbiAgZnVuY3Rpb24gJGNsb3NlKGN1c3RvbUVycm9yKSB7XG4gICAgJGNsb3NlZCA9IHRydWU7XG4gICAgX3JwY1Byb21pc2VNYXAuZm9yRWFjaCgoeyByZWplY3QsIG1ldGhvZCB9KSA9PiB7XG4gICAgICBjb25zdCBlcnJvciA9IG5ldyBFcnJvcihgW2JpcnBjXSBycGMgaXMgY2xvc2VkLCBjYW5ub3QgY2FsbCBcIiR7bWV0aG9kfVwiYCk7XG4gICAgICBpZiAoY3VzdG9tRXJyb3IpIHtcbiAgICAgICAgY3VzdG9tRXJyb3IuY2F1c2UgPz89IGVycm9yO1xuICAgICAgICByZXR1cm4gcmVqZWN0KGN1c3RvbUVycm9yKTtcbiAgICAgIH1cbiAgICAgIHJlamVjdChlcnJvcik7XG4gICAgfSk7XG4gICAgX3JwY1Byb21pc2VNYXAuY2xlYXIoKTtcbiAgICBvZmYob25NZXNzYWdlKTtcbiAgfVxuICBmdW5jdGlvbiAkcmVqZWN0UGVuZGluZ0NhbGxzKGhhbmRsZXIpIHtcbiAgICBjb25zdCBlbnRyaWVzID0gQXJyYXkuZnJvbShfcnBjUHJvbWlzZU1hcC52YWx1ZXMoKSk7XG4gICAgY29uc3QgaGFuZGxlclJlc3VsdHMgPSBlbnRyaWVzLm1hcCgoeyBtZXRob2QsIHJlamVjdCB9KSA9PiB7XG4gICAgICBpZiAoIWhhbmRsZXIpIHtcbiAgICAgICAgcmV0dXJuIHJlamVjdChuZXcgRXJyb3IoYFtiaXJwY106IHJlamVjdGVkIHBlbmRpbmcgY2FsbCBcIiR7bWV0aG9kfVwiLmApKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBoYW5kbGVyKHsgbWV0aG9kLCByZWplY3QgfSk7XG4gICAgfSk7XG4gICAgX3JwY1Byb21pc2VNYXAuY2xlYXIoKTtcbiAgICByZXR1cm4gaGFuZGxlclJlc3VsdHM7XG4gIH1cbiAgYXN5bmMgZnVuY3Rpb24gb25NZXNzYWdlKGRhdGEsIC4uLmV4dHJhKSB7XG4gICAgbGV0IG1zZztcbiAgICB0cnkge1xuICAgICAgbXNnID0gZGVzZXJpYWxpemUoZGF0YSk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgaWYgKG9wdGlvbnMub25HZW5lcmFsRXJyb3I/LmNhbGwocnBjLCBlKSAhPT0gdHJ1ZSlcbiAgICAgICAgdGhyb3cgZTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKG1zZy50ID09PSBUWVBFX1JFUVVFU1QpIHtcbiAgICAgIGNvbnN0IHsgbTogbWV0aG9kLCBhOiBhcmdzLCBvOiBvcHRpb25hbCB9ID0gbXNnO1xuICAgICAgbGV0IHJlc3VsdCwgZXJyb3I7XG4gICAgICBsZXQgZm4gPSBhd2FpdCAocmVzb2x2ZXIgPyByZXNvbHZlci5jYWxsKHJwYywgbWV0aG9kLCAkZnVuY3Rpb25zW21ldGhvZF0pIDogJGZ1bmN0aW9uc1ttZXRob2RdKTtcbiAgICAgIGlmIChvcHRpb25hbClcbiAgICAgICAgZm4gfHw9ICgpID0+IHZvaWQgMDtcbiAgICAgIGlmICghZm4pIHtcbiAgICAgICAgZXJyb3IgPSBuZXcgRXJyb3IoYFtiaXJwY10gZnVuY3Rpb24gXCIke21ldGhvZH1cIiBub3QgZm91bmRgKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgcmVzdWx0ID0gYXdhaXQgZm4uYXBwbHkoYmluZCA9PT0gXCJycGNcIiA/IHJwYyA6ICRmdW5jdGlvbnMsIGFyZ3MpO1xuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgZXJyb3IgPSBlO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBpZiAobXNnLmkpIHtcbiAgICAgICAgaWYgKGVycm9yICYmIG9wdGlvbnMub25FcnJvcilcbiAgICAgICAgICBvcHRpb25zLm9uRXJyb3IuY2FsbChycGMsIGVycm9yLCBtZXRob2QsIGFyZ3MpO1xuICAgICAgICBpZiAoZXJyb3IgJiYgb3B0aW9ucy5vbkZ1bmN0aW9uRXJyb3IpIHtcbiAgICAgICAgICBpZiAob3B0aW9ucy5vbkZ1bmN0aW9uRXJyb3IuY2FsbChycGMsIGVycm9yLCBtZXRob2QsIGFyZ3MpID09PSB0cnVlKVxuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmICghZXJyb3IpIHtcbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgYXdhaXQgcG9zdChzZXJpYWxpemUoeyB0OiBUWVBFX1JFU1BPTlNFLCBpOiBtc2cuaSwgcjogcmVzdWx0IH0pLCAuLi5leHRyYSk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgZXJyb3IgPSBlO1xuICAgICAgICAgICAgaWYgKG9wdGlvbnMub25HZW5lcmFsRXJyb3I/LmNhbGwocnBjLCBlLCBtZXRob2QsIGFyZ3MpICE9PSB0cnVlKVxuICAgICAgICAgICAgICB0aHJvdyBlO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICB0cnkge1xuICAgICAgICAgIGF3YWl0IHBvc3Qoc2VyaWFsaXplKHsgdDogVFlQRV9SRVNQT05TRSwgaTogbXNnLmksIGU6IGVycm9yIH0pLCAuLi5leHRyYSk7XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICBpZiAob3B0aW9ucy5vbkdlbmVyYWxFcnJvcj8uY2FsbChycGMsIGUsIG1ldGhvZCwgYXJncykgIT09IHRydWUpXG4gICAgICAgICAgICB0aHJvdyBlO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IHsgaTogYWNrLCByOiByZXN1bHQsIGU6IGVycm9yIH0gPSBtc2c7XG4gICAgICBjb25zdCBwcm9taXNlID0gX3JwY1Byb21pc2VNYXAuZ2V0KGFjayk7XG4gICAgICBpZiAocHJvbWlzZSkge1xuICAgICAgICBjbGVhclRpbWVvdXQocHJvbWlzZS50aW1lb3V0SWQpO1xuICAgICAgICBpZiAoZXJyb3IpXG4gICAgICAgICAgcHJvbWlzZS5yZWplY3QoZXJyb3IpO1xuICAgICAgICBlbHNlXG4gICAgICAgICAgcHJvbWlzZS5yZXNvbHZlKHJlc3VsdCk7XG4gICAgICB9XG4gICAgICBfcnBjUHJvbWlzZU1hcC5kZWxldGUoYWNrKTtcbiAgICB9XG4gIH1cbiAgX3Byb21pc2VJbml0ID0gb24ob25NZXNzYWdlKTtcbiAgcmV0dXJuIHJwYztcbn1cbmNvbnN0IGNhY2hlTWFwID0gLyogQF9fUFVSRV9fICovIG5ldyBXZWFrTWFwKCk7XG5mdW5jdGlvbiBjYWNoZWRNYXAoaXRlbXMsIGZuKSB7XG4gIHJldHVybiBpdGVtcy5tYXAoKGkpID0+IHtcbiAgICBsZXQgciA9IGNhY2hlTWFwLmdldChpKTtcbiAgICBpZiAoIXIpIHtcbiAgICAgIHIgPSBmbihpKTtcbiAgICAgIGNhY2hlTWFwLnNldChpLCByKTtcbiAgICB9XG4gICAgcmV0dXJuIHI7XG4gIH0pO1xufVxuZnVuY3Rpb24gY3JlYXRlQmlycGNHcm91cChmdW5jdGlvbnMsIGNoYW5uZWxzLCBvcHRpb25zID0ge30pIHtcbiAgY29uc3QgZ2V0Q2hhbm5lbHMgPSAoKSA9PiB0eXBlb2YgY2hhbm5lbHMgPT09IFwiZnVuY3Rpb25cIiA/IGNoYW5uZWxzKCkgOiBjaGFubmVscztcbiAgY29uc3QgZ2V0Q2xpZW50cyA9IChjaGFubmVsczIgPSBnZXRDaGFubmVscygpKSA9PiBjYWNoZWRNYXAoY2hhbm5lbHMyLCAocykgPT4gY3JlYXRlQmlycGMoZnVuY3Rpb25zLCB7IC4uLm9wdGlvbnMsIC4uLnMgfSkpO1xuICBmdW5jdGlvbiBfYm9hcmRjYXN0KG1ldGhvZCwgYXJncywgZXZlbnQsIG9wdGlvbmFsKSB7XG4gICAgY29uc3QgY2xpZW50cyA9IGdldENsaWVudHMoKTtcbiAgICByZXR1cm4gUHJvbWlzZS5hbGwoY2xpZW50cy5tYXAoKGMpID0+IGMuJGNhbGxSYXcoeyBtZXRob2QsIGFyZ3MsIGV2ZW50LCBvcHRpb25hbCB9KSkpO1xuICB9XG4gIGZ1bmN0aW9uICRjYWxsKG1ldGhvZCwgLi4uYXJncykge1xuICAgIHJldHVybiBfYm9hcmRjYXN0KG1ldGhvZCwgYXJncywgZmFsc2UpO1xuICB9XG4gIGZ1bmN0aW9uICRjYWxsT3B0aW9uYWwobWV0aG9kLCAuLi5hcmdzKSB7XG4gICAgcmV0dXJuIF9ib2FyZGNhc3QobWV0aG9kLCBhcmdzLCBmYWxzZSwgdHJ1ZSk7XG4gIH1cbiAgZnVuY3Rpb24gJGNhbGxFdmVudChtZXRob2QsIC4uLmFyZ3MpIHtcbiAgICByZXR1cm4gX2JvYXJkY2FzdChtZXRob2QsIGFyZ3MsIHRydWUpO1xuICB9XG4gIGNvbnN0IGJyb2FkY2FzdEJ1aWx0aW4gPSB7XG4gICAgJGNhbGwsXG4gICAgJGNhbGxPcHRpb25hbCxcbiAgICAkY2FsbEV2ZW50XG4gIH07XG4gIGNvbnN0IGJyb2FkY2FzdFByb3h5ID0gbmV3IFByb3h5KHt9LCB7XG4gICAgZ2V0KF8sIG1ldGhvZCkge1xuICAgICAgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChicm9hZGNhc3RCdWlsdGluLCBtZXRob2QpKVxuICAgICAgICByZXR1cm4gYnJvYWRjYXN0QnVpbHRpblttZXRob2RdO1xuICAgICAgY29uc3QgY2xpZW50ID0gZ2V0Q2xpZW50cygpO1xuICAgICAgY29uc3QgY2FsbGJhY2tzID0gY2xpZW50Lm1hcCgoYykgPT4gY1ttZXRob2RdKTtcbiAgICAgIGNvbnN0IHNlbmRDYWxsID0gKC4uLmFyZ3MpID0+IHtcbiAgICAgICAgcmV0dXJuIFByb21pc2UuYWxsKGNhbGxiYWNrcy5tYXAoKGkpID0+IGkoLi4uYXJncykpKTtcbiAgICAgIH07XG4gICAgICBzZW5kQ2FsbC5hc0V2ZW50ID0gYXN5bmMgKC4uLmFyZ3MpID0+IHtcbiAgICAgICAgYXdhaXQgUHJvbWlzZS5hbGwoY2FsbGJhY2tzLm1hcCgoaSkgPT4gaS5hc0V2ZW50KC4uLmFyZ3MpKSk7XG4gICAgICB9O1xuICAgICAgcmV0dXJuIHNlbmRDYWxsO1xuICAgIH1cbiAgfSk7XG4gIGZ1bmN0aW9uIHVwZGF0ZUNoYW5uZWxzKGZuKSB7XG4gICAgY29uc3QgY2hhbm5lbHMyID0gZ2V0Q2hhbm5lbHMoKTtcbiAgICBmbj8uKGNoYW5uZWxzMik7XG4gICAgcmV0dXJuIGdldENsaWVudHMoY2hhbm5lbHMyKTtcbiAgfVxuICBnZXRDbGllbnRzKCk7XG4gIHJldHVybiB7XG4gICAgZ2V0IGNsaWVudHMoKSB7XG4gICAgICByZXR1cm4gZ2V0Q2xpZW50cygpO1xuICAgIH0sXG4gICAgZnVuY3Rpb25zLFxuICAgIHVwZGF0ZUNoYW5uZWxzLFxuICAgIGJyb2FkY2FzdDogYnJvYWRjYXN0UHJveHksXG4gICAgLyoqXG4gICAgICogQGRlcHJlY2F0ZWQgdXNlIGBicm9hZGNhc3RgXG4gICAgICovXG4gICAgLy8gQHRzLWV4cGVjdC1lcnJvciBkZXByZWNhdGVkXG4gICAgYm9hcmRjYXN0OiBicm9hZGNhc3RQcm94eVxuICB9O1xufVxuZnVuY3Rpb24gY3JlYXRlUHJvbWlzZVdpdGhSZXNvbHZlcnMoKSB7XG4gIGxldCByZXNvbHZlO1xuICBsZXQgcmVqZWN0O1xuICBjb25zdCBwcm9taXNlID0gbmV3IFByb21pc2UoKHJlcywgcmVqKSA9PiB7XG4gICAgcmVzb2x2ZSA9IHJlcztcbiAgICByZWplY3QgPSByZWo7XG4gIH0pO1xuICByZXR1cm4geyBwcm9taXNlLCByZXNvbHZlLCByZWplY3QgfTtcbn1cbmNvbnN0IHVybEFscGhhYmV0ID0gXCJ1c2VhbmRvbS0yNlQxOTgzNDBQWDc1cHhKQUNLVkVSWU1JTkRCVVNIV09MRl9HUVpiZmdoamtscXZ3eXpyaWN0XCI7XG5mdW5jdGlvbiBuYW5vaWQoc2l6ZSA9IDIxKSB7XG4gIGxldCBpZCA9IFwiXCI7XG4gIGxldCBpID0gc2l6ZTtcbiAgd2hpbGUgKGktLSlcbiAgICBpZCArPSB1cmxBbHBoYWJldFtyYW5kb20oKSAqIDY0IHwgMF07XG4gIHJldHVybiBpZDtcbn1cblxuZXhwb3J0IHsgREVGQVVMVF9USU1FT1VULCBjYWNoZWRNYXAsIGNyZWF0ZUJpcnBjLCBjcmVhdGVCaXJwY0dyb3VwIH07XG4iLCJpbXBvcnQgeyBiYXNlbmFtZSwgY2FtZWxpemUsIGNsYXNzaWZ5LCBkZWVwQ2xvbmUsIGlzQnJvd3NlciwgaXNOdXh0QXBwLCBpc1VybFN0cmluZywga2ViYWJpemUsIHRhcmdldCB9IGZyb20gXCJAdnVlL2RldnRvb2xzLXNoYXJlZFwiO1xuaW1wb3J0IHsgZGVib3VuY2UgfSBmcm9tIFwicGVyZmVjdC1kZWJvdW5jZVwiO1xuaW1wb3J0IHsgY3JlYXRlSG9va3MgfSBmcm9tIFwiaG9va2FibGVcIjtcbmltcG9ydCB7IGNyZWF0ZUJpcnBjLCBjcmVhdGVCaXJwY0dyb3VwIH0gZnJvbSBcImJpcnBjXCI7XG4vLyNyZWdpb24gXFwwcm9sbGRvd24vcnVudGltZS5qc1xudmFyIF9fY3JlYXRlID0gT2JqZWN0LmNyZWF0ZTtcbnZhciBfX2RlZlByb3AgPSBPYmplY3QuZGVmaW5lUHJvcGVydHk7XG52YXIgX19nZXRPd25Qcm9wRGVzYyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3I7XG52YXIgX19nZXRPd25Qcm9wTmFtZXMgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcztcbnZhciBfX2dldFByb3RvT2YgPSBPYmplY3QuZ2V0UHJvdG90eXBlT2Y7XG52YXIgX19oYXNPd25Qcm9wID0gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eTtcbnZhciBfX2NvbW1vbkpTTWluID0gKGNiLCBtb2QpID0+ICgpID0+IChtb2QgfHwgY2IoKG1vZCA9IHsgZXhwb3J0czoge30gfSkuZXhwb3J0cywgbW9kKSwgbW9kLmV4cG9ydHMpO1xudmFyIF9fY29weVByb3BzID0gKHRvLCBmcm9tLCBleGNlcHQsIGRlc2MpID0+IHtcblx0aWYgKGZyb20gJiYgdHlwZW9mIGZyb20gPT09IFwib2JqZWN0XCIgfHwgdHlwZW9mIGZyb20gPT09IFwiZnVuY3Rpb25cIikgZm9yICh2YXIga2V5cyA9IF9fZ2V0T3duUHJvcE5hbWVzKGZyb20pLCBpID0gMCwgbiA9IGtleXMubGVuZ3RoLCBrZXk7IGkgPCBuOyBpKyspIHtcblx0XHRrZXkgPSBrZXlzW2ldO1xuXHRcdGlmICghX19oYXNPd25Qcm9wLmNhbGwodG8sIGtleSkgJiYga2V5ICE9PSBleGNlcHQpIF9fZGVmUHJvcCh0bywga2V5LCB7XG5cdFx0XHRnZXQ6ICgoaykgPT4gZnJvbVtrXSkuYmluZChudWxsLCBrZXkpLFxuXHRcdFx0ZW51bWVyYWJsZTogIShkZXNjID0gX19nZXRPd25Qcm9wRGVzYyhmcm9tLCBrZXkpKSB8fCBkZXNjLmVudW1lcmFibGVcblx0XHR9KTtcblx0fVxuXHRyZXR1cm4gdG87XG59O1xudmFyIF9fdG9FU00gPSAobW9kLCBpc05vZGVNb2RlLCB0YXJnZXQpID0+ICh0YXJnZXQgPSBtb2QgIT0gbnVsbCA/IF9fY3JlYXRlKF9fZ2V0UHJvdG9PZihtb2QpKSA6IHt9LCBfX2NvcHlQcm9wcyhpc05vZGVNb2RlIHx8ICFtb2QgfHwgIW1vZC5fX2VzTW9kdWxlID8gX19kZWZQcm9wKHRhcmdldCwgXCJkZWZhdWx0XCIsIHtcblx0dmFsdWU6IG1vZCxcblx0ZW51bWVyYWJsZTogdHJ1ZVxufSkgOiB0YXJnZXQsIG1vZCkpO1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvbXBhdC9pbmRleC50c1xuZnVuY3Rpb24gb25MZWdhY3lEZXZUb29sc1BsdWdpbkFwaUF2YWlsYWJsZShjYikge1xuXHRpZiAodGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX1BMVUdJTl9BUElfQVZBSUxBQkxFX18pIHtcblx0XHRjYigpO1xuXHRcdHJldHVybjtcblx0fVxuXHRPYmplY3QuZGVmaW5lUHJvcGVydHkodGFyZ2V0LCBcIl9fVlVFX0RFVlRPT0xTX1BMVUdJTl9BUElfQVZBSUxBQkxFX19cIiwge1xuXHRcdHNldCh2YWx1ZSkge1xuXHRcdFx0aWYgKHZhbHVlKSBjYigpO1xuXHRcdH0sXG5cdFx0Y29uZmlndXJhYmxlOiB0cnVlXG5cdH0pO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvY29tcG9uZW50L3V0aWxzL2luZGV4LnRzXG5mdW5jdGlvbiBnZXRDb21wb25lbnRUeXBlTmFtZShvcHRpb25zKSB7XG5cdGlmICh0eXBlb2Ygb3B0aW9ucyA9PT0gXCJmdW5jdGlvblwiKSByZXR1cm4gb3B0aW9ucy5kaXNwbGF5TmFtZSB8fCBvcHRpb25zLm5hbWUgfHwgb3B0aW9ucy5fX1ZVRV9ERVZUT09MU19DT01QT05FTlRfR1VTU0VEX05BTUVfXyB8fCBcIlwiO1xuXHRjb25zdCBuYW1lID0gb3B0aW9ucy5uYW1lIHx8IG9wdGlvbnMuX2NvbXBvbmVudFRhZyB8fCBvcHRpb25zLl9fVlVFX0RFVlRPT0xTX0NPTVBPTkVOVF9HVVNTRURfTkFNRV9fIHx8IG9wdGlvbnMuX19uYW1lO1xuXHRpZiAobmFtZSA9PT0gXCJpbmRleFwiICYmIG9wdGlvbnMuX19maWxlPy5lbmRzV2l0aChcImluZGV4LnZ1ZVwiKSkgcmV0dXJuIFwiXCI7XG5cdHJldHVybiBuYW1lO1xufVxuZnVuY3Rpb24gZ2V0Q29tcG9uZW50RmlsZU5hbWUob3B0aW9ucykge1xuXHRjb25zdCBmaWxlID0gb3B0aW9ucy5fX2ZpbGU7XG5cdGlmIChmaWxlKSByZXR1cm4gY2xhc3NpZnkoYmFzZW5hbWUoZmlsZSwgXCIudnVlXCIpKTtcbn1cbmZ1bmN0aW9uIGdldENvbXBvbmVudE5hbWUob3B0aW9ucykge1xuXHRjb25zdCBuYW1lID0gb3B0aW9ucy5kaXNwbGF5TmFtZSB8fCBvcHRpb25zLm5hbWUgfHwgb3B0aW9ucy5fY29tcG9uZW50VGFnO1xuXHRpZiAobmFtZSkgcmV0dXJuIG5hbWU7XG5cdHJldHVybiBnZXRDb21wb25lbnRGaWxlTmFtZShvcHRpb25zKTtcbn1cbmZ1bmN0aW9uIHNhdmVDb21wb25lbnRHdXNzZWROYW1lKGluc3RhbmNlLCBuYW1lKSB7XG5cdGluc3RhbmNlLnR5cGUuX19WVUVfREVWVE9PTFNfQ09NUE9ORU5UX0dVU1NFRF9OQU1FX18gPSBuYW1lO1xuXHRyZXR1cm4gbmFtZTtcbn1cbmZ1bmN0aW9uIGdldEFwcFJlY29yZChpbnN0YW5jZSkge1xuXHRpZiAoaW5zdGFuY2UuX19WVUVfREVWVE9PTFNfTkVYVF9BUFBfUkVDT1JEX18pIHJldHVybiBpbnN0YW5jZS5fX1ZVRV9ERVZUT09MU19ORVhUX0FQUF9SRUNPUkRfXztcblx0ZWxzZSBpZiAoaW5zdGFuY2Uucm9vdCkgcmV0dXJuIGluc3RhbmNlLmFwcENvbnRleHQuYXBwLl9fVlVFX0RFVlRPT0xTX05FWFRfQVBQX1JFQ09SRF9fO1xufVxuYXN5bmMgZnVuY3Rpb24gZ2V0Q29tcG9uZW50SWQob3B0aW9ucykge1xuXHRjb25zdCB7IGFwcCwgdWlkLCBpbnN0YW5jZSB9ID0gb3B0aW9ucztcblx0dHJ5IHtcblx0XHRpZiAoaW5zdGFuY2UuX19WVUVfREVWVE9PTFNfTkVYVF9VSURfXykgcmV0dXJuIGluc3RhbmNlLl9fVlVFX0RFVlRPT0xTX05FWFRfVUlEX187XG5cdFx0Y29uc3QgYXBwUmVjb3JkID0gYXdhaXQgZ2V0QXBwUmVjb3JkKGFwcCk7XG5cdFx0aWYgKCFhcHBSZWNvcmQpIHJldHVybiBudWxsO1xuXHRcdGNvbnN0IGlzUm9vdCA9IGFwcFJlY29yZC5yb290SW5zdGFuY2UgPT09IGluc3RhbmNlO1xuXHRcdHJldHVybiBgJHthcHBSZWNvcmQuaWR9OiR7aXNSb290ID8gXCJyb290XCIgOiB1aWR9YDtcblx0fSBjYXRjaCAoZSkge31cbn1cbmZ1bmN0aW9uIGlzRnJhZ21lbnQoaW5zdGFuY2UpIHtcblx0Y29uc3Qgc3ViVHJlZVR5cGUgPSBpbnN0YW5jZS5zdWJUcmVlPy50eXBlO1xuXHRjb25zdCBhcHBSZWNvcmQgPSBnZXRBcHBSZWNvcmQoaW5zdGFuY2UpO1xuXHRpZiAoYXBwUmVjb3JkKSByZXR1cm4gYXBwUmVjb3JkPy50eXBlcz8uRnJhZ21lbnQgPT09IHN1YlRyZWVUeXBlO1xuXHRyZXR1cm4gZmFsc2U7XG59XG5mdW5jdGlvbiBpc0JlaW5nRGVzdHJveWVkKGluc3RhbmNlKSB7XG5cdHJldHVybiBpbnN0YW5jZS5faXNCZWluZ0Rlc3Ryb3llZCB8fCBpbnN0YW5jZS5pc1VubW91bnRlZDtcbn1cbi8qKlxuKiBHZXQgdGhlIGFwcHJvcHJpYXRlIGRpc3BsYXkgbmFtZSBmb3IgYW4gaW5zdGFuY2UuXG4qXG4qIEBwYXJhbSB7VnVlfSBpbnN0YW5jZVxuKiBAcmV0dXJuIHtzdHJpbmd9XG4qL1xuZnVuY3Rpb24gZ2V0SW5zdGFuY2VOYW1lKGluc3RhbmNlKSB7XG5cdGNvbnN0IG5hbWUgPSBnZXRDb21wb25lbnRUeXBlTmFtZShpbnN0YW5jZT8udHlwZSB8fCB7fSk7XG5cdGlmIChuYW1lKSByZXR1cm4gbmFtZTtcblx0aWYgKGluc3RhbmNlPy5yb290ID09PSBpbnN0YW5jZSkgcmV0dXJuIFwiUm9vdFwiO1xuXHRmb3IgKGNvbnN0IGtleSBpbiBpbnN0YW5jZS5wYXJlbnQ/LnR5cGU/LmNvbXBvbmVudHMpIGlmIChpbnN0YW5jZS5wYXJlbnQudHlwZS5jb21wb25lbnRzW2tleV0gPT09IGluc3RhbmNlPy50eXBlKSByZXR1cm4gc2F2ZUNvbXBvbmVudEd1c3NlZE5hbWUoaW5zdGFuY2UsIGtleSk7XG5cdGZvciAoY29uc3Qga2V5IGluIGluc3RhbmNlLmFwcENvbnRleHQ/LmNvbXBvbmVudHMpIGlmIChpbnN0YW5jZS5hcHBDb250ZXh0LmNvbXBvbmVudHNba2V5XSA9PT0gaW5zdGFuY2U/LnR5cGUpIHJldHVybiBzYXZlQ29tcG9uZW50R3Vzc2VkTmFtZShpbnN0YW5jZSwga2V5KTtcblx0Y29uc3QgZmlsZU5hbWUgPSBnZXRDb21wb25lbnRGaWxlTmFtZShpbnN0YW5jZT8udHlwZSB8fCB7fSk7XG5cdGlmIChmaWxlTmFtZSkgcmV0dXJuIGZpbGVOYW1lO1xuXHRyZXR1cm4gXCJBbm9ueW1vdXMgQ29tcG9uZW50XCI7XG59XG4vKipcbiogUmV0dXJucyBhIGRldnRvb2xzIHVuaXF1ZSBpZCBmb3IgaW5zdGFuY2UuXG4qIEBwYXJhbSB7VnVlfSBpbnN0YW5jZVxuKi9cbmZ1bmN0aW9uIGdldFVuaXF1ZUNvbXBvbmVudElkKGluc3RhbmNlKSB7XG5cdHJldHVybiBgJHtpbnN0YW5jZT8uYXBwQ29udGV4dD8uYXBwPy5fX1ZVRV9ERVZUT09MU19ORVhUX0FQUF9SRUNPUkRfSURfXyA/PyAwfToke2luc3RhbmNlID09PSBpbnN0YW5jZT8ucm9vdCA/IFwicm9vdFwiIDogaW5zdGFuY2UudWlkfWA7XG59XG5mdW5jdGlvbiBnZXRSZW5kZXJLZXkodmFsdWUpIHtcblx0aWYgKHZhbHVlID09IG51bGwpIHJldHVybiBcIlwiO1xuXHRpZiAodHlwZW9mIHZhbHVlID09PSBcIm51bWJlclwiKSByZXR1cm4gdmFsdWU7XG5cdGVsc2UgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gXCJzdHJpbmdcIikgcmV0dXJuIGAnJHt2YWx1ZX0nYDtcblx0ZWxzZSBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHJldHVybiBcIkFycmF5XCI7XG5cdGVsc2UgcmV0dXJuIFwiT2JqZWN0XCI7XG59XG5mdW5jdGlvbiByZXR1cm5FcnJvcihjYikge1xuXHR0cnkge1xuXHRcdHJldHVybiBjYigpO1xuXHR9IGNhdGNoIChlKSB7XG5cdFx0cmV0dXJuIGU7XG5cdH1cbn1cbmZ1bmN0aW9uIGdldENvbXBvbmVudEluc3RhbmNlKGFwcFJlY29yZCwgaW5zdGFuY2VJZCkge1xuXHRpbnN0YW5jZUlkID0gaW5zdGFuY2VJZCB8fCBgJHthcHBSZWNvcmQuaWR9OnJvb3RgO1xuXHRyZXR1cm4gYXBwUmVjb3JkLmluc3RhbmNlTWFwLmdldChpbnN0YW5jZUlkKSB8fCBhcHBSZWNvcmQuaW5zdGFuY2VNYXAuZ2V0KFwiOnJvb3RcIik7XG59XG5mdW5jdGlvbiBlbnN1cmVQcm9wZXJ0eUV4aXN0cyhvYmosIGtleSwgc2tpcE9iakNoZWNrID0gZmFsc2UpIHtcblx0cmV0dXJuIHNraXBPYmpDaGVjayA/IGtleSBpbiBvYmogOiB0eXBlb2Ygb2JqID09PSBcIm9iamVjdFwiICYmIG9iaiAhPT0gbnVsbCA/IGtleSBpbiBvYmogOiBmYWxzZTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL2NvbXBvbmVudC9zdGF0ZS9ib3VuZGluZy1yZWN0LnRzXG5mdW5jdGlvbiBjcmVhdGVSZWN0KCkge1xuXHRjb25zdCByZWN0ID0ge1xuXHRcdHRvcDogMCxcblx0XHRib3R0b206IDAsXG5cdFx0bGVmdDogMCxcblx0XHRyaWdodDogMCxcblx0XHRnZXQgd2lkdGgoKSB7XG5cdFx0XHRyZXR1cm4gcmVjdC5yaWdodCAtIHJlY3QubGVmdDtcblx0XHR9LFxuXHRcdGdldCBoZWlnaHQoKSB7XG5cdFx0XHRyZXR1cm4gcmVjdC5ib3R0b20gLSByZWN0LnRvcDtcblx0XHR9XG5cdH07XG5cdHJldHVybiByZWN0O1xufVxubGV0IHJhbmdlO1xuZnVuY3Rpb24gZ2V0VGV4dFJlY3Qobm9kZSkge1xuXHRpZiAoIXJhbmdlKSByYW5nZSA9IGRvY3VtZW50LmNyZWF0ZVJhbmdlKCk7XG5cdHJhbmdlLnNlbGVjdE5vZGUobm9kZSk7XG5cdHJldHVybiByYW5nZS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbn1cbmZ1bmN0aW9uIGdldEZyYWdtZW50UmVjdCh2bm9kZSkge1xuXHRjb25zdCByZWN0ID0gY3JlYXRlUmVjdCgpO1xuXHRpZiAoIXZub2RlLmNoaWxkcmVuKSByZXR1cm4gcmVjdDtcblx0Zm9yIChsZXQgaSA9IDAsIGwgPSB2bm9kZS5jaGlsZHJlbi5sZW5ndGg7IGkgPCBsOyBpKyspIHtcblx0XHRjb25zdCBjaGlsZFZub2RlID0gdm5vZGUuY2hpbGRyZW5baV07XG5cdFx0bGV0IGNoaWxkUmVjdDtcblx0XHRpZiAoY2hpbGRWbm9kZS5jb21wb25lbnQpIGNoaWxkUmVjdCA9IGdldENvbXBvbmVudEJvdW5kaW5nUmVjdChjaGlsZFZub2RlLmNvbXBvbmVudCk7XG5cdFx0ZWxzZSBpZiAoY2hpbGRWbm9kZS5lbCkge1xuXHRcdFx0Y29uc3QgZWwgPSBjaGlsZFZub2RlLmVsO1xuXHRcdFx0aWYgKGVsLm5vZGVUeXBlID09PSAxIHx8IGVsLmdldEJvdW5kaW5nQ2xpZW50UmVjdCkgY2hpbGRSZWN0ID0gZWwuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG5cdFx0XHRlbHNlIGlmIChlbC5ub2RlVHlwZSA9PT0gMyAmJiBlbC5kYXRhLnRyaW0oKSkgY2hpbGRSZWN0ID0gZ2V0VGV4dFJlY3QoZWwpO1xuXHRcdH1cblx0XHRpZiAoY2hpbGRSZWN0KSBtZXJnZVJlY3RzKHJlY3QsIGNoaWxkUmVjdCk7XG5cdH1cblx0cmV0dXJuIHJlY3Q7XG59XG5mdW5jdGlvbiBtZXJnZVJlY3RzKGEsIGIpIHtcblx0aWYgKCFhLnRvcCB8fCBiLnRvcCA8IGEudG9wKSBhLnRvcCA9IGIudG9wO1xuXHRpZiAoIWEuYm90dG9tIHx8IGIuYm90dG9tID4gYS5ib3R0b20pIGEuYm90dG9tID0gYi5ib3R0b207XG5cdGlmICghYS5sZWZ0IHx8IGIubGVmdCA8IGEubGVmdCkgYS5sZWZ0ID0gYi5sZWZ0O1xuXHRpZiAoIWEucmlnaHQgfHwgYi5yaWdodCA+IGEucmlnaHQpIGEucmlnaHQgPSBiLnJpZ2h0O1xuXHRyZXR1cm4gYTtcbn1cbmNvbnN0IERFRkFVTFRfUkVDVCA9IHtcblx0dG9wOiAwLFxuXHRsZWZ0OiAwLFxuXHRyaWdodDogMCxcblx0Ym90dG9tOiAwLFxuXHR3aWR0aDogMCxcblx0aGVpZ2h0OiAwXG59O1xuZnVuY3Rpb24gZ2V0Q29tcG9uZW50Qm91bmRpbmdSZWN0KGluc3RhbmNlKSB7XG5cdGNvbnN0IGVsID0gaW5zdGFuY2Uuc3ViVHJlZS5lbDtcblx0aWYgKHR5cGVvZiB3aW5kb3cgPT09IFwidW5kZWZpbmVkXCIpIHJldHVybiBERUZBVUxUX1JFQ1Q7XG5cdGlmIChpc0ZyYWdtZW50KGluc3RhbmNlKSkgcmV0dXJuIGdldEZyYWdtZW50UmVjdChpbnN0YW5jZS5zdWJUcmVlKTtcblx0ZWxzZSBpZiAoZWw/Lm5vZGVUeXBlID09PSAxKSByZXR1cm4gZWw/LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuXHRlbHNlIGlmIChpbnN0YW5jZS5zdWJUcmVlLmNvbXBvbmVudCkgcmV0dXJuIGdldENvbXBvbmVudEJvdW5kaW5nUmVjdChpbnN0YW5jZS5zdWJUcmVlLmNvbXBvbmVudCk7XG5cdGVsc2UgcmV0dXJuIERFRkFVTFRfUkVDVDtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL2NvbXBvbmVudC90cmVlL2VsLnRzXG5mdW5jdGlvbiBnZXRSb290RWxlbWVudHNGcm9tQ29tcG9uZW50SW5zdGFuY2UoaW5zdGFuY2UpIHtcblx0aWYgKGlzRnJhZ21lbnQoaW5zdGFuY2UpKSByZXR1cm4gZ2V0RnJhZ21lbnRSb290RWxlbWVudHMoaW5zdGFuY2Uuc3ViVHJlZSk7XG5cdGlmICghaW5zdGFuY2Uuc3ViVHJlZSkgcmV0dXJuIFtdO1xuXHRyZXR1cm4gW2luc3RhbmNlLnN1YlRyZWUuZWxdO1xufVxuZnVuY3Rpb24gZ2V0RnJhZ21lbnRSb290RWxlbWVudHModm5vZGUpIHtcblx0aWYgKCF2bm9kZS5jaGlsZHJlbikgcmV0dXJuIFtdO1xuXHRjb25zdCBsaXN0ID0gW107XG5cdHZub2RlLmNoaWxkcmVuLmZvckVhY2goKGNoaWxkVm5vZGUpID0+IHtcblx0XHRpZiAoY2hpbGRWbm9kZS5jb21wb25lbnQpIGxpc3QucHVzaCguLi5nZXRSb290RWxlbWVudHNGcm9tQ29tcG9uZW50SW5zdGFuY2UoY2hpbGRWbm9kZS5jb21wb25lbnQpKTtcblx0XHRlbHNlIGlmIChjaGlsZFZub2RlPy5lbCkgbGlzdC5wdXNoKGNoaWxkVm5vZGUuZWwpO1xuXHR9KTtcblx0cmV0dXJuIGxpc3Q7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9jb21wb25lbnQtaGlnaGxpZ2h0ZXIvaW5kZXgudHNcbmNvbnN0IENPTlRBSU5FUl9FTEVNRU5UX0lEID0gXCJfX3Z1ZS1kZXZ0b29scy1jb21wb25lbnQtaW5zcGVjdG9yX19cIjtcbmNvbnN0IENBUkRfRUxFTUVOVF9JRCA9IFwiX192dWUtZGV2dG9vbHMtY29tcG9uZW50LWluc3BlY3Rvcl9fY2FyZF9fXCI7XG5jb25zdCBDT01QT05FTlRfTkFNRV9FTEVNRU5UX0lEID0gXCJfX3Z1ZS1kZXZ0b29scy1jb21wb25lbnQtaW5zcGVjdG9yX19uYW1lX19cIjtcbmNvbnN0IElORElDQVRPUl9FTEVNRU5UX0lEID0gXCJfX3Z1ZS1kZXZ0b29scy1jb21wb25lbnQtaW5zcGVjdG9yX19pbmRpY2F0b3JfX1wiO1xuY29uc3QgY29udGFpbmVyU3R5bGVzID0ge1xuXHRkaXNwbGF5OiBcImJsb2NrXCIsXG5cdHpJbmRleDogMjE0NzQ4MzY0MCxcblx0cG9zaXRpb246IFwiZml4ZWRcIixcblx0YmFja2dyb3VuZENvbG9yOiBcIiM0MmI4ODMyNVwiLFxuXHRib3JkZXI6IFwiMXB4IHNvbGlkICM0MmI4ODM1MFwiLFxuXHRib3JkZXJSYWRpdXM6IFwiNXB4XCIsXG5cdHRyYW5zaXRpb246IFwiYWxsIDAuMXMgZWFzZS1pblwiLFxuXHRwb2ludGVyRXZlbnRzOiBcIm5vbmVcIlxufTtcbmNvbnN0IGNhcmRTdHlsZXMgPSB7XG5cdGZvbnRGYW1pbHk6IFwiQXJpYWwsIEhlbHZldGljYSwgc2Fucy1zZXJpZlwiLFxuXHRwYWRkaW5nOiBcIjVweCA4cHhcIixcblx0Ym9yZGVyUmFkaXVzOiBcIjRweFwiLFxuXHR0ZXh0QWxpZ246IFwibGVmdFwiLFxuXHRwb3NpdGlvbjogXCJhYnNvbHV0ZVwiLFxuXHRsZWZ0OiAwLFxuXHRjb2xvcjogXCIjZTllOWU5XCIsXG5cdGZvbnRTaXplOiBcIjE0cHhcIixcblx0Zm9udFdlaWdodDogNjAwLFxuXHRsaW5lSGVpZ2h0OiBcIjI0cHhcIixcblx0YmFja2dyb3VuZENvbG9yOiBcIiM0MmI4ODNcIixcblx0Ym94U2hhZG93OiBcIjAgMXB4IDNweCAwIHJnYmEoMCwgMCwgMCwgMC4xKSwgMCAxcHggMnB4IC0xcHggcmdiYSgwLCAwLCAwLCAwLjEpXCJcbn07XG5jb25zdCBpbmRpY2F0b3JTdHlsZXMgPSB7XG5cdGRpc3BsYXk6IFwiaW5saW5lLWJsb2NrXCIsXG5cdGZvbnRXZWlnaHQ6IDQwMCxcblx0Zm9udFN0eWxlOiBcIm5vcm1hbFwiLFxuXHRmb250U2l6ZTogXCIxMnB4XCIsXG5cdG9wYWNpdHk6IC43XG59O1xuZnVuY3Rpb24gZ2V0Q29udGFpbmVyRWxlbWVudCgpIHtcblx0cmV0dXJuIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKENPTlRBSU5FUl9FTEVNRU5UX0lEKTtcbn1cbmZ1bmN0aW9uIGdldENhcmRFbGVtZW50KCkge1xuXHRyZXR1cm4gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoQ0FSRF9FTEVNRU5UX0lEKTtcbn1cbmZ1bmN0aW9uIGdldEluZGljYXRvckVsZW1lbnQoKSB7XG5cdHJldHVybiBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChJTkRJQ0FUT1JfRUxFTUVOVF9JRCk7XG59XG5mdW5jdGlvbiBnZXROYW1lRWxlbWVudCgpIHtcblx0cmV0dXJuIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKENPTVBPTkVOVF9OQU1FX0VMRU1FTlRfSUQpO1xufVxuZnVuY3Rpb24gZ2V0U3R5bGVzKGJvdW5kcykge1xuXHRyZXR1cm4ge1xuXHRcdGxlZnQ6IGAke01hdGgucm91bmQoYm91bmRzLmxlZnQgKiAxMDApIC8gMTAwfXB4YCxcblx0XHR0b3A6IGAke01hdGgucm91bmQoYm91bmRzLnRvcCAqIDEwMCkgLyAxMDB9cHhgLFxuXHRcdHdpZHRoOiBgJHtNYXRoLnJvdW5kKGJvdW5kcy53aWR0aCAqIDEwMCkgLyAxMDB9cHhgLFxuXHRcdGhlaWdodDogYCR7TWF0aC5yb3VuZChib3VuZHMuaGVpZ2h0ICogMTAwKSAvIDEwMH1weGBcblx0fTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZShvcHRpb25zKSB7XG5cdGNvbnN0IGNvbnRhaW5lckVsID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcblx0Y29udGFpbmVyRWwuaWQgPSBvcHRpb25zLmVsZW1lbnRJZCA/PyBDT05UQUlORVJfRUxFTUVOVF9JRDtcblx0T2JqZWN0LmFzc2lnbihjb250YWluZXJFbC5zdHlsZSwge1xuXHRcdC4uLmNvbnRhaW5lclN0eWxlcyxcblx0XHQuLi5nZXRTdHlsZXMob3B0aW9ucy5ib3VuZHMpLFxuXHRcdC4uLm9wdGlvbnMuc3R5bGVcblx0fSk7XG5cdGNvbnN0IGNhcmRFbCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpO1xuXHRjYXJkRWwuaWQgPSBDQVJEX0VMRU1FTlRfSUQ7XG5cdE9iamVjdC5hc3NpZ24oY2FyZEVsLnN0eWxlLCB7XG5cdFx0Li4uY2FyZFN0eWxlcyxcblx0XHR0b3A6IG9wdGlvbnMuYm91bmRzLnRvcCA8IDM1ID8gMCA6IFwiLTM1cHhcIlxuXHR9KTtcblx0Y29uc3QgbmFtZUVsID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInNwYW5cIik7XG5cdG5hbWVFbC5pZCA9IENPTVBPTkVOVF9OQU1FX0VMRU1FTlRfSUQ7XG5cdG5hbWVFbC5pbm5lckhUTUwgPSBgJmx0OyR7b3B0aW9ucy5uYW1lfSZndDsmbmJzcDsmbmJzcDtgO1xuXHRjb25zdCBpbmRpY2F0b3JFbCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJpXCIpO1xuXHRpbmRpY2F0b3JFbC5pZCA9IElORElDQVRPUl9FTEVNRU5UX0lEO1xuXHRpbmRpY2F0b3JFbC5pbm5lckhUTUwgPSBgJHtNYXRoLnJvdW5kKG9wdGlvbnMuYm91bmRzLndpZHRoICogMTAwKSAvIDEwMH0geCAke01hdGgucm91bmQob3B0aW9ucy5ib3VuZHMuaGVpZ2h0ICogMTAwKSAvIDEwMH1gO1xuXHRPYmplY3QuYXNzaWduKGluZGljYXRvckVsLnN0eWxlLCBpbmRpY2F0b3JTdHlsZXMpO1xuXHRjYXJkRWwuYXBwZW5kQ2hpbGQobmFtZUVsKTtcblx0Y2FyZEVsLmFwcGVuZENoaWxkKGluZGljYXRvckVsKTtcblx0Y29udGFpbmVyRWwuYXBwZW5kQ2hpbGQoY2FyZEVsKTtcblx0ZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChjb250YWluZXJFbCk7XG5cdHJldHVybiBjb250YWluZXJFbDtcbn1cbmZ1bmN0aW9uIHVwZGF0ZShvcHRpb25zKSB7XG5cdGNvbnN0IGNvbnRhaW5lckVsID0gZ2V0Q29udGFpbmVyRWxlbWVudCgpO1xuXHRjb25zdCBjYXJkRWwgPSBnZXRDYXJkRWxlbWVudCgpO1xuXHRjb25zdCBuYW1lRWwgPSBnZXROYW1lRWxlbWVudCgpO1xuXHRjb25zdCBpbmRpY2F0b3JFbCA9IGdldEluZGljYXRvckVsZW1lbnQoKTtcblx0aWYgKGNvbnRhaW5lckVsKSB7XG5cdFx0T2JqZWN0LmFzc2lnbihjb250YWluZXJFbC5zdHlsZSwge1xuXHRcdFx0Li4uY29udGFpbmVyU3R5bGVzLFxuXHRcdFx0Li4uZ2V0U3R5bGVzKG9wdGlvbnMuYm91bmRzKVxuXHRcdH0pO1xuXHRcdE9iamVjdC5hc3NpZ24oY2FyZEVsLnN0eWxlLCB7IHRvcDogb3B0aW9ucy5ib3VuZHMudG9wIDwgMzUgPyAwIDogXCItMzVweFwiIH0pO1xuXHRcdG5hbWVFbC5pbm5lckhUTUwgPSBgJmx0OyR7b3B0aW9ucy5uYW1lfSZndDsmbmJzcDsmbmJzcDtgO1xuXHRcdGluZGljYXRvckVsLmlubmVySFRNTCA9IGAke01hdGgucm91bmQob3B0aW9ucy5ib3VuZHMud2lkdGggKiAxMDApIC8gMTAwfSB4ICR7TWF0aC5yb3VuZChvcHRpb25zLmJvdW5kcy5oZWlnaHQgKiAxMDApIC8gMTAwfWA7XG5cdH1cbn1cbmZ1bmN0aW9uIGhpZ2hsaWdodChpbnN0YW5jZSkge1xuXHRjb25zdCBib3VuZHMgPSBnZXRDb21wb25lbnRCb3VuZGluZ1JlY3QoaW5zdGFuY2UpO1xuXHRpZiAoIWJvdW5kcy53aWR0aCAmJiAhYm91bmRzLmhlaWdodCkgcmV0dXJuO1xuXHRjb25zdCBuYW1lID0gZ2V0SW5zdGFuY2VOYW1lKGluc3RhbmNlKTtcblx0Z2V0Q29udGFpbmVyRWxlbWVudCgpID8gdXBkYXRlKHtcblx0XHRib3VuZHMsXG5cdFx0bmFtZVxuXHR9KSA6IGNyZWF0ZSh7XG5cdFx0Ym91bmRzLFxuXHRcdG5hbWVcblx0fSk7XG59XG5mdW5jdGlvbiB1bmhpZ2hsaWdodCgpIHtcblx0Y29uc3QgZWwgPSBnZXRDb250YWluZXJFbGVtZW50KCk7XG5cdGlmIChlbCkgZWwuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xufVxubGV0IGluc3BlY3RJbnN0YW5jZSA9IG51bGw7XG5mdW5jdGlvbiBpbnNwZWN0Rm4oZSkge1xuXHRjb25zdCB0YXJnZXQgPSBlLnRhcmdldDtcblx0aWYgKHRhcmdldCkge1xuXHRcdGNvbnN0IGluc3RhbmNlID0gdGFyZ2V0Ll9fdnVlUGFyZW50Q29tcG9uZW50O1xuXHRcdGlmIChpbnN0YW5jZSkge1xuXHRcdFx0aW5zcGVjdEluc3RhbmNlID0gaW5zdGFuY2U7XG5cdFx0XHRpZiAoaW5zdGFuY2Uudm5vZGUuZWwpIHtcblx0XHRcdFx0Y29uc3QgYm91bmRzID0gZ2V0Q29tcG9uZW50Qm91bmRpbmdSZWN0KGluc3RhbmNlKTtcblx0XHRcdFx0Y29uc3QgbmFtZSA9IGdldEluc3RhbmNlTmFtZShpbnN0YW5jZSk7XG5cdFx0XHRcdGdldENvbnRhaW5lckVsZW1lbnQoKSA/IHVwZGF0ZSh7XG5cdFx0XHRcdFx0Ym91bmRzLFxuXHRcdFx0XHRcdG5hbWVcblx0XHRcdFx0fSkgOiBjcmVhdGUoe1xuXHRcdFx0XHRcdGJvdW5kcyxcblx0XHRcdFx0XHRuYW1lXG5cdFx0XHRcdH0pO1xuXHRcdFx0fVxuXHRcdH1cblx0fVxufVxuZnVuY3Rpb24gc2VsZWN0Q29tcG9uZW50Rm4oZSwgY2IpIHtcblx0ZS5wcmV2ZW50RGVmYXVsdCgpO1xuXHRlLnN0b3BQcm9wYWdhdGlvbigpO1xuXHRpZiAoaW5zcGVjdEluc3RhbmNlKSBjYihnZXRVbmlxdWVDb21wb25lbnRJZChpbnNwZWN0SW5zdGFuY2UpKTtcbn1cbmxldCBpbnNwZWN0Q29tcG9uZW50SGlnaExpZ2h0ZXJTZWxlY3RGbiA9IG51bGw7XG5mdW5jdGlvbiBjYW5jZWxJbnNwZWN0Q29tcG9uZW50SGlnaExpZ2h0ZXIoKSB7XG5cdHVuaGlnaGxpZ2h0KCk7XG5cdHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwibW91c2VvdmVyXCIsIGluc3BlY3RGbik7XG5cdHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgaW5zcGVjdENvbXBvbmVudEhpZ2hMaWdodGVyU2VsZWN0Rm4sIHRydWUpO1xuXHRpbnNwZWN0Q29tcG9uZW50SGlnaExpZ2h0ZXJTZWxlY3RGbiA9IG51bGw7XG59XG5mdW5jdGlvbiBpbnNwZWN0Q29tcG9uZW50SGlnaExpZ2h0ZXIoKSB7XG5cdHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwibW91c2VvdmVyXCIsIGluc3BlY3RGbik7XG5cdHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuXHRcdGZ1bmN0aW9uIG9uU2VsZWN0KGUpIHtcblx0XHRcdGUucHJldmVudERlZmF1bHQoKTtcblx0XHRcdGUuc3RvcFByb3BhZ2F0aW9uKCk7XG5cdFx0XHRzZWxlY3RDb21wb25lbnRGbihlLCAoaWQpID0+IHtcblx0XHRcdFx0d2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBvblNlbGVjdCwgdHJ1ZSk7XG5cdFx0XHRcdGluc3BlY3RDb21wb25lbnRIaWdoTGlnaHRlclNlbGVjdEZuID0gbnVsbDtcblx0XHRcdFx0d2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJtb3VzZW92ZXJcIiwgaW5zcGVjdEZuKTtcblx0XHRcdFx0Y29uc3QgZWwgPSBnZXRDb250YWluZXJFbGVtZW50KCk7XG5cdFx0XHRcdGlmIChlbCkgZWwuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuXHRcdFx0XHRyZXNvbHZlKEpTT04uc3RyaW5naWZ5KHsgaWQgfSkpO1xuXHRcdFx0fSk7XG5cdFx0fVxuXHRcdGluc3BlY3RDb21wb25lbnRIaWdoTGlnaHRlclNlbGVjdEZuID0gb25TZWxlY3Q7XG5cdFx0d2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBvblNlbGVjdCwgdHJ1ZSk7XG5cdH0pO1xufVxuZnVuY3Rpb24gc2Nyb2xsVG9Db21wb25lbnQob3B0aW9ucykge1xuXHRjb25zdCBpbnN0YW5jZSA9IGdldENvbXBvbmVudEluc3RhbmNlKGFjdGl2ZUFwcFJlY29yZC52YWx1ZSwgb3B0aW9ucy5pZCk7XG5cdGlmIChpbnN0YW5jZSkge1xuXHRcdGNvbnN0IFtlbF0gPSBnZXRSb290RWxlbWVudHNGcm9tQ29tcG9uZW50SW5zdGFuY2UoaW5zdGFuY2UpO1xuXHRcdGlmICh0eXBlb2YgZWwuc2Nyb2xsSW50b1ZpZXcgPT09IFwiZnVuY3Rpb25cIikgZWwuc2Nyb2xsSW50b1ZpZXcoeyBiZWhhdmlvcjogXCJzbW9vdGhcIiB9KTtcblx0XHRlbHNlIHtcblx0XHRcdGNvbnN0IGJvdW5kcyA9IGdldENvbXBvbmVudEJvdW5kaW5nUmVjdChpbnN0YW5jZSk7XG5cdFx0XHRjb25zdCBzY3JvbGxUYXJnZXQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuXHRcdFx0Y29uc3Qgc3R5bGVzID0ge1xuXHRcdFx0XHQuLi5nZXRTdHlsZXMoYm91bmRzKSxcblx0XHRcdFx0cG9zaXRpb246IFwiYWJzb2x1dGVcIlxuXHRcdFx0fTtcblx0XHRcdE9iamVjdC5hc3NpZ24oc2Nyb2xsVGFyZ2V0LnN0eWxlLCBzdHlsZXMpO1xuXHRcdFx0ZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChzY3JvbGxUYXJnZXQpO1xuXHRcdFx0c2Nyb2xsVGFyZ2V0LnNjcm9sbEludG9WaWV3KHsgYmVoYXZpb3I6IFwic21vb3RoXCIgfSk7XG5cdFx0XHRzZXRUaW1lb3V0KCgpID0+IHtcblx0XHRcdFx0ZG9jdW1lbnQuYm9keS5yZW1vdmVDaGlsZChzY3JvbGxUYXJnZXQpO1xuXHRcdFx0fSwgMmUzKTtcblx0XHR9XG5cdFx0c2V0VGltZW91dCgoKSA9PiB7XG5cdFx0XHRjb25zdCBib3VuZHMgPSBnZXRDb21wb25lbnRCb3VuZGluZ1JlY3QoaW5zdGFuY2UpO1xuXHRcdFx0aWYgKGJvdW5kcy53aWR0aCB8fCBib3VuZHMuaGVpZ2h0KSB7XG5cdFx0XHRcdGNvbnN0IG5hbWUgPSBnZXRJbnN0YW5jZU5hbWUoaW5zdGFuY2UpO1xuXHRcdFx0XHRjb25zdCBlbCA9IGdldENvbnRhaW5lckVsZW1lbnQoKTtcblx0XHRcdFx0ZWwgPyB1cGRhdGUoe1xuXHRcdFx0XHRcdC4uLm9wdGlvbnMsXG5cdFx0XHRcdFx0bmFtZSxcblx0XHRcdFx0XHRib3VuZHNcblx0XHRcdFx0fSkgOiBjcmVhdGUoe1xuXHRcdFx0XHRcdC4uLm9wdGlvbnMsXG5cdFx0XHRcdFx0bmFtZSxcblx0XHRcdFx0XHRib3VuZHNcblx0XHRcdFx0fSk7XG5cdFx0XHRcdHNldFRpbWVvdXQoKCkgPT4ge1xuXHRcdFx0XHRcdGlmIChlbCkgZWwuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuXHRcdFx0XHR9LCAxNTAwKTtcblx0XHRcdH1cblx0XHR9LCAxMjAwKTtcblx0fVxufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvY29tcG9uZW50LWluc3BlY3Rvci9pbmRleC50c1xudGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0NPTVBPTkVOVF9JTlNQRUNUT1JfRU5BQkxFRF9fID8/PSB0cnVlO1xuZnVuY3Rpb24gdG9nZ2xlQ29tcG9uZW50SW5zcGVjdG9yRW5hYmxlZChlbmFibGVkKSB7XG5cdHRhcmdldC5fX1ZVRV9ERVZUT09MU19DT01QT05FTlRfSU5TUEVDVE9SX0VOQUJMRURfXyA9IGVuYWJsZWQ7XG59XG5mdW5jdGlvbiB3YWl0Rm9ySW5zcGVjdG9ySW5pdChjYikge1xuXHRsZXQgdG90YWwgPSAwO1xuXHRjb25zdCB0aW1lciA9IHNldEludGVydmFsKCgpID0+IHtcblx0XHRpZiAodGFyZ2V0Ll9fVlVFX0lOU1BFQ1RPUl9fKSB7XG5cdFx0XHRjbGVhckludGVydmFsKHRpbWVyKTtcblx0XHRcdHRvdGFsICs9IDMwO1xuXHRcdFx0Y2IoKTtcblx0XHR9XG5cdFx0aWYgKHRvdGFsID49IDVlMykgY2xlYXJJbnRlcnZhbCh0aW1lcik7XG5cdH0sIDMwKTtcbn1cbmZ1bmN0aW9uIHNldHVwSW5zcGVjdG9yKCkge1xuXHRjb25zdCBpbnNwZWN0b3IgPSB0YXJnZXQuX19WVUVfSU5TUEVDVE9SX187XG5cdGNvbnN0IF9vcGVuSW5FZGl0b3IgPSBpbnNwZWN0b3Iub3BlbkluRWRpdG9yO1xuXHRpbnNwZWN0b3Iub3BlbkluRWRpdG9yID0gYXN5bmMgKC4uLnBhcmFtcykgPT4ge1xuXHRcdGluc3BlY3Rvci5kaXNhYmxlKCk7XG5cdFx0X29wZW5JbkVkaXRvciguLi5wYXJhbXMpO1xuXHR9O1xufVxuZnVuY3Rpb24gZ2V0Q29tcG9uZW50SW5zcGVjdG9yKCkge1xuXHRyZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcblx0XHRmdW5jdGlvbiBzZXR1cCgpIHtcblx0XHRcdHNldHVwSW5zcGVjdG9yKCk7XG5cdFx0XHRyZXNvbHZlKHRhcmdldC5fX1ZVRV9JTlNQRUNUT1JfXyk7XG5cdFx0fVxuXHRcdGlmICghdGFyZ2V0Ll9fVlVFX0lOU1BFQ1RPUl9fKSB3YWl0Rm9ySW5zcGVjdG9ySW5pdCgoKSA9PiB7XG5cdFx0XHRzZXR1cCgpO1xuXHRcdH0pO1xuXHRcdGVsc2Ugc2V0dXAoKTtcblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvc2hhcmVkL3N0dWItdnVlLnRzXG4vKipcbiogVG8gcHJldmVudCBpbmNsdWRlIGEgKipIVUdFKiogdnVlIHBhY2thZ2UgaW4gdGhlIGZpbmFsIGJ1bmRsZSBvZiBjaHJvbWUgZXh0IC8gZWxlY3Ryb25cbiogd2Ugc3R1YiB0aGUgbmVjZXNzYXJ5IHZ1ZSBtb2R1bGUuXG4qIFRoaXMgaW1wbGVtZW50YXRpb24gaXMgYmFzZWQgb24gdGhlIDFjMzMyN2EwZmE1OTgzYWE5MDc4ZTNmN2JiMjMzMGY1NzI0MzU0MjUgY29tbWl0XG4qL1xuLyoqXG4qIEBmcm9tIFtAdnVlL3JlYWN0aXZpdHldKGh0dHBzOi8vZ2l0aHViLmNvbS92dWVqcy9jb3JlL2Jsb2IvMWMzMzI3YTBmYTU5ODNhYTkwNzhlM2Y3YmIyMzMwZjU3MjQzNTQyNS9wYWNrYWdlcy9yZWFjdGl2aXR5L3NyYy9jb25zdGFudHMudHMjTDE3LUwyMylcbiovXG5sZXQgUmVhY3RpdmVGbGFncyA9IC8qIEBfX1BVUkVfXyAqLyBmdW5jdGlvbihSZWFjdGl2ZUZsYWdzKSB7XG5cdFJlYWN0aXZlRmxhZ3NbXCJTS0lQXCJdID0gXCJfX3Zfc2tpcFwiO1xuXHRSZWFjdGl2ZUZsYWdzW1wiSVNfUkVBQ1RJVkVcIl0gPSBcIl9fdl9pc1JlYWN0aXZlXCI7XG5cdFJlYWN0aXZlRmxhZ3NbXCJJU19SRUFET05MWVwiXSA9IFwiX192X2lzUmVhZG9ubHlcIjtcblx0UmVhY3RpdmVGbGFnc1tcIklTX1NIQUxMT1dcIl0gPSBcIl9fdl9pc1NoYWxsb3dcIjtcblx0UmVhY3RpdmVGbGFnc1tcIlJBV1wiXSA9IFwiX192X3Jhd1wiO1xuXHRyZXR1cm4gUmVhY3RpdmVGbGFncztcbn0oe30pO1xuLyoqXG4qIEBmcm9tIFtAdnVlL3JlYWN0aXZpdHldKGh0dHBzOi8vZ2l0aHViLmNvbS92dWVqcy9jb3JlL2Jsb2IvMWMzMzI3YTBmYTU5ODNhYTkwNzhlM2Y3YmIyMzMwZjU3MjQzNTQyNS9wYWNrYWdlcy9yZWFjdGl2aXR5L3NyYy9yZWFjdGl2ZS50cyNMMzMwLUwzMzIpXG4qL1xuZnVuY3Rpb24gaXNSZWFkb25seSh2YWx1ZSkge1xuXHRyZXR1cm4gISEodmFsdWUgJiYgdmFsdWVbUmVhY3RpdmVGbGFncy5JU19SRUFET05MWV0pO1xufVxuLyoqXG4qIEBmcm9tIFtAdnVlL3JlYWN0aXZpdHldKGh0dHBzOi8vZ2l0aHViLmNvbS92dWVqcy9jb3JlL2Jsb2IvMWMzMzI3YTBmYTU5ODNhYTkwNzhlM2Y3YmIyMzMwZjU3MjQzNTQyNS9wYWNrYWdlcy9yZWFjdGl2aXR5L3NyYy9yZWFjdGl2ZS50cyNMMzEyLUwzMTcpXG4qL1xuZnVuY3Rpb24gaXNSZWFjdGl2ZSQxKHZhbHVlKSB7XG5cdGlmIChpc1JlYWRvbmx5KHZhbHVlKSkgcmV0dXJuIGlzUmVhY3RpdmUkMSh2YWx1ZVtSZWFjdGl2ZUZsYWdzLlJBV10pO1xuXHRyZXR1cm4gISEodmFsdWUgJiYgdmFsdWVbUmVhY3RpdmVGbGFncy5JU19SRUFDVElWRV0pO1xufVxuZnVuY3Rpb24gaXNSZWYkMShyKSB7XG5cdHJldHVybiAhIShyICYmIHIuX192X2lzUmVmID09PSB0cnVlKTtcbn1cbi8qKlxuKiBAZnJvbSBbQHZ1ZS9yZWFjdGl2aXR5XShodHRwczovL2dpdGh1Yi5jb20vdnVlanMvY29yZS9ibG9iLzFjMzMyN2EwZmE1OTgzYWE5MDc4ZTNmN2JiMjMzMGY1NzI0MzU0MjUvcGFja2FnZXMvcmVhY3Rpdml0eS9zcmMvcmVhY3RpdmUudHMjTDM3Mi1MMzc1KVxuKi9cbmZ1bmN0aW9uIHRvUmF3JDEob2JzZXJ2ZWQpIHtcblx0Y29uc3QgcmF3ID0gb2JzZXJ2ZWQgJiYgb2JzZXJ2ZWRbUmVhY3RpdmVGbGFncy5SQVddO1xuXHRyZXR1cm4gcmF3ID8gdG9SYXckMShyYXcpIDogb2JzZXJ2ZWQ7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9jb21wb25lbnQvc3RhdGUvZWRpdG9yLnRzXG52YXIgU3RhdGVFZGl0b3IgPSBjbGFzcyB7XG5cdGNvbnN0cnVjdG9yKCkge1xuXHRcdHRoaXMucmVmRWRpdG9yID0gbmV3IFJlZlN0YXRlRWRpdG9yKCk7XG5cdH1cblx0c2V0KG9iamVjdCwgcGF0aCwgdmFsdWUsIGNiKSB7XG5cdFx0Y29uc3Qgc2VjdGlvbnMgPSBBcnJheS5pc0FycmF5KHBhdGgpID8gcGF0aCA6IHBhdGguc3BsaXQoXCIuXCIpO1xuXHRcdHdoaWxlIChzZWN0aW9ucy5sZW5ndGggPiAxKSB7XG5cdFx0XHRjb25zdCBzZWN0aW9uID0gc2VjdGlvbnMuc2hpZnQoKTtcblx0XHRcdGlmIChvYmplY3QgaW5zdGFuY2VvZiBNYXApIG9iamVjdCA9IG9iamVjdC5nZXQoc2VjdGlvbik7XG5cdFx0XHRlbHNlIGlmIChvYmplY3QgaW5zdGFuY2VvZiBTZXQpIG9iamVjdCA9IEFycmF5LmZyb20ob2JqZWN0LnZhbHVlcygpKVtzZWN0aW9uXTtcblx0XHRcdGVsc2Ugb2JqZWN0ID0gb2JqZWN0W3NlY3Rpb25dO1xuXHRcdFx0aWYgKHRoaXMucmVmRWRpdG9yLmlzUmVmKG9iamVjdCkpIG9iamVjdCA9IHRoaXMucmVmRWRpdG9yLmdldChvYmplY3QpO1xuXHRcdH1cblx0XHRjb25zdCBmaWVsZCA9IHNlY3Rpb25zWzBdO1xuXHRcdGNvbnN0IGl0ZW0gPSB0aGlzLnJlZkVkaXRvci5nZXQob2JqZWN0KVtmaWVsZF07XG5cdFx0aWYgKGNiKSBjYihvYmplY3QsIGZpZWxkLCB2YWx1ZSk7XG5cdFx0ZWxzZSBpZiAodGhpcy5yZWZFZGl0b3IuaXNSZWYoaXRlbSkpIHRoaXMucmVmRWRpdG9yLnNldChpdGVtLCB2YWx1ZSk7XG5cdFx0ZWxzZSBvYmplY3RbZmllbGRdID0gdmFsdWU7XG5cdH1cblx0Z2V0KG9iamVjdCwgcGF0aCkge1xuXHRcdGNvbnN0IHNlY3Rpb25zID0gQXJyYXkuaXNBcnJheShwYXRoKSA/IHBhdGggOiBwYXRoLnNwbGl0KFwiLlwiKTtcblx0XHRmb3IgKGxldCBpID0gMDsgaSA8IHNlY3Rpb25zLmxlbmd0aDsgaSsrKSB7XG5cdFx0XHRpZiAob2JqZWN0IGluc3RhbmNlb2YgTWFwKSBvYmplY3QgPSBvYmplY3QuZ2V0KHNlY3Rpb25zW2ldKTtcblx0XHRcdGVsc2Ugb2JqZWN0ID0gb2JqZWN0W3NlY3Rpb25zW2ldXTtcblx0XHRcdGlmICh0aGlzLnJlZkVkaXRvci5pc1JlZihvYmplY3QpKSBvYmplY3QgPSB0aGlzLnJlZkVkaXRvci5nZXQob2JqZWN0KTtcblx0XHRcdGlmICghb2JqZWN0KSByZXR1cm4gdm9pZCAwO1xuXHRcdH1cblx0XHRyZXR1cm4gb2JqZWN0O1xuXHR9XG5cdGhhcyhvYmplY3QsIHBhdGgsIHBhcmVudCA9IGZhbHNlKSB7XG5cdFx0aWYgKHR5cGVvZiBvYmplY3QgPT09IFwidW5kZWZpbmVkXCIpIHJldHVybiBmYWxzZTtcblx0XHRjb25zdCBzZWN0aW9ucyA9IEFycmF5LmlzQXJyYXkocGF0aCkgPyBwYXRoLnNsaWNlKCkgOiBwYXRoLnNwbGl0KFwiLlwiKTtcblx0XHRjb25zdCBzaXplID0gIXBhcmVudCA/IDEgOiAyO1xuXHRcdHdoaWxlIChvYmplY3QgJiYgc2VjdGlvbnMubGVuZ3RoID4gc2l6ZSkge1xuXHRcdFx0Y29uc3Qgc2VjdGlvbiA9IHNlY3Rpb25zLnNoaWZ0KCk7XG5cdFx0XHRvYmplY3QgPSBvYmplY3Rbc2VjdGlvbl07XG5cdFx0XHRpZiAodGhpcy5yZWZFZGl0b3IuaXNSZWYob2JqZWN0KSkgb2JqZWN0ID0gdGhpcy5yZWZFZGl0b3IuZ2V0KG9iamVjdCk7XG5cdFx0fVxuXHRcdHJldHVybiBvYmplY3QgIT0gbnVsbCAmJiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqZWN0LCBzZWN0aW9uc1swXSk7XG5cdH1cblx0Y3JlYXRlRGVmYXVsdFNldENhbGxiYWNrKHN0YXRlKSB7XG5cdFx0cmV0dXJuIChvYmplY3QsIGZpZWxkLCB2YWx1ZSkgPT4ge1xuXHRcdFx0aWYgKHN0YXRlLnJlbW92ZSB8fCBzdGF0ZS5uZXdLZXkpIGlmIChBcnJheS5pc0FycmF5KG9iamVjdCkpIG9iamVjdC5zcGxpY2UoZmllbGQsIDEpO1xuXHRcdFx0ZWxzZSBpZiAodG9SYXckMShvYmplY3QpIGluc3RhbmNlb2YgTWFwKSBvYmplY3QuZGVsZXRlKGZpZWxkKTtcblx0XHRcdGVsc2UgaWYgKHRvUmF3JDEob2JqZWN0KSBpbnN0YW5jZW9mIFNldCkgb2JqZWN0LmRlbGV0ZShBcnJheS5mcm9tKG9iamVjdC52YWx1ZXMoKSlbZmllbGRdKTtcblx0XHRcdGVsc2UgUmVmbGVjdC5kZWxldGVQcm9wZXJ0eShvYmplY3QsIGZpZWxkKTtcblx0XHRcdGlmICghc3RhdGUucmVtb3ZlKSB7XG5cdFx0XHRcdGNvbnN0IHRhcmdldCA9IG9iamVjdFtzdGF0ZS5uZXdLZXkgfHwgZmllbGRdO1xuXHRcdFx0XHRpZiAodGhpcy5yZWZFZGl0b3IuaXNSZWYodGFyZ2V0KSkgdGhpcy5yZWZFZGl0b3Iuc2V0KHRhcmdldCwgdmFsdWUpO1xuXHRcdFx0XHRlbHNlIGlmICh0b1JhdyQxKG9iamVjdCkgaW5zdGFuY2VvZiBNYXApIG9iamVjdC5zZXQoc3RhdGUubmV3S2V5IHx8IGZpZWxkLCB2YWx1ZSk7XG5cdFx0XHRcdGVsc2UgaWYgKHRvUmF3JDEob2JqZWN0KSBpbnN0YW5jZW9mIFNldCkgb2JqZWN0LmFkZCh2YWx1ZSk7XG5cdFx0XHRcdGVsc2Ugb2JqZWN0W3N0YXRlLm5ld0tleSB8fCBmaWVsZF0gPSB2YWx1ZTtcblx0XHRcdH1cblx0XHR9O1xuXHR9XG59O1xudmFyIFJlZlN0YXRlRWRpdG9yID0gY2xhc3Mge1xuXHRzZXQocmVmLCB2YWx1ZSkge1xuXHRcdGlmIChpc1JlZiQxKHJlZikpIHJlZi52YWx1ZSA9IHZhbHVlO1xuXHRcdGVsc2Uge1xuXHRcdFx0aWYgKHJlZiBpbnN0YW5jZW9mIFNldCAmJiBBcnJheS5pc0FycmF5KHZhbHVlKSkge1xuXHRcdFx0XHRyZWYuY2xlYXIoKTtcblx0XHRcdFx0dmFsdWUuZm9yRWFjaCgodikgPT4gcmVmLmFkZCh2KSk7XG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblx0XHRcdGNvbnN0IGN1cnJlbnRLZXlzID0gT2JqZWN0LmtleXModmFsdWUpO1xuXHRcdFx0aWYgKHJlZiBpbnN0YW5jZW9mIE1hcCkge1xuXHRcdFx0XHRjb25zdCBwcmV2aW91c0tleXNTZXQgPSBuZXcgU2V0KHJlZi5rZXlzKCkpO1xuXHRcdFx0XHRjdXJyZW50S2V5cy5mb3JFYWNoKChrZXkpID0+IHtcblx0XHRcdFx0XHRyZWYuc2V0KGtleSwgUmVmbGVjdC5nZXQodmFsdWUsIGtleSkpO1xuXHRcdFx0XHRcdHByZXZpb3VzS2V5c1NldC5kZWxldGUoa2V5KTtcblx0XHRcdFx0fSk7XG5cdFx0XHRcdHByZXZpb3VzS2V5c1NldC5mb3JFYWNoKChrZXkpID0+IHJlZi5kZWxldGUoa2V5KSk7XG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblx0XHRcdGNvbnN0IHByZXZpb3VzS2V5c1NldCA9IG5ldyBTZXQoT2JqZWN0LmtleXMocmVmKSk7XG5cdFx0XHRjdXJyZW50S2V5cy5mb3JFYWNoKChrZXkpID0+IHtcblx0XHRcdFx0UmVmbGVjdC5zZXQocmVmLCBrZXksIFJlZmxlY3QuZ2V0KHZhbHVlLCBrZXkpKTtcblx0XHRcdFx0cHJldmlvdXNLZXlzU2V0LmRlbGV0ZShrZXkpO1xuXHRcdFx0fSk7XG5cdFx0XHRwcmV2aW91c0tleXNTZXQuZm9yRWFjaCgoa2V5KSA9PiBSZWZsZWN0LmRlbGV0ZVByb3BlcnR5KHJlZiwga2V5KSk7XG5cdFx0fVxuXHR9XG5cdGdldChyZWYpIHtcblx0XHRyZXR1cm4gaXNSZWYkMShyZWYpID8gcmVmLnZhbHVlIDogcmVmO1xuXHR9XG5cdGlzUmVmKHJlZikge1xuXHRcdHJldHVybiBpc1JlZiQxKHJlZikgfHwgaXNSZWFjdGl2ZSQxKHJlZik7XG5cdH1cbn07XG5hc3luYyBmdW5jdGlvbiBlZGl0Q29tcG9uZW50U3RhdGUocGF5bG9hZCwgc3RhdGVFZGl0b3IpIHtcblx0Y29uc3QgeyBwYXRoLCBub2RlSWQsIHN0YXRlLCB0eXBlIH0gPSBwYXlsb2FkO1xuXHRjb25zdCBpbnN0YW5jZSA9IGdldENvbXBvbmVudEluc3RhbmNlKGFjdGl2ZUFwcFJlY29yZC52YWx1ZSwgbm9kZUlkKTtcblx0aWYgKCFpbnN0YW5jZSkgcmV0dXJuO1xuXHRjb25zdCB0YXJnZXRQYXRoID0gcGF0aC5zbGljZSgpO1xuXHRsZXQgdGFyZ2V0O1xuXHRpZiAoT2JqZWN0LmtleXMoaW5zdGFuY2UucHJvcHMpLmluY2x1ZGVzKHBhdGhbMF0pKSB0YXJnZXQgPSBpbnN0YW5jZS5wcm9wcztcblx0ZWxzZSBpZiAoaW5zdGFuY2UuZGV2dG9vbHNSYXdTZXR1cFN0YXRlICYmIE9iamVjdC5rZXlzKGluc3RhbmNlLmRldnRvb2xzUmF3U2V0dXBTdGF0ZSkuaW5jbHVkZXMocGF0aFswXSkpIHRhcmdldCA9IGluc3RhbmNlLmRldnRvb2xzUmF3U2V0dXBTdGF0ZTtcblx0ZWxzZSBpZiAoaW5zdGFuY2UuZGF0YSAmJiBPYmplY3Qua2V5cyhpbnN0YW5jZS5kYXRhKS5pbmNsdWRlcyhwYXRoWzBdKSkgdGFyZ2V0ID0gaW5zdGFuY2UuZGF0YTtcblx0ZWxzZSB0YXJnZXQgPSBpbnN0YW5jZS5wcm94eTtcblx0aWYgKHRhcmdldCAmJiB0YXJnZXRQYXRoKSB7XG5cdFx0aWYgKHN0YXRlLnR5cGUgPT09IFwib2JqZWN0XCIgJiYgdHlwZSA9PT0gXCJyZWFjdGl2ZVwiKSB7fVxuXHRcdHN0YXRlRWRpdG9yLnNldCh0YXJnZXQsIHRhcmdldFBhdGgsIHN0YXRlLnZhbHVlLCBzdGF0ZUVkaXRvci5jcmVhdGVEZWZhdWx0U2V0Q2FsbGJhY2soc3RhdGUpKTtcblx0fVxufVxuY29uc3Qgc3RhdGVFZGl0b3IgPSBuZXcgU3RhdGVFZGl0b3IoKTtcbmFzeW5jIGZ1bmN0aW9uIGVkaXRTdGF0ZShwYXlsb2FkKSB7XG5cdGVkaXRDb21wb25lbnRTdGF0ZShwYXlsb2FkLCBzdGF0ZUVkaXRvcik7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS90aW1lbGluZS9zdG9yYWdlLnRzXG5jb25zdCBUSU1FTElORV9MQVlFUlNfU1RBVEVfU1RPUkFHRV9JRCA9IFwiX19WVUVfREVWVE9PTFNfS0lUX1RJTUVMSU5FX0xBWUVSU19TVEFURV9fXCI7XG5mdW5jdGlvbiBhZGRUaW1lbGluZUxheWVyc1N0YXRlVG9TdG9yYWdlKHN0YXRlKSB7XG5cdGlmICghaXNCcm93c2VyIHx8IHR5cGVvZiBsb2NhbFN0b3JhZ2UgPT09IFwidW5kZWZpbmVkXCIgfHwgbG9jYWxTdG9yYWdlID09PSBudWxsKSByZXR1cm47XG5cdGxvY2FsU3RvcmFnZS5zZXRJdGVtKFRJTUVMSU5FX0xBWUVSU19TVEFURV9TVE9SQUdFX0lELCBKU09OLnN0cmluZ2lmeShzdGF0ZSkpO1xufVxuZnVuY3Rpb24gZ2V0VGltZWxpbmVMYXllcnNTdGF0ZUZyb21TdG9yYWdlKCkge1xuXHRpZiAodHlwZW9mIHdpbmRvdyA9PT0gXCJ1bmRlZmluZWRcIiB8fCAhaXNCcm93c2VyIHx8IHR5cGVvZiBsb2NhbFN0b3JhZ2UgPT09IFwidW5kZWZpbmVkXCIgfHwgbG9jYWxTdG9yYWdlID09PSBudWxsKSByZXR1cm4ge1xuXHRcdHJlY29yZGluZ1N0YXRlOiBmYWxzZSxcblx0XHRtb3VzZUV2ZW50RW5hYmxlZDogZmFsc2UsXG5cdFx0a2V5Ym9hcmRFdmVudEVuYWJsZWQ6IGZhbHNlLFxuXHRcdGNvbXBvbmVudEV2ZW50RW5hYmxlZDogZmFsc2UsXG5cdFx0cGVyZm9ybWFuY2VFdmVudEVuYWJsZWQ6IGZhbHNlLFxuXHRcdHNlbGVjdGVkOiBcIlwiXG5cdH07XG5cdGNvbnN0IHN0YXRlID0gdHlwZW9mIGxvY2FsU3RvcmFnZS5nZXRJdGVtICE9PSBcInVuZGVmaW5lZFwiID8gbG9jYWxTdG9yYWdlLmdldEl0ZW0oVElNRUxJTkVfTEFZRVJTX1NUQVRFX1NUT1JBR0VfSUQpIDogbnVsbDtcblx0cmV0dXJuIHN0YXRlID8gSlNPTi5wYXJzZShzdGF0ZSkgOiB7XG5cdFx0cmVjb3JkaW5nU3RhdGU6IGZhbHNlLFxuXHRcdG1vdXNlRXZlbnRFbmFibGVkOiBmYWxzZSxcblx0XHRrZXlib2FyZEV2ZW50RW5hYmxlZDogZmFsc2UsXG5cdFx0Y29tcG9uZW50RXZlbnRFbmFibGVkOiBmYWxzZSxcblx0XHRwZXJmb3JtYW5jZUV2ZW50RW5hYmxlZDogZmFsc2UsXG5cdFx0c2VsZWN0ZWQ6IFwiXCJcblx0fTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jdHgvdGltZWxpbmUudHNcbnRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfVElNRUxJTkVfTEFZRVJTID8/PSBbXTtcbmNvbnN0IGRldnRvb2xzVGltZWxpbmVMYXllcnMgPSBuZXcgUHJveHkodGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9USU1FTElORV9MQVlFUlMsIHsgZ2V0KHRhcmdldCwgcHJvcCwgcmVjZWl2ZXIpIHtcblx0cmV0dXJuIFJlZmxlY3QuZ2V0KHRhcmdldCwgcHJvcCwgcmVjZWl2ZXIpO1xufSB9KTtcbmZ1bmN0aW9uIGFkZFRpbWVsaW5lTGF5ZXIob3B0aW9ucywgZGVzY3JpcHRvcikge1xuXHRkZXZ0b29sc1N0YXRlLnRpbWVsaW5lTGF5ZXJzU3RhdGVbZGVzY3JpcHRvci5pZF0gPSBmYWxzZTtcblx0ZGV2dG9vbHNUaW1lbGluZUxheWVycy5wdXNoKHtcblx0XHQuLi5vcHRpb25zLFxuXHRcdGRlc2NyaXB0b3JJZDogZGVzY3JpcHRvci5pZCxcblx0XHRhcHBSZWNvcmQ6IGdldEFwcFJlY29yZChkZXNjcmlwdG9yLmFwcClcblx0fSk7XG59XG5mdW5jdGlvbiB1cGRhdGVUaW1lbGluZUxheWVyc1N0YXRlKHN0YXRlKSB7XG5cdGNvbnN0IHVwZGF0ZWRTdGF0ZSA9IHtcblx0XHQuLi5kZXZ0b29sc1N0YXRlLnRpbWVsaW5lTGF5ZXJzU3RhdGUsXG5cdFx0Li4uc3RhdGVcblx0fTtcblx0YWRkVGltZWxpbmVMYXllcnNTdGF0ZVRvU3RvcmFnZSh1cGRhdGVkU3RhdGUpO1xuXHR1cGRhdGVEZXZUb29sc1N0YXRlKHsgdGltZWxpbmVMYXllcnNTdGF0ZTogdXBkYXRlZFN0YXRlIH0pO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2N0eC9pbnNwZWN0b3IudHNcbnRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfSU5TUEVDVE9SX18gPz89IFtdO1xuY29uc3QgZGV2dG9vbHNJbnNwZWN0b3IgPSBuZXcgUHJveHkodGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9JTlNQRUNUT1JfXywgeyBnZXQodGFyZ2V0LCBwcm9wLCByZWNlaXZlcikge1xuXHRyZXR1cm4gUmVmbGVjdC5nZXQodGFyZ2V0LCBwcm9wLCByZWNlaXZlcik7XG59IH0pO1xuY29uc3QgY2FsbEluc3BlY3RvclVwZGF0ZWRIb29rID0gZGVib3VuY2UoKCkgPT4ge1xuXHRkZXZ0b29sc0NvbnRleHQuaG9va3MuY2FsbEhvb2soRGV2VG9vbHNNZXNzYWdpbmdIb29rS2V5cy5TRU5EX0lOU1BFQ1RPUl9UT19DTElFTlQsIGdldEFjdGl2ZUluc3BlY3RvcnMoKSk7XG59KTtcbmZ1bmN0aW9uIGFkZEluc3BlY3RvcihpbnNwZWN0b3IsIGRlc2NyaXB0b3IpIHtcblx0ZGV2dG9vbHNJbnNwZWN0b3IucHVzaCh7XG5cdFx0b3B0aW9uczogaW5zcGVjdG9yLFxuXHRcdGRlc2NyaXB0b3IsXG5cdFx0dHJlZUZpbHRlclBsYWNlaG9sZGVyOiBpbnNwZWN0b3IudHJlZUZpbHRlclBsYWNlaG9sZGVyID8/IFwiU2VhcmNoIHRyZWUuLi5cIixcblx0XHRzdGF0ZUZpbHRlclBsYWNlaG9sZGVyOiBpbnNwZWN0b3Iuc3RhdGVGaWx0ZXJQbGFjZWhvbGRlciA/PyBcIlNlYXJjaCBzdGF0ZS4uLlwiLFxuXHRcdHRyZWVGaWx0ZXI6IFwiXCIsXG5cdFx0c2VsZWN0ZWROb2RlSWQ6IFwiXCIsXG5cdFx0YXBwUmVjb3JkOiBnZXRBcHBSZWNvcmQoZGVzY3JpcHRvci5hcHApXG5cdH0pO1xuXHRjYWxsSW5zcGVjdG9yVXBkYXRlZEhvb2soKTtcbn1cbmZ1bmN0aW9uIGdldEFjdGl2ZUluc3BlY3RvcnMoKSB7XG5cdHJldHVybiBkZXZ0b29sc0luc3BlY3Rvci5maWx0ZXIoKGluc3BlY3RvcikgPT4gaW5zcGVjdG9yLmRlc2NyaXB0b3IuYXBwID09PSBhY3RpdmVBcHBSZWNvcmQudmFsdWUuYXBwKS5maWx0ZXIoKGluc3BlY3RvcikgPT4gaW5zcGVjdG9yLmRlc2NyaXB0b3IuaWQgIT09IFwiY29tcG9uZW50c1wiKS5tYXAoKGluc3BlY3RvcikgPT4ge1xuXHRcdGNvbnN0IGRlc2NyaXB0b3IgPSBpbnNwZWN0b3IuZGVzY3JpcHRvcjtcblx0XHRjb25zdCBvcHRpb25zID0gaW5zcGVjdG9yLm9wdGlvbnM7XG5cdFx0cmV0dXJuIHtcblx0XHRcdGlkOiBvcHRpb25zLmlkLFxuXHRcdFx0bGFiZWw6IG9wdGlvbnMubGFiZWwsXG5cdFx0XHRsb2dvOiBkZXNjcmlwdG9yLmxvZ28sXG5cdFx0XHRpY29uOiBgY3VzdG9tLWljLWJhc2VsaW5lLSR7b3B0aW9ucz8uaWNvbj8ucmVwbGFjZSgvXy9nLCBcIi1cIil9YCxcblx0XHRcdHBhY2thZ2VOYW1lOiBkZXNjcmlwdG9yLnBhY2thZ2VOYW1lLFxuXHRcdFx0aG9tZXBhZ2U6IGRlc2NyaXB0b3IuaG9tZXBhZ2UsXG5cdFx0XHRwbHVnaW5JZDogZGVzY3JpcHRvci5pZFxuXHRcdH07XG5cdH0pO1xufVxuZnVuY3Rpb24gZ2V0SW5zcGVjdG9ySW5mbyhpZCkge1xuXHRjb25zdCBpbnNwZWN0b3IgPSBnZXRJbnNwZWN0b3IoaWQsIGFjdGl2ZUFwcFJlY29yZC52YWx1ZS5hcHApO1xuXHRpZiAoIWluc3BlY3RvcikgcmV0dXJuO1xuXHRjb25zdCBkZXNjcmlwdG9yID0gaW5zcGVjdG9yLmRlc2NyaXB0b3I7XG5cdGNvbnN0IG9wdGlvbnMgPSBpbnNwZWN0b3Iub3B0aW9ucztcblx0Y29uc3QgdGltZWxpbmVMYXllcnMgPSBkZXZ0b29sc1RpbWVsaW5lTGF5ZXJzLmZpbHRlcigobGF5ZXIpID0+IGxheWVyLmRlc2NyaXB0b3JJZCA9PT0gZGVzY3JpcHRvci5pZCkubWFwKChpdGVtKSA9PiAoe1xuXHRcdGlkOiBpdGVtLmlkLFxuXHRcdGxhYmVsOiBpdGVtLmxhYmVsLFxuXHRcdGNvbG9yOiBpdGVtLmNvbG9yXG5cdH0pKTtcblx0cmV0dXJuIHtcblx0XHRpZDogb3B0aW9ucy5pZCxcblx0XHRsYWJlbDogb3B0aW9ucy5sYWJlbCxcblx0XHRsb2dvOiBkZXNjcmlwdG9yLmxvZ28sXG5cdFx0cGFja2FnZU5hbWU6IGRlc2NyaXB0b3IucGFja2FnZU5hbWUsXG5cdFx0aG9tZXBhZ2U6IGRlc2NyaXB0b3IuaG9tZXBhZ2UsXG5cdFx0dGltZWxpbmVMYXllcnMsXG5cdFx0dHJlZUZpbHRlclBsYWNlaG9sZGVyOiBpbnNwZWN0b3IudHJlZUZpbHRlclBsYWNlaG9sZGVyLFxuXHRcdHN0YXRlRmlsdGVyUGxhY2Vob2xkZXI6IGluc3BlY3Rvci5zdGF0ZUZpbHRlclBsYWNlaG9sZGVyXG5cdH07XG59XG5mdW5jdGlvbiBnZXRJbnNwZWN0b3IoaWQsIGFwcCkge1xuXHRyZXR1cm4gZGV2dG9vbHNJbnNwZWN0b3IuZmluZCgoaW5zcGVjdG9yKSA9PiBpbnNwZWN0b3Iub3B0aW9ucy5pZCA9PT0gaWQgJiYgKGFwcCA/IGluc3BlY3Rvci5kZXNjcmlwdG9yLmFwcCA9PT0gYXBwIDogdHJ1ZSkpO1xufVxuZnVuY3Rpb24gZ2V0SW5zcGVjdG9yQWN0aW9ucyhpZCkge1xuXHRyZXR1cm4gZ2V0SW5zcGVjdG9yKGlkKT8ub3B0aW9ucy5hY3Rpb25zO1xufVxuZnVuY3Rpb24gZ2V0SW5zcGVjdG9yTm9kZUFjdGlvbnMoaWQpIHtcblx0cmV0dXJuIGdldEluc3BlY3RvcihpZCk/Lm9wdGlvbnMubm9kZUFjdGlvbnM7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY3R4L2hvb2sudHNcbmxldCBEZXZUb29sc1Y2UGx1Z2luQVBJSG9va0tleXMgPSAvKiBAX19QVVJFX18gKi8gZnVuY3Rpb24oRGV2VG9vbHNWNlBsdWdpbkFQSUhvb2tLZXlzKSB7XG5cdERldlRvb2xzVjZQbHVnaW5BUElIb29rS2V5c1tcIlZJU0lUX0NPTVBPTkVOVF9UUkVFXCJdID0gXCJ2aXNpdENvbXBvbmVudFRyZWVcIjtcblx0RGV2VG9vbHNWNlBsdWdpbkFQSUhvb2tLZXlzW1wiSU5TUEVDVF9DT01QT05FTlRcIl0gPSBcImluc3BlY3RDb21wb25lbnRcIjtcblx0RGV2VG9vbHNWNlBsdWdpbkFQSUhvb2tLZXlzW1wiRURJVF9DT01QT05FTlRfU1RBVEVcIl0gPSBcImVkaXRDb21wb25lbnRTdGF0ZVwiO1xuXHREZXZUb29sc1Y2UGx1Z2luQVBJSG9va0tleXNbXCJHRVRfSU5TUEVDVE9SX1RSRUVcIl0gPSBcImdldEluc3BlY3RvclRyZWVcIjtcblx0RGV2VG9vbHNWNlBsdWdpbkFQSUhvb2tLZXlzW1wiR0VUX0lOU1BFQ1RPUl9TVEFURVwiXSA9IFwiZ2V0SW5zcGVjdG9yU3RhdGVcIjtcblx0RGV2VG9vbHNWNlBsdWdpbkFQSUhvb2tLZXlzW1wiRURJVF9JTlNQRUNUT1JfU1RBVEVcIl0gPSBcImVkaXRJbnNwZWN0b3JTdGF0ZVwiO1xuXHREZXZUb29sc1Y2UGx1Z2luQVBJSG9va0tleXNbXCJJTlNQRUNUX1RJTUVMSU5FX0VWRU5UXCJdID0gXCJpbnNwZWN0VGltZWxpbmVFdmVudFwiO1xuXHREZXZUb29sc1Y2UGx1Z2luQVBJSG9va0tleXNbXCJUSU1FTElORV9DTEVBUkVEXCJdID0gXCJ0aW1lbGluZUNsZWFyZWRcIjtcblx0RGV2VG9vbHNWNlBsdWdpbkFQSUhvb2tLZXlzW1wiU0VUX1BMVUdJTl9TRVRUSU5HU1wiXSA9IFwic2V0UGx1Z2luU2V0dGluZ3NcIjtcblx0cmV0dXJuIERldlRvb2xzVjZQbHVnaW5BUElIb29rS2V5cztcbn0oe30pO1xubGV0IERldlRvb2xzQ29udGV4dEhvb2tLZXlzID0gLyogQF9fUFVSRV9fICovIGZ1bmN0aW9uKERldlRvb2xzQ29udGV4dEhvb2tLZXlzKSB7XG5cdERldlRvb2xzQ29udGV4dEhvb2tLZXlzW1wiQUREX0lOU1BFQ1RPUlwiXSA9IFwiYWRkSW5zcGVjdG9yXCI7XG5cdERldlRvb2xzQ29udGV4dEhvb2tLZXlzW1wiU0VORF9JTlNQRUNUT1JfVFJFRVwiXSA9IFwic2VuZEluc3BlY3RvclRyZWVcIjtcblx0RGV2VG9vbHNDb250ZXh0SG9va0tleXNbXCJTRU5EX0lOU1BFQ1RPUl9TVEFURVwiXSA9IFwic2VuZEluc3BlY3RvclN0YXRlXCI7XG5cdERldlRvb2xzQ29udGV4dEhvb2tLZXlzW1wiQ1VTVE9NX0lOU1BFQ1RPUl9TRUxFQ1RfTk9ERVwiXSA9IFwiY3VzdG9tSW5zcGVjdG9yU2VsZWN0Tm9kZVwiO1xuXHREZXZUb29sc0NvbnRleHRIb29rS2V5c1tcIlRJTUVMSU5FX0xBWUVSX0FEREVEXCJdID0gXCJ0aW1lbGluZUxheWVyQWRkZWRcIjtcblx0RGV2VG9vbHNDb250ZXh0SG9va0tleXNbXCJUSU1FTElORV9FVkVOVF9BRERFRFwiXSA9IFwidGltZWxpbmVFdmVudEFkZGVkXCI7XG5cdERldlRvb2xzQ29udGV4dEhvb2tLZXlzW1wiR0VUX0NPTVBPTkVOVF9JTlNUQU5DRVNcIl0gPSBcImdldENvbXBvbmVudEluc3RhbmNlc1wiO1xuXHREZXZUb29sc0NvbnRleHRIb29rS2V5c1tcIkdFVF9DT01QT05FTlRfQk9VTkRTXCJdID0gXCJnZXRDb21wb25lbnRCb3VuZHNcIjtcblx0RGV2VG9vbHNDb250ZXh0SG9va0tleXNbXCJHRVRfQ09NUE9ORU5UX05BTUVcIl0gPSBcImdldENvbXBvbmVudE5hbWVcIjtcblx0RGV2VG9vbHNDb250ZXh0SG9va0tleXNbXCJDT01QT05FTlRfSElHSExJR0hUXCJdID0gXCJjb21wb25lbnRIaWdobGlnaHRcIjtcblx0RGV2VG9vbHNDb250ZXh0SG9va0tleXNbXCJDT01QT05FTlRfVU5ISUdITElHSFRcIl0gPSBcImNvbXBvbmVudFVuaGlnaGxpZ2h0XCI7XG5cdHJldHVybiBEZXZUb29sc0NvbnRleHRIb29rS2V5cztcbn0oe30pO1xubGV0IERldlRvb2xzTWVzc2FnaW5nSG9va0tleXMgPSAvKiBAX19QVVJFX18gKi8gZnVuY3Rpb24oRGV2VG9vbHNNZXNzYWdpbmdIb29rS2V5cykge1xuXHREZXZUb29sc01lc3NhZ2luZ0hvb2tLZXlzW1wiU0VORF9JTlNQRUNUT1JfVFJFRV9UT19DTElFTlRcIl0gPSBcInNlbmRJbnNwZWN0b3JUcmVlVG9DbGllbnRcIjtcblx0RGV2VG9vbHNNZXNzYWdpbmdIb29rS2V5c1tcIlNFTkRfSU5TUEVDVE9SX1NUQVRFX1RPX0NMSUVOVFwiXSA9IFwic2VuZEluc3BlY3RvclN0YXRlVG9DbGllbnRcIjtcblx0RGV2VG9vbHNNZXNzYWdpbmdIb29rS2V5c1tcIlNFTkRfVElNRUxJTkVfRVZFTlRfVE9fQ0xJRU5UXCJdID0gXCJzZW5kVGltZWxpbmVFdmVudFRvQ2xpZW50XCI7XG5cdERldlRvb2xzTWVzc2FnaW5nSG9va0tleXNbXCJTRU5EX0lOU1BFQ1RPUl9UT19DTElFTlRcIl0gPSBcInNlbmRJbnNwZWN0b3JUb0NsaWVudFwiO1xuXHREZXZUb29sc01lc3NhZ2luZ0hvb2tLZXlzW1wiU0VORF9BQ1RJVkVfQVBQX1VOTU9VTlRFRF9UT19DTElFTlRcIl0gPSBcInNlbmRBY3RpdmVBcHBVcGRhdGVkVG9DbGllbnRcIjtcblx0RGV2VG9vbHNNZXNzYWdpbmdIb29rS2V5c1tcIkRFVlRPT0xTX1NUQVRFX1VQREFURURcIl0gPSBcImRldnRvb2xzU3RhdGVVcGRhdGVkXCI7XG5cdERldlRvb2xzTWVzc2FnaW5nSG9va0tleXNbXCJERVZUT09MU19DT05ORUNURURfVVBEQVRFRFwiXSA9IFwiZGV2dG9vbHNDb25uZWN0ZWRVcGRhdGVkXCI7XG5cdERldlRvb2xzTWVzc2FnaW5nSG9va0tleXNbXCJST1VURVJfSU5GT19VUERBVEVEXCJdID0gXCJyb3V0ZXJJbmZvVXBkYXRlZFwiO1xuXHRyZXR1cm4gRGV2VG9vbHNNZXNzYWdpbmdIb29rS2V5cztcbn0oe30pO1xuZnVuY3Rpb24gY3JlYXRlRGV2VG9vbHNDdHhIb29rcygpIHtcblx0Y29uc3QgaG9va3MgPSBjcmVhdGVIb29rcygpO1xuXHRob29rcy5ob29rKERldlRvb2xzQ29udGV4dEhvb2tLZXlzLkFERF9JTlNQRUNUT1IsICh7IGluc3BlY3RvciwgcGx1Z2luIH0pID0+IHtcblx0XHRhZGRJbnNwZWN0b3IoaW5zcGVjdG9yLCBwbHVnaW4uZGVzY3JpcHRvcik7XG5cdH0pO1xuXHRjb25zdCBkZWJvdW5jZVNlbmRJbnNwZWN0b3JUcmVlID0gZGVib3VuY2UoYXN5bmMgKHsgaW5zcGVjdG9ySWQsIHBsdWdpbiB9KSA9PiB7XG5cdFx0aWYgKCFpbnNwZWN0b3JJZCB8fCAhcGx1Z2luPy5kZXNjcmlwdG9yPy5hcHAgfHwgZGV2dG9vbHNTdGF0ZS5oaWdoUGVyZk1vZGVFbmFibGVkKSByZXR1cm47XG5cdFx0Y29uc3QgaW5zcGVjdG9yID0gZ2V0SW5zcGVjdG9yKGluc3BlY3RvcklkLCBwbHVnaW4uZGVzY3JpcHRvci5hcHApO1xuXHRcdGNvbnN0IF9wYXlsb2FkID0ge1xuXHRcdFx0YXBwOiBwbHVnaW4uZGVzY3JpcHRvci5hcHAsXG5cdFx0XHRpbnNwZWN0b3JJZCxcblx0XHRcdGZpbHRlcjogaW5zcGVjdG9yPy50cmVlRmlsdGVyIHx8IFwiXCIsXG5cdFx0XHRyb290Tm9kZXM6IFtdXG5cdFx0fTtcblx0XHRhd2FpdCBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuXHRcdFx0aG9va3MuY2FsbEhvb2tXaXRoKGFzeW5jIChjYWxsYmFja3MpID0+IHtcblx0XHRcdFx0YXdhaXQgUHJvbWlzZS5hbGwoY2FsbGJhY2tzLm1hcCgoY2IpID0+IGNiKF9wYXlsb2FkKSkpO1xuXHRcdFx0XHRyZXNvbHZlKCk7XG5cdFx0XHR9LCBEZXZUb29sc1Y2UGx1Z2luQVBJSG9va0tleXMuR0VUX0lOU1BFQ1RPUl9UUkVFKTtcblx0XHR9KTtcblx0XHRob29rcy5jYWxsSG9va1dpdGgoYXN5bmMgKGNhbGxiYWNrcykgPT4ge1xuXHRcdFx0YXdhaXQgUHJvbWlzZS5hbGwoY2FsbGJhY2tzLm1hcCgoY2IpID0+IGNiKHtcblx0XHRcdFx0aW5zcGVjdG9ySWQsXG5cdFx0XHRcdHJvb3ROb2RlczogX3BheWxvYWQucm9vdE5vZGVzXG5cdFx0XHR9KSkpO1xuXHRcdH0sIERldlRvb2xzTWVzc2FnaW5nSG9va0tleXMuU0VORF9JTlNQRUNUT1JfVFJFRV9UT19DTElFTlQpO1xuXHR9LCAxMjApO1xuXHRob29rcy5ob29rKERldlRvb2xzQ29udGV4dEhvb2tLZXlzLlNFTkRfSU5TUEVDVE9SX1RSRUUsIGRlYm91bmNlU2VuZEluc3BlY3RvclRyZWUpO1xuXHRjb25zdCBkZWJvdW5jZVNlbmRJbnNwZWN0b3JTdGF0ZSA9IGRlYm91bmNlKGFzeW5jICh7IGluc3BlY3RvcklkLCBwbHVnaW4gfSkgPT4ge1xuXHRcdGlmICghaW5zcGVjdG9ySWQgfHwgIXBsdWdpbj8uZGVzY3JpcHRvcj8uYXBwIHx8IGRldnRvb2xzU3RhdGUuaGlnaFBlcmZNb2RlRW5hYmxlZCkgcmV0dXJuO1xuXHRcdGNvbnN0IGluc3BlY3RvciA9IGdldEluc3BlY3RvcihpbnNwZWN0b3JJZCwgcGx1Z2luLmRlc2NyaXB0b3IuYXBwKTtcblx0XHRjb25zdCBfcGF5bG9hZCA9IHtcblx0XHRcdGFwcDogcGx1Z2luLmRlc2NyaXB0b3IuYXBwLFxuXHRcdFx0aW5zcGVjdG9ySWQsXG5cdFx0XHRub2RlSWQ6IGluc3BlY3Rvcj8uc2VsZWN0ZWROb2RlSWQgfHwgXCJcIixcblx0XHRcdHN0YXRlOiBudWxsXG5cdFx0fTtcblx0XHRjb25zdCBjdHggPSB7IGN1cnJlbnRUYWI6IGBjdXN0b20taW5zcGVjdG9yOiR7aW5zcGVjdG9ySWR9YCB9O1xuXHRcdGlmIChfcGF5bG9hZC5ub2RlSWQpIGF3YWl0IG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG5cdFx0XHRob29rcy5jYWxsSG9va1dpdGgoYXN5bmMgKGNhbGxiYWNrcykgPT4ge1xuXHRcdFx0XHRhd2FpdCBQcm9taXNlLmFsbChjYWxsYmFja3MubWFwKChjYikgPT4gY2IoX3BheWxvYWQsIGN0eCkpKTtcblx0XHRcdFx0cmVzb2x2ZSgpO1xuXHRcdFx0fSwgRGV2VG9vbHNWNlBsdWdpbkFQSUhvb2tLZXlzLkdFVF9JTlNQRUNUT1JfU1RBVEUpO1xuXHRcdH0pO1xuXHRcdGhvb2tzLmNhbGxIb29rV2l0aChhc3luYyAoY2FsbGJhY2tzKSA9PiB7XG5cdFx0XHRhd2FpdCBQcm9taXNlLmFsbChjYWxsYmFja3MubWFwKChjYikgPT4gY2Ioe1xuXHRcdFx0XHRpbnNwZWN0b3JJZCxcblx0XHRcdFx0bm9kZUlkOiBfcGF5bG9hZC5ub2RlSWQsXG5cdFx0XHRcdHN0YXRlOiBfcGF5bG9hZC5zdGF0ZVxuXHRcdFx0fSkpKTtcblx0XHR9LCBEZXZUb29sc01lc3NhZ2luZ0hvb2tLZXlzLlNFTkRfSU5TUEVDVE9SX1NUQVRFX1RPX0NMSUVOVCk7XG5cdH0sIDEyMCk7XG5cdGhvb2tzLmhvb2soRGV2VG9vbHNDb250ZXh0SG9va0tleXMuU0VORF9JTlNQRUNUT1JfU1RBVEUsIGRlYm91bmNlU2VuZEluc3BlY3RvclN0YXRlKTtcblx0aG9va3MuaG9vayhEZXZUb29sc0NvbnRleHRIb29rS2V5cy5DVVNUT01fSU5TUEVDVE9SX1NFTEVDVF9OT0RFLCAoeyBpbnNwZWN0b3JJZCwgbm9kZUlkLCBwbHVnaW4gfSkgPT4ge1xuXHRcdGNvbnN0IGluc3BlY3RvciA9IGdldEluc3BlY3RvcihpbnNwZWN0b3JJZCwgcGx1Z2luLmRlc2NyaXB0b3IuYXBwKTtcblx0XHRpZiAoIWluc3BlY3RvcikgcmV0dXJuO1xuXHRcdGluc3BlY3Rvci5zZWxlY3RlZE5vZGVJZCA9IG5vZGVJZDtcblx0fSk7XG5cdGhvb2tzLmhvb2soRGV2VG9vbHNDb250ZXh0SG9va0tleXMuVElNRUxJTkVfTEFZRVJfQURERUQsICh7IG9wdGlvbnMsIHBsdWdpbiB9KSA9PiB7XG5cdFx0YWRkVGltZWxpbmVMYXllcihvcHRpb25zLCBwbHVnaW4uZGVzY3JpcHRvcik7XG5cdH0pO1xuXHRob29rcy5ob29rKERldlRvb2xzQ29udGV4dEhvb2tLZXlzLlRJTUVMSU5FX0VWRU5UX0FEREVELCAoeyBvcHRpb25zLCBwbHVnaW4gfSkgPT4ge1xuXHRcdGlmIChkZXZ0b29sc1N0YXRlLmhpZ2hQZXJmTW9kZUVuYWJsZWQgfHwgIWRldnRvb2xzU3RhdGUudGltZWxpbmVMYXllcnNTdGF0ZT8uW3BsdWdpbi5kZXNjcmlwdG9yLmlkXSAmJiAhW1xuXHRcdFx0XCJwZXJmb3JtYW5jZVwiLFxuXHRcdFx0XCJjb21wb25lbnQtZXZlbnRcIixcblx0XHRcdFwia2V5Ym9hcmRcIixcblx0XHRcdFwibW91c2VcIlxuXHRcdF0uaW5jbHVkZXMob3B0aW9ucy5sYXllcklkKSkgcmV0dXJuO1xuXHRcdGhvb2tzLmNhbGxIb29rV2l0aChhc3luYyAoY2FsbGJhY2tzKSA9PiB7XG5cdFx0XHRhd2FpdCBQcm9taXNlLmFsbChjYWxsYmFja3MubWFwKChjYikgPT4gY2Iob3B0aW9ucykpKTtcblx0XHR9LCBEZXZUb29sc01lc3NhZ2luZ0hvb2tLZXlzLlNFTkRfVElNRUxJTkVfRVZFTlRfVE9fQ0xJRU5UKTtcblx0fSk7XG5cdGhvb2tzLmhvb2soRGV2VG9vbHNDb250ZXh0SG9va0tleXMuR0VUX0NPTVBPTkVOVF9JTlNUQU5DRVMsIGFzeW5jICh7IGFwcCB9KSA9PiB7XG5cdFx0Y29uc3QgYXBwUmVjb3JkID0gYXBwLl9fVlVFX0RFVlRPT0xTX05FWFRfQVBQX1JFQ09SRF9fO1xuXHRcdGlmICghYXBwUmVjb3JkKSByZXR1cm4gbnVsbDtcblx0XHRjb25zdCBhcHBJZCA9IGFwcFJlY29yZC5pZC50b1N0cmluZygpO1xuXHRcdHJldHVybiBbLi4uYXBwUmVjb3JkLmluc3RhbmNlTWFwXS5maWx0ZXIoKFtrZXldKSA9PiBrZXkuc3BsaXQoXCI6XCIpWzBdID09PSBhcHBJZCkubWFwKChbLCBpbnN0YW5jZV0pID0+IGluc3RhbmNlKTtcblx0fSk7XG5cdGhvb2tzLmhvb2soRGV2VG9vbHNDb250ZXh0SG9va0tleXMuR0VUX0NPTVBPTkVOVF9CT1VORFMsIGFzeW5jICh7IGluc3RhbmNlIH0pID0+IHtcblx0XHRyZXR1cm4gZ2V0Q29tcG9uZW50Qm91bmRpbmdSZWN0KGluc3RhbmNlKTtcblx0fSk7XG5cdGhvb2tzLmhvb2soRGV2VG9vbHNDb250ZXh0SG9va0tleXMuR0VUX0NPTVBPTkVOVF9OQU1FLCAoeyBpbnN0YW5jZSB9KSA9PiB7XG5cdFx0cmV0dXJuIGdldEluc3RhbmNlTmFtZShpbnN0YW5jZSk7XG5cdH0pO1xuXHRob29rcy5ob29rKERldlRvb2xzQ29udGV4dEhvb2tLZXlzLkNPTVBPTkVOVF9ISUdITElHSFQsICh7IHVpZCB9KSA9PiB7XG5cdFx0Y29uc3QgaW5zdGFuY2UgPSBhY3RpdmVBcHBSZWNvcmQudmFsdWUuaW5zdGFuY2VNYXAuZ2V0KHVpZCk7XG5cdFx0aWYgKGluc3RhbmNlKSBoaWdobGlnaHQoaW5zdGFuY2UpO1xuXHR9KTtcblx0aG9va3MuaG9vayhEZXZUb29sc0NvbnRleHRIb29rS2V5cy5DT01QT05FTlRfVU5ISUdITElHSFQsICgpID0+IHtcblx0XHR1bmhpZ2hsaWdodCgpO1xuXHR9KTtcblx0cmV0dXJuIGhvb2tzO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2N0eC9zdGF0ZS50c1xudGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9BUFBfUkVDT1JEU19fID8/PSBbXTtcbnRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfQUNUSVZFX0FQUF9SRUNPUkRfXyA/Pz0ge307XG50YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX0FDVElWRV9BUFBfUkVDT1JEX0lEX18gPz89IFwiXCI7XG50YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX0NVU1RPTV9UQUJTX18gPz89IFtdO1xudGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9DVVNUT01fQ09NTUFORFNfXyA/Pz0gW107XG5jb25zdCBTVEFURV9LRVkgPSBcIl9fVlVFX0RFVlRPT0xTX0tJVF9HTE9CQUxfU1RBVEVfX1wiO1xuZnVuY3Rpb24gaW5pdFN0YXRlRmFjdG9yeSgpIHtcblx0cmV0dXJuIHtcblx0XHRjb25uZWN0ZWQ6IGZhbHNlLFxuXHRcdGNsaWVudENvbm5lY3RlZDogZmFsc2UsXG5cdFx0dml0ZVBsdWdpbkRldGVjdGVkOiB0cnVlLFxuXHRcdGFwcFJlY29yZHM6IFtdLFxuXHRcdGFjdGl2ZUFwcFJlY29yZElkOiBcIlwiLFxuXHRcdHRhYnM6IFtdLFxuXHRcdGNvbW1hbmRzOiBbXSxcblx0XHRoaWdoUGVyZk1vZGVFbmFibGVkOiB0cnVlLFxuXHRcdGRldnRvb2xzQ2xpZW50RGV0ZWN0ZWQ6IHt9LFxuXHRcdHBlcmZVbmlxdWVHcm91cElkOiAwLFxuXHRcdHRpbWVsaW5lTGF5ZXJzU3RhdGU6IGdldFRpbWVsaW5lTGF5ZXJzU3RhdGVGcm9tU3RvcmFnZSgpXG5cdH07XG59XG50YXJnZXRbU1RBVEVfS0VZXSA/Pz0gaW5pdFN0YXRlRmFjdG9yeSgpO1xuY29uc3QgY2FsbFN0YXRlVXBkYXRlZEhvb2sgPSBkZWJvdW5jZSgoc3RhdGUpID0+IHtcblx0ZGV2dG9vbHNDb250ZXh0Lmhvb2tzLmNhbGxIb29rKERldlRvb2xzTWVzc2FnaW5nSG9va0tleXMuREVWVE9PTFNfU1RBVEVfVVBEQVRFRCwgeyBzdGF0ZSB9KTtcbn0pO1xuY29uc3QgY2FsbENvbm5lY3RlZFVwZGF0ZWRIb29rID0gZGVib3VuY2UoKHN0YXRlLCBvbGRTdGF0ZSkgPT4ge1xuXHRkZXZ0b29sc0NvbnRleHQuaG9va3MuY2FsbEhvb2soRGV2VG9vbHNNZXNzYWdpbmdIb29rS2V5cy5ERVZUT09MU19DT05ORUNURURfVVBEQVRFRCwge1xuXHRcdHN0YXRlLFxuXHRcdG9sZFN0YXRlXG5cdH0pO1xufSk7XG5jb25zdCBkZXZ0b29sc0FwcFJlY29yZHMgPSBuZXcgUHJveHkodGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9BUFBfUkVDT1JEU19fLCB7IGdldChfdGFyZ2V0LCBwcm9wLCByZWNlaXZlcikge1xuXHRpZiAocHJvcCA9PT0gXCJ2YWx1ZVwiKSByZXR1cm4gdGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9BUFBfUkVDT1JEU19fO1xuXHRyZXR1cm4gdGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9BUFBfUkVDT1JEU19fW3Byb3BdO1xufSB9KTtcbmNvbnN0IGFkZERldlRvb2xzQXBwUmVjb3JkID0gKGFwcCkgPT4ge1xuXHR0YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX0FQUF9SRUNPUkRTX18gPSBbLi4udGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9BUFBfUkVDT1JEU19fLCBhcHBdO1xufTtcbmNvbnN0IHJlbW92ZURldlRvb2xzQXBwUmVjb3JkID0gKGFwcCkgPT4ge1xuXHR0YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX0FQUF9SRUNPUkRTX18gPSBkZXZ0b29sc0FwcFJlY29yZHMudmFsdWUuZmlsdGVyKChyZWNvcmQpID0+IHJlY29yZC5hcHAgIT09IGFwcCk7XG59O1xuY29uc3QgYWN0aXZlQXBwUmVjb3JkID0gbmV3IFByb3h5KHRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfQUNUSVZFX0FQUF9SRUNPUkRfXywgeyBnZXQoX3RhcmdldCwgcHJvcCwgcmVjZWl2ZXIpIHtcblx0aWYgKHByb3AgPT09IFwidmFsdWVcIikgcmV0dXJuIHRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfQUNUSVZFX0FQUF9SRUNPUkRfXztcblx0ZWxzZSBpZiAocHJvcCA9PT0gXCJpZFwiKSByZXR1cm4gdGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9BQ1RJVkVfQVBQX1JFQ09SRF9JRF9fO1xuXHRyZXR1cm4gdGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9BQ1RJVkVfQVBQX1JFQ09SRF9fW3Byb3BdO1xufSB9KTtcbmZ1bmN0aW9uIHVwZGF0ZUFsbFN0YXRlcygpIHtcblx0Y2FsbFN0YXRlVXBkYXRlZEhvb2soe1xuXHRcdC4uLnRhcmdldFtTVEFURV9LRVldLFxuXHRcdGFwcFJlY29yZHM6IGRldnRvb2xzQXBwUmVjb3Jkcy52YWx1ZSxcblx0XHRhY3RpdmVBcHBSZWNvcmRJZDogYWN0aXZlQXBwUmVjb3JkLmlkLFxuXHRcdHRhYnM6IHRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfQ1VTVE9NX1RBQlNfXyxcblx0XHRjb21tYW5kczogdGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9DVVNUT01fQ09NTUFORFNfX1xuXHR9KTtcbn1cbmZ1bmN0aW9uIHNldEFjdGl2ZUFwcFJlY29yZChhcHApIHtcblx0dGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9BQ1RJVkVfQVBQX1JFQ09SRF9fID0gYXBwO1xuXHR1cGRhdGVBbGxTdGF0ZXMoKTtcbn1cbmZ1bmN0aW9uIHNldEFjdGl2ZUFwcFJlY29yZElkKGlkKSB7XG5cdHRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfQUNUSVZFX0FQUF9SRUNPUkRfSURfXyA9IGlkO1xuXHR1cGRhdGVBbGxTdGF0ZXMoKTtcbn1cbmNvbnN0IGRldnRvb2xzU3RhdGUgPSBuZXcgUHJveHkodGFyZ2V0W1NUQVRFX0tFWV0sIHtcblx0Z2V0KHRhcmdldCQzLCBwcm9wZXJ0eSkge1xuXHRcdGlmIChwcm9wZXJ0eSA9PT0gXCJhcHBSZWNvcmRzXCIpIHJldHVybiBkZXZ0b29sc0FwcFJlY29yZHM7XG5cdFx0ZWxzZSBpZiAocHJvcGVydHkgPT09IFwiYWN0aXZlQXBwUmVjb3JkSWRcIikgcmV0dXJuIGFjdGl2ZUFwcFJlY29yZC5pZDtcblx0XHRlbHNlIGlmIChwcm9wZXJ0eSA9PT0gXCJ0YWJzXCIpIHJldHVybiB0YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX0NVU1RPTV9UQUJTX187XG5cdFx0ZWxzZSBpZiAocHJvcGVydHkgPT09IFwiY29tbWFuZHNcIikgcmV0dXJuIHRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfQ1VTVE9NX0NPTU1BTkRTX187XG5cdFx0cmV0dXJuIHRhcmdldFtTVEFURV9LRVldW3Byb3BlcnR5XTtcblx0fSxcblx0ZGVsZXRlUHJvcGVydHkodGFyZ2V0LCBwcm9wZXJ0eSkge1xuXHRcdGRlbGV0ZSB0YXJnZXRbcHJvcGVydHldO1xuXHRcdHJldHVybiB0cnVlO1xuXHR9LFxuXHRzZXQodGFyZ2V0JDQsIHByb3BlcnR5LCB2YWx1ZSkge1xuXHRcdHRhcmdldCQ0W3Byb3BlcnR5XSA9IHZhbHVlO1xuXHRcdHRhcmdldFtTVEFURV9LRVldW3Byb3BlcnR5XSA9IHZhbHVlO1xuXHRcdHJldHVybiB0cnVlO1xuXHR9XG59KTtcbmZ1bmN0aW9uIHJlc2V0RGV2VG9vbHNTdGF0ZSgpIHtcblx0T2JqZWN0LmFzc2lnbih0YXJnZXRbU1RBVEVfS0VZXSwgaW5pdFN0YXRlRmFjdG9yeSgpKTtcbn1cbmZ1bmN0aW9uIHVwZGF0ZURldlRvb2xzU3RhdGUoc3RhdGUpIHtcblx0Y29uc3Qgb2xkU3RhdGUgPSB7XG5cdFx0Li4udGFyZ2V0W1NUQVRFX0tFWV0sXG5cdFx0YXBwUmVjb3JkczogZGV2dG9vbHNBcHBSZWNvcmRzLnZhbHVlLFxuXHRcdGFjdGl2ZUFwcFJlY29yZElkOiBhY3RpdmVBcHBSZWNvcmQuaWRcblx0fTtcblx0aWYgKG9sZFN0YXRlLmNvbm5lY3RlZCAhPT0gc3RhdGUuY29ubmVjdGVkICYmIHN0YXRlLmNvbm5lY3RlZCB8fCBvbGRTdGF0ZS5jbGllbnRDb25uZWN0ZWQgIT09IHN0YXRlLmNsaWVudENvbm5lY3RlZCAmJiBzdGF0ZS5jbGllbnRDb25uZWN0ZWQpIGNhbGxDb25uZWN0ZWRVcGRhdGVkSG9vayh0YXJnZXRbU1RBVEVfS0VZXSwgb2xkU3RhdGUpO1xuXHRPYmplY3QuYXNzaWduKHRhcmdldFtTVEFURV9LRVldLCBzdGF0ZSk7XG5cdHVwZGF0ZUFsbFN0YXRlcygpO1xufVxuZnVuY3Rpb24gb25EZXZUb29sc0Nvbm5lY3RlZChmbikge1xuXHRyZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcblx0XHRpZiAoZGV2dG9vbHNTdGF0ZS5jb25uZWN0ZWQpIHtcblx0XHRcdGZuKCk7XG5cdFx0XHRyZXNvbHZlKCk7XG5cdFx0fVxuXHRcdGRldnRvb2xzQ29udGV4dC5ob29rcy5ob29rKERldlRvb2xzTWVzc2FnaW5nSG9va0tleXMuREVWVE9PTFNfQ09OTkVDVEVEX1VQREFURUQsICh7IHN0YXRlIH0pID0+IHtcblx0XHRcdGlmIChzdGF0ZS5jb25uZWN0ZWQpIHtcblx0XHRcdFx0Zm4oKTtcblx0XHRcdFx0cmVzb2x2ZSgpO1xuXHRcdFx0fVxuXHRcdH0pO1xuXHR9KTtcbn1cbmNvbnN0IHJlc29sdmVJY29uID0gKGljb24pID0+IHtcblx0aWYgKCFpY29uKSByZXR1cm47XG5cdGlmIChpY29uLnN0YXJ0c1dpdGgoXCJiYXNlbGluZS1cIikpIHJldHVybiBgY3VzdG9tLWljLSR7aWNvbn1gO1xuXHRpZiAoaWNvbi5zdGFydHNXaXRoKFwiaS1cIikgfHwgaXNVcmxTdHJpbmcoaWNvbikpIHJldHVybiBpY29uO1xuXHRyZXR1cm4gYGN1c3RvbS1pYy1iYXNlbGluZS0ke2ljb259YDtcbn07XG5mdW5jdGlvbiBhZGRDdXN0b21UYWIodGFiKSB7XG5cdGNvbnN0IHRhYnMgPSB0YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX0NVU1RPTV9UQUJTX187XG5cdGlmICh0YWJzLnNvbWUoKHQpID0+IHQubmFtZSA9PT0gdGFiLm5hbWUpKSByZXR1cm47XG5cdHRhYnMucHVzaCh7XG5cdFx0Li4udGFiLFxuXHRcdGljb246IHJlc29sdmVJY29uKHRhYi5pY29uKVxuXHR9KTtcblx0dXBkYXRlQWxsU3RhdGVzKCk7XG59XG5mdW5jdGlvbiBhZGRDdXN0b21Db21tYW5kKGFjdGlvbikge1xuXHRjb25zdCBjb21tYW5kcyA9IHRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfQ1VTVE9NX0NPTU1BTkRTX187XG5cdGlmIChjb21tYW5kcy5zb21lKCh0KSA9PiB0LmlkID09PSBhY3Rpb24uaWQpKSByZXR1cm47XG5cdGNvbW1hbmRzLnB1c2goe1xuXHRcdC4uLmFjdGlvbixcblx0XHRpY29uOiByZXNvbHZlSWNvbihhY3Rpb24uaWNvbiksXG5cdFx0Y2hpbGRyZW46IGFjdGlvbi5jaGlsZHJlbiA/IGFjdGlvbi5jaGlsZHJlbi5tYXAoKGNoaWxkKSA9PiAoe1xuXHRcdFx0Li4uY2hpbGQsXG5cdFx0XHRpY29uOiByZXNvbHZlSWNvbihjaGlsZC5pY29uKVxuXHRcdH0pKSA6IHZvaWQgMFxuXHR9KTtcblx0dXBkYXRlQWxsU3RhdGVzKCk7XG59XG5mdW5jdGlvbiByZW1vdmVDdXN0b21Db21tYW5kKGFjdGlvbklkKSB7XG5cdGNvbnN0IGNvbW1hbmRzID0gdGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9DVVNUT01fQ09NTUFORFNfXztcblx0Y29uc3QgaW5kZXggPSBjb21tYW5kcy5maW5kSW5kZXgoKHQpID0+IHQuaWQgPT09IGFjdGlvbklkKTtcblx0aWYgKGluZGV4ID09PSAtMSkgcmV0dXJuO1xuXHRjb21tYW5kcy5zcGxpY2UoaW5kZXgsIDEpO1xuXHR1cGRhdGVBbGxTdGF0ZXMoKTtcbn1cbmZ1bmN0aW9uIHRvZ2dsZUNsaWVudENvbm5lY3RlZChzdGF0ZSkge1xuXHR1cGRhdGVEZXZUb29sc1N0YXRlKHsgY2xpZW50Q29ubmVjdGVkOiBzdGF0ZSB9KTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL29wZW4taW4tZWRpdG9yL2luZGV4LnRzXG5mdW5jdGlvbiBzZXRPcGVuSW5FZGl0b3JCYXNlVXJsKHVybCkge1xuXHR0YXJnZXQuX19WVUVfREVWVE9PTFNfT1BFTl9JTl9FRElUT1JfQkFTRV9VUkxfXyA9IHVybDtcbn1cbmZ1bmN0aW9uIG9wZW5JbkVkaXRvcihvcHRpb25zID0ge30pIHtcblx0Y29uc3QgeyBmaWxlLCBob3N0LCBiYXNlVXJsID0gd2luZG93LmxvY2F0aW9uLm9yaWdpbiwgbGluZSA9IDAsIGNvbHVtbiA9IDAgfSA9IG9wdGlvbnM7XG5cdGlmIChmaWxlKSB7XG5cdFx0aWYgKGhvc3QgPT09IFwiY2hyb21lLWV4dGVuc2lvblwiKSB7XG5cdFx0XHRjb25zdCBmaWxlTmFtZSA9IGZpbGUucmVwbGFjZSgvXFxcXC9nLCBcIlxcXFxcXFxcXCIpO1xuXHRcdFx0Y29uc3QgX2Jhc2VVcmwgPSB3aW5kb3cuVlVFX0RFVlRPT0xTX0NPTkZJRz8ub3BlbkluRWRpdG9ySG9zdCA/PyBcIi9cIjtcblx0XHRcdGZldGNoKGAke19iYXNlVXJsfV9fb3Blbi1pbi1lZGl0b3I/ZmlsZT0ke2VuY29kZVVSSShmaWxlKX1gKS50aGVuKChyZXNwb25zZSkgPT4ge1xuXHRcdFx0XHRpZiAoIXJlc3BvbnNlLm9rKSB7XG5cdFx0XHRcdFx0Y29uc3QgbXNnID0gYE9wZW5pbmcgY29tcG9uZW50ICR7ZmlsZU5hbWV9IGZhaWxlZGA7XG5cdFx0XHRcdFx0Y29uc29sZS5sb2coYCVjJHttc2d9YCwgXCJjb2xvcjpyZWRcIik7XG5cdFx0XHRcdH1cblx0XHRcdH0pO1xuXHRcdH0gZWxzZSBpZiAoZGV2dG9vbHNTdGF0ZS52aXRlUGx1Z2luRGV0ZWN0ZWQpIHtcblx0XHRcdGNvbnN0IF9iYXNlVXJsID0gdGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX09QRU5fSU5fRURJVE9SX0JBU0VfVVJMX18gPz8gYmFzZVVybDtcblx0XHRcdHRhcmdldC5fX1ZVRV9JTlNQRUNUT1JfXy5vcGVuSW5FZGl0b3IoX2Jhc2VVcmwsIGZpbGUsIGxpbmUsIGNvbHVtbik7XG5cdFx0fVxuXHR9XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY3R4L3BsdWdpbi50c1xudGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9QTFVHSU5fQlVGRkVSX18gPz89IFtdO1xuY29uc3QgZGV2dG9vbHNQbHVnaW5CdWZmZXIgPSBuZXcgUHJveHkodGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9QTFVHSU5fQlVGRkVSX18sIHsgZ2V0KHRhcmdldCwgcHJvcCwgcmVjZWl2ZXIpIHtcblx0cmV0dXJuIFJlZmxlY3QuZ2V0KHRhcmdldCwgcHJvcCwgcmVjZWl2ZXIpO1xufSB9KTtcbmZ1bmN0aW9uIGFkZERldlRvb2xzUGx1Z2luVG9CdWZmZXIocGx1Z2luRGVzY3JpcHRvciwgc2V0dXBGbikge1xuXHRkZXZ0b29sc1BsdWdpbkJ1ZmZlci5wdXNoKFtwbHVnaW5EZXNjcmlwdG9yLCBzZXR1cEZuXSk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9wbHVnaW4vcGx1Z2luLXNldHRpbmdzLnRzXG5mdW5jdGlvbiBfZ2V0U2V0dGluZ3Moc2V0dGluZ3MpIHtcblx0Y29uc3QgX3NldHRpbmdzID0ge307XG5cdE9iamVjdC5rZXlzKHNldHRpbmdzKS5mb3JFYWNoKChrZXkpID0+IHtcblx0XHRfc2V0dGluZ3Nba2V5XSA9IHNldHRpbmdzW2tleV0uZGVmYXVsdFZhbHVlO1xuXHR9KTtcblx0cmV0dXJuIF9zZXR0aW5ncztcbn1cbmZ1bmN0aW9uIGdldFBsdWdpbkxvY2FsS2V5KHBsdWdpbklkKSB7XG5cdHJldHVybiBgX19WVUVfREVWVE9PTFNfTkVYVF9QTFVHSU5fU0VUVElOR1NfXyR7cGx1Z2luSWR9X19gO1xufVxuZnVuY3Rpb24gZ2V0UGx1Z2luU2V0dGluZ3NPcHRpb25zKHBsdWdpbklkKSB7XG5cdHJldHVybiAoZGV2dG9vbHNQbHVnaW5CdWZmZXIuZmluZCgoaXRlbSkgPT4gaXRlbVswXS5pZCA9PT0gcGx1Z2luSWQgJiYgISFpdGVtWzBdPy5zZXR0aW5ncyk/LlswXSA/PyBudWxsKT8uc2V0dGluZ3MgPz8gbnVsbDtcbn1cbmZ1bmN0aW9uIGdldFBsdWdpblNldHRpbmdzKHBsdWdpbklkLCBmYWxsYmFja1ZhbHVlKSB7XG5cdGNvbnN0IGxvY2FsS2V5ID0gZ2V0UGx1Z2luTG9jYWxLZXkocGx1Z2luSWQpO1xuXHRpZiAobG9jYWxLZXkpIHtcblx0XHRjb25zdCBsb2NhbFNldHRpbmdzID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0obG9jYWxLZXkpO1xuXHRcdGlmIChsb2NhbFNldHRpbmdzKSByZXR1cm4gSlNPTi5wYXJzZShsb2NhbFNldHRpbmdzKTtcblx0fVxuXHRpZiAocGx1Z2luSWQpIHJldHVybiBfZ2V0U2V0dGluZ3MoKGRldnRvb2xzUGx1Z2luQnVmZmVyLmZpbmQoKGl0ZW0pID0+IGl0ZW1bMF0uaWQgPT09IHBsdWdpbklkKT8uWzBdID8/IG51bGwpPy5zZXR0aW5ncyA/PyB7fSk7XG5cdHJldHVybiBfZ2V0U2V0dGluZ3MoZmFsbGJhY2tWYWx1ZSk7XG59XG5mdW5jdGlvbiBpbml0UGx1Z2luU2V0dGluZ3MocGx1Z2luSWQsIHNldHRpbmdzKSB7XG5cdGNvbnN0IGxvY2FsS2V5ID0gZ2V0UGx1Z2luTG9jYWxLZXkocGx1Z2luSWQpO1xuXHRpZiAoIWxvY2FsU3RvcmFnZS5nZXRJdGVtKGxvY2FsS2V5KSkgbG9jYWxTdG9yYWdlLnNldEl0ZW0obG9jYWxLZXksIEpTT04uc3RyaW5naWZ5KF9nZXRTZXR0aW5ncyhzZXR0aW5ncykpKTtcbn1cbmZ1bmN0aW9uIHNldFBsdWdpblNldHRpbmdzKHBsdWdpbklkLCBrZXksIHZhbHVlKSB7XG5cdGNvbnN0IGxvY2FsS2V5ID0gZ2V0UGx1Z2luTG9jYWxLZXkocGx1Z2luSWQpO1xuXHRjb25zdCBsb2NhbFNldHRpbmdzID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0obG9jYWxLZXkpO1xuXHRjb25zdCBwYXJzZWRMb2NhbFNldHRpbmdzID0gSlNPTi5wYXJzZShsb2NhbFNldHRpbmdzIHx8IFwie31cIik7XG5cdGNvbnN0IHVwZGF0ZWQgPSB7XG5cdFx0Li4ucGFyc2VkTG9jYWxTZXR0aW5ncyxcblx0XHRba2V5XTogdmFsdWVcblx0fTtcblx0bG9jYWxTdG9yYWdlLnNldEl0ZW0obG9jYWxLZXksIEpTT04uc3RyaW5naWZ5KHVwZGF0ZWQpKTtcblx0ZGV2dG9vbHNDb250ZXh0Lmhvb2tzLmNhbGxIb29rV2l0aCgoY2FsbGJhY2tzKSA9PiB7XG5cdFx0Y2FsbGJhY2tzLmZvckVhY2goKGNiKSA9PiBjYih7XG5cdFx0XHRwbHVnaW5JZCxcblx0XHRcdGtleSxcblx0XHRcdG9sZFZhbHVlOiBwYXJzZWRMb2NhbFNldHRpbmdzW2tleV0sXG5cdFx0XHRuZXdWYWx1ZTogdmFsdWUsXG5cdFx0XHRzZXR0aW5nczogdXBkYXRlZFxuXHRcdH0pKTtcblx0fSwgRGV2VG9vbHNWNlBsdWdpbkFQSUhvb2tLZXlzLlNFVF9QTFVHSU5fU0VUVElOR1MpO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3R5cGVzL2hvb2sudHNcbmxldCBEZXZUb29sc0hvb2tzID0gLyogQF9fUFVSRV9fICovIGZ1bmN0aW9uKERldlRvb2xzSG9va3MpIHtcblx0RGV2VG9vbHNIb29rc1tcIkFQUF9JTklUXCJdID0gXCJhcHA6aW5pdFwiO1xuXHREZXZUb29sc0hvb2tzW1wiQVBQX1VOTU9VTlRcIl0gPSBcImFwcDp1bm1vdW50XCI7XG5cdERldlRvb2xzSG9va3NbXCJDT01QT05FTlRfVVBEQVRFRFwiXSA9IFwiY29tcG9uZW50OnVwZGF0ZWRcIjtcblx0RGV2VG9vbHNIb29rc1tcIkNPTVBPTkVOVF9BRERFRFwiXSA9IFwiY29tcG9uZW50OmFkZGVkXCI7XG5cdERldlRvb2xzSG9va3NbXCJDT01QT05FTlRfUkVNT1ZFRFwiXSA9IFwiY29tcG9uZW50OnJlbW92ZWRcIjtcblx0RGV2VG9vbHNIb29rc1tcIkNPTVBPTkVOVF9FTUlUXCJdID0gXCJjb21wb25lbnQ6ZW1pdFwiO1xuXHREZXZUb29sc0hvb2tzW1wiUEVSRk9STUFOQ0VfU1RBUlRcIl0gPSBcInBlcmY6c3RhcnRcIjtcblx0RGV2VG9vbHNIb29rc1tcIlBFUkZPUk1BTkNFX0VORFwiXSA9IFwicGVyZjplbmRcIjtcblx0RGV2VG9vbHNIb29rc1tcIkFERF9ST1VURVwiXSA9IFwicm91dGVyOmFkZC1yb3V0ZVwiO1xuXHREZXZUb29sc0hvb2tzW1wiUkVNT1ZFX1JPVVRFXCJdID0gXCJyb3V0ZXI6cmVtb3ZlLXJvdXRlXCI7XG5cdERldlRvb2xzSG9va3NbXCJSRU5ERVJfVFJBQ0tFRFwiXSA9IFwicmVuZGVyOnRyYWNrZWRcIjtcblx0RGV2VG9vbHNIb29rc1tcIlJFTkRFUl9UUklHR0VSRURcIl0gPSBcInJlbmRlcjp0cmlnZ2VyZWRcIjtcblx0RGV2VG9vbHNIb29rc1tcIkFQUF9DT05ORUNURURcIl0gPSBcImFwcDpjb25uZWN0ZWRcIjtcblx0RGV2VG9vbHNIb29rc1tcIlNFVFVQX0RFVlRPT0xTX1BMVUdJTlwiXSA9IFwiZGV2dG9vbHMtcGx1Z2luOnNldHVwXCI7XG5cdHJldHVybiBEZXZUb29sc0hvb2tzO1xufSh7fSk7XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvaG9vay9pbmRleC50c1xuY29uc3QgZGV2dG9vbHNIb29rcyA9IHRhcmdldC5fX1ZVRV9ERVZUT09MU19IT09LID8/PSBjcmVhdGVIb29rcygpO1xuY29uc3Qgb24gPSB7XG5cdHZ1ZUFwcEluaXQoZm4pIHtcblx0XHRkZXZ0b29sc0hvb2tzLmhvb2soRGV2VG9vbHNIb29rcy5BUFBfSU5JVCwgZm4pO1xuXHR9LFxuXHR2dWVBcHBVbm1vdW50KGZuKSB7XG5cdFx0ZGV2dG9vbHNIb29rcy5ob29rKERldlRvb2xzSG9va3MuQVBQX1VOTU9VTlQsIGZuKTtcblx0fSxcblx0dnVlQXBwQ29ubmVjdGVkKGZuKSB7XG5cdFx0ZGV2dG9vbHNIb29rcy5ob29rKERldlRvb2xzSG9va3MuQVBQX0NPTk5FQ1RFRCwgZm4pO1xuXHR9LFxuXHRjb21wb25lbnRBZGRlZChmbikge1xuXHRcdHJldHVybiBkZXZ0b29sc0hvb2tzLmhvb2soRGV2VG9vbHNIb29rcy5DT01QT05FTlRfQURERUQsIGZuKTtcblx0fSxcblx0Y29tcG9uZW50RW1pdChmbikge1xuXHRcdHJldHVybiBkZXZ0b29sc0hvb2tzLmhvb2soRGV2VG9vbHNIb29rcy5DT01QT05FTlRfRU1JVCwgZm4pO1xuXHR9LFxuXHRjb21wb25lbnRVcGRhdGVkKGZuKSB7XG5cdFx0cmV0dXJuIGRldnRvb2xzSG9va3MuaG9vayhEZXZUb29sc0hvb2tzLkNPTVBPTkVOVF9VUERBVEVELCBmbik7XG5cdH0sXG5cdGNvbXBvbmVudFJlbW92ZWQoZm4pIHtcblx0XHRyZXR1cm4gZGV2dG9vbHNIb29rcy5ob29rKERldlRvb2xzSG9va3MuQ09NUE9ORU5UX1JFTU9WRUQsIGZuKTtcblx0fSxcblx0c2V0dXBEZXZ0b29sc1BsdWdpbihmbikge1xuXHRcdGRldnRvb2xzSG9va3MuaG9vayhEZXZUb29sc0hvb2tzLlNFVFVQX0RFVlRPT0xTX1BMVUdJTiwgZm4pO1xuXHR9LFxuXHRwZXJmU3RhcnQoZm4pIHtcblx0XHRyZXR1cm4gZGV2dG9vbHNIb29rcy5ob29rKERldlRvb2xzSG9va3MuUEVSRk9STUFOQ0VfU1RBUlQsIGZuKTtcblx0fSxcblx0cGVyZkVuZChmbikge1xuXHRcdHJldHVybiBkZXZ0b29sc0hvb2tzLmhvb2soRGV2VG9vbHNIb29rcy5QRVJGT1JNQU5DRV9FTkQsIGZuKTtcblx0fVxufTtcbmZ1bmN0aW9uIGNyZWF0ZURldlRvb2xzSG9vaygpIHtcblx0cmV0dXJuIHtcblx0XHRpZDogXCJ2dWUtZGV2dG9vbHMtbmV4dFwiLFxuXHRcdGRldnRvb2xzVmVyc2lvbjogXCI3LjBcIixcblx0XHRlbmFibGVkOiBmYWxzZSxcblx0XHRhcHBSZWNvcmRzOiBbXSxcblx0XHRhcHBzOiBbXSxcblx0XHRldmVudHM6IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCksXG5cdFx0b24oZXZlbnQsIGZuKSB7XG5cdFx0XHRpZiAoIXRoaXMuZXZlbnRzLmhhcyhldmVudCkpIHRoaXMuZXZlbnRzLnNldChldmVudCwgW10pO1xuXHRcdFx0dGhpcy5ldmVudHMuZ2V0KGV2ZW50KT8ucHVzaChmbik7XG5cdFx0XHRyZXR1cm4gKCkgPT4gdGhpcy5vZmYoZXZlbnQsIGZuKTtcblx0XHR9LFxuXHRcdG9uY2UoZXZlbnQsIGZuKSB7XG5cdFx0XHRjb25zdCBvbmNlRm4gPSAoLi4uYXJncykgPT4ge1xuXHRcdFx0XHR0aGlzLm9mZihldmVudCwgb25jZUZuKTtcblx0XHRcdFx0Zm4oLi4uYXJncyk7XG5cdFx0XHR9O1xuXHRcdFx0dGhpcy5vbihldmVudCwgb25jZUZuKTtcblx0XHRcdHJldHVybiBbZXZlbnQsIG9uY2VGbl07XG5cdFx0fSxcblx0XHRvZmYoZXZlbnQsIGZuKSB7XG5cdFx0XHRpZiAodGhpcy5ldmVudHMuaGFzKGV2ZW50KSkge1xuXHRcdFx0XHRjb25zdCBldmVudENhbGxiYWNrcyA9IHRoaXMuZXZlbnRzLmdldChldmVudCk7XG5cdFx0XHRcdGNvbnN0IGluZGV4ID0gZXZlbnRDYWxsYmFja3MuaW5kZXhPZihmbik7XG5cdFx0XHRcdGlmIChpbmRleCAhPT0gLTEpIGV2ZW50Q2FsbGJhY2tzLnNwbGljZShpbmRleCwgMSk7XG5cdFx0XHR9XG5cdFx0fSxcblx0XHRlbWl0KGV2ZW50LCAuLi5wYXlsb2FkKSB7XG5cdFx0XHRpZiAodGhpcy5ldmVudHMuaGFzKGV2ZW50KSkgdGhpcy5ldmVudHMuZ2V0KGV2ZW50KS5mb3JFYWNoKChmbikgPT4gZm4oLi4ucGF5bG9hZCkpO1xuXHRcdH1cblx0fTtcbn1cbmZ1bmN0aW9uIHN1YnNjcmliZURldlRvb2xzSG9vayhob29rKSB7XG5cdGhvb2sub24oRGV2VG9vbHNIb29rcy5BUFBfSU5JVCwgKGFwcCwgdmVyc2lvbiwgdHlwZXMpID0+IHtcblx0XHRpZiAoYXBwPy5faW5zdGFuY2U/LnR5cGU/LmRldnRvb2xzPy5oaWRlKSByZXR1cm47XG5cdFx0ZGV2dG9vbHNIb29rcy5jYWxsSG9vayhEZXZUb29sc0hvb2tzLkFQUF9JTklULCBhcHAsIHZlcnNpb24sIHR5cGVzKTtcblx0fSk7XG5cdGhvb2sub24oRGV2VG9vbHNIb29rcy5BUFBfVU5NT1VOVCwgKGFwcCkgPT4ge1xuXHRcdGRldnRvb2xzSG9va3MuY2FsbEhvb2soRGV2VG9vbHNIb29rcy5BUFBfVU5NT1VOVCwgYXBwKTtcblx0fSk7XG5cdGhvb2sub24oRGV2VG9vbHNIb29rcy5DT01QT05FTlRfQURERUQsIGFzeW5jIChhcHAsIHVpZCwgcGFyZW50VWlkLCBjb21wb25lbnQpID0+IHtcblx0XHRpZiAoYXBwPy5faW5zdGFuY2U/LnR5cGU/LmRldnRvb2xzPy5oaWRlIHx8IGRldnRvb2xzU3RhdGUuaGlnaFBlcmZNb2RlRW5hYmxlZCkgcmV0dXJuO1xuXHRcdGlmICghYXBwIHx8IHR5cGVvZiB1aWQgIT09IFwibnVtYmVyXCIgJiYgIXVpZCB8fCAhY29tcG9uZW50KSByZXR1cm47XG5cdFx0ZGV2dG9vbHNIb29rcy5jYWxsSG9vayhEZXZUb29sc0hvb2tzLkNPTVBPTkVOVF9BRERFRCwgYXBwLCB1aWQsIHBhcmVudFVpZCwgY29tcG9uZW50KTtcblx0fSk7XG5cdGhvb2sub24oRGV2VG9vbHNIb29rcy5DT01QT05FTlRfVVBEQVRFRCwgKGFwcCwgdWlkLCBwYXJlbnRVaWQsIGNvbXBvbmVudCkgPT4ge1xuXHRcdGlmICghYXBwIHx8IHR5cGVvZiB1aWQgIT09IFwibnVtYmVyXCIgJiYgIXVpZCB8fCAhY29tcG9uZW50IHx8IGRldnRvb2xzU3RhdGUuaGlnaFBlcmZNb2RlRW5hYmxlZCkgcmV0dXJuO1xuXHRcdGRldnRvb2xzSG9va3MuY2FsbEhvb2soRGV2VG9vbHNIb29rcy5DT01QT05FTlRfVVBEQVRFRCwgYXBwLCB1aWQsIHBhcmVudFVpZCwgY29tcG9uZW50KTtcblx0fSk7XG5cdGhvb2sub24oRGV2VG9vbHNIb29rcy5DT01QT05FTlRfUkVNT1ZFRCwgYXN5bmMgKGFwcCwgdWlkLCBwYXJlbnRVaWQsIGNvbXBvbmVudCkgPT4ge1xuXHRcdGlmICghYXBwIHx8IHR5cGVvZiB1aWQgIT09IFwibnVtYmVyXCIgJiYgIXVpZCB8fCAhY29tcG9uZW50IHx8IGRldnRvb2xzU3RhdGUuaGlnaFBlcmZNb2RlRW5hYmxlZCkgcmV0dXJuO1xuXHRcdGRldnRvb2xzSG9va3MuY2FsbEhvb2soRGV2VG9vbHNIb29rcy5DT01QT05FTlRfUkVNT1ZFRCwgYXBwLCB1aWQsIHBhcmVudFVpZCwgY29tcG9uZW50KTtcblx0fSk7XG5cdGhvb2sub24oRGV2VG9vbHNIb29rcy5DT01QT05FTlRfRU1JVCwgYXN5bmMgKGFwcCwgaW5zdGFuY2UsIGV2ZW50LCBwYXJhbXMpID0+IHtcblx0XHRpZiAoIWFwcCB8fCAhaW5zdGFuY2UgfHwgZGV2dG9vbHNTdGF0ZS5oaWdoUGVyZk1vZGVFbmFibGVkKSByZXR1cm47XG5cdFx0ZGV2dG9vbHNIb29rcy5jYWxsSG9vayhEZXZUb29sc0hvb2tzLkNPTVBPTkVOVF9FTUlULCBhcHAsIGluc3RhbmNlLCBldmVudCwgcGFyYW1zKTtcblx0fSk7XG5cdGhvb2sub24oRGV2VG9vbHNIb29rcy5QRVJGT1JNQU5DRV9TVEFSVCwgKGFwcCwgdWlkLCB2bSwgdHlwZSwgdGltZSkgPT4ge1xuXHRcdGlmICghYXBwIHx8IGRldnRvb2xzU3RhdGUuaGlnaFBlcmZNb2RlRW5hYmxlZCkgcmV0dXJuO1xuXHRcdGRldnRvb2xzSG9va3MuY2FsbEhvb2soRGV2VG9vbHNIb29rcy5QRVJGT1JNQU5DRV9TVEFSVCwgYXBwLCB1aWQsIHZtLCB0eXBlLCB0aW1lKTtcblx0fSk7XG5cdGhvb2sub24oRGV2VG9vbHNIb29rcy5QRVJGT1JNQU5DRV9FTkQsIChhcHAsIHVpZCwgdm0sIHR5cGUsIHRpbWUpID0+IHtcblx0XHRpZiAoIWFwcCB8fCBkZXZ0b29sc1N0YXRlLmhpZ2hQZXJmTW9kZUVuYWJsZWQpIHJldHVybjtcblx0XHRkZXZ0b29sc0hvb2tzLmNhbGxIb29rKERldlRvb2xzSG9va3MuUEVSRk9STUFOQ0VfRU5ELCBhcHAsIHVpZCwgdm0sIHR5cGUsIHRpbWUpO1xuXHR9KTtcblx0aG9vay5vbihEZXZUb29sc0hvb2tzLlNFVFVQX0RFVlRPT0xTX1BMVUdJTiwgKHBsdWdpbkRlc2NyaXB0b3IsIHNldHVwRm4sIG9wdGlvbnMpID0+IHtcblx0XHRpZiAob3B0aW9ucz8udGFyZ2V0ID09PSBcImxlZ2FjeVwiKSByZXR1cm47XG5cdFx0ZGV2dG9vbHNIb29rcy5jYWxsSG9vayhEZXZUb29sc0hvb2tzLlNFVFVQX0RFVlRPT0xTX1BMVUdJTiwgcGx1Z2luRGVzY3JpcHRvciwgc2V0dXBGbik7XG5cdH0pO1xufVxuY29uc3QgaG9vayA9IHtcblx0b24sXG5cdHNldHVwRGV2VG9vbHNQbHVnaW4ocGx1Z2luRGVzY3JpcHRvciwgc2V0dXBGbikge1xuXHRcdHJldHVybiBkZXZ0b29sc0hvb2tzLmNhbGxIb29rKERldlRvb2xzSG9va3MuU0VUVVBfREVWVE9PTFNfUExVR0lOLCBwbHVnaW5EZXNjcmlwdG9yLCBzZXR1cEZuKTtcblx0fVxufTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hcGkvdjYvaW5kZXgudHNcbnZhciBEZXZUb29sc1Y2UGx1Z2luQVBJID0gY2xhc3Mge1xuXHRjb25zdHJ1Y3Rvcih7IHBsdWdpbiwgY3R4IH0pIHtcblx0XHR0aGlzLmhvb2tzID0gY3R4Lmhvb2tzO1xuXHRcdHRoaXMucGx1Z2luID0gcGx1Z2luO1xuXHR9XG5cdGdldCBvbigpIHtcblx0XHRyZXR1cm4ge1xuXHRcdFx0dmlzaXRDb21wb25lbnRUcmVlOiAoaGFuZGxlcikgPT4ge1xuXHRcdFx0XHR0aGlzLmhvb2tzLmhvb2soRGV2VG9vbHNWNlBsdWdpbkFQSUhvb2tLZXlzLlZJU0lUX0NPTVBPTkVOVF9UUkVFLCBoYW5kbGVyKTtcblx0XHRcdH0sXG5cdFx0XHRpbnNwZWN0Q29tcG9uZW50OiAoaGFuZGxlcikgPT4ge1xuXHRcdFx0XHR0aGlzLmhvb2tzLmhvb2soRGV2VG9vbHNWNlBsdWdpbkFQSUhvb2tLZXlzLklOU1BFQ1RfQ09NUE9ORU5ULCBoYW5kbGVyKTtcblx0XHRcdH0sXG5cdFx0XHRlZGl0Q29tcG9uZW50U3RhdGU6IChoYW5kbGVyKSA9PiB7XG5cdFx0XHRcdHRoaXMuaG9va3MuaG9vayhEZXZUb29sc1Y2UGx1Z2luQVBJSG9va0tleXMuRURJVF9DT01QT05FTlRfU1RBVEUsIGhhbmRsZXIpO1xuXHRcdFx0fSxcblx0XHRcdGdldEluc3BlY3RvclRyZWU6IChoYW5kbGVyKSA9PiB7XG5cdFx0XHRcdHRoaXMuaG9va3MuaG9vayhEZXZUb29sc1Y2UGx1Z2luQVBJSG9va0tleXMuR0VUX0lOU1BFQ1RPUl9UUkVFLCBoYW5kbGVyKTtcblx0XHRcdH0sXG5cdFx0XHRnZXRJbnNwZWN0b3JTdGF0ZTogKGhhbmRsZXIpID0+IHtcblx0XHRcdFx0dGhpcy5ob29rcy5ob29rKERldlRvb2xzVjZQbHVnaW5BUElIb29rS2V5cy5HRVRfSU5TUEVDVE9SX1NUQVRFLCBoYW5kbGVyKTtcblx0XHRcdH0sXG5cdFx0XHRlZGl0SW5zcGVjdG9yU3RhdGU6IChoYW5kbGVyKSA9PiB7XG5cdFx0XHRcdHRoaXMuaG9va3MuaG9vayhEZXZUb29sc1Y2UGx1Z2luQVBJSG9va0tleXMuRURJVF9JTlNQRUNUT1JfU1RBVEUsIGhhbmRsZXIpO1xuXHRcdFx0fSxcblx0XHRcdGluc3BlY3RUaW1lbGluZUV2ZW50OiAoaGFuZGxlcikgPT4ge1xuXHRcdFx0XHR0aGlzLmhvb2tzLmhvb2soRGV2VG9vbHNWNlBsdWdpbkFQSUhvb2tLZXlzLklOU1BFQ1RfVElNRUxJTkVfRVZFTlQsIGhhbmRsZXIpO1xuXHRcdFx0fSxcblx0XHRcdHRpbWVsaW5lQ2xlYXJlZDogKGhhbmRsZXIpID0+IHtcblx0XHRcdFx0dGhpcy5ob29rcy5ob29rKERldlRvb2xzVjZQbHVnaW5BUElIb29rS2V5cy5USU1FTElORV9DTEVBUkVELCBoYW5kbGVyKTtcblx0XHRcdH0sXG5cdFx0XHRzZXRQbHVnaW5TZXR0aW5nczogKGhhbmRsZXIpID0+IHtcblx0XHRcdFx0dGhpcy5ob29rcy5ob29rKERldlRvb2xzVjZQbHVnaW5BUElIb29rS2V5cy5TRVRfUExVR0lOX1NFVFRJTkdTLCBoYW5kbGVyKTtcblx0XHRcdH1cblx0XHR9O1xuXHR9XG5cdG5vdGlmeUNvbXBvbmVudFVwZGF0ZShpbnN0YW5jZSkge1xuXHRcdGlmIChkZXZ0b29sc1N0YXRlLmhpZ2hQZXJmTW9kZUVuYWJsZWQpIHJldHVybjtcblx0XHRjb25zdCBpbnNwZWN0b3IgPSBnZXRBY3RpdmVJbnNwZWN0b3JzKCkuZmluZCgoaSkgPT4gaS5wYWNrYWdlTmFtZSA9PT0gdGhpcy5wbHVnaW4uZGVzY3JpcHRvci5wYWNrYWdlTmFtZSk7XG5cdFx0aWYgKGluc3BlY3Rvcj8uaWQpIHtcblx0XHRcdGlmIChpbnN0YW5jZSkge1xuXHRcdFx0XHRjb25zdCBhcmdzID0gW1xuXHRcdFx0XHRcdGluc3RhbmNlLmFwcENvbnRleHQuYXBwLFxuXHRcdFx0XHRcdGluc3RhbmNlLnVpZCxcblx0XHRcdFx0XHRpbnN0YW5jZS5wYXJlbnQ/LnVpZCxcblx0XHRcdFx0XHRpbnN0YW5jZVxuXHRcdFx0XHRdO1xuXHRcdFx0XHRkZXZ0b29sc0hvb2tzLmNhbGxIb29rKERldlRvb2xzSG9va3MuQ09NUE9ORU5UX1VQREFURUQsIC4uLmFyZ3MpO1xuXHRcdFx0fSBlbHNlIGRldnRvb2xzSG9va3MuY2FsbEhvb2soRGV2VG9vbHNIb29rcy5DT01QT05FTlRfVVBEQVRFRCk7XG5cdFx0XHR0aGlzLmhvb2tzLmNhbGxIb29rKERldlRvb2xzQ29udGV4dEhvb2tLZXlzLlNFTkRfSU5TUEVDVE9SX1NUQVRFLCB7XG5cdFx0XHRcdGluc3BlY3RvcklkOiBpbnNwZWN0b3IuaWQsXG5cdFx0XHRcdHBsdWdpbjogdGhpcy5wbHVnaW5cblx0XHRcdH0pO1xuXHRcdH1cblx0fVxuXHRhZGRJbnNwZWN0b3Iob3B0aW9ucykge1xuXHRcdHRoaXMuaG9va3MuY2FsbEhvb2soRGV2VG9vbHNDb250ZXh0SG9va0tleXMuQUREX0lOU1BFQ1RPUiwge1xuXHRcdFx0aW5zcGVjdG9yOiBvcHRpb25zLFxuXHRcdFx0cGx1Z2luOiB0aGlzLnBsdWdpblxuXHRcdH0pO1xuXHRcdGlmICh0aGlzLnBsdWdpbi5kZXNjcmlwdG9yLnNldHRpbmdzKSBpbml0UGx1Z2luU2V0dGluZ3Mob3B0aW9ucy5pZCwgdGhpcy5wbHVnaW4uZGVzY3JpcHRvci5zZXR0aW5ncyk7XG5cdH1cblx0c2VuZEluc3BlY3RvclRyZWUoaW5zcGVjdG9ySWQpIHtcblx0XHRpZiAoZGV2dG9vbHNTdGF0ZS5oaWdoUGVyZk1vZGVFbmFibGVkKSByZXR1cm47XG5cdFx0dGhpcy5ob29rcy5jYWxsSG9vayhEZXZUb29sc0NvbnRleHRIb29rS2V5cy5TRU5EX0lOU1BFQ1RPUl9UUkVFLCB7XG5cdFx0XHRpbnNwZWN0b3JJZCxcblx0XHRcdHBsdWdpbjogdGhpcy5wbHVnaW5cblx0XHR9KTtcblx0fVxuXHRzZW5kSW5zcGVjdG9yU3RhdGUoaW5zcGVjdG9ySWQpIHtcblx0XHRpZiAoZGV2dG9vbHNTdGF0ZS5oaWdoUGVyZk1vZGVFbmFibGVkKSByZXR1cm47XG5cdFx0dGhpcy5ob29rcy5jYWxsSG9vayhEZXZUb29sc0NvbnRleHRIb29rS2V5cy5TRU5EX0lOU1BFQ1RPUl9TVEFURSwge1xuXHRcdFx0aW5zcGVjdG9ySWQsXG5cdFx0XHRwbHVnaW46IHRoaXMucGx1Z2luXG5cdFx0fSk7XG5cdH1cblx0c2VsZWN0SW5zcGVjdG9yTm9kZShpbnNwZWN0b3JJZCwgbm9kZUlkKSB7XG5cdFx0dGhpcy5ob29rcy5jYWxsSG9vayhEZXZUb29sc0NvbnRleHRIb29rS2V5cy5DVVNUT01fSU5TUEVDVE9SX1NFTEVDVF9OT0RFLCB7XG5cdFx0XHRpbnNwZWN0b3JJZCxcblx0XHRcdG5vZGVJZCxcblx0XHRcdHBsdWdpbjogdGhpcy5wbHVnaW5cblx0XHR9KTtcblx0fVxuXHR2aXNpdENvbXBvbmVudFRyZWUocGF5bG9hZCkge1xuXHRcdHJldHVybiB0aGlzLmhvb2tzLmNhbGxIb29rKERldlRvb2xzVjZQbHVnaW5BUElIb29rS2V5cy5WSVNJVF9DT01QT05FTlRfVFJFRSwgcGF5bG9hZCk7XG5cdH1cblx0bm93KCkge1xuXHRcdGlmIChkZXZ0b29sc1N0YXRlLmhpZ2hQZXJmTW9kZUVuYWJsZWQpIHJldHVybiAwO1xuXHRcdHJldHVybiBEYXRlLm5vdygpO1xuXHR9XG5cdGFkZFRpbWVsaW5lTGF5ZXIob3B0aW9ucykge1xuXHRcdHRoaXMuaG9va3MuY2FsbEhvb2soRGV2VG9vbHNDb250ZXh0SG9va0tleXMuVElNRUxJTkVfTEFZRVJfQURERUQsIHtcblx0XHRcdG9wdGlvbnMsXG5cdFx0XHRwbHVnaW46IHRoaXMucGx1Z2luXG5cdFx0fSk7XG5cdH1cblx0YWRkVGltZWxpbmVFdmVudChvcHRpb25zKSB7XG5cdFx0aWYgKGRldnRvb2xzU3RhdGUuaGlnaFBlcmZNb2RlRW5hYmxlZCkgcmV0dXJuO1xuXHRcdHRoaXMuaG9va3MuY2FsbEhvb2soRGV2VG9vbHNDb250ZXh0SG9va0tleXMuVElNRUxJTkVfRVZFTlRfQURERUQsIHtcblx0XHRcdG9wdGlvbnMsXG5cdFx0XHRwbHVnaW46IHRoaXMucGx1Z2luXG5cdFx0fSk7XG5cdH1cblx0Z2V0U2V0dGluZ3MocGx1Z2luSWQpIHtcblx0XHRyZXR1cm4gZ2V0UGx1Z2luU2V0dGluZ3MocGx1Z2luSWQgPz8gdGhpcy5wbHVnaW4uZGVzY3JpcHRvci5pZCwgdGhpcy5wbHVnaW4uZGVzY3JpcHRvci5zZXR0aW5ncyk7XG5cdH1cblx0Z2V0Q29tcG9uZW50SW5zdGFuY2VzKGFwcCkge1xuXHRcdHJldHVybiB0aGlzLmhvb2tzLmNhbGxIb29rKERldlRvb2xzQ29udGV4dEhvb2tLZXlzLkdFVF9DT01QT05FTlRfSU5TVEFOQ0VTLCB7IGFwcCB9KTtcblx0fVxuXHRnZXRDb21wb25lbnRCb3VuZHMoaW5zdGFuY2UpIHtcblx0XHRyZXR1cm4gdGhpcy5ob29rcy5jYWxsSG9vayhEZXZUb29sc0NvbnRleHRIb29rS2V5cy5HRVRfQ09NUE9ORU5UX0JPVU5EUywgeyBpbnN0YW5jZSB9KTtcblx0fVxuXHRnZXRDb21wb25lbnROYW1lKGluc3RhbmNlKSB7XG5cdFx0cmV0dXJuIHRoaXMuaG9va3MuY2FsbEhvb2soRGV2VG9vbHNDb250ZXh0SG9va0tleXMuR0VUX0NPTVBPTkVOVF9OQU1FLCB7IGluc3RhbmNlIH0pO1xuXHR9XG5cdGhpZ2hsaWdodEVsZW1lbnQoaW5zdGFuY2UpIHtcblx0XHRjb25zdCB1aWQgPSBpbnN0YW5jZS5fX1ZVRV9ERVZUT09MU19ORVhUX1VJRF9fO1xuXHRcdHJldHVybiB0aGlzLmhvb2tzLmNhbGxIb29rKERldlRvb2xzQ29udGV4dEhvb2tLZXlzLkNPTVBPTkVOVF9ISUdITElHSFQsIHsgdWlkIH0pO1xuXHR9XG5cdHVuaGlnaGxpZ2h0RWxlbWVudCgpIHtcblx0XHRyZXR1cm4gdGhpcy5ob29rcy5jYWxsSG9vayhEZXZUb29sc0NvbnRleHRIb29rS2V5cy5DT01QT05FTlRfVU5ISUdITElHSFQpO1xuXHR9XG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FwaS9pbmRleC50c1xuY29uc3QgRGV2VG9vbHNQbHVnaW5BUEkgPSBEZXZUb29sc1Y2UGx1Z2luQVBJO1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvY29tcG9uZW50L3N0YXRlL2NvbnN0YW50cy50c1xuY29uc3QgdnVlQnVpbHRpbnMgPSBuZXcgU2V0KFtcblx0XCJuZXh0VGlja1wiLFxuXHRcImRlZmluZUNvbXBvbmVudFwiLFxuXHRcImRlZmluZUFzeW5jQ29tcG9uZW50XCIsXG5cdFwiZGVmaW5lQ3VzdG9tRWxlbWVudFwiLFxuXHRcInJlZlwiLFxuXHRcImNvbXB1dGVkXCIsXG5cdFwicmVhY3RpdmVcIixcblx0XCJyZWFkb25seVwiLFxuXHRcIndhdGNoRWZmZWN0XCIsXG5cdFwid2F0Y2hQb3N0RWZmZWN0XCIsXG5cdFwid2F0Y2hTeW5jRWZmZWN0XCIsXG5cdFwid2F0Y2hcIixcblx0XCJpc1JlZlwiLFxuXHRcInVucmVmXCIsXG5cdFwidG9SZWZcIixcblx0XCJ0b1JlZnNcIixcblx0XCJpc1Byb3h5XCIsXG5cdFwiaXNSZWFjdGl2ZVwiLFxuXHRcImlzUmVhZG9ubHlcIixcblx0XCJzaGFsbG93UmVmXCIsXG5cdFwidHJpZ2dlclJlZlwiLFxuXHRcImN1c3RvbVJlZlwiLFxuXHRcInNoYWxsb3dSZWFjdGl2ZVwiLFxuXHRcInNoYWxsb3dSZWFkb25seVwiLFxuXHRcInRvUmF3XCIsXG5cdFwibWFya1Jhd1wiLFxuXHRcImVmZmVjdFNjb3BlXCIsXG5cdFwiZ2V0Q3VycmVudFNjb3BlXCIsXG5cdFwib25TY29wZURpc3Bvc2VcIixcblx0XCJvbk1vdW50ZWRcIixcblx0XCJvblVwZGF0ZWRcIixcblx0XCJvblVubW91bnRlZFwiLFxuXHRcIm9uQmVmb3JlTW91bnRcIixcblx0XCJvbkJlZm9yZVVwZGF0ZVwiLFxuXHRcIm9uQmVmb3JlVW5tb3VudFwiLFxuXHRcIm9uRXJyb3JDYXB0dXJlZFwiLFxuXHRcIm9uUmVuZGVyVHJhY2tlZFwiLFxuXHRcIm9uUmVuZGVyVHJpZ2dlcmVkXCIsXG5cdFwib25BY3RpdmF0ZWRcIixcblx0XCJvbkRlYWN0aXZhdGVkXCIsXG5cdFwib25TZXJ2ZXJQcmVmZXRjaFwiLFxuXHRcInByb3ZpZGVcIixcblx0XCJpbmplY3RcIixcblx0XCJoXCIsXG5cdFwibWVyZ2VQcm9wc1wiLFxuXHRcImNsb25lVk5vZGVcIixcblx0XCJpc1ZOb2RlXCIsXG5cdFwicmVzb2x2ZUNvbXBvbmVudFwiLFxuXHRcInJlc29sdmVEaXJlY3RpdmVcIixcblx0XCJ3aXRoRGlyZWN0aXZlc1wiLFxuXHRcIndpdGhNb2RpZmllcnNcIlxuXSk7XG5jb25zdCBzeW1ib2xSRSA9IC9eXFxbbmF0aXZlIFN5bWJvbCBTeW1ib2xcXCgoLiopXFwpXFxdJC87XG5jb25zdCByYXdUeXBlUkUgPSAvXlxcW29iamVjdCAoXFx3KylcXF0kLztcbmNvbnN0IHNwZWNpYWxUeXBlUkUgPSAvXlxcW25hdGl2ZSAoXFx3KykgKC4qPykoPD4oKFtcXHNcXFNdKSopKT9cXF0kLztcbmNvbnN0IGZuVHlwZVJFID0gL14oPzpmdW5jdGlvbnxjbGFzcykgKFxcdyspLztcbmNvbnN0IE1BWF9TVFJJTkdfU0laRSA9IDFlNDtcbmNvbnN0IE1BWF9BUlJBWV9TSVpFID0gNWUzO1xuY29uc3QgVU5ERUZJTkVEID0gXCJfX3Z1ZV9kZXZ0b29sX3VuZGVmaW5lZF9fXCI7XG5jb25zdCBJTkZJTklUWSA9IFwiX192dWVfZGV2dG9vbF9pbmZpbml0eV9fXCI7XG5jb25zdCBORUdBVElWRV9JTkZJTklUWSA9IFwiX192dWVfZGV2dG9vbF9uZWdhdGl2ZV9pbmZpbml0eV9fXCI7XG5jb25zdCBOQU4gPSBcIl9fdnVlX2RldnRvb2xfbmFuX19cIjtcbmNvbnN0IEVTQyA9IHtcblx0XCI8XCI6IFwiJmx0O1wiLFxuXHRcIj5cIjogXCImZ3Q7XCIsXG5cdFwiXFxcIlwiOiBcIiZxdW90O1wiLFxuXHRcIiZcIjogXCImYW1wO1wiXG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvY29tcG9uZW50L3N0YXRlL2lzLnRzXG5mdW5jdGlvbiBpc1Z1ZUluc3RhbmNlKHZhbHVlKSB7XG5cdGlmICghZW5zdXJlUHJvcGVydHlFeGlzdHModmFsdWUsIFwiX1wiKSkgcmV0dXJuIGZhbHNlO1xuXHRpZiAoIWlzUGxhaW5PYmplY3QodmFsdWUuXykpIHJldHVybiBmYWxzZTtcblx0cmV0dXJuIE9iamVjdC5rZXlzKHZhbHVlLl8pLmluY2x1ZGVzKFwidm5vZGVcIik7XG59XG5mdW5jdGlvbiBpc1BsYWluT2JqZWN0KG9iaikge1xuXHRyZXR1cm4gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKG9iaikgPT09IFwiW29iamVjdCBPYmplY3RdXCI7XG59XG5mdW5jdGlvbiBpc1ByaW1pdGl2ZSQxKGRhdGEpIHtcblx0aWYgKGRhdGEgPT0gbnVsbCkgcmV0dXJuIHRydWU7XG5cdGNvbnN0IHR5cGUgPSB0eXBlb2YgZGF0YTtcblx0cmV0dXJuIHR5cGUgPT09IFwic3RyaW5nXCIgfHwgdHlwZSA9PT0gXCJudW1iZXJcIiB8fCB0eXBlID09PSBcImJvb2xlYW5cIjtcbn1cbmZ1bmN0aW9uIGlzUmVmKHJhdykge1xuXHRyZXR1cm4gISFyYXcuX192X2lzUmVmO1xufVxuZnVuY3Rpb24gaXNDb21wdXRlZChyYXcpIHtcblx0cmV0dXJuIGlzUmVmKHJhdykgJiYgISFyYXcuZWZmZWN0O1xufVxuZnVuY3Rpb24gaXNSZWFjdGl2ZShyYXcpIHtcblx0cmV0dXJuICEhcmF3Ll9fdl9pc1JlYWN0aXZlO1xufVxuZnVuY3Rpb24gaXNSZWFkT25seShyYXcpIHtcblx0cmV0dXJuICEhcmF3Ll9fdl9pc1JlYWRvbmx5O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvY29tcG9uZW50L3N0YXRlL3V0aWwudHNcbmNvbnN0IHRva2VuTWFwID0ge1xuXHRbVU5ERUZJTkVEXTogXCJ1bmRlZmluZWRcIixcblx0W05BTl06IFwiTmFOXCIsXG5cdFtJTkZJTklUWV06IFwiSW5maW5pdHlcIixcblx0W05FR0FUSVZFX0lORklOSVRZXTogXCItSW5maW5pdHlcIlxufTtcbmNvbnN0IHJldmVyc2VkVG9rZW5NYXAgPSBPYmplY3QuZW50cmllcyh0b2tlbk1hcCkucmVkdWNlKChhY2MsIFtrZXksIHZhbHVlXSkgPT4ge1xuXHRhY2NbdmFsdWVdID0ga2V5O1xuXHRyZXR1cm4gYWNjO1xufSwge30pO1xuZnVuY3Rpb24gaW50ZXJuYWxTdGF0ZVRva2VuVG9TdHJpbmcodmFsdWUpIHtcblx0aWYgKHZhbHVlID09PSBudWxsKSByZXR1cm4gXCJudWxsXCI7XG5cdHJldHVybiB0eXBlb2YgdmFsdWUgPT09IFwic3RyaW5nXCIgJiYgdG9rZW5NYXBbdmFsdWVdIHx8IGZhbHNlO1xufVxuZnVuY3Rpb24gcmVwbGFjZVRva2VuVG9TdHJpbmcodmFsdWUpIHtcblx0Y29uc3QgcmVwbGFjZVJlZ2V4ID0gbmV3IFJlZ0V4cChgXCIoJHtPYmplY3Qua2V5cyh0b2tlbk1hcCkuam9pbihcInxcIil9KVwiYCwgXCJnXCIpO1xuXHRyZXR1cm4gdmFsdWUucmVwbGFjZShyZXBsYWNlUmVnZXgsIChfLCBnMSkgPT4gdG9rZW5NYXBbZzFdKTtcbn1cbmZ1bmN0aW9uIHJlcGxhY2VTdHJpbmdUb1Rva2VuKHZhbHVlKSB7XG5cdGNvbnN0IGxpdGVyYWxWYWx1ZSA9IHJldmVyc2VkVG9rZW5NYXBbdmFsdWUudHJpbSgpXTtcblx0aWYgKGxpdGVyYWxWYWx1ZSkgcmV0dXJuIGBcIiR7bGl0ZXJhbFZhbHVlfVwiYDtcblx0Y29uc3QgcmVwbGFjZVJlZ2V4ID0gbmV3IFJlZ0V4cChgOlxcXFxzKigke09iamVjdC5rZXlzKHJldmVyc2VkVG9rZW5NYXApLmpvaW4oXCJ8XCIpfSlgLCBcImdcIik7XG5cdHJldHVybiB2YWx1ZS5yZXBsYWNlKHJlcGxhY2VSZWdleCwgKF8sIGcxKSA9PiBgOlwiJHtyZXZlcnNlZFRva2VuTWFwW2cxXX1cImApO1xufVxuLyoqXG4qIENvbnZlcnQgcHJvcCB0eXBlIGNvbnN0cnVjdG9yIHRvIHN0cmluZy5cbiovXG5mdW5jdGlvbiBnZXRQcm9wVHlwZSh0eXBlKSB7XG5cdGlmIChBcnJheS5pc0FycmF5KHR5cGUpKSByZXR1cm4gdHlwZS5tYXAoKHQpID0+IGdldFByb3BUeXBlKHQpKS5qb2luKFwiIG9yIFwiKTtcblx0aWYgKHR5cGUgPT0gbnVsbCkgcmV0dXJuIFwibnVsbFwiO1xuXHRjb25zdCBtYXRjaCA9IHR5cGUudG9TdHJpbmcoKS5tYXRjaChmblR5cGVSRSk7XG5cdHJldHVybiB0eXBlb2YgdHlwZSA9PT0gXCJmdW5jdGlvblwiID8gbWF0Y2ggJiYgbWF0Y2hbMV0gfHwgXCJhbnlcIiA6IFwiYW55XCI7XG59XG4vKipcbiogU2FuaXRpemUgZGF0YSB0byBiZSBwb3N0ZWQgdG8gdGhlIG90aGVyIHNpZGUuXG4qIFNpbmNlIHRoZSBtZXNzYWdlIHBvc3RlZCBpcyBzZW50IHdpdGggc3RydWN0dXJlZCBjbG9uZSxcbiogd2UgbmVlZCB0byBmaWx0ZXIgb3V0IGFueSB0eXBlcyB0aGF0IG1pZ2h0IGNhdXNlIGFuIGVycm9yLlxuKi9cbmZ1bmN0aW9uIHNhbml0aXplKGRhdGEpIHtcblx0aWYgKCFpc1ByaW1pdGl2ZSQxKGRhdGEpICYmICFBcnJheS5pc0FycmF5KGRhdGEpICYmICFpc1BsYWluT2JqZWN0KGRhdGEpKSByZXR1cm4gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKGRhdGEpO1xuXHRlbHNlIHJldHVybiBkYXRhO1xufVxuZnVuY3Rpb24gZ2V0U2V0dXBTdGF0ZVR5cGUocmF3KSB7XG5cdHRyeSB7XG5cdFx0cmV0dXJuIHtcblx0XHRcdHJlZjogaXNSZWYocmF3KSxcblx0XHRcdGNvbXB1dGVkOiBpc0NvbXB1dGVkKHJhdyksXG5cdFx0XHRyZWFjdGl2ZTogaXNSZWFjdGl2ZShyYXcpLFxuXHRcdFx0cmVhZG9ubHk6IGlzUmVhZE9ubHkocmF3KVxuXHRcdH07XG5cdH0gY2F0Y2gge1xuXHRcdHJldHVybiB7XG5cdFx0XHRyZWY6IGZhbHNlLFxuXHRcdFx0Y29tcHV0ZWQ6IGZhbHNlLFxuXHRcdFx0cmVhY3RpdmU6IGZhbHNlLFxuXHRcdFx0cmVhZG9ubHk6IGZhbHNlXG5cdFx0fTtcblx0fVxufVxuZnVuY3Rpb24gdG9SYXcodmFsdWUpIHtcblx0aWYgKHZhbHVlPy5fX3ZfcmF3KSByZXR1cm4gdmFsdWUuX192X3Jhdztcblx0cmV0dXJuIHZhbHVlO1xufVxuZnVuY3Rpb24gZXNjYXBlKHMpIHtcblx0cmV0dXJuIHMucmVwbGFjZSgvWzw+XCImXS9nLCAocykgPT4ge1xuXHRcdHJldHVybiBFU0Nbc10gfHwgcztcblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9jb21wb25lbnQvc3RhdGUvcHJvY2Vzcy50c1xuZnVuY3Rpb24gbWVyZ2VPcHRpb25zKHRvLCBmcm9tLCBpbnN0YW5jZSkge1xuXHRpZiAodHlwZW9mIGZyb20gPT09IFwiZnVuY3Rpb25cIikgZnJvbSA9IGZyb20ub3B0aW9ucztcblx0aWYgKCFmcm9tKSByZXR1cm4gdG87XG5cdGNvbnN0IHsgbWl4aW5zLCBleHRlbmRzOiBleHRlbmRzT3B0aW9ucyB9ID0gZnJvbTtcblx0ZXh0ZW5kc09wdGlvbnMgJiYgbWVyZ2VPcHRpb25zKHRvLCBleHRlbmRzT3B0aW9ucywgaW5zdGFuY2UpO1xuXHRtaXhpbnMgJiYgbWl4aW5zLmZvckVhY2goKG0pID0+IG1lcmdlT3B0aW9ucyh0bywgbSwgaW5zdGFuY2UpKTtcblx0Zm9yIChjb25zdCBrZXkgb2YgW1wiY29tcHV0ZWRcIiwgXCJpbmplY3RcIl0pIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoZnJvbSwga2V5KSkge1xuXHRcdHRvW2tleV0gPz89IHt9O1xuXHRcdE9iamVjdC5hc3NpZ24odG9ba2V5XSwgZnJvbVtrZXldKTtcblx0fVxuXHRyZXR1cm4gdG87XG59XG5mdW5jdGlvbiByZXNvbHZlTWVyZ2VkT3B0aW9ucyhpbnN0YW5jZSkge1xuXHRjb25zdCByYXcgPSBpbnN0YW5jZT8udHlwZTtcblx0aWYgKCFyYXcpIHJldHVybiB7fTtcblx0Y29uc3QgeyBtaXhpbnMsIGV4dGVuZHM6IGV4dGVuZHNPcHRpb25zIH0gPSByYXc7XG5cdGNvbnN0IGdsb2JhbE1peGlucyA9IGluc3RhbmNlLmFwcENvbnRleHQubWl4aW5zO1xuXHRpZiAoIWdsb2JhbE1peGlucy5sZW5ndGggJiYgIW1peGlucyAmJiAhZXh0ZW5kc09wdGlvbnMpIHJldHVybiByYXc7XG5cdGNvbnN0IG9wdGlvbnMgPSB7fTtcblx0Z2xvYmFsTWl4aW5zLmZvckVhY2goKG0pID0+IG1lcmdlT3B0aW9ucyhvcHRpb25zLCBtLCBpbnN0YW5jZSkpO1xuXHRtZXJnZU9wdGlvbnMob3B0aW9ucywgcmF3LCBpbnN0YW5jZSk7XG5cdHJldHVybiBvcHRpb25zO1xufVxuLyoqXG4qIFByb2Nlc3MgdGhlIHByb3BzIG9mIGFuIGluc3RhbmNlLlxuKiBNYWtlIHN1cmUgcmV0dXJuIGEgcGxhaW4gb2JqZWN0IGJlY2F1c2Ugd2luZG93LnBvc3RNZXNzYWdlKClcbiogd2lsbCB0aHJvdyBhbiBFcnJvciBpZiB0aGUgcGFzc2VkIG9iamVjdCBjb250YWlucyBGdW5jdGlvbnMuXG4qXG4qL1xuZnVuY3Rpb24gcHJvY2Vzc1Byb3BzKGluc3RhbmNlKSB7XG5cdGNvbnN0IHByb3BzID0gW107XG5cdGNvbnN0IHByb3BEZWZpbml0aW9ucyA9IGluc3RhbmNlPy50eXBlPy5wcm9wcztcblx0Zm9yIChjb25zdCBrZXkgaW4gaW5zdGFuY2U/LnByb3BzKSB7XG5cdFx0Y29uc3QgcHJvcERlZmluaXRpb24gPSBwcm9wRGVmaW5pdGlvbnMgPyBwcm9wRGVmaW5pdGlvbnNba2V5XSA6IG51bGw7XG5cdFx0Y29uc3QgY2FtZWxpemVLZXkgPSBjYW1lbGl6ZShrZXkpO1xuXHRcdHByb3BzLnB1c2goe1xuXHRcdFx0dHlwZTogXCJwcm9wc1wiLFxuXHRcdFx0a2V5OiBjYW1lbGl6ZUtleSxcblx0XHRcdHZhbHVlOiByZXR1cm5FcnJvcigoKSA9PiBpbnN0YW5jZS5wcm9wc1trZXldKSxcblx0XHRcdGVkaXRhYmxlOiB0cnVlLFxuXHRcdFx0bWV0YTogcHJvcERlZmluaXRpb24gPyB7XG5cdFx0XHRcdHR5cGU6IHByb3BEZWZpbml0aW9uLnR5cGUgPyBnZXRQcm9wVHlwZShwcm9wRGVmaW5pdGlvbi50eXBlKSA6IFwiYW55XCIsXG5cdFx0XHRcdHJlcXVpcmVkOiAhIXByb3BEZWZpbml0aW9uLnJlcXVpcmVkLFxuXHRcdFx0XHQuLi5wcm9wRGVmaW5pdGlvbi5kZWZhdWx0ID8geyBkZWZhdWx0OiBwcm9wRGVmaW5pdGlvbi5kZWZhdWx0LnRvU3RyaW5nKCkgfSA6IHt9XG5cdFx0XHR9IDogeyB0eXBlOiBcImludmFsaWRcIiB9XG5cdFx0fSk7XG5cdH1cblx0cmV0dXJuIHByb3BzO1xufVxuLyoqXG4qIFByb2Nlc3Mgc3RhdGUsIGZpbHRlcmluZyBvdXQgcHJvcHMgYW5kIFwiY2xlYW5cIiB0aGUgcmVzdWx0XG4qIHdpdGggYSBKU09OIGRhbmNlLiBUaGlzIHJlbW92ZXMgZnVuY3Rpb25zIHdoaWNoIGNhbiBjYXVzZVxuKiBlcnJvcnMgZHVyaW5nIHN0cnVjdHVyZWQgY2xvbmUgdXNlZCBieSB3aW5kb3cucG9zdE1lc3NhZ2UuXG4qXG4qL1xuZnVuY3Rpb24gcHJvY2Vzc1N0YXRlKGluc3RhbmNlKSB7XG5cdGNvbnN0IHR5cGUgPSBpbnN0YW5jZS50eXBlO1xuXHRjb25zdCBwcm9wcyA9IHR5cGU/LnByb3BzO1xuXHRjb25zdCBnZXR0ZXJzID0gdHlwZS52dWV4ICYmIHR5cGUudnVleC5nZXR0ZXJzO1xuXHRjb25zdCBjb21wdXRlZERlZnMgPSB0eXBlLmNvbXB1dGVkO1xuXHRjb25zdCBkYXRhID0ge1xuXHRcdC4uLmluc3RhbmNlLmRhdGEsXG5cdFx0Li4uaW5zdGFuY2UucmVuZGVyQ29udGV4dFxuXHR9O1xuXHRyZXR1cm4gT2JqZWN0LmtleXMoZGF0YSkuZmlsdGVyKChrZXkpID0+ICEocHJvcHMgJiYga2V5IGluIHByb3BzKSAmJiAhKGdldHRlcnMgJiYga2V5IGluIGdldHRlcnMpICYmICEoY29tcHV0ZWREZWZzICYmIGtleSBpbiBjb21wdXRlZERlZnMpKS5tYXAoKGtleSkgPT4gKHtcblx0XHRrZXksXG5cdFx0dHlwZTogXCJkYXRhXCIsXG5cdFx0dmFsdWU6IHJldHVybkVycm9yKCgpID0+IGRhdGFba2V5XSksXG5cdFx0ZWRpdGFibGU6IHRydWVcblx0fSkpO1xufVxuZnVuY3Rpb24gZ2V0U3RhdGVUeXBlQW5kTmFtZShpbmZvKSB7XG5cdGNvbnN0IHN0YXRlVHlwZSA9IGluZm8uY29tcHV0ZWQgPyBcImNvbXB1dGVkXCIgOiBpbmZvLnJlZiA/IFwicmVmXCIgOiBpbmZvLnJlYWN0aXZlID8gXCJyZWFjdGl2ZVwiIDogbnVsbDtcblx0cmV0dXJuIHtcblx0XHRzdGF0ZVR5cGUsXG5cdFx0c3RhdGVUeXBlTmFtZTogc3RhdGVUeXBlID8gYCR7c3RhdGVUeXBlLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpfSR7c3RhdGVUeXBlLnNsaWNlKDEpfWAgOiBudWxsXG5cdH07XG59XG5mdW5jdGlvbiBwcm9jZXNzU2V0dXBTdGF0ZShpbnN0YW5jZSkge1xuXHRjb25zdCByYXcgPSBpbnN0YW5jZS5kZXZ0b29sc1Jhd1NldHVwU3RhdGUgfHwge307XG5cdHJldHVybiBPYmplY3Qua2V5cyhpbnN0YW5jZS5zZXR1cFN0YXRlKS5maWx0ZXIoKGtleSkgPT4gIXZ1ZUJ1aWx0aW5zLmhhcyhrZXkpICYmIGtleS5zcGxpdCgvKD89W0EtWl0pLylbMF0gIT09IFwidXNlXCIpLm1hcCgoa2V5KSA9PiB7XG5cdFx0Y29uc3QgdmFsdWUgPSByZXR1cm5FcnJvcigoKSA9PiB0b1JhdyhpbnN0YW5jZS5zZXR1cFN0YXRlW2tleV0pKTtcblx0XHRjb25zdCBhY2Nlc3NFcnJvciA9IHZhbHVlIGluc3RhbmNlb2YgRXJyb3I7XG5cdFx0Y29uc3QgcmF3RGF0YSA9IHJhd1trZXldO1xuXHRcdGxldCByZXN1bHQ7XG5cdFx0bGV0IGlzT3RoZXJUeXBlID0gYWNjZXNzRXJyb3IgfHwgdHlwZW9mIHZhbHVlID09PSBcImZ1bmN0aW9uXCIgfHwgZW5zdXJlUHJvcGVydHlFeGlzdHModmFsdWUsIFwicmVuZGVyXCIpICYmIHR5cGVvZiB2YWx1ZS5yZW5kZXIgPT09IFwiZnVuY3Rpb25cIiB8fCBlbnN1cmVQcm9wZXJ0eUV4aXN0cyh2YWx1ZSwgXCJfX2FzeW5jTG9hZGVyXCIpICYmIHR5cGVvZiB2YWx1ZS5fX2FzeW5jTG9hZGVyID09PSBcImZ1bmN0aW9uXCIgfHwgdHlwZW9mIHZhbHVlID09PSBcIm9iamVjdFwiICYmIHZhbHVlICYmIChcInNldHVwXCIgaW4gdmFsdWUgfHwgXCJwcm9wc1wiIGluIHZhbHVlKSB8fCAvXnZbQS1aXS8udGVzdChrZXkpO1xuXHRcdGlmIChyYXdEYXRhICYmICFhY2Nlc3NFcnJvcikge1xuXHRcdFx0Y29uc3QgaW5mbyA9IGdldFNldHVwU3RhdGVUeXBlKHJhd0RhdGEpO1xuXHRcdFx0Y29uc3QgeyBzdGF0ZVR5cGUsIHN0YXRlVHlwZU5hbWUgfSA9IGdldFN0YXRlVHlwZUFuZE5hbWUoaW5mbyk7XG5cdFx0XHRjb25zdCBpc1N0YXRlID0gaW5mby5yZWYgfHwgaW5mby5jb21wdXRlZCB8fCBpbmZvLnJlYWN0aXZlO1xuXHRcdFx0Y29uc3QgcmF3ID0gZW5zdXJlUHJvcGVydHlFeGlzdHMocmF3RGF0YSwgXCJlZmZlY3RcIikgPyByYXdEYXRhLmVmZmVjdD8ucmF3Py50b1N0cmluZygpIHx8IHJhd0RhdGEuZWZmZWN0Py5mbj8udG9TdHJpbmcoKSA6IG51bGw7XG5cdFx0XHRpZiAoc3RhdGVUeXBlKSBpc090aGVyVHlwZSA9IGZhbHNlO1xuXHRcdFx0cmVzdWx0ID0ge1xuXHRcdFx0XHQuLi5zdGF0ZVR5cGUgPyB7XG5cdFx0XHRcdFx0c3RhdGVUeXBlLFxuXHRcdFx0XHRcdHN0YXRlVHlwZU5hbWVcblx0XHRcdFx0fSA6IHt9LFxuXHRcdFx0XHQuLi5yYXcgPyB7IHJhdyB9IDoge30sXG5cdFx0XHRcdGVkaXRhYmxlOiBpc1N0YXRlICYmICFpbmZvLnJlYWRvbmx5XG5cdFx0XHR9O1xuXHRcdH1cblx0XHRyZXR1cm4ge1xuXHRcdFx0a2V5LFxuXHRcdFx0dmFsdWUsXG5cdFx0XHR0eXBlOiBpc090aGVyVHlwZSA/IFwic2V0dXAgKG90aGVyKVwiIDogXCJzZXR1cFwiLFxuXHRcdFx0Li4ucmVzdWx0XG5cdFx0fTtcblx0fSk7XG59XG4vKipcbiogUHJvY2VzcyB0aGUgY29tcHV0ZWQgcHJvcGVydGllcyBvZiBhbiBpbnN0YW5jZS5cbiovXG5mdW5jdGlvbiBwcm9jZXNzQ29tcHV0ZWQoaW5zdGFuY2UsIG1lcmdlZFR5cGUpIHtcblx0Y29uc3QgdHlwZSA9IG1lcmdlZFR5cGU7XG5cdGNvbnN0IGNvbXB1dGVkID0gW107XG5cdGNvbnN0IGRlZnMgPSB0eXBlLmNvbXB1dGVkIHx8IHt9O1xuXHRmb3IgKGNvbnN0IGtleSBpbiBkZWZzKSB7XG5cdFx0Y29uc3QgZGVmID0gZGVmc1trZXldO1xuXHRcdGNvbnN0IHR5cGUgPSB0eXBlb2YgZGVmID09PSBcImZ1bmN0aW9uXCIgJiYgZGVmLnZ1ZXggPyBcInZ1ZXggYmluZGluZ3NcIiA6IFwiY29tcHV0ZWRcIjtcblx0XHRjb21wdXRlZC5wdXNoKHtcblx0XHRcdHR5cGUsXG5cdFx0XHRrZXksXG5cdFx0XHR2YWx1ZTogcmV0dXJuRXJyb3IoKCkgPT4gaW5zdGFuY2U/LnByb3h5Py5ba2V5XSksXG5cdFx0XHRlZGl0YWJsZTogdHlwZW9mIGRlZi5zZXQgPT09IFwiZnVuY3Rpb25cIlxuXHRcdH0pO1xuXHR9XG5cdHJldHVybiBjb21wdXRlZDtcbn1cbmZ1bmN0aW9uIHByb2Nlc3NBdHRycyhpbnN0YW5jZSkge1xuXHRyZXR1cm4gT2JqZWN0LmtleXMoaW5zdGFuY2UuYXR0cnMpLm1hcCgoa2V5KSA9PiAoe1xuXHRcdHR5cGU6IFwiYXR0cnNcIixcblx0XHRrZXksXG5cdFx0dmFsdWU6IHJldHVybkVycm9yKCgpID0+IGluc3RhbmNlLmF0dHJzW2tleV0pXG5cdH0pKTtcbn1cbmZ1bmN0aW9uIHByb2Nlc3NQcm92aWRlKGluc3RhbmNlKSB7XG5cdHJldHVybiBSZWZsZWN0Lm93bktleXMoaW5zdGFuY2UucHJvdmlkZXMpLm1hcCgoa2V5KSA9PiAoe1xuXHRcdHR5cGU6IFwicHJvdmlkZWRcIixcblx0XHRrZXk6IGtleS50b1N0cmluZygpLFxuXHRcdHZhbHVlOiByZXR1cm5FcnJvcigoKSA9PiBpbnN0YW5jZS5wcm92aWRlc1trZXldKVxuXHR9KSk7XG59XG5jb25zdCBoYXNPd25Qcm9wZXJ0eSA9IE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHk7XG5jb25zdCBoYXNPd24gPSAodmFsLCBrZXkpID0+IGhhc093blByb3BlcnR5LmNhbGwodmFsLCBrZXkpO1xuZnVuY3Rpb24gcHJvY2Vzc0luamVjdChpbnN0YW5jZSwgbWVyZ2VkVHlwZSkge1xuXHRpZiAoIW1lcmdlZFR5cGU/LmluamVjdCkgcmV0dXJuIFtdO1xuXHRsZXQga2V5cztcblx0aWYgKEFycmF5LmlzQXJyYXkobWVyZ2VkVHlwZS5pbmplY3QpKSBrZXlzID0gbWVyZ2VkVHlwZS5pbmplY3QubWFwKChrZXkpID0+ICh7XG5cdFx0a2V5LFxuXHRcdG9yaWdpbmFsS2V5OiBrZXlcblx0fSkpO1xuXHRlbHNlIGtleXMgPSBSZWZsZWN0Lm93bktleXMobWVyZ2VkVHlwZS5pbmplY3QpLm1hcCgoa2V5KSA9PiB7XG5cdFx0Y29uc3QgdmFsdWUgPSBtZXJnZWRUeXBlLmluamVjdFtrZXldO1xuXHRcdGxldCBvcmlnaW5hbEtleTtcblx0XHRpZiAodHlwZW9mIHZhbHVlID09PSBcInN0cmluZ1wiIHx8IHR5cGVvZiB2YWx1ZSA9PT0gXCJzeW1ib2xcIikgb3JpZ2luYWxLZXkgPSB2YWx1ZTtcblx0XHRlbHNlIG9yaWdpbmFsS2V5ID0gdmFsdWUuZnJvbSA/PyBrZXk7XG5cdFx0cmV0dXJuIHtcblx0XHRcdGtleSxcblx0XHRcdG9yaWdpbmFsS2V5XG5cdFx0fTtcblx0fSk7XG5cdHJldHVybiBrZXlzLm1hcCgoeyBrZXksIG9yaWdpbmFsS2V5IH0pID0+ICh7XG5cdFx0dHlwZTogXCJpbmplY3RlZFwiLFxuXHRcdGtleToga2V5ICE9PSBvcmlnaW5hbEtleSA/IGAke1N0cmluZyhvcmlnaW5hbEtleSl9IOKeniAke1N0cmluZyhrZXkpfWAgOiBTdHJpbmcoa2V5KSxcblx0XHR2YWx1ZTogcmV0dXJuRXJyb3IoKCkgPT4gaGFzT3duKGluc3RhbmNlLmN0eCwga2V5KSA/IGluc3RhbmNlLmN0eFtrZXldIDogdm9pZCAwKVxuXHR9KSk7XG59XG5mdW5jdGlvbiBwcm9jZXNzUmVmcyhpbnN0YW5jZSkge1xuXHRyZXR1cm4gT2JqZWN0LmtleXMoaW5zdGFuY2UucmVmcykubWFwKChrZXkpID0+ICh7XG5cdFx0dHlwZTogXCJ0ZW1wbGF0ZSByZWZzXCIsXG5cdFx0a2V5LFxuXHRcdHZhbHVlOiByZXR1cm5FcnJvcigoKSA9PiBpbnN0YW5jZS5yZWZzW2tleV0pXG5cdH0pKTtcbn1cbmNvbnN0IHZub2RlRXZlbnRzID0gbmV3IFNldChbXG5cdFwidm5vZGUtYmVmb3JlLW1vdW50XCIsXG5cdFwidm5vZGUtbW91bnRlZFwiLFxuXHRcInZub2RlLWJlZm9yZS11cGRhdGVcIixcblx0XCJ2bm9kZS11cGRhdGVkXCIsXG5cdFwidm5vZGUtYmVmb3JlLXVubW91bnRcIixcblx0XCJ2bm9kZS11bm1vdW50ZWRcIlxuXSk7XG5mdW5jdGlvbiBwcm9jZXNzRXZlbnRMaXN0ZW5lcnMoaW5zdGFuY2UpIHtcblx0Y29uc3QgZW1pdHNEZWZpbml0aW9uID0gaW5zdGFuY2UudHlwZS5lbWl0cztcblx0Y29uc3QgZGVjbGFyZWRFbWl0cyA9IEFycmF5LmlzQXJyYXkoZW1pdHNEZWZpbml0aW9uKSA/IGVtaXRzRGVmaW5pdGlvbiA6IE9iamVjdC5rZXlzKGVtaXRzRGVmaW5pdGlvbiA/PyB7fSk7XG5cdGNvbnN0IGtleXMgPSBPYmplY3Qua2V5cyhpbnN0YW5jZT8udm5vZGU/LnByb3BzID8/IHt9KTtcblx0Y29uc3QgcmVzdWx0ID0gW107XG5cdGZvciAoY29uc3Qga2V5IG9mIGtleXMpIHtcblx0XHRjb25zdCBbcHJlZml4LCAuLi5ldmVudE5hbWVQYXJ0c10gPSBrZXkuc3BsaXQoLyg/PVtBLVpdKS8pO1xuXHRcdGlmIChwcmVmaXggPT09IFwib25cIikge1xuXHRcdFx0Y29uc3QgZXZlbnROYW1lID0gZXZlbnROYW1lUGFydHMuam9pbihcIi1cIikudG9Mb3dlckNhc2UoKTtcblx0XHRcdGNvbnN0IGlzQnVpbHRJbiA9IHZub2RlRXZlbnRzLmhhcyhldmVudE5hbWUpO1xuXHRcdFx0Y29uc3QgaXNEZWNsYXJlZCA9IGRlY2xhcmVkRW1pdHMuaW5jbHVkZXMoZXZlbnROYW1lKSB8fCBkZWNsYXJlZEVtaXRzLmluY2x1ZGVzKGNhbWVsaXplKGV2ZW50TmFtZSkpO1xuXHRcdFx0Y29uc3QgdGV4dCA9IGlzQnVpbHRJbiA/IFwi4pyFIEJ1aWx0LWluXCIgOiBpc0RlY2xhcmVkID8gXCLinIUgRGVjbGFyZWRcIiA6IFwi4pqg77iPIE5vdCBkZWNsYXJlZFwiO1xuXHRcdFx0cmVzdWx0LnB1c2goe1xuXHRcdFx0XHR0eXBlOiBcImV2ZW50IGxpc3RlbmVyc1wiLFxuXHRcdFx0XHRrZXk6IGV2ZW50TmFtZSxcblx0XHRcdFx0dmFsdWU6IHsgX2N1c3RvbToge1xuXHRcdFx0XHRcdGRpc3BsYXlUZXh0OiB0ZXh0LFxuXHRcdFx0XHRcdGtleTogdGV4dCxcblx0XHRcdFx0XHR2YWx1ZTogdGV4dCxcblx0XHRcdFx0XHR0b29sdGlwVGV4dDogaXNCdWlsdEluID8gYFRoZSBldmVudCA8Y29kZT4ke2VzY2FwZShldmVudE5hbWUpfTwvY29kZT4gaXMgcGFydCBvZiBWdWUgYW5kIGRvZXNuJ3QgbmVlZCB0byBiZSBkZWNsYXJlZCBieSB0aGUgY29tcG9uZW50YCA6ICFpc0RlY2xhcmVkID8gYFRoZSBldmVudCA8Y29kZT4ke2VzY2FwZShldmVudE5hbWUpfTwvY29kZT4gaXMgbm90IGRlY2xhcmVkIGluIHRoZSA8Y29kZT5lbWl0czwvY29kZT4gb3B0aW9uLiBJdCB3aWxsIGxlYWsgaW50byB0aGUgY29tcG9uZW50J3MgYXR0cmlidXRlcyAoPGNvZGU+JGF0dHJzPC9jb2RlPikuYCA6IG51bGxcblx0XHRcdFx0fSB9XG5cdFx0XHR9KTtcblx0XHR9XG5cdH1cblx0cmV0dXJuIHJlc3VsdDtcbn1cbmZ1bmN0aW9uIHByb2Nlc3NJbnN0YW5jZVN0YXRlKGluc3RhbmNlKSB7XG5cdGNvbnN0IG1lcmdlZFR5cGUgPSByZXNvbHZlTWVyZ2VkT3B0aW9ucyhpbnN0YW5jZSk7XG5cdHJldHVybiBwcm9jZXNzUHJvcHMoaW5zdGFuY2UpLmNvbmNhdChwcm9jZXNzU3RhdGUoaW5zdGFuY2UpLCBwcm9jZXNzU2V0dXBTdGF0ZShpbnN0YW5jZSksIHByb2Nlc3NDb21wdXRlZChpbnN0YW5jZSwgbWVyZ2VkVHlwZSksIHByb2Nlc3NBdHRycyhpbnN0YW5jZSksIHByb2Nlc3NQcm92aWRlKGluc3RhbmNlKSwgcHJvY2Vzc0luamVjdChpbnN0YW5jZSwgbWVyZ2VkVHlwZSksIHByb2Nlc3NSZWZzKGluc3RhbmNlKSwgcHJvY2Vzc0V2ZW50TGlzdGVuZXJzKGluc3RhbmNlKSk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9jb21wb25lbnQvc3RhdGUvaW5kZXgudHNcbmZ1bmN0aW9uIGdldEluc3RhbmNlU3RhdGUocGFyYW1zKSB7XG5cdGNvbnN0IGluc3RhbmNlID0gZ2V0Q29tcG9uZW50SW5zdGFuY2UoYWN0aXZlQXBwUmVjb3JkLnZhbHVlLCBwYXJhbXMuaW5zdGFuY2VJZCk7XG5cdHJldHVybiB7XG5cdFx0aWQ6IGdldFVuaXF1ZUNvbXBvbmVudElkKGluc3RhbmNlKSxcblx0XHRuYW1lOiBnZXRJbnN0YW5jZU5hbWUoaW5zdGFuY2UpLFxuXHRcdGZpbGU6IGluc3RhbmNlPy50eXBlPy5fX2ZpbGUsXG5cdFx0c3RhdGU6IHByb2Nlc3NJbnN0YW5jZVN0YXRlKGluc3RhbmNlKSxcblx0XHRpbnN0YW5jZVxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvY29tcG9uZW50L3RyZWUvZmlsdGVyLnRzXG52YXIgQ29tcG9uZW50RmlsdGVyID0gY2xhc3Mge1xuXHRjb25zdHJ1Y3RvcihmaWx0ZXIpIHtcblx0XHR0aGlzLmZpbHRlciA9IGZpbHRlciB8fCBcIlwiO1xuXHR9XG5cdC8qKlxuXHQqIENoZWNrIGlmIGFuIGluc3RhbmNlIGlzIHF1YWxpZmllZC5cblx0KlxuXHQqIEBwYXJhbSB7VnVlfFZub2RlfSBpbnN0YW5jZVxuXHQqIEByZXR1cm4ge2Jvb2xlYW59XG5cdCovXG5cdGlzUXVhbGlmaWVkKGluc3RhbmNlKSB7XG5cdFx0Y29uc3QgbmFtZSA9IGdldEluc3RhbmNlTmFtZShpbnN0YW5jZSk7XG5cdFx0cmV0dXJuIGNsYXNzaWZ5KG5hbWUpLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXModGhpcy5maWx0ZXIpIHx8IGtlYmFiaXplKG5hbWUpLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXModGhpcy5maWx0ZXIpO1xuXHR9XG59O1xuZnVuY3Rpb24gY3JlYXRlQ29tcG9uZW50RmlsdGVyKGZpbHRlclRleHQpIHtcblx0cmV0dXJuIG5ldyBDb21wb25lbnRGaWx0ZXIoZmlsdGVyVGV4dCk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9jb21wb25lbnQvdHJlZS93YWxrZXIudHNcbnZhciBDb21wb25lbnRXYWxrZXIgPSBjbGFzcyB7XG5cdGNvbnN0cnVjdG9yKG9wdGlvbnMpIHtcblx0XHR0aGlzLmNhcHR1cmVJZHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHRcdGNvbnN0IHsgZmlsdGVyVGV4dCA9IFwiXCIsIG1heERlcHRoLCByZWN1cnNpdmVseSwgYXBpIH0gPSBvcHRpb25zO1xuXHRcdHRoaXMuY29tcG9uZW50RmlsdGVyID0gY3JlYXRlQ29tcG9uZW50RmlsdGVyKGZpbHRlclRleHQpO1xuXHRcdHRoaXMubWF4RGVwdGggPSBtYXhEZXB0aDtcblx0XHR0aGlzLnJlY3Vyc2l2ZWx5ID0gcmVjdXJzaXZlbHk7XG5cdFx0dGhpcy5hcGkgPSBhcGk7XG5cdH1cblx0Z2V0Q29tcG9uZW50VHJlZShpbnN0YW5jZSkge1xuXHRcdHRoaXMuY2FwdHVyZUlkcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdFx0cmV0dXJuIHRoaXMuZmluZFF1YWxpZmllZENoaWxkcmVuKGluc3RhbmNlLCAwKTtcblx0fVxuXHRnZXRDb21wb25lbnRQYXJlbnRzKGluc3RhbmNlKSB7XG5cdFx0dGhpcy5jYXB0dXJlSWRzID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0XHRjb25zdCBwYXJlbnRzID0gW107XG5cdFx0dGhpcy5jYXB0dXJlSWQoaW5zdGFuY2UpO1xuXHRcdGxldCBwYXJlbnQgPSBpbnN0YW5jZTtcblx0XHR3aGlsZSAocGFyZW50ID0gcGFyZW50LnBhcmVudCkge1xuXHRcdFx0dGhpcy5jYXB0dXJlSWQocGFyZW50KTtcblx0XHRcdHBhcmVudHMucHVzaChwYXJlbnQpO1xuXHRcdH1cblx0XHRyZXR1cm4gcGFyZW50cztcblx0fVxuXHRjYXB0dXJlSWQoaW5zdGFuY2UpIHtcblx0XHRpZiAoIWluc3RhbmNlKSByZXR1cm4gbnVsbDtcblx0XHRjb25zdCBpZCA9IGluc3RhbmNlLl9fVlVFX0RFVlRPT0xTX05FWFRfVUlEX18gIT0gbnVsbCA/IGluc3RhbmNlLl9fVlVFX0RFVlRPT0xTX05FWFRfVUlEX18gOiBnZXRVbmlxdWVDb21wb25lbnRJZChpbnN0YW5jZSk7XG5cdFx0aW5zdGFuY2UuX19WVUVfREVWVE9PTFNfTkVYVF9VSURfXyA9IGlkO1xuXHRcdGlmICh0aGlzLmNhcHR1cmVJZHMuaGFzKGlkKSkgcmV0dXJuIG51bGw7XG5cdFx0ZWxzZSB0aGlzLmNhcHR1cmVJZHMuc2V0KGlkLCB2b2lkIDApO1xuXHRcdHRoaXMubWFyayhpbnN0YW5jZSk7XG5cdFx0cmV0dXJuIGlkO1xuXHR9XG5cdC8qKlxuXHQqIENhcHR1cmUgdGhlIG1ldGEgaW5mb3JtYXRpb24gb2YgYW4gaW5zdGFuY2UuIChyZWN1cnNpdmUpXG5cdCpcblx0KiBAcGFyYW0ge1Z1ZX0gaW5zdGFuY2Vcblx0KiBAcmV0dXJuIHtvYmplY3R9XG5cdCovXG5cdGFzeW5jIGNhcHR1cmUoaW5zdGFuY2UsIGRlcHRoKSB7XG5cdFx0aWYgKCFpbnN0YW5jZSkgcmV0dXJuIG51bGw7XG5cdFx0Y29uc3QgaWQgPSB0aGlzLmNhcHR1cmVJZChpbnN0YW5jZSk7XG5cdFx0Y29uc3QgbmFtZSA9IGdldEluc3RhbmNlTmFtZShpbnN0YW5jZSk7XG5cdFx0Y29uc3QgY2hpbGRyZW4gPSB0aGlzLmdldEludGVybmFsSW5zdGFuY2VDaGlsZHJlbihpbnN0YW5jZS5zdWJUcmVlKS5maWx0ZXIoKGNoaWxkKSA9PiAhaXNCZWluZ0Rlc3Ryb3llZChjaGlsZCkpO1xuXHRcdGNvbnN0IHBhcmVudHMgPSB0aGlzLmdldENvbXBvbmVudFBhcmVudHMoaW5zdGFuY2UpIHx8IFtdO1xuXHRcdGNvbnN0IGluYWN0aXZlID0gISFpbnN0YW5jZS5pc0RlYWN0aXZhdGVkIHx8IHBhcmVudHMuc29tZSgocGFyZW50KSA9PiBwYXJlbnQuaXNEZWFjdGl2YXRlZCk7XG5cdFx0Y29uc3QgdHJlZU5vZGUgPSB7XG5cdFx0XHR1aWQ6IGluc3RhbmNlLnVpZCxcblx0XHRcdGlkLFxuXHRcdFx0bmFtZSxcblx0XHRcdHJlbmRlcktleTogZ2V0UmVuZGVyS2V5KGluc3RhbmNlLnZub2RlID8gaW5zdGFuY2Uudm5vZGUua2V5IDogbnVsbCksXG5cdFx0XHRpbmFjdGl2ZSxcblx0XHRcdGNoaWxkcmVuOiBbXSxcblx0XHRcdGhhc0NoaWxkcmVuOiAhIWNoaWxkcmVuLmxlbmd0aCxcblx0XHRcdGlzRnJhZ21lbnQ6IGlzRnJhZ21lbnQoaW5zdGFuY2UpLFxuXHRcdFx0dGFnczogdHlwZW9mIGluc3RhbmNlLnR5cGUgIT09IFwiZnVuY3Rpb25cIiA/IFtdIDogW3tcblx0XHRcdFx0bGFiZWw6IFwiZnVuY3Rpb25hbFwiLFxuXHRcdFx0XHR0ZXh0Q29sb3I6IDU1OTI0MDUsXG5cdFx0XHRcdGJhY2tncm91bmRDb2xvcjogMTU2NTg3MzRcblx0XHRcdH1dLFxuXHRcdFx0YXV0b09wZW46IHRoaXMucmVjdXJzaXZlbHksXG5cdFx0XHRmaWxlOiBpbnN0YW5jZS50eXBlLl9fZmlsZSB8fCBcIlwiXG5cdFx0fTtcblx0XHRpZiAoZGVwdGggPCB0aGlzLm1heERlcHRoIHx8IGluc3RhbmNlLnR5cGUuX19pc0tlZXBBbGl2ZSB8fCBwYXJlbnRzLnNvbWUoKHBhcmVudCkgPT4gcGFyZW50LnR5cGUuX19pc0tlZXBBbGl2ZSkpIHRyZWVOb2RlLmNoaWxkcmVuID0gYXdhaXQgUHJvbWlzZS5hbGwoY2hpbGRyZW4ubWFwKChjaGlsZCkgPT4gdGhpcy5jYXB0dXJlKGNoaWxkLCBkZXB0aCArIDEpKS5maWx0ZXIoQm9vbGVhbikpO1xuXHRcdGlmICh0aGlzLmlzS2VlcEFsaXZlKGluc3RhbmNlKSkge1xuXHRcdFx0Y29uc3QgY2FjaGVkQ29tcG9uZW50cyA9IHRoaXMuZ2V0S2VlcEFsaXZlQ2FjaGVkSW5zdGFuY2VzKGluc3RhbmNlKTtcblx0XHRcdGNvbnN0IGNoaWxkcmVuSWRzID0gY2hpbGRyZW4ubWFwKChjaGlsZCkgPT4gY2hpbGQuX19WVUVfREVWVE9PTFNfTkVYVF9VSURfXyk7XG5cdFx0XHRmb3IgKGNvbnN0IGNhY2hlZENoaWxkIG9mIGNhY2hlZENvbXBvbmVudHMpIGlmICghY2hpbGRyZW5JZHMuaW5jbHVkZXMoY2FjaGVkQ2hpbGQuX19WVUVfREVWVE9PTFNfTkVYVF9VSURfXykpIHtcblx0XHRcdFx0Y29uc3Qgbm9kZSA9IGF3YWl0IHRoaXMuY2FwdHVyZSh7XG5cdFx0XHRcdFx0Li4uY2FjaGVkQ2hpbGQsXG5cdFx0XHRcdFx0aXNEZWFjdGl2YXRlZDogdHJ1ZVxuXHRcdFx0XHR9LCBkZXB0aCArIDEpO1xuXHRcdFx0XHRpZiAobm9kZSkgdHJlZU5vZGUuY2hpbGRyZW4ucHVzaChub2RlKTtcblx0XHRcdH1cblx0XHR9XG5cdFx0Y29uc3QgZmlyc3RFbGVtZW50ID0gZ2V0Um9vdEVsZW1lbnRzRnJvbUNvbXBvbmVudEluc3RhbmNlKGluc3RhbmNlKVswXTtcblx0XHRpZiAoZmlyc3RFbGVtZW50Py5wYXJlbnRFbGVtZW50KSB7XG5cdFx0XHRjb25zdCBwYXJlbnRJbnN0YW5jZSA9IGluc3RhbmNlLnBhcmVudDtcblx0XHRcdGNvbnN0IHBhcmVudFJvb3RFbGVtZW50cyA9IHBhcmVudEluc3RhbmNlID8gZ2V0Um9vdEVsZW1lbnRzRnJvbUNvbXBvbmVudEluc3RhbmNlKHBhcmVudEluc3RhbmNlKSA6IFtdO1xuXHRcdFx0bGV0IGVsID0gZmlyc3RFbGVtZW50O1xuXHRcdFx0Y29uc3QgaW5kZXhMaXN0ID0gW107XG5cdFx0XHRkbyB7XG5cdFx0XHRcdGluZGV4TGlzdC5wdXNoKEFycmF5LmZyb20oZWwucGFyZW50RWxlbWVudC5jaGlsZE5vZGVzKS5pbmRleE9mKGVsKSk7XG5cdFx0XHRcdGVsID0gZWwucGFyZW50RWxlbWVudDtcblx0XHRcdH0gd2hpbGUgKGVsLnBhcmVudEVsZW1lbnQgJiYgcGFyZW50Um9vdEVsZW1lbnRzLmxlbmd0aCAmJiAhcGFyZW50Um9vdEVsZW1lbnRzLmluY2x1ZGVzKGVsKSk7XG5cdFx0XHR0cmVlTm9kZS5kb21PcmRlciA9IGluZGV4TGlzdC5yZXZlcnNlKCk7XG5cdFx0fSBlbHNlIHRyZWVOb2RlLmRvbU9yZGVyID0gWy0xXTtcblx0XHRpZiAoaW5zdGFuY2Uuc3VzcGVuc2U/LnN1c3BlbnNlS2V5KSB7XG5cdFx0XHR0cmVlTm9kZS50YWdzLnB1c2goe1xuXHRcdFx0XHRsYWJlbDogaW5zdGFuY2Uuc3VzcGVuc2Uuc3VzcGVuc2VLZXksXG5cdFx0XHRcdGJhY2tncm91bmRDb2xvcjogMTQ5Nzk4MTIsXG5cdFx0XHRcdHRleHRDb2xvcjogMTY3NzcyMTVcblx0XHRcdH0pO1xuXHRcdFx0dGhpcy5tYXJrKGluc3RhbmNlLCB0cnVlKTtcblx0XHR9XG5cdFx0dGhpcy5hcGkudmlzaXRDb21wb25lbnRUcmVlKHtcblx0XHRcdHRyZWVOb2RlLFxuXHRcdFx0Y29tcG9uZW50SW5zdGFuY2U6IGluc3RhbmNlLFxuXHRcdFx0YXBwOiBpbnN0YW5jZS5hcHBDb250ZXh0LmFwcCxcblx0XHRcdGZpbHRlcjogdGhpcy5jb21wb25lbnRGaWx0ZXIuZmlsdGVyXG5cdFx0fSk7XG5cdFx0cmV0dXJuIHRyZWVOb2RlO1xuXHR9XG5cdC8qKlxuXHQqIEZpbmQgcXVhbGlmaWVkIGNoaWxkcmVuIGZyb20gYSBzaW5nbGUgaW5zdGFuY2UuXG5cdCogSWYgdGhlIGluc3RhbmNlIGl0c2VsZiBpcyBxdWFsaWZpZWQsIGp1c3QgcmV0dXJuIGl0c2VsZi5cblx0KiBUaGlzIGlzIG9rIGJlY2F1c2UgW10uY29uY2F0IHdvcmtzIGluIGJvdGggY2FzZXMuXG5cdCpcblx0KiBAcGFyYW0ge1Z1ZXxWbm9kZX0gaW5zdGFuY2Vcblx0KiBAcmV0dXJuIHtWdWV8QXJyYXl9XG5cdCovXG5cdGFzeW5jIGZpbmRRdWFsaWZpZWRDaGlsZHJlbihpbnN0YW5jZSwgZGVwdGgpIHtcblx0XHRpZiAodGhpcy5jb21wb25lbnRGaWx0ZXIuaXNRdWFsaWZpZWQoaW5zdGFuY2UpICYmICFpbnN0YW5jZS50eXBlLmRldnRvb2xzPy5oaWRlKSByZXR1cm4gW2F3YWl0IHRoaXMuY2FwdHVyZShpbnN0YW5jZSwgZGVwdGgpXTtcblx0XHRlbHNlIGlmIChpbnN0YW5jZS5zdWJUcmVlKSB7XG5cdFx0XHRjb25zdCBsaXN0ID0gdGhpcy5pc0tlZXBBbGl2ZShpbnN0YW5jZSkgPyB0aGlzLmdldEtlZXBBbGl2ZUNhY2hlZEluc3RhbmNlcyhpbnN0YW5jZSkgOiB0aGlzLmdldEludGVybmFsSW5zdGFuY2VDaGlsZHJlbihpbnN0YW5jZS5zdWJUcmVlKTtcblx0XHRcdHJldHVybiB0aGlzLmZpbmRRdWFsaWZpZWRDaGlsZHJlbkZyb21MaXN0KGxpc3QsIGRlcHRoKTtcblx0XHR9IGVsc2UgcmV0dXJuIFtdO1xuXHR9XG5cdC8qKlxuXHQqIEl0ZXJhdGUgdGhyb3VnaCBhbiBhcnJheSBvZiBpbnN0YW5jZXMgYW5kIGZsYXR0ZW4gaXQgaW50b1xuXHQqIGFuIGFycmF5IG9mIHF1YWxpZmllZCBpbnN0YW5jZXMuIFRoaXMgaXMgYSBkZXB0aC1maXJzdFxuXHQqIHRyYXZlcnNhbCAtIGUuZy4gaWYgYW4gaW5zdGFuY2UgaXMgbm90IG1hdGNoZWQsIHdlIHdpbGxcblx0KiByZWN1cnNpdmVseSBnbyBkZWVwZXIgdW50aWwgYSBxdWFsaWZpZWQgY2hpbGQgaXMgZm91bmQuXG5cdCpcblx0KiBAcGFyYW0ge0FycmF5fSBpbnN0YW5jZXNcblx0KiBAcmV0dXJuIHtBcnJheX1cblx0Ki9cblx0YXN5bmMgZmluZFF1YWxpZmllZENoaWxkcmVuRnJvbUxpc3QoaW5zdGFuY2VzLCBkZXB0aCkge1xuXHRcdGluc3RhbmNlcyA9IGluc3RhbmNlcy5maWx0ZXIoKGNoaWxkKSA9PiAhaXNCZWluZ0Rlc3Ryb3llZChjaGlsZCkgJiYgIWNoaWxkLnR5cGUuZGV2dG9vbHM/LmhpZGUpO1xuXHRcdGlmICghdGhpcy5jb21wb25lbnRGaWx0ZXIuZmlsdGVyKSByZXR1cm4gUHJvbWlzZS5hbGwoaW5zdGFuY2VzLm1hcCgoY2hpbGQpID0+IHRoaXMuY2FwdHVyZShjaGlsZCwgZGVwdGgpKSk7XG5cdFx0ZWxzZSByZXR1cm4gQXJyYXkucHJvdG90eXBlLmNvbmNhdC5hcHBseShbXSwgYXdhaXQgUHJvbWlzZS5hbGwoaW5zdGFuY2VzLm1hcCgoaSkgPT4gdGhpcy5maW5kUXVhbGlmaWVkQ2hpbGRyZW4oaSwgZGVwdGgpKSkpO1xuXHR9XG5cdC8qKlxuXHQqIEdldCBjaGlsZHJlbiBmcm9tIGEgY29tcG9uZW50IGluc3RhbmNlLlxuXHQqL1xuXHRnZXRJbnRlcm5hbEluc3RhbmNlQ2hpbGRyZW4oc3ViVHJlZSwgc3VzcGVuc2UgPSBudWxsKSB7XG5cdFx0Y29uc3QgbGlzdCA9IFtdO1xuXHRcdGlmIChzdWJUcmVlKSB7XG5cdFx0XHRpZiAoc3ViVHJlZS5jb21wb25lbnQpICFzdXNwZW5zZSA/IGxpc3QucHVzaChzdWJUcmVlLmNvbXBvbmVudCkgOiBsaXN0LnB1c2goe1xuXHRcdFx0XHQuLi5zdWJUcmVlLmNvbXBvbmVudCxcblx0XHRcdFx0c3VzcGVuc2Vcblx0XHRcdH0pO1xuXHRcdFx0ZWxzZSBpZiAoc3ViVHJlZS5zdXNwZW5zZSkge1xuXHRcdFx0XHRjb25zdCBzdXNwZW5zZUtleSA9ICFzdWJUcmVlLnN1c3BlbnNlLmlzSW5GYWxsYmFjayA/IFwic3VzcGVuc2UgZGVmYXVsdFwiIDogXCJzdXNwZW5zZSBmYWxsYmFja1wiO1xuXHRcdFx0XHRsaXN0LnB1c2goLi4udGhpcy5nZXRJbnRlcm5hbEluc3RhbmNlQ2hpbGRyZW4oc3ViVHJlZS5zdXNwZW5zZS5hY3RpdmVCcmFuY2gsIHtcblx0XHRcdFx0XHQuLi5zdWJUcmVlLnN1c3BlbnNlLFxuXHRcdFx0XHRcdHN1c3BlbnNlS2V5XG5cdFx0XHRcdH0pKTtcblx0XHRcdH0gZWxzZSBpZiAoQXJyYXkuaXNBcnJheShzdWJUcmVlLmNoaWxkcmVuKSkgc3ViVHJlZS5jaGlsZHJlbi5mb3JFYWNoKChjaGlsZFN1YlRyZWUpID0+IHtcblx0XHRcdFx0aWYgKGNoaWxkU3ViVHJlZS5jb21wb25lbnQpICFzdXNwZW5zZSA/IGxpc3QucHVzaChjaGlsZFN1YlRyZWUuY29tcG9uZW50KSA6IGxpc3QucHVzaCh7XG5cdFx0XHRcdFx0Li4uY2hpbGRTdWJUcmVlLmNvbXBvbmVudCxcblx0XHRcdFx0XHRzdXNwZW5zZVxuXHRcdFx0XHR9KTtcblx0XHRcdFx0ZWxzZSBsaXN0LnB1c2goLi4udGhpcy5nZXRJbnRlcm5hbEluc3RhbmNlQ2hpbGRyZW4oY2hpbGRTdWJUcmVlLCBzdXNwZW5zZSkpO1xuXHRcdFx0fSk7XG5cdFx0fVxuXHRcdHJldHVybiBsaXN0LmZpbHRlcigoY2hpbGQpID0+ICFpc0JlaW5nRGVzdHJveWVkKGNoaWxkKSAmJiAhY2hpbGQudHlwZS5kZXZ0b29scz8uaGlkZSk7XG5cdH1cblx0LyoqXG5cdCogTWFyayBhbiBpbnN0YW5jZSBhcyBjYXB0dXJlZCBhbmQgc3RvcmUgaXQgaW4gdGhlIGluc3RhbmNlIG1hcC5cblx0KlxuXHQqIEBwYXJhbSB7VnVlfSBpbnN0YW5jZVxuXHQqL1xuXHRtYXJrKGluc3RhbmNlLCBmb3JjZSA9IGZhbHNlKSB7XG5cdFx0Y29uc3QgaW5zdGFuY2VNYXAgPSBnZXRBcHBSZWNvcmQoaW5zdGFuY2UpLmluc3RhbmNlTWFwO1xuXHRcdGlmIChmb3JjZSB8fCAhaW5zdGFuY2VNYXAuaGFzKGluc3RhbmNlLl9fVlVFX0RFVlRPT0xTX05FWFRfVUlEX18pKSB7XG5cdFx0XHRpbnN0YW5jZU1hcC5zZXQoaW5zdGFuY2UuX19WVUVfREVWVE9PTFNfTkVYVF9VSURfXywgaW5zdGFuY2UpO1xuXHRcdFx0YWN0aXZlQXBwUmVjb3JkLnZhbHVlLmluc3RhbmNlTWFwID0gaW5zdGFuY2VNYXA7XG5cdFx0fVxuXHR9XG5cdGlzS2VlcEFsaXZlKGluc3RhbmNlKSB7XG5cdFx0cmV0dXJuIGluc3RhbmNlLnR5cGUuX19pc0tlZXBBbGl2ZSAmJiBpbnN0YW5jZS5fX3ZfY2FjaGU7XG5cdH1cblx0Z2V0S2VlcEFsaXZlQ2FjaGVkSW5zdGFuY2VzKGluc3RhbmNlKSB7XG5cdFx0cmV0dXJuIEFycmF5LmZyb20oaW5zdGFuY2UuX192X2NhY2hlLnZhbHVlcygpKS5tYXAoKHZub2RlKSA9PiB2bm9kZS5jb21wb25lbnQpLmZpbHRlcihCb29sZWFuKTtcblx0fVxufTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL3RpbWVsaW5lL3BlcmYudHNcbmNvbnN0IG1hcmtFbmRRdWV1ZSA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5jb25zdCBQRVJGT1JNQU5DRV9FVkVOVF9MQVlFUl9JRCA9IFwicGVyZm9ybWFuY2VcIjtcbmFzeW5jIGZ1bmN0aW9uIHBlcmZvcm1hbmNlTWFya1N0YXJ0KGFwaSwgYXBwLCB1aWQsIHZtLCB0eXBlLCB0aW1lKSB7XG5cdGNvbnN0IGFwcFJlY29yZCA9IGF3YWl0IGdldEFwcFJlY29yZChhcHApO1xuXHRpZiAoIWFwcFJlY29yZCkgcmV0dXJuO1xuXHRjb25zdCBjb21wb25lbnROYW1lID0gZ2V0SW5zdGFuY2VOYW1lKHZtKSB8fCBcIlVua25vd24gQ29tcG9uZW50XCI7XG5cdGNvbnN0IGdyb3VwSWQgPSBkZXZ0b29sc1N0YXRlLnBlcmZVbmlxdWVHcm91cElkKys7XG5cdGNvbnN0IGdyb3VwS2V5ID0gYCR7dWlkfS0ke3R5cGV9YDtcblx0YXBwUmVjb3JkLnBlcmZHcm91cElkcy5zZXQoZ3JvdXBLZXksIHtcblx0XHRncm91cElkLFxuXHRcdHRpbWVcblx0fSk7XG5cdGF3YWl0IGFwaS5hZGRUaW1lbGluZUV2ZW50KHtcblx0XHRsYXllcklkOiBQRVJGT1JNQU5DRV9FVkVOVF9MQVlFUl9JRCxcblx0XHRldmVudDoge1xuXHRcdFx0dGltZTogRGF0ZS5ub3coKSxcblx0XHRcdGRhdGE6IHtcblx0XHRcdFx0Y29tcG9uZW50OiBjb21wb25lbnROYW1lLFxuXHRcdFx0XHR0eXBlLFxuXHRcdFx0XHRtZWFzdXJlOiBcInN0YXJ0XCJcblx0XHRcdH0sXG5cdFx0XHR0aXRsZTogY29tcG9uZW50TmFtZSxcblx0XHRcdHN1YnRpdGxlOiB0eXBlLFxuXHRcdFx0Z3JvdXBJZFxuXHRcdH1cblx0fSk7XG5cdGlmIChtYXJrRW5kUXVldWUuaGFzKGdyb3VwS2V5KSkge1xuXHRcdGNvbnN0IHsgYXBwLCB1aWQsIGluc3RhbmNlLCB0eXBlLCB0aW1lIH0gPSBtYXJrRW5kUXVldWUuZ2V0KGdyb3VwS2V5KTtcblx0XHRtYXJrRW5kUXVldWUuZGVsZXRlKGdyb3VwS2V5KTtcblx0XHRhd2FpdCBwZXJmb3JtYW5jZU1hcmtFbmQoYXBpLCBhcHAsIHVpZCwgaW5zdGFuY2UsIHR5cGUsIHRpbWUpO1xuXHR9XG59XG5mdW5jdGlvbiBwZXJmb3JtYW5jZU1hcmtFbmQoYXBpLCBhcHAsIHVpZCwgdm0sIHR5cGUsIHRpbWUpIHtcblx0Y29uc3QgYXBwUmVjb3JkID0gZ2V0QXBwUmVjb3JkKGFwcCk7XG5cdGlmICghYXBwUmVjb3JkKSByZXR1cm47XG5cdGNvbnN0IGNvbXBvbmVudE5hbWUgPSBnZXRJbnN0YW5jZU5hbWUodm0pIHx8IFwiVW5rbm93biBDb21wb25lbnRcIjtcblx0Y29uc3QgZ3JvdXBLZXkgPSBgJHt1aWR9LSR7dHlwZX1gO1xuXHRjb25zdCBncm91cEluZm8gPSBhcHBSZWNvcmQucGVyZkdyb3VwSWRzLmdldChncm91cEtleSk7XG5cdGlmIChncm91cEluZm8pIHtcblx0XHRjb25zdCBncm91cElkID0gZ3JvdXBJbmZvLmdyb3VwSWQ7XG5cdFx0Y29uc3QgZHVyYXRpb24gPSB0aW1lIC0gZ3JvdXBJbmZvLnRpbWU7XG5cdFx0YXBpLmFkZFRpbWVsaW5lRXZlbnQoe1xuXHRcdFx0bGF5ZXJJZDogUEVSRk9STUFOQ0VfRVZFTlRfTEFZRVJfSUQsXG5cdFx0XHRldmVudDoge1xuXHRcdFx0XHR0aW1lOiBEYXRlLm5vdygpLFxuXHRcdFx0XHRkYXRhOiB7XG5cdFx0XHRcdFx0Y29tcG9uZW50OiBjb21wb25lbnROYW1lLFxuXHRcdFx0XHRcdHR5cGUsXG5cdFx0XHRcdFx0bWVhc3VyZTogXCJlbmRcIixcblx0XHRcdFx0XHRkdXJhdGlvbjogeyBfY3VzdG9tOiB7XG5cdFx0XHRcdFx0XHR0eXBlOiBcIkR1cmF0aW9uXCIsXG5cdFx0XHRcdFx0XHR2YWx1ZTogZHVyYXRpb24sXG5cdFx0XHRcdFx0XHRkaXNwbGF5OiBgJHtkdXJhdGlvbn0gbXNgXG5cdFx0XHRcdFx0fSB9XG5cdFx0XHRcdH0sXG5cdFx0XHRcdHRpdGxlOiBjb21wb25lbnROYW1lLFxuXHRcdFx0XHRzdWJ0aXRsZTogdHlwZSxcblx0XHRcdFx0Z3JvdXBJZFxuXHRcdFx0fVxuXHRcdH0pO1xuXHR9IGVsc2UgbWFya0VuZFF1ZXVlLnNldChncm91cEtleSwge1xuXHRcdGFwcCxcblx0XHR1aWQsXG5cdFx0aW5zdGFuY2U6IHZtLFxuXHRcdHR5cGUsXG5cdFx0dGltZVxuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL3RpbWVsaW5lL2luZGV4LnRzXG5jb25zdCBDT01QT05FTlRfRVZFTlRfTEFZRVJfSUQgPSBcImNvbXBvbmVudC1ldmVudFwiO1xuZnVuY3Rpb24gc2V0dXBCdWlsdGluVGltZWxpbmVMYXllcnMoYXBpKSB7XG5cdGlmICghaXNCcm93c2VyKSByZXR1cm47XG5cdGFwaS5hZGRUaW1lbGluZUxheWVyKHtcblx0XHRpZDogXCJtb3VzZVwiLFxuXHRcdGxhYmVsOiBcIk1vdXNlXCIsXG5cdFx0Y29sb3I6IDEwNzY4ODE1XG5cdH0pO1xuXHRbXG5cdFx0XCJtb3VzZWRvd25cIixcblx0XHRcIm1vdXNldXBcIixcblx0XHRcImNsaWNrXCIsXG5cdFx0XCJkYmxjbGlja1wiXG5cdF0uZm9yRWFjaCgoZXZlbnRUeXBlKSA9PiB7XG5cdFx0aWYgKCFkZXZ0b29sc1N0YXRlLnRpbWVsaW5lTGF5ZXJzU3RhdGUucmVjb3JkaW5nU3RhdGUgfHwgIWRldnRvb2xzU3RhdGUudGltZWxpbmVMYXllcnNTdGF0ZS5tb3VzZUV2ZW50RW5hYmxlZCkgcmV0dXJuO1xuXHRcdHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKGV2ZW50VHlwZSwgYXN5bmMgKGV2ZW50KSA9PiB7XG5cdFx0XHRhd2FpdCBhcGkuYWRkVGltZWxpbmVFdmVudCh7XG5cdFx0XHRcdGxheWVySWQ6IFwibW91c2VcIixcblx0XHRcdFx0ZXZlbnQ6IHtcblx0XHRcdFx0XHR0aW1lOiBEYXRlLm5vdygpLFxuXHRcdFx0XHRcdGRhdGE6IHtcblx0XHRcdFx0XHRcdHR5cGU6IGV2ZW50VHlwZSxcblx0XHRcdFx0XHRcdHg6IGV2ZW50LmNsaWVudFgsXG5cdFx0XHRcdFx0XHR5OiBldmVudC5jbGllbnRZXG5cdFx0XHRcdFx0fSxcblx0XHRcdFx0XHR0aXRsZTogZXZlbnRUeXBlXG5cdFx0XHRcdH1cblx0XHRcdH0pO1xuXHRcdH0sIHtcblx0XHRcdGNhcHR1cmU6IHRydWUsXG5cdFx0XHRwYXNzaXZlOiB0cnVlXG5cdFx0fSk7XG5cdH0pO1xuXHRhcGkuYWRkVGltZWxpbmVMYXllcih7XG5cdFx0aWQ6IFwia2V5Ym9hcmRcIixcblx0XHRsYWJlbDogXCJLZXlib2FyZFwiLFxuXHRcdGNvbG9yOiA4NDc1MDU1XG5cdH0pO1xuXHRbXG5cdFx0XCJrZXl1cFwiLFxuXHRcdFwia2V5ZG93blwiLFxuXHRcdFwia2V5cHJlc3NcIlxuXHRdLmZvckVhY2goKGV2ZW50VHlwZSkgPT4ge1xuXHRcdHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKGV2ZW50VHlwZSwgYXN5bmMgKGV2ZW50KSA9PiB7XG5cdFx0XHRpZiAoIWRldnRvb2xzU3RhdGUudGltZWxpbmVMYXllcnNTdGF0ZS5yZWNvcmRpbmdTdGF0ZSB8fCAhZGV2dG9vbHNTdGF0ZS50aW1lbGluZUxheWVyc1N0YXRlLmtleWJvYXJkRXZlbnRFbmFibGVkKSByZXR1cm47XG5cdFx0XHRhd2FpdCBhcGkuYWRkVGltZWxpbmVFdmVudCh7XG5cdFx0XHRcdGxheWVySWQ6IFwia2V5Ym9hcmRcIixcblx0XHRcdFx0ZXZlbnQ6IHtcblx0XHRcdFx0XHR0aW1lOiBEYXRlLm5vdygpLFxuXHRcdFx0XHRcdGRhdGE6IHtcblx0XHRcdFx0XHRcdHR5cGU6IGV2ZW50VHlwZSxcblx0XHRcdFx0XHRcdGtleTogZXZlbnQua2V5LFxuXHRcdFx0XHRcdFx0Y3RybEtleTogZXZlbnQuY3RybEtleSxcblx0XHRcdFx0XHRcdHNoaWZ0S2V5OiBldmVudC5zaGlmdEtleSxcblx0XHRcdFx0XHRcdGFsdEtleTogZXZlbnQuYWx0S2V5LFxuXHRcdFx0XHRcdFx0bWV0YUtleTogZXZlbnQubWV0YUtleVxuXHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0dGl0bGU6IGV2ZW50LmtleVxuXHRcdFx0XHR9XG5cdFx0XHR9KTtcblx0XHR9LCB7XG5cdFx0XHRjYXB0dXJlOiB0cnVlLFxuXHRcdFx0cGFzc2l2ZTogdHJ1ZVxuXHRcdH0pO1xuXHR9KTtcblx0YXBpLmFkZFRpbWVsaW5lTGF5ZXIoe1xuXHRcdGlkOiBDT01QT05FTlRfRVZFTlRfTEFZRVJfSUQsXG5cdFx0bGFiZWw6IFwiQ29tcG9uZW50IGV2ZW50c1wiLFxuXHRcdGNvbG9yOiA1MjI2NjM3XG5cdH0pO1xuXHRob29rLm9uLmNvbXBvbmVudEVtaXQoYXN5bmMgKGFwcCwgaW5zdGFuY2UsIGV2ZW50LCBwYXJhbXMpID0+IHtcblx0XHRpZiAoIWRldnRvb2xzU3RhdGUudGltZWxpbmVMYXllcnNTdGF0ZS5yZWNvcmRpbmdTdGF0ZSB8fCAhZGV2dG9vbHNTdGF0ZS50aW1lbGluZUxheWVyc1N0YXRlLmNvbXBvbmVudEV2ZW50RW5hYmxlZCkgcmV0dXJuO1xuXHRcdGNvbnN0IGFwcFJlY29yZCA9IGF3YWl0IGdldEFwcFJlY29yZChhcHApO1xuXHRcdGlmICghYXBwUmVjb3JkKSByZXR1cm47XG5cdFx0Y29uc3QgY29tcG9uZW50SWQgPSBgJHthcHBSZWNvcmQuaWR9OiR7aW5zdGFuY2UudWlkfWA7XG5cdFx0Y29uc3QgY29tcG9uZW50TmFtZSA9IGdldEluc3RhbmNlTmFtZShpbnN0YW5jZSkgfHwgXCJVbmtub3duIENvbXBvbmVudFwiO1xuXHRcdGFwaS5hZGRUaW1lbGluZUV2ZW50KHtcblx0XHRcdGxheWVySWQ6IENPTVBPTkVOVF9FVkVOVF9MQVlFUl9JRCxcblx0XHRcdGV2ZW50OiB7XG5cdFx0XHRcdHRpbWU6IERhdGUubm93KCksXG5cdFx0XHRcdGRhdGE6IHtcblx0XHRcdFx0XHRjb21wb25lbnQ6IHsgX2N1c3RvbToge1xuXHRcdFx0XHRcdFx0dHlwZTogXCJjb21wb25lbnQtZGVmaW5pdGlvblwiLFxuXHRcdFx0XHRcdFx0ZGlzcGxheTogY29tcG9uZW50TmFtZVxuXHRcdFx0XHRcdH0gfSxcblx0XHRcdFx0XHRldmVudCxcblx0XHRcdFx0XHRwYXJhbXNcblx0XHRcdFx0fSxcblx0XHRcdFx0dGl0bGU6IGV2ZW50LFxuXHRcdFx0XHRzdWJ0aXRsZTogYGJ5ICR7Y29tcG9uZW50TmFtZX1gLFxuXHRcdFx0XHRtZXRhOiB7IGNvbXBvbmVudElkIH1cblx0XHRcdH1cblx0XHR9KTtcblx0fSk7XG5cdGFwaS5hZGRUaW1lbGluZUxheWVyKHtcblx0XHRpZDogXCJwZXJmb3JtYW5jZVwiLFxuXHRcdGxhYmVsOiBQRVJGT1JNQU5DRV9FVkVOVF9MQVlFUl9JRCxcblx0XHRjb2xvcjogNDMwNzA1MFxuXHR9KTtcblx0aG9vay5vbi5wZXJmU3RhcnQoKGFwcCwgdWlkLCB2bSwgdHlwZSwgdGltZSkgPT4ge1xuXHRcdGlmICghZGV2dG9vbHNTdGF0ZS50aW1lbGluZUxheWVyc1N0YXRlLnJlY29yZGluZ1N0YXRlIHx8ICFkZXZ0b29sc1N0YXRlLnRpbWVsaW5lTGF5ZXJzU3RhdGUucGVyZm9ybWFuY2VFdmVudEVuYWJsZWQpIHJldHVybjtcblx0XHRwZXJmb3JtYW5jZU1hcmtTdGFydChhcGksIGFwcCwgdWlkLCB2bSwgdHlwZSwgdGltZSk7XG5cdH0pO1xuXHRob29rLm9uLnBlcmZFbmQoKGFwcCwgdWlkLCB2bSwgdHlwZSwgdGltZSkgPT4ge1xuXHRcdGlmICghZGV2dG9vbHNTdGF0ZS50aW1lbGluZUxheWVyc1N0YXRlLnJlY29yZGluZ1N0YXRlIHx8ICFkZXZ0b29sc1N0YXRlLnRpbWVsaW5lTGF5ZXJzU3RhdGUucGVyZm9ybWFuY2VFdmVudEVuYWJsZWQpIHJldHVybjtcblx0XHRwZXJmb3JtYW5jZU1hcmtFbmQoYXBpLCBhcHAsIHVpZCwgdm0sIHR5cGUsIHRpbWUpO1xuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL3ZtL2luZGV4LnRzXG5jb25zdCBNQVhfJFZNID0gMTA7XG5jb25zdCAkdm1RdWV1ZSA9IFtdO1xuZnVuY3Rpb24gZXhwb3NlSW5zdGFuY2VUb1dpbmRvdyhjb21wb25lbnRJbnN0YW5jZSkge1xuXHRpZiAodHlwZW9mIHdpbmRvdyA9PT0gXCJ1bmRlZmluZWRcIikgcmV0dXJuO1xuXHRjb25zdCB3aW4gPSB3aW5kb3c7XG5cdGlmICghY29tcG9uZW50SW5zdGFuY2UpIHJldHVybjtcblx0d2luLiR2bSA9IGNvbXBvbmVudEluc3RhbmNlO1xuXHRpZiAoJHZtUXVldWVbMF0gIT09IGNvbXBvbmVudEluc3RhbmNlKSB7XG5cdFx0aWYgKCR2bVF1ZXVlLmxlbmd0aCA+PSBNQVhfJFZNKSAkdm1RdWV1ZS5wb3AoKTtcblx0XHRmb3IgKGxldCBpID0gJHZtUXVldWUubGVuZ3RoOyBpID4gMDsgaS0tKSB3aW5bYCR2bSR7aX1gXSA9ICR2bVF1ZXVlW2ldID0gJHZtUXVldWVbaSAtIDFdO1xuXHRcdHdpbi4kdm0wID0gJHZtUXVldWVbMF0gPSBjb21wb25lbnRJbnN0YW5jZTtcblx0fVxufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvcGx1Z2luL2NvbXBvbmVudHMudHNcbmNvbnN0IElOU1BFQ1RPUl9JRCA9IFwiY29tcG9uZW50c1wiO1xuZnVuY3Rpb24gY3JlYXRlQ29tcG9uZW50c0RldlRvb2xzUGx1Z2luKGFwcCkge1xuXHRjb25zdCBkZXNjcmlwdG9yID0ge1xuXHRcdGlkOiBJTlNQRUNUT1JfSUQsXG5cdFx0bGFiZWw6IFwiQ29tcG9uZW50c1wiLFxuXHRcdGFwcFxuXHR9O1xuXHRjb25zdCBzZXR1cEZuID0gKGFwaSkgPT4ge1xuXHRcdGFwaS5hZGRJbnNwZWN0b3Ioe1xuXHRcdFx0aWQ6IElOU1BFQ1RPUl9JRCxcblx0XHRcdGxhYmVsOiBcIkNvbXBvbmVudHNcIixcblx0XHRcdHRyZWVGaWx0ZXJQbGFjZWhvbGRlcjogXCJTZWFyY2ggY29tcG9uZW50c1wiXG5cdFx0fSk7XG5cdFx0c2V0dXBCdWlsdGluVGltZWxpbmVMYXllcnMoYXBpKTtcblx0XHRhcGkub24uZ2V0SW5zcGVjdG9yVHJlZShhc3luYyAocGF5bG9hZCkgPT4ge1xuXHRcdFx0aWYgKHBheWxvYWQuYXBwID09PSBhcHAgJiYgcGF5bG9hZC5pbnNwZWN0b3JJZCA9PT0gSU5TUEVDVE9SX0lEKSB7XG5cdFx0XHRcdGNvbnN0IGluc3RhbmNlID0gZ2V0Q29tcG9uZW50SW5zdGFuY2UoYWN0aXZlQXBwUmVjb3JkLnZhbHVlLCBwYXlsb2FkLmluc3RhbmNlSWQpO1xuXHRcdFx0XHRpZiAoaW5zdGFuY2UpIHBheWxvYWQucm9vdE5vZGVzID0gYXdhaXQgbmV3IENvbXBvbmVudFdhbGtlcih7XG5cdFx0XHRcdFx0ZmlsdGVyVGV4dDogcGF5bG9hZC5maWx0ZXIsXG5cdFx0XHRcdFx0bWF4RGVwdGg6IDEwMCxcblx0XHRcdFx0XHRyZWN1cnNpdmVseTogZmFsc2UsXG5cdFx0XHRcdFx0YXBpXG5cdFx0XHRcdH0pLmdldENvbXBvbmVudFRyZWUoaW5zdGFuY2UpO1xuXHRcdFx0fVxuXHRcdH0pO1xuXHRcdGFwaS5vbi5nZXRJbnNwZWN0b3JTdGF0ZShhc3luYyAocGF5bG9hZCkgPT4ge1xuXHRcdFx0aWYgKHBheWxvYWQuYXBwID09PSBhcHAgJiYgcGF5bG9hZC5pbnNwZWN0b3JJZCA9PT0gSU5TUEVDVE9SX0lEKSB7XG5cdFx0XHRcdGNvbnN0IHJlc3VsdCA9IGdldEluc3RhbmNlU3RhdGUoeyBpbnN0YW5jZUlkOiBwYXlsb2FkLm5vZGVJZCB9KTtcblx0XHRcdFx0Y29uc3QgY29tcG9uZW50SW5zdGFuY2UgPSByZXN1bHQuaW5zdGFuY2U7XG5cdFx0XHRcdGNvbnN0IF9wYXlsb2FkID0ge1xuXHRcdFx0XHRcdGNvbXBvbmVudEluc3RhbmNlLFxuXHRcdFx0XHRcdGFwcDogcmVzdWx0Lmluc3RhbmNlPy5hcHBDb250ZXh0LmFwcCxcblx0XHRcdFx0XHRpbnN0YW5jZURhdGE6IHJlc3VsdFxuXHRcdFx0XHR9O1xuXHRcdFx0XHRkZXZ0b29sc0NvbnRleHQuaG9va3MuY2FsbEhvb2tXaXRoKChjYWxsYmFja3MpID0+IHtcblx0XHRcdFx0XHRjYWxsYmFja3MuZm9yRWFjaCgoY2IpID0+IGNiKF9wYXlsb2FkKSk7XG5cdFx0XHRcdH0sIERldlRvb2xzVjZQbHVnaW5BUElIb29rS2V5cy5JTlNQRUNUX0NPTVBPTkVOVCk7XG5cdFx0XHRcdHBheWxvYWQuc3RhdGUgPSByZXN1bHQ7XG5cdFx0XHRcdGV4cG9zZUluc3RhbmNlVG9XaW5kb3coY29tcG9uZW50SW5zdGFuY2UpO1xuXHRcdFx0fVxuXHRcdH0pO1xuXHRcdGFwaS5vbi5lZGl0SW5zcGVjdG9yU3RhdGUoYXN5bmMgKHBheWxvYWQpID0+IHtcblx0XHRcdGlmIChwYXlsb2FkLmFwcCA9PT0gYXBwICYmIHBheWxvYWQuaW5zcGVjdG9ySWQgPT09IElOU1BFQ1RPUl9JRCkge1xuXHRcdFx0XHRlZGl0U3RhdGUocGF5bG9hZCk7XG5cdFx0XHRcdGF3YWl0IGFwaS5zZW5kSW5zcGVjdG9yU3RhdGUoXCJjb21wb25lbnRzXCIpO1xuXHRcdFx0fVxuXHRcdH0pO1xuXHRcdGNvbnN0IGRlYm91bmNlU2VuZEluc3BlY3RvclRyZWUgPSBkZWJvdW5jZSgoKSA9PiB7XG5cdFx0XHRhcGkuc2VuZEluc3BlY3RvclRyZWUoSU5TUEVDVE9SX0lEKTtcblx0XHR9LCAxMjApO1xuXHRcdGNvbnN0IGRlYm91bmNlU2VuZEluc3BlY3RvclN0YXRlID0gZGVib3VuY2UoKCkgPT4ge1xuXHRcdFx0YXBpLnNlbmRJbnNwZWN0b3JTdGF0ZShJTlNQRUNUT1JfSUQpO1xuXHRcdH0sIDEyMCk7XG5cdFx0aG9vay5vbi5jb21wb25lbnRBZGRlZChhc3luYyAoYXBwLCB1aWQsIHBhcmVudFVpZCwgY29tcG9uZW50KSA9PiB7XG5cdFx0XHRpZiAoZGV2dG9vbHNTdGF0ZS5oaWdoUGVyZk1vZGVFbmFibGVkKSByZXR1cm47XG5cdFx0XHRpZiAoYXBwPy5faW5zdGFuY2U/LnR5cGU/LmRldnRvb2xzPy5oaWRlKSByZXR1cm47XG5cdFx0XHRpZiAoIWFwcCB8fCB0eXBlb2YgdWlkICE9PSBcIm51bWJlclwiICYmICF1aWQgfHwgIWNvbXBvbmVudCkgcmV0dXJuO1xuXHRcdFx0Y29uc3QgaWQgPSBhd2FpdCBnZXRDb21wb25lbnRJZCh7XG5cdFx0XHRcdGFwcCxcblx0XHRcdFx0dWlkLFxuXHRcdFx0XHRpbnN0YW5jZTogY29tcG9uZW50XG5cdFx0XHR9KTtcblx0XHRcdGNvbnN0IGFwcFJlY29yZCA9IGF3YWl0IGdldEFwcFJlY29yZChhcHApO1xuXHRcdFx0aWYgKGNvbXBvbmVudCkge1xuXHRcdFx0XHRpZiAoY29tcG9uZW50Ll9fVlVFX0RFVlRPT0xTX05FWFRfVUlEX18gPT0gbnVsbCkgY29tcG9uZW50Ll9fVlVFX0RFVlRPT0xTX05FWFRfVUlEX18gPSBpZDtcblx0XHRcdFx0aWYgKCFhcHBSZWNvcmQ/Lmluc3RhbmNlTWFwLmhhcyhpZCkpIHtcblx0XHRcdFx0XHRhcHBSZWNvcmQ/Lmluc3RhbmNlTWFwLnNldChpZCwgY29tcG9uZW50KTtcblx0XHRcdFx0XHRpZiAoYWN0aXZlQXBwUmVjb3JkLnZhbHVlLmlkID09PSBhcHBSZWNvcmQ/LmlkKSBhY3RpdmVBcHBSZWNvcmQudmFsdWUuaW5zdGFuY2VNYXAgPSBhcHBSZWNvcmQuaW5zdGFuY2VNYXA7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdGlmICghYXBwUmVjb3JkKSByZXR1cm47XG5cdFx0XHRkZWJvdW5jZVNlbmRJbnNwZWN0b3JUcmVlKCk7XG5cdFx0fSk7XG5cdFx0aG9vay5vbi5jb21wb25lbnRVcGRhdGVkKGFzeW5jIChhcHAsIHVpZCwgcGFyZW50VWlkLCBjb21wb25lbnQpID0+IHtcblx0XHRcdGlmIChkZXZ0b29sc1N0YXRlLmhpZ2hQZXJmTW9kZUVuYWJsZWQpIHJldHVybjtcblx0XHRcdGlmIChhcHA/Ll9pbnN0YW5jZT8udHlwZT8uZGV2dG9vbHM/LmhpZGUpIHJldHVybjtcblx0XHRcdGlmICghYXBwIHx8IHR5cGVvZiB1aWQgIT09IFwibnVtYmVyXCIgJiYgIXVpZCB8fCAhY29tcG9uZW50KSByZXR1cm47XG5cdFx0XHRjb25zdCBpZCA9IGF3YWl0IGdldENvbXBvbmVudElkKHtcblx0XHRcdFx0YXBwLFxuXHRcdFx0XHR1aWQsXG5cdFx0XHRcdGluc3RhbmNlOiBjb21wb25lbnRcblx0XHRcdH0pO1xuXHRcdFx0Y29uc3QgYXBwUmVjb3JkID0gYXdhaXQgZ2V0QXBwUmVjb3JkKGFwcCk7XG5cdFx0XHRpZiAoY29tcG9uZW50KSB7XG5cdFx0XHRcdGlmIChjb21wb25lbnQuX19WVUVfREVWVE9PTFNfTkVYVF9VSURfXyA9PSBudWxsKSBjb21wb25lbnQuX19WVUVfREVWVE9PTFNfTkVYVF9VSURfXyA9IGlkO1xuXHRcdFx0XHRpZiAoIWFwcFJlY29yZD8uaW5zdGFuY2VNYXAuaGFzKGlkKSkge1xuXHRcdFx0XHRcdGFwcFJlY29yZD8uaW5zdGFuY2VNYXAuc2V0KGlkLCBjb21wb25lbnQpO1xuXHRcdFx0XHRcdGlmIChhY3RpdmVBcHBSZWNvcmQudmFsdWUuaWQgPT09IGFwcFJlY29yZD8uaWQpIGFjdGl2ZUFwcFJlY29yZC52YWx1ZS5pbnN0YW5jZU1hcCA9IGFwcFJlY29yZC5pbnN0YW5jZU1hcDtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0aWYgKCFhcHBSZWNvcmQpIHJldHVybjtcblx0XHRcdGRlYm91bmNlU2VuZEluc3BlY3RvclRyZWUoKTtcblx0XHRcdGRlYm91bmNlU2VuZEluc3BlY3RvclN0YXRlKCk7XG5cdFx0fSk7XG5cdFx0aG9vay5vbi5jb21wb25lbnRSZW1vdmVkKGFzeW5jIChhcHAsIHVpZCwgcGFyZW50VWlkLCBjb21wb25lbnQpID0+IHtcblx0XHRcdGlmIChkZXZ0b29sc1N0YXRlLmhpZ2hQZXJmTW9kZUVuYWJsZWQpIHJldHVybjtcblx0XHRcdGlmIChhcHA/Ll9pbnN0YW5jZT8udHlwZT8uZGV2dG9vbHM/LmhpZGUpIHJldHVybjtcblx0XHRcdGlmICghYXBwIHx8IHR5cGVvZiB1aWQgIT09IFwibnVtYmVyXCIgJiYgIXVpZCB8fCAhY29tcG9uZW50KSByZXR1cm47XG5cdFx0XHRjb25zdCBhcHBSZWNvcmQgPSBhd2FpdCBnZXRBcHBSZWNvcmQoYXBwKTtcblx0XHRcdGlmICghYXBwUmVjb3JkKSByZXR1cm47XG5cdFx0XHRjb25zdCBpZCA9IGF3YWl0IGdldENvbXBvbmVudElkKHtcblx0XHRcdFx0YXBwLFxuXHRcdFx0XHR1aWQsXG5cdFx0XHRcdGluc3RhbmNlOiBjb21wb25lbnRcblx0XHRcdH0pO1xuXHRcdFx0YXBwUmVjb3JkPy5pbnN0YW5jZU1hcC5kZWxldGUoaWQpO1xuXHRcdFx0aWYgKGFjdGl2ZUFwcFJlY29yZC52YWx1ZS5pZCA9PT0gYXBwUmVjb3JkPy5pZCkgYWN0aXZlQXBwUmVjb3JkLnZhbHVlLmluc3RhbmNlTWFwID0gYXBwUmVjb3JkLmluc3RhbmNlTWFwO1xuXHRcdFx0ZGVib3VuY2VTZW5kSW5zcGVjdG9yVHJlZSgpO1xuXHRcdH0pO1xuXHR9O1xuXHRyZXR1cm4gW2Rlc2NyaXB0b3IsIHNldHVwRm5dO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvcGx1Z2luL2luZGV4LnRzXG50YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX19SRUdJU1RFUkVEX1BMVUdJTl9BUFBTX18gPz89IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG5mdW5jdGlvbiBzZXR1cERldlRvb2xzUGx1Z2luKHBsdWdpbkRlc2NyaXB0b3IsIHNldHVwRm4pIHtcblx0cmV0dXJuIGhvb2suc2V0dXBEZXZUb29sc1BsdWdpbihwbHVnaW5EZXNjcmlwdG9yLCBzZXR1cEZuKTtcbn1cbmZ1bmN0aW9uIGNhbGxEZXZUb29sc1BsdWdpblNldHVwRm4ocGx1Z2luLCBhcHApIHtcblx0Y29uc3QgW3BsdWdpbkRlc2NyaXB0b3IsIHNldHVwRm5dID0gcGx1Z2luO1xuXHRpZiAocGx1Z2luRGVzY3JpcHRvci5hcHAgIT09IGFwcCkgcmV0dXJuO1xuXHRjb25zdCBhcGkgPSBuZXcgRGV2VG9vbHNQbHVnaW5BUEkoe1xuXHRcdHBsdWdpbjoge1xuXHRcdFx0c2V0dXBGbixcblx0XHRcdGRlc2NyaXB0b3I6IHBsdWdpbkRlc2NyaXB0b3Jcblx0XHR9LFxuXHRcdGN0eDogZGV2dG9vbHNDb250ZXh0XG5cdH0pO1xuXHRpZiAocGx1Z2luRGVzY3JpcHRvci5wYWNrYWdlTmFtZSA9PT0gXCJ2dWV4XCIpIGFwaS5vbi5lZGl0SW5zcGVjdG9yU3RhdGUoKHBheWxvYWQpID0+IHtcblx0XHRhcGkuc2VuZEluc3BlY3RvclN0YXRlKHBheWxvYWQuaW5zcGVjdG9ySWQpO1xuXHR9KTtcblx0c2V0dXBGbihhcGkpO1xufVxuZnVuY3Rpb24gcmVtb3ZlUmVnaXN0ZXJlZFBsdWdpbkFwcChhcHApIHtcblx0dGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9fUkVHSVNURVJFRF9QTFVHSU5fQVBQU19fLmRlbGV0ZShhcHApO1xufVxuZnVuY3Rpb24gcmVnaXN0ZXJEZXZUb29sc1BsdWdpbihhcHAsIG9wdGlvbnMpIHtcblx0aWYgKHRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfX1JFR0lTVEVSRURfUExVR0lOX0FQUFNfXy5oYXMoYXBwKSkgcmV0dXJuO1xuXHRpZiAoZGV2dG9vbHNTdGF0ZS5oaWdoUGVyZk1vZGVFbmFibGVkICYmICFvcHRpb25zPy5pbnNwZWN0aW5nQ29tcG9uZW50KSByZXR1cm47XG5cdHRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfX1JFR0lTVEVSRURfUExVR0lOX0FQUFNfXy5hZGQoYXBwKTtcblx0ZGV2dG9vbHNQbHVnaW5CdWZmZXIuZm9yRWFjaCgocGx1Z2luKSA9PiB7XG5cdFx0Y2FsbERldlRvb2xzUGx1Z2luU2V0dXBGbihwbHVnaW4sIGFwcCk7XG5cdH0pO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2N0eC9yb3V0ZXIudHNcbmNvbnN0IFJPVVRFUl9LRVkgPSBcIl9fVlVFX0RFVlRPT0xTX1JPVVRFUl9fXCI7XG5jb25zdCBST1VURVJfSU5GT19LRVkgPSBcIl9fVlVFX0RFVlRPT0xTX1JPVVRFUl9JTkZPX19cIjtcbnRhcmdldFtST1VURVJfSU5GT19LRVldID8/PSB7XG5cdGN1cnJlbnRSb3V0ZTogbnVsbCxcblx0cm91dGVzOiBbXVxufTtcbnRhcmdldFtST1VURVJfS0VZXSA/Pz0ge307XG5jb25zdCBkZXZ0b29sc1JvdXRlckluZm8gPSBuZXcgUHJveHkodGFyZ2V0W1JPVVRFUl9JTkZPX0tFWV0sIHsgZ2V0KHRhcmdldCQxLCBwcm9wZXJ0eSkge1xuXHRyZXR1cm4gdGFyZ2V0W1JPVVRFUl9JTkZPX0tFWV1bcHJvcGVydHldO1xufSB9KTtcbmNvbnN0IGRldnRvb2xzUm91dGVyID0gbmV3IFByb3h5KHRhcmdldFtST1VURVJfS0VZXSwgeyBnZXQodGFyZ2V0JDIsIHByb3BlcnR5KSB7XG5cdGlmIChwcm9wZXJ0eSA9PT0gXCJ2YWx1ZVwiKSByZXR1cm4gdGFyZ2V0W1JPVVRFUl9LRVldO1xufSB9KTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL3JvdXRlci9pbmRleC50c1xuZnVuY3Rpb24gZ2V0Um91dGVzKHJvdXRlcikge1xuXHRjb25zdCByb3V0ZXNNYXAgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHRyZXR1cm4gKHJvdXRlcj8uZ2V0Um91dGVzKCkgfHwgW10pLmZpbHRlcigoaSkgPT4gIXJvdXRlc01hcC5oYXMoaS5wYXRoKSAmJiByb3V0ZXNNYXAuc2V0KGkucGF0aCwgMSkpO1xufVxuZnVuY3Rpb24gZmlsdGVyUm91dGVzKHJvdXRlcykge1xuXHRyZXR1cm4gcm91dGVzLm1hcCgoaXRlbSkgPT4ge1xuXHRcdGxldCB7IHBhdGgsIG5hbWUsIGNoaWxkcmVuLCBtZXRhIH0gPSBpdGVtO1xuXHRcdGlmIChjaGlsZHJlbj8ubGVuZ3RoKSBjaGlsZHJlbiA9IGZpbHRlclJvdXRlcyhjaGlsZHJlbik7XG5cdFx0cmV0dXJuIHtcblx0XHRcdHBhdGgsXG5cdFx0XHRuYW1lLFxuXHRcdFx0Y2hpbGRyZW4sXG5cdFx0XHRtZXRhXG5cdFx0fTtcblx0fSk7XG59XG5mdW5jdGlvbiBmaWx0ZXJDdXJyZW50Um91dGUocm91dGUpIHtcblx0aWYgKHJvdXRlKSB7XG5cdFx0Y29uc3QgeyBmdWxsUGF0aCwgaGFzaCwgaHJlZiwgcGF0aCwgbmFtZSwgbWF0Y2hlZCwgcGFyYW1zLCBxdWVyeSB9ID0gcm91dGU7XG5cdFx0cmV0dXJuIHtcblx0XHRcdGZ1bGxQYXRoLFxuXHRcdFx0aGFzaCxcblx0XHRcdGhyZWYsXG5cdFx0XHRwYXRoLFxuXHRcdFx0bmFtZSxcblx0XHRcdHBhcmFtcyxcblx0XHRcdHF1ZXJ5LFxuXHRcdFx0bWF0Y2hlZDogZmlsdGVyUm91dGVzKG1hdGNoZWQpXG5cdFx0fTtcblx0fVxuXHRyZXR1cm4gcm91dGU7XG59XG5mdW5jdGlvbiBub3JtYWxpemVSb3V0ZXJJbmZvKGFwcFJlY29yZCwgYWN0aXZlQXBwUmVjb3JkKSB7XG5cdGZ1bmN0aW9uIGluaXQoKSB7XG5cdFx0Y29uc3Qgcm91dGVyID0gYXBwUmVjb3JkLmFwcD8uY29uZmlnLmdsb2JhbFByb3BlcnRpZXMuJHJvdXRlcjtcblx0XHRjb25zdCBjdXJyZW50Um91dGUgPSBmaWx0ZXJDdXJyZW50Um91dGUocm91dGVyPy5jdXJyZW50Um91dGUudmFsdWUpO1xuXHRcdGNvbnN0IHJvdXRlcyA9IGZpbHRlclJvdXRlcyhnZXRSb3V0ZXMocm91dGVyKSk7XG5cdFx0Y29uc3QgYyA9IGNvbnNvbGUud2Fybjtcblx0XHRjb25zb2xlLndhcm4gPSAoKSA9PiB7fTtcblx0XHR0YXJnZXRbUk9VVEVSX0lORk9fS0VZXSA9IHtcblx0XHRcdGN1cnJlbnRSb3V0ZTogY3VycmVudFJvdXRlID8gZGVlcENsb25lKGN1cnJlbnRSb3V0ZSkgOiB7fSxcblx0XHRcdHJvdXRlczogZGVlcENsb25lKHJvdXRlcylcblx0XHR9O1xuXHRcdHRhcmdldFtST1VURVJfS0VZXSA9IHJvdXRlcjtcblx0XHRjb25zb2xlLndhcm4gPSBjO1xuXHR9XG5cdGluaXQoKTtcblx0aG9vay5vbi5jb21wb25lbnRVcGRhdGVkKGRlYm91bmNlKCgpID0+IHtcblx0XHRpZiAoYWN0aXZlQXBwUmVjb3JkLnZhbHVlPy5hcHAgIT09IGFwcFJlY29yZC5hcHApIHJldHVybjtcblx0XHRpbml0KCk7XG5cdFx0aWYgKGRldnRvb2xzU3RhdGUuaGlnaFBlcmZNb2RlRW5hYmxlZCkgcmV0dXJuO1xuXHRcdGRldnRvb2xzQ29udGV4dC5ob29rcy5jYWxsSG9vayhEZXZUb29sc01lc3NhZ2luZ0hvb2tLZXlzLlJPVVRFUl9JTkZPX1VQREFURUQsIHsgc3RhdGU6IHRhcmdldFtST1VURVJfSU5GT19LRVldIH0pO1xuXHR9LCAyMDApKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jdHgvYXBpLnRzXG5mdW5jdGlvbiBjcmVhdGVEZXZUb29sc0FwaShob29rcykge1xuXHRyZXR1cm4ge1xuXHRcdGFzeW5jIGdldEluc3BlY3RvclRyZWUocGF5bG9hZCkge1xuXHRcdFx0Y29uc3QgX3BheWxvYWQgPSB7XG5cdFx0XHRcdC4uLnBheWxvYWQsXG5cdFx0XHRcdGFwcDogYWN0aXZlQXBwUmVjb3JkLnZhbHVlLmFwcCxcblx0XHRcdFx0cm9vdE5vZGVzOiBbXVxuXHRcdFx0fTtcblx0XHRcdGF3YWl0IG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG5cdFx0XHRcdGhvb2tzLmNhbGxIb29rV2l0aChhc3luYyAoY2FsbGJhY2tzKSA9PiB7XG5cdFx0XHRcdFx0YXdhaXQgUHJvbWlzZS5hbGwoY2FsbGJhY2tzLm1hcCgoY2IpID0+IGNiKF9wYXlsb2FkKSkpO1xuXHRcdFx0XHRcdHJlc29sdmUoKTtcblx0XHRcdFx0fSwgRGV2VG9vbHNWNlBsdWdpbkFQSUhvb2tLZXlzLkdFVF9JTlNQRUNUT1JfVFJFRSk7XG5cdFx0XHR9KTtcblx0XHRcdHJldHVybiBfcGF5bG9hZC5yb290Tm9kZXM7XG5cdFx0fSxcblx0XHRhc3luYyBnZXRJbnNwZWN0b3JTdGF0ZShwYXlsb2FkKSB7XG5cdFx0XHRjb25zdCBfcGF5bG9hZCA9IHtcblx0XHRcdFx0Li4ucGF5bG9hZCxcblx0XHRcdFx0YXBwOiBhY3RpdmVBcHBSZWNvcmQudmFsdWUuYXBwLFxuXHRcdFx0XHRzdGF0ZTogbnVsbFxuXHRcdFx0fTtcblx0XHRcdGNvbnN0IGN0eCA9IHsgY3VycmVudFRhYjogYGN1c3RvbS1pbnNwZWN0b3I6JHtwYXlsb2FkLmluc3BlY3RvcklkfWAgfTtcblx0XHRcdGF3YWl0IG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG5cdFx0XHRcdGhvb2tzLmNhbGxIb29rV2l0aChhc3luYyAoY2FsbGJhY2tzKSA9PiB7XG5cdFx0XHRcdFx0YXdhaXQgUHJvbWlzZS5hbGwoY2FsbGJhY2tzLm1hcCgoY2IpID0+IGNiKF9wYXlsb2FkLCBjdHgpKSk7XG5cdFx0XHRcdFx0cmVzb2x2ZSgpO1xuXHRcdFx0XHR9LCBEZXZUb29sc1Y2UGx1Z2luQVBJSG9va0tleXMuR0VUX0lOU1BFQ1RPUl9TVEFURSk7XG5cdFx0XHR9KTtcblx0XHRcdHJldHVybiBfcGF5bG9hZC5zdGF0ZTtcblx0XHR9LFxuXHRcdGVkaXRJbnNwZWN0b3JTdGF0ZShwYXlsb2FkKSB7XG5cdFx0XHRjb25zdCBzdGF0ZUVkaXRvciA9IG5ldyBTdGF0ZUVkaXRvcigpO1xuXHRcdFx0Y29uc3QgX3BheWxvYWQgPSB7XG5cdFx0XHRcdC4uLnBheWxvYWQsXG5cdFx0XHRcdGFwcDogYWN0aXZlQXBwUmVjb3JkLnZhbHVlLmFwcCxcblx0XHRcdFx0c2V0OiAob2JqLCBwYXRoID0gcGF5bG9hZC5wYXRoLCB2YWx1ZSA9IHBheWxvYWQuc3RhdGUudmFsdWUsIGNiKSA9PiB7XG5cdFx0XHRcdFx0c3RhdGVFZGl0b3Iuc2V0KG9iaiwgcGF0aCwgdmFsdWUsIGNiIHx8IHN0YXRlRWRpdG9yLmNyZWF0ZURlZmF1bHRTZXRDYWxsYmFjayhwYXlsb2FkLnN0YXRlKSk7XG5cdFx0XHRcdH1cblx0XHRcdH07XG5cdFx0XHRob29rcy5jYWxsSG9va1dpdGgoKGNhbGxiYWNrcykgPT4ge1xuXHRcdFx0XHRjYWxsYmFja3MuZm9yRWFjaCgoY2IpID0+IGNiKF9wYXlsb2FkKSk7XG5cdFx0XHR9LCBEZXZUb29sc1Y2UGx1Z2luQVBJSG9va0tleXMuRURJVF9JTlNQRUNUT1JfU1RBVEUpO1xuXHRcdH0sXG5cdFx0c2VuZEluc3BlY3RvclN0YXRlKGluc3BlY3RvcklkKSB7XG5cdFx0XHRjb25zdCBpbnNwZWN0b3IgPSBnZXRJbnNwZWN0b3IoaW5zcGVjdG9ySWQpO1xuXHRcdFx0aG9va3MuY2FsbEhvb2soRGV2VG9vbHNDb250ZXh0SG9va0tleXMuU0VORF9JTlNQRUNUT1JfU1RBVEUsIHtcblx0XHRcdFx0aW5zcGVjdG9ySWQsXG5cdFx0XHRcdHBsdWdpbjoge1xuXHRcdFx0XHRcdGRlc2NyaXB0b3I6IGluc3BlY3Rvci5kZXNjcmlwdG9yLFxuXHRcdFx0XHRcdHNldHVwRm46ICgpID0+ICh7fSlcblx0XHRcdFx0fVxuXHRcdFx0fSk7XG5cdFx0fSxcblx0XHRpbnNwZWN0Q29tcG9uZW50SW5zcGVjdG9yKCkge1xuXHRcdFx0cmV0dXJuIGluc3BlY3RDb21wb25lbnRIaWdoTGlnaHRlcigpO1xuXHRcdH0sXG5cdFx0Y2FuY2VsSW5zcGVjdENvbXBvbmVudEluc3BlY3RvcigpIHtcblx0XHRcdHJldHVybiBjYW5jZWxJbnNwZWN0Q29tcG9uZW50SGlnaExpZ2h0ZXIoKTtcblx0XHR9LFxuXHRcdGdldENvbXBvbmVudFJlbmRlckNvZGUoaWQpIHtcblx0XHRcdGNvbnN0IGluc3RhbmNlID0gZ2V0Q29tcG9uZW50SW5zdGFuY2UoYWN0aXZlQXBwUmVjb3JkLnZhbHVlLCBpZCk7XG5cdFx0XHRpZiAoaW5zdGFuY2UpIHJldHVybiAhKHR5cGVvZiBpbnN0YW5jZT8udHlwZSA9PT0gXCJmdW5jdGlvblwiKSA/IGluc3RhbmNlLnJlbmRlci50b1N0cmluZygpIDogaW5zdGFuY2UudHlwZS50b1N0cmluZygpO1xuXHRcdH0sXG5cdFx0c2Nyb2xsVG9Db21wb25lbnQoaWQpIHtcblx0XHRcdHJldHVybiBzY3JvbGxUb0NvbXBvbmVudCh7IGlkIH0pO1xuXHRcdH0sXG5cdFx0b3BlbkluRWRpdG9yLFxuXHRcdGdldFZ1ZUluc3BlY3RvcjogZ2V0Q29tcG9uZW50SW5zcGVjdG9yLFxuXHRcdHRvZ2dsZUFwcChpZCwgb3B0aW9ucykge1xuXHRcdFx0Y29uc3QgYXBwUmVjb3JkID0gZGV2dG9vbHNBcHBSZWNvcmRzLnZhbHVlLmZpbmQoKHJlY29yZCkgPT4gcmVjb3JkLmlkID09PSBpZCk7XG5cdFx0XHRpZiAoYXBwUmVjb3JkKSB7XG5cdFx0XHRcdHNldEFjdGl2ZUFwcFJlY29yZElkKGlkKTtcblx0XHRcdFx0c2V0QWN0aXZlQXBwUmVjb3JkKGFwcFJlY29yZCk7XG5cdFx0XHRcdG5vcm1hbGl6ZVJvdXRlckluZm8oYXBwUmVjb3JkLCBhY3RpdmVBcHBSZWNvcmQpO1xuXHRcdFx0XHRjYWxsSW5zcGVjdG9yVXBkYXRlZEhvb2soKTtcblx0XHRcdFx0cmVnaXN0ZXJEZXZUb29sc1BsdWdpbihhcHBSZWNvcmQuYXBwLCBvcHRpb25zKTtcblx0XHRcdH1cblx0XHR9LFxuXHRcdGluc3BlY3RET00oaW5zdGFuY2VJZCkge1xuXHRcdFx0Y29uc3QgaW5zdGFuY2UgPSBnZXRDb21wb25lbnRJbnN0YW5jZShhY3RpdmVBcHBSZWNvcmQudmFsdWUsIGluc3RhbmNlSWQpO1xuXHRcdFx0aWYgKGluc3RhbmNlKSB7XG5cdFx0XHRcdGNvbnN0IFtlbF0gPSBnZXRSb290RWxlbWVudHNGcm9tQ29tcG9uZW50SW5zdGFuY2UoaW5zdGFuY2UpO1xuXHRcdFx0XHRpZiAoZWwpIHRhcmdldC5fX1ZVRV9ERVZUT09MU19JTlNQRUNUX0RPTV9UQVJHRVRfXyA9IGVsO1xuXHRcdFx0fVxuXHRcdH0sXG5cdFx0dXBkYXRlUGx1Z2luU2V0dGluZ3MocGx1Z2luSWQsIGtleSwgdmFsdWUpIHtcblx0XHRcdHNldFBsdWdpblNldHRpbmdzKHBsdWdpbklkLCBrZXksIHZhbHVlKTtcblx0XHR9LFxuXHRcdGdldFBsdWdpblNldHRpbmdzKHBsdWdpbklkKSB7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRvcHRpb25zOiBnZXRQbHVnaW5TZXR0aW5nc09wdGlvbnMocGx1Z2luSWQpLFxuXHRcdFx0XHR2YWx1ZXM6IGdldFBsdWdpblNldHRpbmdzKHBsdWdpbklkKVxuXHRcdFx0fTtcblx0XHR9XG5cdH07XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY3R4L2Vudi50c1xudGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0VOVl9fID8/PSB7IHZpdGVQbHVnaW5EZXRlY3RlZDogZmFsc2UgfTtcbmZ1bmN0aW9uIGdldERldlRvb2xzRW52KCkge1xuXHRyZXR1cm4gdGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0VOVl9fO1xufVxuZnVuY3Rpb24gc2V0RGV2VG9vbHNFbnYoZW52KSB7XG5cdHRhcmdldC5fX1ZVRV9ERVZUT09MU19FTlZfXyA9IHtcblx0XHQuLi50YXJnZXQuX19WVUVfREVWVE9PTFNfRU5WX18sXG5cdFx0Li4uZW52XG5cdH07XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY3R4L2luZGV4LnRzXG5jb25zdCBob29rcyA9IGNyZWF0ZURldlRvb2xzQ3R4SG9va3MoKTtcbnRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfQ09OVEVYVF9fID8/PSB7XG5cdGhvb2tzLFxuXHRnZXQgc3RhdGUoKSB7XG5cdFx0cmV0dXJuIHtcblx0XHRcdC4uLmRldnRvb2xzU3RhdGUsXG5cdFx0XHRhY3RpdmVBcHBSZWNvcmRJZDogYWN0aXZlQXBwUmVjb3JkLmlkLFxuXHRcdFx0YWN0aXZlQXBwUmVjb3JkOiBhY3RpdmVBcHBSZWNvcmQudmFsdWUsXG5cdFx0XHRhcHBSZWNvcmRzOiBkZXZ0b29sc0FwcFJlY29yZHMudmFsdWVcblx0XHR9O1xuXHR9LFxuXHRhcGk6IGNyZWF0ZURldlRvb2xzQXBpKGhvb2tzKVxufTtcbmNvbnN0IGRldnRvb2xzQ29udGV4dCA9IHRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfQ09OVEVYVF9fO1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3NwZWFraW5ndXJsQDE0LjAuMS9ub2RlX21vZHVsZXMvc3BlYWtpbmd1cmwvbGliL3NwZWFraW5ndXJsLmpzXG52YXIgcmVxdWlyZV9zcGVha2luZ3VybCQxID0gLyogQF9fUFVSRV9fICovIF9fY29tbW9uSlNNaW4oKChleHBvcnRzLCBtb2R1bGUpID0+IHtcblx0KGZ1bmN0aW9uKHJvb3QpIHtcblx0XHRcInVzZSBzdHJpY3RcIjtcblx0XHQvKipcblx0XHQqIGNoYXJNYXBcblx0XHQqIEB0eXBlIHtPYmplY3R9XG5cdFx0Ki9cblx0XHR2YXIgY2hhck1hcCA9IHtcblx0XHRcdFwiw4BcIjogXCJBXCIsXG5cdFx0XHRcIsOBXCI6IFwiQVwiLFxuXHRcdFx0XCLDglwiOiBcIkFcIixcblx0XHRcdFwiw4NcIjogXCJBXCIsXG5cdFx0XHRcIsOEXCI6IFwiQWVcIixcblx0XHRcdFwiw4VcIjogXCJBXCIsXG5cdFx0XHRcIsOGXCI6IFwiQUVcIixcblx0XHRcdFwiw4dcIjogXCJDXCIsXG5cdFx0XHRcIsOIXCI6IFwiRVwiLFxuXHRcdFx0XCLDiVwiOiBcIkVcIixcblx0XHRcdFwiw4pcIjogXCJFXCIsXG5cdFx0XHRcIsOLXCI6IFwiRVwiLFxuXHRcdFx0XCLDjFwiOiBcIklcIixcblx0XHRcdFwiw41cIjogXCJJXCIsXG5cdFx0XHRcIsOOXCI6IFwiSVwiLFxuXHRcdFx0XCLDj1wiOiBcIklcIixcblx0XHRcdFwiw5BcIjogXCJEXCIsXG5cdFx0XHRcIsORXCI6IFwiTlwiLFxuXHRcdFx0XCLDklwiOiBcIk9cIixcblx0XHRcdFwiw5NcIjogXCJPXCIsXG5cdFx0XHRcIsOUXCI6IFwiT1wiLFxuXHRcdFx0XCLDlVwiOiBcIk9cIixcblx0XHRcdFwiw5ZcIjogXCJPZVwiLFxuXHRcdFx0XCLFkFwiOiBcIk9cIixcblx0XHRcdFwiw5hcIjogXCJPXCIsXG5cdFx0XHRcIsOZXCI6IFwiVVwiLFxuXHRcdFx0XCLDmlwiOiBcIlVcIixcblx0XHRcdFwiw5tcIjogXCJVXCIsXG5cdFx0XHRcIsOcXCI6IFwiVWVcIixcblx0XHRcdFwixbBcIjogXCJVXCIsXG5cdFx0XHRcIsOdXCI6IFwiWVwiLFxuXHRcdFx0XCLDnlwiOiBcIlRIXCIsXG5cdFx0XHRcIsOfXCI6IFwic3NcIixcblx0XHRcdFwiw6BcIjogXCJhXCIsXG5cdFx0XHRcIsOhXCI6IFwiYVwiLFxuXHRcdFx0XCLDolwiOiBcImFcIixcblx0XHRcdFwiw6NcIjogXCJhXCIsXG5cdFx0XHRcIsOkXCI6IFwiYWVcIixcblx0XHRcdFwiw6VcIjogXCJhXCIsXG5cdFx0XHRcIsOmXCI6IFwiYWVcIixcblx0XHRcdFwiw6dcIjogXCJjXCIsXG5cdFx0XHRcIsOoXCI6IFwiZVwiLFxuXHRcdFx0XCLDqVwiOiBcImVcIixcblx0XHRcdFwiw6pcIjogXCJlXCIsXG5cdFx0XHRcIsOrXCI6IFwiZVwiLFxuXHRcdFx0XCLDrFwiOiBcImlcIixcblx0XHRcdFwiw61cIjogXCJpXCIsXG5cdFx0XHRcIsOuXCI6IFwiaVwiLFxuXHRcdFx0XCLDr1wiOiBcImlcIixcblx0XHRcdFwiw7BcIjogXCJkXCIsXG5cdFx0XHRcIsOxXCI6IFwiblwiLFxuXHRcdFx0XCLDslwiOiBcIm9cIixcblx0XHRcdFwiw7NcIjogXCJvXCIsXG5cdFx0XHRcIsO0XCI6IFwib1wiLFxuXHRcdFx0XCLDtVwiOiBcIm9cIixcblx0XHRcdFwiw7ZcIjogXCJvZVwiLFxuXHRcdFx0XCLFkVwiOiBcIm9cIixcblx0XHRcdFwiw7hcIjogXCJvXCIsXG5cdFx0XHRcIsO5XCI6IFwidVwiLFxuXHRcdFx0XCLDulwiOiBcInVcIixcblx0XHRcdFwiw7tcIjogXCJ1XCIsXG5cdFx0XHRcIsO8XCI6IFwidWVcIixcblx0XHRcdFwixbFcIjogXCJ1XCIsXG5cdFx0XHRcIsO9XCI6IFwieVwiLFxuXHRcdFx0XCLDvlwiOiBcInRoXCIsXG5cdFx0XHRcIsO/XCI6IFwieVwiLFxuXHRcdFx0XCLhup5cIjogXCJTU1wiLFxuXHRcdFx0XCLYp1wiOiBcImFcIixcblx0XHRcdFwi2KNcIjogXCJhXCIsXG5cdFx0XHRcItilXCI6IFwiaVwiLFxuXHRcdFx0XCLYolwiOiBcImFhXCIsXG5cdFx0XHRcItikXCI6IFwidVwiLFxuXHRcdFx0XCLYplwiOiBcImVcIixcblx0XHRcdFwi2KFcIjogXCJhXCIsXG5cdFx0XHRcItioXCI6IFwiYlwiLFxuXHRcdFx0XCLYqlwiOiBcInRcIixcblx0XHRcdFwi2KtcIjogXCJ0aFwiLFxuXHRcdFx0XCLYrFwiOiBcImpcIixcblx0XHRcdFwi2K1cIjogXCJoXCIsXG5cdFx0XHRcItiuXCI6IFwia2hcIixcblx0XHRcdFwi2K9cIjogXCJkXCIsXG5cdFx0XHRcItiwXCI6IFwidGhcIixcblx0XHRcdFwi2LFcIjogXCJyXCIsXG5cdFx0XHRcItiyXCI6IFwielwiLFxuXHRcdFx0XCLYs1wiOiBcInNcIixcblx0XHRcdFwi2LRcIjogXCJzaFwiLFxuXHRcdFx0XCLYtVwiOiBcInNcIixcblx0XHRcdFwi2LZcIjogXCJkaFwiLFxuXHRcdFx0XCLYt1wiOiBcInRcIixcblx0XHRcdFwi2LhcIjogXCJ6XCIsXG5cdFx0XHRcIti5XCI6IFwiYVwiLFxuXHRcdFx0XCLYulwiOiBcImdoXCIsXG5cdFx0XHRcItmBXCI6IFwiZlwiLFxuXHRcdFx0XCLZglwiOiBcInFcIixcblx0XHRcdFwi2YNcIjogXCJrXCIsXG5cdFx0XHRcItmEXCI6IFwibFwiLFxuXHRcdFx0XCLZhVwiOiBcIm1cIixcblx0XHRcdFwi2YZcIjogXCJuXCIsXG5cdFx0XHRcItmHXCI6IFwiaFwiLFxuXHRcdFx0XCLZiFwiOiBcIndcIixcblx0XHRcdFwi2YpcIjogXCJ5XCIsXG5cdFx0XHRcItmJXCI6IFwiYVwiLFxuXHRcdFx0XCLYqVwiOiBcImhcIixcblx0XHRcdFwi77u7XCI6IFwibGFcIixcblx0XHRcdFwi77u3XCI6IFwibGFhXCIsXG5cdFx0XHRcIu+7uVwiOiBcImxhaVwiLFxuXHRcdFx0XCLvu7VcIjogXCJsYWFcIixcblx0XHRcdFwi2q9cIjogXCJnXCIsXG5cdFx0XHRcItqGXCI6IFwiY2hcIixcblx0XHRcdFwi2b5cIjogXCJwXCIsXG5cdFx0XHRcItqYXCI6IFwiemhcIixcblx0XHRcdFwi2qlcIjogXCJrXCIsXG5cdFx0XHRcItuMXCI6IFwieVwiLFxuXHRcdFx0XCLZjlwiOiBcImFcIixcblx0XHRcdFwi2YtcIjogXCJhblwiLFxuXHRcdFx0XCLZkFwiOiBcImVcIixcblx0XHRcdFwi2Y1cIjogXCJlblwiLFxuXHRcdFx0XCLZj1wiOiBcInVcIixcblx0XHRcdFwi2YxcIjogXCJvblwiLFxuXHRcdFx0XCLZklwiOiBcIlwiLFxuXHRcdFx0XCLZoFwiOiBcIjBcIixcblx0XHRcdFwi2aFcIjogXCIxXCIsXG5cdFx0XHRcItmiXCI6IFwiMlwiLFxuXHRcdFx0XCLZo1wiOiBcIjNcIixcblx0XHRcdFwi2aRcIjogXCI0XCIsXG5cdFx0XHRcItmlXCI6IFwiNVwiLFxuXHRcdFx0XCLZplwiOiBcIjZcIixcblx0XHRcdFwi2adcIjogXCI3XCIsXG5cdFx0XHRcItmoXCI6IFwiOFwiLFxuXHRcdFx0XCLZqVwiOiBcIjlcIixcblx0XHRcdFwi27BcIjogXCIwXCIsXG5cdFx0XHRcItuxXCI6IFwiMVwiLFxuXHRcdFx0XCLbslwiOiBcIjJcIixcblx0XHRcdFwi27NcIjogXCIzXCIsXG5cdFx0XHRcItu0XCI6IFwiNFwiLFxuXHRcdFx0XCLbtVwiOiBcIjVcIixcblx0XHRcdFwi27ZcIjogXCI2XCIsXG5cdFx0XHRcItu3XCI6IFwiN1wiLFxuXHRcdFx0XCLbuFwiOiBcIjhcIixcblx0XHRcdFwi27lcIjogXCI5XCIsXG5cdFx0XHRcIuGAgFwiOiBcImtcIixcblx0XHRcdFwi4YCBXCI6IFwia2hcIixcblx0XHRcdFwi4YCCXCI6IFwiZ1wiLFxuXHRcdFx0XCLhgINcIjogXCJnYVwiLFxuXHRcdFx0XCLhgIRcIjogXCJuZ1wiLFxuXHRcdFx0XCLhgIVcIjogXCJzXCIsXG5cdFx0XHRcIuGAhlwiOiBcInNhXCIsXG5cdFx0XHRcIuGAh1wiOiBcInpcIixcblx0XHRcdFwi4YCF4YC7XCI6IFwiemFcIixcblx0XHRcdFwi4YCKXCI6IFwibnlcIixcblx0XHRcdFwi4YCLXCI6IFwidFwiLFxuXHRcdFx0XCLhgIxcIjogXCJ0YVwiLFxuXHRcdFx0XCLhgI1cIjogXCJkXCIsXG5cdFx0XHRcIuGAjlwiOiBcImRhXCIsXG5cdFx0XHRcIuGAj1wiOiBcIm5hXCIsXG5cdFx0XHRcIuGAkFwiOiBcInRcIixcblx0XHRcdFwi4YCRXCI6IFwidGFcIixcblx0XHRcdFwi4YCSXCI6IFwiZFwiLFxuXHRcdFx0XCLhgJNcIjogXCJkYVwiLFxuXHRcdFx0XCLhgJRcIjogXCJuXCIsXG5cdFx0XHRcIuGAlVwiOiBcInBcIixcblx0XHRcdFwi4YCWXCI6IFwicGFcIixcblx0XHRcdFwi4YCXXCI6IFwiYlwiLFxuXHRcdFx0XCLhgJhcIjogXCJiYVwiLFxuXHRcdFx0XCLhgJlcIjogXCJtXCIsXG5cdFx0XHRcIuGAmlwiOiBcInlcIixcblx0XHRcdFwi4YCbXCI6IFwieWFcIixcblx0XHRcdFwi4YCcXCI6IFwibFwiLFxuXHRcdFx0XCLhgJ1cIjogXCJ3XCIsXG5cdFx0XHRcIuGAnlwiOiBcInRoXCIsXG5cdFx0XHRcIuGAn1wiOiBcImhcIixcblx0XHRcdFwi4YCgXCI6IFwibGFcIixcblx0XHRcdFwi4YChXCI6IFwiYVwiLFxuXHRcdFx0XCLhgLxcIjogXCJ5XCIsXG5cdFx0XHRcIuGAu1wiOiBcInlhXCIsXG5cdFx0XHRcIuGAvVwiOiBcIndcIixcblx0XHRcdFwi4YC84YC9XCI6IFwieXdcIixcblx0XHRcdFwi4YC74YC9XCI6IFwieXdhXCIsXG5cdFx0XHRcIuGAvlwiOiBcImhcIixcblx0XHRcdFwi4YCnXCI6IFwiZVwiLFxuXHRcdFx0XCLhgY9cIjogXCItZVwiLFxuXHRcdFx0XCLhgKNcIjogXCJpXCIsXG5cdFx0XHRcIuGApFwiOiBcIi1pXCIsXG5cdFx0XHRcIuGAiVwiOiBcInVcIixcblx0XHRcdFwi4YCmXCI6IFwiLXVcIixcblx0XHRcdFwi4YCpXCI6IFwiYXdcIixcblx0XHRcdFwi4YCe4YC84YCx4YCsXCI6IFwiYXdcIixcblx0XHRcdFwi4YCqXCI6IFwiYXdcIixcblx0XHRcdFwi4YGAXCI6IFwiMFwiLFxuXHRcdFx0XCLhgYFcIjogXCIxXCIsXG5cdFx0XHRcIuGBglwiOiBcIjJcIixcblx0XHRcdFwi4YGDXCI6IFwiM1wiLFxuXHRcdFx0XCLhgYRcIjogXCI0XCIsXG5cdFx0XHRcIuGBhVwiOiBcIjVcIixcblx0XHRcdFwi4YGGXCI6IFwiNlwiLFxuXHRcdFx0XCLhgYdcIjogXCI3XCIsXG5cdFx0XHRcIuGBiFwiOiBcIjhcIixcblx0XHRcdFwi4YGJXCI6IFwiOVwiLFxuXHRcdFx0XCLhgLlcIjogXCJcIixcblx0XHRcdFwi4YC3XCI6IFwiXCIsXG5cdFx0XHRcIuGAuFwiOiBcIlwiLFxuXHRcdFx0XCLEjVwiOiBcImNcIixcblx0XHRcdFwixI9cIjogXCJkXCIsXG5cdFx0XHRcIsSbXCI6IFwiZVwiLFxuXHRcdFx0XCLFiFwiOiBcIm5cIixcblx0XHRcdFwixZlcIjogXCJyXCIsXG5cdFx0XHRcIsWhXCI6IFwic1wiLFxuXHRcdFx0XCLFpVwiOiBcInRcIixcblx0XHRcdFwixa9cIjogXCJ1XCIsXG5cdFx0XHRcIsW+XCI6IFwielwiLFxuXHRcdFx0XCLEjFwiOiBcIkNcIixcblx0XHRcdFwixI5cIjogXCJEXCIsXG5cdFx0XHRcIsSaXCI6IFwiRVwiLFxuXHRcdFx0XCLFh1wiOiBcIk5cIixcblx0XHRcdFwixZhcIjogXCJSXCIsXG5cdFx0XHRcIsWgXCI6IFwiU1wiLFxuXHRcdFx0XCLFpFwiOiBcIlRcIixcblx0XHRcdFwixa5cIjogXCJVXCIsXG5cdFx0XHRcIsW9XCI6IFwiWlwiLFxuXHRcdFx0XCLegFwiOiBcImhcIixcblx0XHRcdFwi3oFcIjogXCJzaFwiLFxuXHRcdFx0XCLeglwiOiBcIm5cIixcblx0XHRcdFwi3oNcIjogXCJyXCIsXG5cdFx0XHRcIt6EXCI6IFwiYlwiLFxuXHRcdFx0XCLehVwiOiBcImxoXCIsXG5cdFx0XHRcIt6GXCI6IFwia1wiLFxuXHRcdFx0XCLeh1wiOiBcImFcIixcblx0XHRcdFwi3ohcIjogXCJ2XCIsXG5cdFx0XHRcIt6JXCI6IFwibVwiLFxuXHRcdFx0XCLeilwiOiBcImZcIixcblx0XHRcdFwi3otcIjogXCJkaFwiLFxuXHRcdFx0XCLejFwiOiBcInRoXCIsXG5cdFx0XHRcIt6NXCI6IFwibFwiLFxuXHRcdFx0XCLejlwiOiBcImdcIixcblx0XHRcdFwi3o9cIjogXCJnblwiLFxuXHRcdFx0XCLekFwiOiBcInNcIixcblx0XHRcdFwi3pFcIjogXCJkXCIsXG5cdFx0XHRcIt6SXCI6IFwielwiLFxuXHRcdFx0XCLek1wiOiBcInRcIixcblx0XHRcdFwi3pRcIjogXCJ5XCIsXG5cdFx0XHRcIt6VXCI6IFwicFwiLFxuXHRcdFx0XCLellwiOiBcImpcIixcblx0XHRcdFwi3pdcIjogXCJjaFwiLFxuXHRcdFx0XCLemFwiOiBcInR0XCIsXG5cdFx0XHRcIt6ZXCI6IFwiaGhcIixcblx0XHRcdFwi3ppcIjogXCJraFwiLFxuXHRcdFx0XCLem1wiOiBcInRoXCIsXG5cdFx0XHRcIt6cXCI6IFwielwiLFxuXHRcdFx0XCLenVwiOiBcInNoXCIsXG5cdFx0XHRcIt6eXCI6IFwic1wiLFxuXHRcdFx0XCLen1wiOiBcImRcIixcblx0XHRcdFwi3qBcIjogXCJ0XCIsXG5cdFx0XHRcIt6hXCI6IFwielwiLFxuXHRcdFx0XCLeolwiOiBcImFcIixcblx0XHRcdFwi3qNcIjogXCJnaFwiLFxuXHRcdFx0XCLepFwiOiBcInFcIixcblx0XHRcdFwi3qVcIjogXCJ3XCIsXG5cdFx0XHRcIt6mXCI6IFwiYVwiLFxuXHRcdFx0XCLep1wiOiBcImFhXCIsXG5cdFx0XHRcIt6oXCI6IFwiaVwiLFxuXHRcdFx0XCLeqVwiOiBcImVlXCIsXG5cdFx0XHRcIt6qXCI6IFwidVwiLFxuXHRcdFx0XCLeq1wiOiBcIm9vXCIsXG5cdFx0XHRcIt6sXCI6IFwiZVwiLFxuXHRcdFx0XCLerVwiOiBcImV5XCIsXG5cdFx0XHRcIt6uXCI6IFwib1wiLFxuXHRcdFx0XCLer1wiOiBcIm9hXCIsXG5cdFx0XHRcIt6wXCI6IFwiXCIsXG5cdFx0XHRcIuGDkFwiOiBcImFcIixcblx0XHRcdFwi4YORXCI6IFwiYlwiLFxuXHRcdFx0XCLhg5JcIjogXCJnXCIsXG5cdFx0XHRcIuGDk1wiOiBcImRcIixcblx0XHRcdFwi4YOUXCI6IFwiZVwiLFxuXHRcdFx0XCLhg5VcIjogXCJ2XCIsXG5cdFx0XHRcIuGDllwiOiBcInpcIixcblx0XHRcdFwi4YOXXCI6IFwidFwiLFxuXHRcdFx0XCLhg5hcIjogXCJpXCIsXG5cdFx0XHRcIuGDmVwiOiBcImtcIixcblx0XHRcdFwi4YOaXCI6IFwibFwiLFxuXHRcdFx0XCLhg5tcIjogXCJtXCIsXG5cdFx0XHRcIuGDnFwiOiBcIm5cIixcblx0XHRcdFwi4YOdXCI6IFwib1wiLFxuXHRcdFx0XCLhg55cIjogXCJwXCIsXG5cdFx0XHRcIuGDn1wiOiBcInpoXCIsXG5cdFx0XHRcIuGDoFwiOiBcInJcIixcblx0XHRcdFwi4YOhXCI6IFwic1wiLFxuXHRcdFx0XCLhg6JcIjogXCJ0XCIsXG5cdFx0XHRcIuGDo1wiOiBcInVcIixcblx0XHRcdFwi4YOkXCI6IFwicFwiLFxuXHRcdFx0XCLhg6VcIjogXCJrXCIsXG5cdFx0XHRcIuGDplwiOiBcImdoXCIsXG5cdFx0XHRcIuGDp1wiOiBcInFcIixcblx0XHRcdFwi4YOoXCI6IFwic2hcIixcblx0XHRcdFwi4YOpXCI6IFwiY2hcIixcblx0XHRcdFwi4YOqXCI6IFwidHNcIixcblx0XHRcdFwi4YOrXCI6IFwiZHpcIixcblx0XHRcdFwi4YOsXCI6IFwidHNcIixcblx0XHRcdFwi4YOtXCI6IFwiY2hcIixcblx0XHRcdFwi4YOuXCI6IFwia2hcIixcblx0XHRcdFwi4YOvXCI6IFwialwiLFxuXHRcdFx0XCLhg7BcIjogXCJoXCIsXG5cdFx0XHRcIs6xXCI6IFwiYVwiLFxuXHRcdFx0XCLOslwiOiBcInZcIixcblx0XHRcdFwizrNcIjogXCJnXCIsXG5cdFx0XHRcIs60XCI6IFwiZFwiLFxuXHRcdFx0XCLOtVwiOiBcImVcIixcblx0XHRcdFwizrZcIjogXCJ6XCIsXG5cdFx0XHRcIs63XCI6IFwiaVwiLFxuXHRcdFx0XCLOuFwiOiBcInRoXCIsXG5cdFx0XHRcIs65XCI6IFwiaVwiLFxuXHRcdFx0XCLOulwiOiBcImtcIixcblx0XHRcdFwizrtcIjogXCJsXCIsXG5cdFx0XHRcIs68XCI6IFwibVwiLFxuXHRcdFx0XCLOvVwiOiBcIm5cIixcblx0XHRcdFwizr5cIjogXCJrc1wiLFxuXHRcdFx0XCLOv1wiOiBcIm9cIixcblx0XHRcdFwiz4BcIjogXCJwXCIsXG5cdFx0XHRcIs+BXCI6IFwiclwiLFxuXHRcdFx0XCLPg1wiOiBcInNcIixcblx0XHRcdFwiz4RcIjogXCJ0XCIsXG5cdFx0XHRcIs+FXCI6IFwieVwiLFxuXHRcdFx0XCLPhlwiOiBcImZcIixcblx0XHRcdFwiz4dcIjogXCJ4XCIsXG5cdFx0XHRcIs+IXCI6IFwicHNcIixcblx0XHRcdFwiz4lcIjogXCJvXCIsXG5cdFx0XHRcIs6sXCI6IFwiYVwiLFxuXHRcdFx0XCLOrVwiOiBcImVcIixcblx0XHRcdFwizq9cIjogXCJpXCIsXG5cdFx0XHRcIs+MXCI6IFwib1wiLFxuXHRcdFx0XCLPjVwiOiBcInlcIixcblx0XHRcdFwizq5cIjogXCJpXCIsXG5cdFx0XHRcIs+OXCI6IFwib1wiLFxuXHRcdFx0XCLPglwiOiBcInNcIixcblx0XHRcdFwiz4pcIjogXCJpXCIsXG5cdFx0XHRcIs6wXCI6IFwieVwiLFxuXHRcdFx0XCLPi1wiOiBcInlcIixcblx0XHRcdFwizpBcIjogXCJpXCIsXG5cdFx0XHRcIs6RXCI6IFwiQVwiLFxuXHRcdFx0XCLOklwiOiBcIkJcIixcblx0XHRcdFwizpNcIjogXCJHXCIsXG5cdFx0XHRcIs6UXCI6IFwiRFwiLFxuXHRcdFx0XCLOlVwiOiBcIkVcIixcblx0XHRcdFwizpZcIjogXCJaXCIsXG5cdFx0XHRcIs6XXCI6IFwiSVwiLFxuXHRcdFx0XCLOmFwiOiBcIlRIXCIsXG5cdFx0XHRcIs6ZXCI6IFwiSVwiLFxuXHRcdFx0XCLOmlwiOiBcIktcIixcblx0XHRcdFwizptcIjogXCJMXCIsXG5cdFx0XHRcIs6cXCI6IFwiTVwiLFxuXHRcdFx0XCLOnVwiOiBcIk5cIixcblx0XHRcdFwizp5cIjogXCJLU1wiLFxuXHRcdFx0XCLOn1wiOiBcIk9cIixcblx0XHRcdFwizqBcIjogXCJQXCIsXG5cdFx0XHRcIs6hXCI6IFwiUlwiLFxuXHRcdFx0XCLOo1wiOiBcIlNcIixcblx0XHRcdFwizqRcIjogXCJUXCIsXG5cdFx0XHRcIs6lXCI6IFwiWVwiLFxuXHRcdFx0XCLOplwiOiBcIkZcIixcblx0XHRcdFwizqdcIjogXCJYXCIsXG5cdFx0XHRcIs6oXCI6IFwiUFNcIixcblx0XHRcdFwizqlcIjogXCJPXCIsXG5cdFx0XHRcIs6GXCI6IFwiQVwiLFxuXHRcdFx0XCLOiFwiOiBcIkVcIixcblx0XHRcdFwizopcIjogXCJJXCIsXG5cdFx0XHRcIs6MXCI6IFwiT1wiLFxuXHRcdFx0XCLOjlwiOiBcIllcIixcblx0XHRcdFwizolcIjogXCJJXCIsXG5cdFx0XHRcIs6PXCI6IFwiT1wiLFxuXHRcdFx0XCLOqlwiOiBcIklcIixcblx0XHRcdFwizqtcIjogXCJZXCIsXG5cdFx0XHRcIsSBXCI6IFwiYVwiLFxuXHRcdFx0XCLEk1wiOiBcImVcIixcblx0XHRcdFwixKNcIjogXCJnXCIsXG5cdFx0XHRcIsSrXCI6IFwiaVwiLFxuXHRcdFx0XCLEt1wiOiBcImtcIixcblx0XHRcdFwixLxcIjogXCJsXCIsXG5cdFx0XHRcIsWGXCI6IFwiblwiLFxuXHRcdFx0XCLFq1wiOiBcInVcIixcblx0XHRcdFwixIBcIjogXCJBXCIsXG5cdFx0XHRcIsSSXCI6IFwiRVwiLFxuXHRcdFx0XCLEolwiOiBcIkdcIixcblx0XHRcdFwixKpcIjogXCJJXCIsXG5cdFx0XHRcIsS2XCI6IFwia1wiLFxuXHRcdFx0XCLEu1wiOiBcIkxcIixcblx0XHRcdFwixYVcIjogXCJOXCIsXG5cdFx0XHRcIsWqXCI6IFwiVVwiLFxuXHRcdFx0XCLQjFwiOiBcIktqXCIsXG5cdFx0XHRcItGcXCI6IFwia2pcIixcblx0XHRcdFwi0IlcIjogXCJMalwiLFxuXHRcdFx0XCLRmVwiOiBcImxqXCIsXG5cdFx0XHRcItCKXCI6IFwiTmpcIixcblx0XHRcdFwi0ZpcIjogXCJualwiLFxuXHRcdFx0XCLQotGBXCI6IFwiVHNcIixcblx0XHRcdFwi0YLRgVwiOiBcInRzXCIsXG5cdFx0XHRcIsSFXCI6IFwiYVwiLFxuXHRcdFx0XCLEh1wiOiBcImNcIixcblx0XHRcdFwixJlcIjogXCJlXCIsXG5cdFx0XHRcIsWCXCI6IFwibFwiLFxuXHRcdFx0XCLFhFwiOiBcIm5cIixcblx0XHRcdFwixZtcIjogXCJzXCIsXG5cdFx0XHRcIsW6XCI6IFwielwiLFxuXHRcdFx0XCLFvFwiOiBcInpcIixcblx0XHRcdFwixIRcIjogXCJBXCIsXG5cdFx0XHRcIsSGXCI6IFwiQ1wiLFxuXHRcdFx0XCLEmFwiOiBcIkVcIixcblx0XHRcdFwixYFcIjogXCJMXCIsXG5cdFx0XHRcIsWDXCI6IFwiTlwiLFxuXHRcdFx0XCLFmlwiOiBcIlNcIixcblx0XHRcdFwixblcIjogXCJaXCIsXG5cdFx0XHRcIsW7XCI6IFwiWlwiLFxuXHRcdFx0XCLQhFwiOiBcIlllXCIsXG5cdFx0XHRcItCGXCI6IFwiSVwiLFxuXHRcdFx0XCLQh1wiOiBcIllpXCIsXG5cdFx0XHRcItKQXCI6IFwiR1wiLFxuXHRcdFx0XCLRlFwiOiBcInllXCIsXG5cdFx0XHRcItGWXCI6IFwiaVwiLFxuXHRcdFx0XCLRl1wiOiBcInlpXCIsXG5cdFx0XHRcItKRXCI6IFwiZ1wiLFxuXHRcdFx0XCLEg1wiOiBcImFcIixcblx0XHRcdFwixIJcIjogXCJBXCIsXG5cdFx0XHRcIsiZXCI6IFwic1wiLFxuXHRcdFx0XCLImFwiOiBcIlNcIixcblx0XHRcdFwiyJtcIjogXCJ0XCIsXG5cdFx0XHRcIsiaXCI6IFwiVFwiLFxuXHRcdFx0XCLFo1wiOiBcInRcIixcblx0XHRcdFwixaJcIjogXCJUXCIsXG5cdFx0XHRcItCwXCI6IFwiYVwiLFxuXHRcdFx0XCLQsVwiOiBcImJcIixcblx0XHRcdFwi0LJcIjogXCJ2XCIsXG5cdFx0XHRcItCzXCI6IFwiZ1wiLFxuXHRcdFx0XCLQtFwiOiBcImRcIixcblx0XHRcdFwi0LVcIjogXCJlXCIsXG5cdFx0XHRcItGRXCI6IFwieW9cIixcblx0XHRcdFwi0LZcIjogXCJ6aFwiLFxuXHRcdFx0XCLQt1wiOiBcInpcIixcblx0XHRcdFwi0LhcIjogXCJpXCIsXG5cdFx0XHRcItC5XCI6IFwiaVwiLFxuXHRcdFx0XCLQulwiOiBcImtcIixcblx0XHRcdFwi0LtcIjogXCJsXCIsXG5cdFx0XHRcItC8XCI6IFwibVwiLFxuXHRcdFx0XCLQvVwiOiBcIm5cIixcblx0XHRcdFwi0L5cIjogXCJvXCIsXG5cdFx0XHRcItC/XCI6IFwicFwiLFxuXHRcdFx0XCLRgFwiOiBcInJcIixcblx0XHRcdFwi0YFcIjogXCJzXCIsXG5cdFx0XHRcItGCXCI6IFwidFwiLFxuXHRcdFx0XCLRg1wiOiBcInVcIixcblx0XHRcdFwi0YRcIjogXCJmXCIsXG5cdFx0XHRcItGFXCI6IFwia2hcIixcblx0XHRcdFwi0YZcIjogXCJjXCIsXG5cdFx0XHRcItGHXCI6IFwiY2hcIixcblx0XHRcdFwi0YhcIjogXCJzaFwiLFxuXHRcdFx0XCLRiVwiOiBcInNoXCIsXG5cdFx0XHRcItGKXCI6IFwiXCIsXG5cdFx0XHRcItGLXCI6IFwieVwiLFxuXHRcdFx0XCLRjFwiOiBcIlwiLFxuXHRcdFx0XCLRjVwiOiBcImVcIixcblx0XHRcdFwi0Y5cIjogXCJ5dVwiLFxuXHRcdFx0XCLRj1wiOiBcInlhXCIsXG5cdFx0XHRcItCQXCI6IFwiQVwiLFxuXHRcdFx0XCLQkVwiOiBcIkJcIixcblx0XHRcdFwi0JJcIjogXCJWXCIsXG5cdFx0XHRcItCTXCI6IFwiR1wiLFxuXHRcdFx0XCLQlFwiOiBcIkRcIixcblx0XHRcdFwi0JVcIjogXCJFXCIsXG5cdFx0XHRcItCBXCI6IFwiWW9cIixcblx0XHRcdFwi0JZcIjogXCJaaFwiLFxuXHRcdFx0XCLQl1wiOiBcIlpcIixcblx0XHRcdFwi0JhcIjogXCJJXCIsXG5cdFx0XHRcItCZXCI6IFwiSVwiLFxuXHRcdFx0XCLQmlwiOiBcIktcIixcblx0XHRcdFwi0JtcIjogXCJMXCIsXG5cdFx0XHRcItCcXCI6IFwiTVwiLFxuXHRcdFx0XCLQnVwiOiBcIk5cIixcblx0XHRcdFwi0J5cIjogXCJPXCIsXG5cdFx0XHRcItCfXCI6IFwiUFwiLFxuXHRcdFx0XCLQoFwiOiBcIlJcIixcblx0XHRcdFwi0KFcIjogXCJTXCIsXG5cdFx0XHRcItCiXCI6IFwiVFwiLFxuXHRcdFx0XCLQo1wiOiBcIlVcIixcblx0XHRcdFwi0KRcIjogXCJGXCIsXG5cdFx0XHRcItClXCI6IFwiS2hcIixcblx0XHRcdFwi0KZcIjogXCJDXCIsXG5cdFx0XHRcItCnXCI6IFwiQ2hcIixcblx0XHRcdFwi0KhcIjogXCJTaFwiLFxuXHRcdFx0XCLQqVwiOiBcIlNoXCIsXG5cdFx0XHRcItCqXCI6IFwiXCIsXG5cdFx0XHRcItCrXCI6IFwiWVwiLFxuXHRcdFx0XCLQrFwiOiBcIlwiLFxuXHRcdFx0XCLQrVwiOiBcIkVcIixcblx0XHRcdFwi0K5cIjogXCJZdVwiLFxuXHRcdFx0XCLQr1wiOiBcIllhXCIsXG5cdFx0XHRcItGSXCI6IFwiZGpcIixcblx0XHRcdFwi0ZhcIjogXCJqXCIsXG5cdFx0XHRcItGbXCI6IFwiY1wiLFxuXHRcdFx0XCLRn1wiOiBcImR6XCIsXG5cdFx0XHRcItCCXCI6IFwiRGpcIixcblx0XHRcdFwi0IhcIjogXCJqXCIsXG5cdFx0XHRcItCLXCI6IFwiQ1wiLFxuXHRcdFx0XCLQj1wiOiBcIkR6XCIsXG5cdFx0XHRcIsS+XCI6IFwibFwiLFxuXHRcdFx0XCLEulwiOiBcImxcIixcblx0XHRcdFwixZVcIjogXCJyXCIsXG5cdFx0XHRcIsS9XCI6IFwiTFwiLFxuXHRcdFx0XCLEuVwiOiBcIkxcIixcblx0XHRcdFwixZRcIjogXCJSXCIsXG5cdFx0XHRcIsWfXCI6IFwic1wiLFxuXHRcdFx0XCLFnlwiOiBcIlNcIixcblx0XHRcdFwixLFcIjogXCJpXCIsXG5cdFx0XHRcIsSwXCI6IFwiSVwiLFxuXHRcdFx0XCLEn1wiOiBcImdcIixcblx0XHRcdFwixJ5cIjogXCJHXCIsXG5cdFx0XHRcIuG6o1wiOiBcImFcIixcblx0XHRcdFwi4bqiXCI6IFwiQVwiLFxuXHRcdFx0XCLhurNcIjogXCJhXCIsXG5cdFx0XHRcIuG6slwiOiBcIkFcIixcblx0XHRcdFwi4bqpXCI6IFwiYVwiLFxuXHRcdFx0XCLhuqhcIjogXCJBXCIsXG5cdFx0XHRcIsSRXCI6IFwiZFwiLFxuXHRcdFx0XCLEkFwiOiBcIkRcIixcblx0XHRcdFwi4bq5XCI6IFwiZVwiLFxuXHRcdFx0XCLhurhcIjogXCJFXCIsXG5cdFx0XHRcIuG6vVwiOiBcImVcIixcblx0XHRcdFwi4bq8XCI6IFwiRVwiLFxuXHRcdFx0XCLhurtcIjogXCJlXCIsXG5cdFx0XHRcIuG6ulwiOiBcIkVcIixcblx0XHRcdFwi4bq/XCI6IFwiZVwiLFxuXHRcdFx0XCLhur5cIjogXCJFXCIsXG5cdFx0XHRcIuG7gVwiOiBcImVcIixcblx0XHRcdFwi4buAXCI6IFwiRVwiLFxuXHRcdFx0XCLhu4dcIjogXCJlXCIsXG5cdFx0XHRcIuG7hlwiOiBcIkVcIixcblx0XHRcdFwi4buFXCI6IFwiZVwiLFxuXHRcdFx0XCLhu4RcIjogXCJFXCIsXG5cdFx0XHRcIuG7g1wiOiBcImVcIixcblx0XHRcdFwi4buCXCI6IFwiRVwiLFxuXHRcdFx0XCLhu49cIjogXCJvXCIsXG5cdFx0XHRcIuG7jVwiOiBcIm9cIixcblx0XHRcdFwi4buMXCI6IFwib1wiLFxuXHRcdFx0XCLhu5FcIjogXCJvXCIsXG5cdFx0XHRcIuG7kFwiOiBcIk9cIixcblx0XHRcdFwi4buTXCI6IFwib1wiLFxuXHRcdFx0XCLhu5JcIjogXCJPXCIsXG5cdFx0XHRcIuG7lVwiOiBcIm9cIixcblx0XHRcdFwi4buUXCI6IFwiT1wiLFxuXHRcdFx0XCLhu5lcIjogXCJvXCIsXG5cdFx0XHRcIuG7mFwiOiBcIk9cIixcblx0XHRcdFwi4buXXCI6IFwib1wiLFxuXHRcdFx0XCLhu5ZcIjogXCJPXCIsXG5cdFx0XHRcIsahXCI6IFwib1wiLFxuXHRcdFx0XCLGoFwiOiBcIk9cIixcblx0XHRcdFwi4bubXCI6IFwib1wiLFxuXHRcdFx0XCLhu5pcIjogXCJPXCIsXG5cdFx0XHRcIuG7nVwiOiBcIm9cIixcblx0XHRcdFwi4bucXCI6IFwiT1wiLFxuXHRcdFx0XCLhu6NcIjogXCJvXCIsXG5cdFx0XHRcIuG7olwiOiBcIk9cIixcblx0XHRcdFwi4buhXCI6IFwib1wiLFxuXHRcdFx0XCLhu6BcIjogXCJPXCIsXG5cdFx0XHRcIuG7nlwiOiBcIm9cIixcblx0XHRcdFwi4bufXCI6IFwib1wiLFxuXHRcdFx0XCLhu4tcIjogXCJpXCIsXG5cdFx0XHRcIuG7ilwiOiBcIklcIixcblx0XHRcdFwixKlcIjogXCJpXCIsXG5cdFx0XHRcIsSoXCI6IFwiSVwiLFxuXHRcdFx0XCLhu4lcIjogXCJpXCIsXG5cdFx0XHRcIuG7iFwiOiBcImlcIixcblx0XHRcdFwi4bunXCI6IFwidVwiLFxuXHRcdFx0XCLhu6ZcIjogXCJVXCIsXG5cdFx0XHRcIuG7pVwiOiBcInVcIixcblx0XHRcdFwi4bukXCI6IFwiVVwiLFxuXHRcdFx0XCLFqVwiOiBcInVcIixcblx0XHRcdFwixahcIjogXCJVXCIsXG5cdFx0XHRcIsawXCI6IFwidVwiLFxuXHRcdFx0XCLGr1wiOiBcIlVcIixcblx0XHRcdFwi4bupXCI6IFwidVwiLFxuXHRcdFx0XCLhu6hcIjogXCJVXCIsXG5cdFx0XHRcIuG7q1wiOiBcInVcIixcblx0XHRcdFwi4buqXCI6IFwiVVwiLFxuXHRcdFx0XCLhu7FcIjogXCJ1XCIsXG5cdFx0XHRcIuG7sFwiOiBcIlVcIixcblx0XHRcdFwi4buvXCI6IFwidVwiLFxuXHRcdFx0XCLhu65cIjogXCJVXCIsXG5cdFx0XHRcIuG7rVwiOiBcInVcIixcblx0XHRcdFwi4busXCI6IFwixrBcIixcblx0XHRcdFwi4bu3XCI6IFwieVwiLFxuXHRcdFx0XCLhu7ZcIjogXCJ5XCIsXG5cdFx0XHRcIuG7s1wiOiBcInlcIixcblx0XHRcdFwi4buyXCI6IFwiWVwiLFxuXHRcdFx0XCLhu7VcIjogXCJ5XCIsXG5cdFx0XHRcIuG7tFwiOiBcIllcIixcblx0XHRcdFwi4bu5XCI6IFwieVwiLFxuXHRcdFx0XCLhu7hcIjogXCJZXCIsXG5cdFx0XHRcIuG6oVwiOiBcImFcIixcblx0XHRcdFwi4bqgXCI6IFwiQVwiLFxuXHRcdFx0XCLhuqVcIjogXCJhXCIsXG5cdFx0XHRcIuG6pFwiOiBcIkFcIixcblx0XHRcdFwi4bqnXCI6IFwiYVwiLFxuXHRcdFx0XCLhuqZcIjogXCJBXCIsXG5cdFx0XHRcIuG6rVwiOiBcImFcIixcblx0XHRcdFwi4bqsXCI6IFwiQVwiLFxuXHRcdFx0XCLhuqtcIjogXCJhXCIsXG5cdFx0XHRcIuG6qlwiOiBcIkFcIixcblx0XHRcdFwi4bqvXCI6IFwiYVwiLFxuXHRcdFx0XCLhuq5cIjogXCJBXCIsXG5cdFx0XHRcIuG6sVwiOiBcImFcIixcblx0XHRcdFwi4bqwXCI6IFwiQVwiLFxuXHRcdFx0XCLhurdcIjogXCJhXCIsXG5cdFx0XHRcIuG6tlwiOiBcIkFcIixcblx0XHRcdFwi4bq1XCI6IFwiYVwiLFxuXHRcdFx0XCLhurRcIjogXCJBXCIsXG5cdFx0XHRcIuKTqlwiOiBcIjBcIixcblx0XHRcdFwi4pGgXCI6IFwiMVwiLFxuXHRcdFx0XCLikaFcIjogXCIyXCIsXG5cdFx0XHRcIuKRolwiOiBcIjNcIixcblx0XHRcdFwi4pGjXCI6IFwiNFwiLFxuXHRcdFx0XCLikaRcIjogXCI1XCIsXG5cdFx0XHRcIuKRpVwiOiBcIjZcIixcblx0XHRcdFwi4pGmXCI6IFwiN1wiLFxuXHRcdFx0XCLikadcIjogXCI4XCIsXG5cdFx0XHRcIuKRqFwiOiBcIjlcIixcblx0XHRcdFwi4pGpXCI6IFwiMTBcIixcblx0XHRcdFwi4pGqXCI6IFwiMTFcIixcblx0XHRcdFwi4pGrXCI6IFwiMTJcIixcblx0XHRcdFwi4pGsXCI6IFwiMTNcIixcblx0XHRcdFwi4pGtXCI6IFwiMTRcIixcblx0XHRcdFwi4pGuXCI6IFwiMTVcIixcblx0XHRcdFwi4pGvXCI6IFwiMTZcIixcblx0XHRcdFwi4pGwXCI6IFwiMTdcIixcblx0XHRcdFwi4pGxXCI6IFwiMThcIixcblx0XHRcdFwi4pGyXCI6IFwiMThcIixcblx0XHRcdFwi4pGzXCI6IFwiMThcIixcblx0XHRcdFwi4pO1XCI6IFwiMVwiLFxuXHRcdFx0XCLik7ZcIjogXCIyXCIsXG5cdFx0XHRcIuKTt1wiOiBcIjNcIixcblx0XHRcdFwi4pO4XCI6IFwiNFwiLFxuXHRcdFx0XCLik7lcIjogXCI1XCIsXG5cdFx0XHRcIuKTulwiOiBcIjZcIixcblx0XHRcdFwi4pO7XCI6IFwiN1wiLFxuXHRcdFx0XCLik7xcIjogXCI4XCIsXG5cdFx0XHRcIuKTvVwiOiBcIjlcIixcblx0XHRcdFwi4pO+XCI6IFwiMTBcIixcblx0XHRcdFwi4pO/XCI6IFwiMFwiLFxuXHRcdFx0XCLik6tcIjogXCIxMVwiLFxuXHRcdFx0XCLik6xcIjogXCIxMlwiLFxuXHRcdFx0XCLik61cIjogXCIxM1wiLFxuXHRcdFx0XCLik65cIjogXCIxNFwiLFxuXHRcdFx0XCLik69cIjogXCIxNVwiLFxuXHRcdFx0XCLik7BcIjogXCIxNlwiLFxuXHRcdFx0XCLik7FcIjogXCIxN1wiLFxuXHRcdFx0XCLik7JcIjogXCIxOFwiLFxuXHRcdFx0XCLik7NcIjogXCIxOVwiLFxuXHRcdFx0XCLik7RcIjogXCIyMFwiLFxuXHRcdFx0XCLikrZcIjogXCJBXCIsXG5cdFx0XHRcIuKSt1wiOiBcIkJcIixcblx0XHRcdFwi4pK4XCI6IFwiQ1wiLFxuXHRcdFx0XCLikrlcIjogXCJEXCIsXG5cdFx0XHRcIuKSulwiOiBcIkVcIixcblx0XHRcdFwi4pK7XCI6IFwiRlwiLFxuXHRcdFx0XCLikrxcIjogXCJHXCIsXG5cdFx0XHRcIuKSvVwiOiBcIkhcIixcblx0XHRcdFwi4pK+XCI6IFwiSVwiLFxuXHRcdFx0XCLikr9cIjogXCJKXCIsXG5cdFx0XHRcIuKTgFwiOiBcIktcIixcblx0XHRcdFwi4pOBXCI6IFwiTFwiLFxuXHRcdFx0XCLik4JcIjogXCJNXCIsXG5cdFx0XHRcIuKTg1wiOiBcIk5cIixcblx0XHRcdFwi4pOEXCI6IFwiT1wiLFxuXHRcdFx0XCLik4VcIjogXCJQXCIsXG5cdFx0XHRcIuKThlwiOiBcIlFcIixcblx0XHRcdFwi4pOHXCI6IFwiUlwiLFxuXHRcdFx0XCLik4hcIjogXCJTXCIsXG5cdFx0XHRcIuKTiVwiOiBcIlRcIixcblx0XHRcdFwi4pOKXCI6IFwiVVwiLFxuXHRcdFx0XCLik4tcIjogXCJWXCIsXG5cdFx0XHRcIuKTjFwiOiBcIldcIixcblx0XHRcdFwi4pONXCI6IFwiWFwiLFxuXHRcdFx0XCLik45cIjogXCJZXCIsXG5cdFx0XHRcIuKTj1wiOiBcIlpcIixcblx0XHRcdFwi4pOQXCI6IFwiYVwiLFxuXHRcdFx0XCLik5FcIjogXCJiXCIsXG5cdFx0XHRcIuKTklwiOiBcImNcIixcblx0XHRcdFwi4pOTXCI6IFwiZFwiLFxuXHRcdFx0XCLik5RcIjogXCJlXCIsXG5cdFx0XHRcIuKTlVwiOiBcImZcIixcblx0XHRcdFwi4pOWXCI6IFwiZ1wiLFxuXHRcdFx0XCLik5dcIjogXCJoXCIsXG5cdFx0XHRcIuKTmFwiOiBcImlcIixcblx0XHRcdFwi4pOZXCI6IFwialwiLFxuXHRcdFx0XCLik5pcIjogXCJrXCIsXG5cdFx0XHRcIuKTm1wiOiBcImxcIixcblx0XHRcdFwi4pOcXCI6IFwibVwiLFxuXHRcdFx0XCLik51cIjogXCJuXCIsXG5cdFx0XHRcIuKTnlwiOiBcIm9cIixcblx0XHRcdFwi4pOfXCI6IFwicFwiLFxuXHRcdFx0XCLik6BcIjogXCJxXCIsXG5cdFx0XHRcIuKToVwiOiBcInJcIixcblx0XHRcdFwi4pOiXCI6IFwic1wiLFxuXHRcdFx0XCLik6NcIjogXCJ0XCIsXG5cdFx0XHRcIuKTpFwiOiBcInVcIixcblx0XHRcdFwi4pOmXCI6IFwidlwiLFxuXHRcdFx0XCLik6VcIjogXCJ3XCIsXG5cdFx0XHRcIuKTp1wiOiBcInhcIixcblx0XHRcdFwi4pOoXCI6IFwieVwiLFxuXHRcdFx0XCLik6lcIjogXCJ6XCIsXG5cdFx0XHRcIuKAnFwiOiBcIlxcXCJcIixcblx0XHRcdFwi4oCdXCI6IFwiXFxcIlwiLFxuXHRcdFx0XCLigJhcIjogXCInXCIsXG5cdFx0XHRcIuKAmVwiOiBcIidcIixcblx0XHRcdFwi4oiCXCI6IFwiZFwiLFxuXHRcdFx0XCLGklwiOiBcImZcIixcblx0XHRcdFwi4oSiXCI6IFwiKFRNKVwiLFxuXHRcdFx0XCLCqVwiOiBcIihDKVwiLFxuXHRcdFx0XCLFk1wiOiBcIm9lXCIsXG5cdFx0XHRcIsWSXCI6IFwiT0VcIixcblx0XHRcdFwiwq5cIjogXCIoUilcIixcblx0XHRcdFwi4oCgXCI6IFwiK1wiLFxuXHRcdFx0XCLihKBcIjogXCIoU00pXCIsXG5cdFx0XHRcIuKAplwiOiBcIi4uLlwiLFxuXHRcdFx0XCLLmlwiOiBcIm9cIixcblx0XHRcdFwiwrpcIjogXCJvXCIsXG5cdFx0XHRcIsKqXCI6IFwiYVwiLFxuXHRcdFx0XCLigKJcIjogXCIqXCIsXG5cdFx0XHRcIuGBilwiOiBcIixcIixcblx0XHRcdFwi4YGLXCI6IFwiLlwiLFxuXHRcdFx0XCIkXCI6IFwiVVNEXCIsXG5cdFx0XHRcIuKCrFwiOiBcIkVVUlwiLFxuXHRcdFx0XCLigqJcIjogXCJCUk5cIixcblx0XHRcdFwi4oKjXCI6IFwiRlJGXCIsXG5cdFx0XHRcIsKjXCI6IFwiR0JQXCIsXG5cdFx0XHRcIuKCpFwiOiBcIklUTFwiLFxuXHRcdFx0XCLigqZcIjogXCJOR05cIixcblx0XHRcdFwi4oKnXCI6IFwiRVNQXCIsXG5cdFx0XHRcIuKCqVwiOiBcIktSV1wiLFxuXHRcdFx0XCLigqpcIjogXCJJTFNcIixcblx0XHRcdFwi4oKrXCI6IFwiVk5EXCIsXG5cdFx0XHRcIuKCrVwiOiBcIkxBS1wiLFxuXHRcdFx0XCLigq5cIjogXCJNTlRcIixcblx0XHRcdFwi4oKvXCI6IFwiR1JEXCIsXG5cdFx0XHRcIuKCsVwiOiBcIkFSU1wiLFxuXHRcdFx0XCLigrJcIjogXCJQWUdcIixcblx0XHRcdFwi4oKzXCI6IFwiQVJBXCIsXG5cdFx0XHRcIuKCtFwiOiBcIlVBSFwiLFxuXHRcdFx0XCLigrVcIjogXCJHSFNcIixcblx0XHRcdFwiwqJcIjogXCJjZW50XCIsXG5cdFx0XHRcIsKlXCI6IFwiQ05ZXCIsXG5cdFx0XHRcIuWFg1wiOiBcIkNOWVwiLFxuXHRcdFx0XCLlhoZcIjogXCJZRU5cIixcblx0XHRcdFwi77e8XCI6IFwiSVJSXCIsXG5cdFx0XHRcIuKCoFwiOiBcIkVXRVwiLFxuXHRcdFx0XCLguL9cIjogXCJUSEJcIixcblx0XHRcdFwi4oKoXCI6IFwiSU5SXCIsXG5cdFx0XHRcIuKCuVwiOiBcIklOUlwiLFxuXHRcdFx0XCLigrBcIjogXCJQRlwiLFxuXHRcdFx0XCLigrpcIjogXCJUUllcIixcblx0XHRcdFwi2ItcIjogXCJBRk5cIixcblx0XHRcdFwi4oK8XCI6IFwiQVpOXCIsXG5cdFx0XHRcItC70LJcIjogXCJCR05cIixcblx0XHRcdFwi4Z+bXCI6IFwiS0hSXCIsXG5cdFx0XHRcIuKCoVwiOiBcIkNSQ1wiLFxuXHRcdFx0XCLigrhcIjogXCJLWlRcIixcblx0XHRcdFwi0LTQtdC9XCI6IFwiTUtEXCIsXG5cdFx0XHRcInrFglwiOiBcIlBMTlwiLFxuXHRcdFx0XCLigr1cIjogXCJSVUJcIixcblx0XHRcdFwi4oK+XCI6IFwiR0VMXCJcblx0XHR9O1xuXHRcdC8qKlxuXHRcdCogc3BlY2lhbCBsb29rIGFoZWFkIGNoYXJhY3RlciBhcnJheVxuXHRcdCogVGhlc2UgY2hhcmFjdGVycyBmb3JtIHdpdGggY29uc29uYW50cyB0byBiZWNvbWUgJ3NpbmdsZScvY29uc29uYW50IGNvbWJvXG5cdFx0KiBAdHlwZSBbQXJyYXldXG5cdFx0Ki9cblx0XHR2YXIgbG9va0FoZWFkQ2hhckFycmF5ID0gW1wi4YC6XCIsIFwi3rBcIl07XG5cdFx0LyoqXG5cdFx0KiBkaWF0cmljTWFwIGZvciBsYW5ndWFnZXMgd2hlcmUgdHJhbnNsaXRlcmF0aW9uIGNoYW5nZXMgZW50aXJlbHkgYXMgbW9yZSBkaWF0cmljcyBhcmUgYWRkZWRcblx0XHQqIEB0eXBlIHtPYmplY3R9XG5cdFx0Ki9cblx0XHR2YXIgZGlhdHJpY01hcCA9IHtcblx0XHRcdFwi4YCsXCI6IFwiYVwiLFxuXHRcdFx0XCLhgKtcIjogXCJhXCIsXG5cdFx0XHRcIuGAsVwiOiBcImVcIixcblx0XHRcdFwi4YCyXCI6IFwiZVwiLFxuXHRcdFx0XCLhgK1cIjogXCJpXCIsXG5cdFx0XHRcIuGArlwiOiBcImlcIixcblx0XHRcdFwi4YCt4YCvXCI6IFwib1wiLFxuXHRcdFx0XCLhgK9cIjogXCJ1XCIsXG5cdFx0XHRcIuGAsFwiOiBcInVcIixcblx0XHRcdFwi4YCx4YCr4YCE4YC6XCI6IFwiYXVuZ1wiLFxuXHRcdFx0XCLhgLHhgKxcIjogXCJhd1wiLFxuXHRcdFx0XCLhgLHhgKzhgLpcIjogXCJhd1wiLFxuXHRcdFx0XCLhgLHhgKtcIjogXCJhd1wiLFxuXHRcdFx0XCLhgLHhgKvhgLpcIjogXCJhd1wiLFxuXHRcdFx0XCLhgLpcIjogXCLhgLpcIixcblx0XHRcdFwi4YCA4YC6XCI6IFwiZXRcIixcblx0XHRcdFwi4YCt4YCv4YCA4YC6XCI6IFwiYWlrXCIsXG5cdFx0XHRcIuGAseGArOGAgOGAulwiOiBcImF1a1wiLFxuXHRcdFx0XCLhgIThgLpcIjogXCJpblwiLFxuXHRcdFx0XCLhgK3hgK/hgIThgLpcIjogXCJhaW5nXCIsXG5cdFx0XHRcIuGAseGArOGAhOGAulwiOiBcImF1bmdcIixcblx0XHRcdFwi4YCF4YC6XCI6IFwiaXRcIixcblx0XHRcdFwi4YCK4YC6XCI6IFwiaVwiLFxuXHRcdFx0XCLhgJDhgLpcIjogXCJhdFwiLFxuXHRcdFx0XCLhgK3hgJDhgLpcIjogXCJlaWtcIixcblx0XHRcdFwi4YCv4YCQ4YC6XCI6IFwib2tcIixcblx0XHRcdFwi4YC94YCQ4YC6XCI6IFwidXRcIixcblx0XHRcdFwi4YCx4YCQ4YC6XCI6IFwiaXRcIixcblx0XHRcdFwi4YCS4YC6XCI6IFwiZFwiLFxuXHRcdFx0XCLhgK3hgK/hgJLhgLpcIjogXCJva1wiLFxuXHRcdFx0XCLhgK/hgJLhgLpcIjogXCJhaXRcIixcblx0XHRcdFwi4YCU4YC6XCI6IFwiYW5cIixcblx0XHRcdFwi4YCs4YCU4YC6XCI6IFwiYW5cIixcblx0XHRcdFwi4YCt4YCU4YC6XCI6IFwiZWluXCIsXG5cdFx0XHRcIuGAr+GAlOGAulwiOiBcIm9uXCIsXG5cdFx0XHRcIuGAveGAlOGAulwiOiBcInVuXCIsXG5cdFx0XHRcIuGAleGAulwiOiBcImF0XCIsXG5cdFx0XHRcIuGAreGAleGAulwiOiBcImVpa1wiLFxuXHRcdFx0XCLhgK/hgJXhgLpcIjogXCJva1wiLFxuXHRcdFx0XCLhgL3hgJXhgLpcIjogXCJ1dFwiLFxuXHRcdFx0XCLhgJThgLrhgK/hgJXhgLpcIjogXCJudWJcIixcblx0XHRcdFwi4YCZ4YC6XCI6IFwiYW5cIixcblx0XHRcdFwi4YCt4YCZ4YC6XCI6IFwiZWluXCIsXG5cdFx0XHRcIuGAr+GAmeGAulwiOiBcIm9uXCIsXG5cdFx0XHRcIuGAveGAmeGAulwiOiBcInVuXCIsXG5cdFx0XHRcIuGAmuGAulwiOiBcImVcIixcblx0XHRcdFwi4YCt4YCv4YCc4YC6XCI6IFwib2xcIixcblx0XHRcdFwi4YCJ4YC6XCI6IFwiaW5cIixcblx0XHRcdFwi4YC2XCI6IFwiYW5cIixcblx0XHRcdFwi4YCt4YC2XCI6IFwiZWluXCIsXG5cdFx0XHRcIuGAr+GAtlwiOiBcIm9uXCIsXG5cdFx0XHRcIt6m3ofesFwiOiBcImFoXCIsXG5cdFx0XHRcIt6m3oHesFwiOiBcImFoXCJcblx0XHR9O1xuXHRcdC8qKlxuXHRcdCogbGFuZ0NoYXJNYXAgbGFuZ3VhZ2Ugc3BlY2lmaWMgY2hhcmFjdGVycyB0cmFuc2xhdGlvbnNcblx0XHQqIEB0eXBlICAge09iamVjdH1cblx0XHQqL1xuXHRcdHZhciBsYW5nQ2hhck1hcCA9IHtcblx0XHRcdFwiZW5cIjoge30sXG5cdFx0XHRcImF6XCI6IHtcblx0XHRcdFx0XCLDp1wiOiBcImNcIixcblx0XHRcdFx0XCLJmVwiOiBcImVcIixcblx0XHRcdFx0XCLEn1wiOiBcImdcIixcblx0XHRcdFx0XCLEsVwiOiBcImlcIixcblx0XHRcdFx0XCLDtlwiOiBcIm9cIixcblx0XHRcdFx0XCLFn1wiOiBcInNcIixcblx0XHRcdFx0XCLDvFwiOiBcInVcIixcblx0XHRcdFx0XCLDh1wiOiBcIkNcIixcblx0XHRcdFx0XCLGj1wiOiBcIkVcIixcblx0XHRcdFx0XCLEnlwiOiBcIkdcIixcblx0XHRcdFx0XCLEsFwiOiBcIklcIixcblx0XHRcdFx0XCLDllwiOiBcIk9cIixcblx0XHRcdFx0XCLFnlwiOiBcIlNcIixcblx0XHRcdFx0XCLDnFwiOiBcIlVcIlxuXHRcdFx0fSxcblx0XHRcdFwiY3NcIjoge1xuXHRcdFx0XHRcIsSNXCI6IFwiY1wiLFxuXHRcdFx0XHRcIsSPXCI6IFwiZFwiLFxuXHRcdFx0XHRcIsSbXCI6IFwiZVwiLFxuXHRcdFx0XHRcIsWIXCI6IFwiblwiLFxuXHRcdFx0XHRcIsWZXCI6IFwiclwiLFxuXHRcdFx0XHRcIsWhXCI6IFwic1wiLFxuXHRcdFx0XHRcIsWlXCI6IFwidFwiLFxuXHRcdFx0XHRcIsWvXCI6IFwidVwiLFxuXHRcdFx0XHRcIsW+XCI6IFwielwiLFxuXHRcdFx0XHRcIsSMXCI6IFwiQ1wiLFxuXHRcdFx0XHRcIsSOXCI6IFwiRFwiLFxuXHRcdFx0XHRcIsSaXCI6IFwiRVwiLFxuXHRcdFx0XHRcIsWHXCI6IFwiTlwiLFxuXHRcdFx0XHRcIsWYXCI6IFwiUlwiLFxuXHRcdFx0XHRcIsWgXCI6IFwiU1wiLFxuXHRcdFx0XHRcIsWkXCI6IFwiVFwiLFxuXHRcdFx0XHRcIsWuXCI6IFwiVVwiLFxuXHRcdFx0XHRcIsW9XCI6IFwiWlwiXG5cdFx0XHR9LFxuXHRcdFx0XCJmaVwiOiB7XG5cdFx0XHRcdFwiw6RcIjogXCJhXCIsXG5cdFx0XHRcdFwiw4RcIjogXCJBXCIsXG5cdFx0XHRcdFwiw7ZcIjogXCJvXCIsXG5cdFx0XHRcdFwiw5ZcIjogXCJPXCJcblx0XHRcdH0sXG5cdFx0XHRcImh1XCI6IHtcblx0XHRcdFx0XCLDpFwiOiBcImFcIixcblx0XHRcdFx0XCLDhFwiOiBcIkFcIixcblx0XHRcdFx0XCLDtlwiOiBcIm9cIixcblx0XHRcdFx0XCLDllwiOiBcIk9cIixcblx0XHRcdFx0XCLDvFwiOiBcInVcIixcblx0XHRcdFx0XCLDnFwiOiBcIlVcIixcblx0XHRcdFx0XCLFsVwiOiBcInVcIixcblx0XHRcdFx0XCLFsFwiOiBcIlVcIlxuXHRcdFx0fSxcblx0XHRcdFwibHRcIjoge1xuXHRcdFx0XHRcIsSFXCI6IFwiYVwiLFxuXHRcdFx0XHRcIsSNXCI6IFwiY1wiLFxuXHRcdFx0XHRcIsSZXCI6IFwiZVwiLFxuXHRcdFx0XHRcIsSXXCI6IFwiZVwiLFxuXHRcdFx0XHRcIsSvXCI6IFwiaVwiLFxuXHRcdFx0XHRcIsWhXCI6IFwic1wiLFxuXHRcdFx0XHRcIsWzXCI6IFwidVwiLFxuXHRcdFx0XHRcIsWrXCI6IFwidVwiLFxuXHRcdFx0XHRcIsW+XCI6IFwielwiLFxuXHRcdFx0XHRcIsSEXCI6IFwiQVwiLFxuXHRcdFx0XHRcIsSMXCI6IFwiQ1wiLFxuXHRcdFx0XHRcIsSYXCI6IFwiRVwiLFxuXHRcdFx0XHRcIsSWXCI6IFwiRVwiLFxuXHRcdFx0XHRcIsSuXCI6IFwiSVwiLFxuXHRcdFx0XHRcIsWgXCI6IFwiU1wiLFxuXHRcdFx0XHRcIsWyXCI6IFwiVVwiLFxuXHRcdFx0XHRcIsWqXCI6IFwiVVwiXG5cdFx0XHR9LFxuXHRcdFx0XCJsdlwiOiB7XG5cdFx0XHRcdFwixIFcIjogXCJhXCIsXG5cdFx0XHRcdFwixI1cIjogXCJjXCIsXG5cdFx0XHRcdFwixJNcIjogXCJlXCIsXG5cdFx0XHRcdFwixKNcIjogXCJnXCIsXG5cdFx0XHRcdFwixKtcIjogXCJpXCIsXG5cdFx0XHRcdFwixLdcIjogXCJrXCIsXG5cdFx0XHRcdFwixLxcIjogXCJsXCIsXG5cdFx0XHRcdFwixYZcIjogXCJuXCIsXG5cdFx0XHRcdFwixaFcIjogXCJzXCIsXG5cdFx0XHRcdFwixatcIjogXCJ1XCIsXG5cdFx0XHRcdFwixb5cIjogXCJ6XCIsXG5cdFx0XHRcdFwixIBcIjogXCJBXCIsXG5cdFx0XHRcdFwixIxcIjogXCJDXCIsXG5cdFx0XHRcdFwixJJcIjogXCJFXCIsXG5cdFx0XHRcdFwixKJcIjogXCJHXCIsXG5cdFx0XHRcdFwixKpcIjogXCJpXCIsXG5cdFx0XHRcdFwixLZcIjogXCJrXCIsXG5cdFx0XHRcdFwixLtcIjogXCJMXCIsXG5cdFx0XHRcdFwixYVcIjogXCJOXCIsXG5cdFx0XHRcdFwixaBcIjogXCJTXCIsXG5cdFx0XHRcdFwixapcIjogXCJ1XCIsXG5cdFx0XHRcdFwixb1cIjogXCJaXCJcblx0XHRcdH0sXG5cdFx0XHRcInBsXCI6IHtcblx0XHRcdFx0XCLEhVwiOiBcImFcIixcblx0XHRcdFx0XCLEh1wiOiBcImNcIixcblx0XHRcdFx0XCLEmVwiOiBcImVcIixcblx0XHRcdFx0XCLFglwiOiBcImxcIixcblx0XHRcdFx0XCLFhFwiOiBcIm5cIixcblx0XHRcdFx0XCLDs1wiOiBcIm9cIixcblx0XHRcdFx0XCLFm1wiOiBcInNcIixcblx0XHRcdFx0XCLFulwiOiBcInpcIixcblx0XHRcdFx0XCLFvFwiOiBcInpcIixcblx0XHRcdFx0XCLEhFwiOiBcIkFcIixcblx0XHRcdFx0XCLEhlwiOiBcIkNcIixcblx0XHRcdFx0XCLEmFwiOiBcImVcIixcblx0XHRcdFx0XCLFgVwiOiBcIkxcIixcblx0XHRcdFx0XCLFg1wiOiBcIk5cIixcblx0XHRcdFx0XCLDk1wiOiBcIk9cIixcblx0XHRcdFx0XCLFmlwiOiBcIlNcIixcblx0XHRcdFx0XCLFuVwiOiBcIlpcIixcblx0XHRcdFx0XCLFu1wiOiBcIlpcIlxuXHRcdFx0fSxcblx0XHRcdFwic3ZcIjoge1xuXHRcdFx0XHRcIsOkXCI6IFwiYVwiLFxuXHRcdFx0XHRcIsOEXCI6IFwiQVwiLFxuXHRcdFx0XHRcIsO2XCI6IFwib1wiLFxuXHRcdFx0XHRcIsOWXCI6IFwiT1wiXG5cdFx0XHR9LFxuXHRcdFx0XCJza1wiOiB7XG5cdFx0XHRcdFwiw6RcIjogXCJhXCIsXG5cdFx0XHRcdFwiw4RcIjogXCJBXCJcblx0XHRcdH0sXG5cdFx0XHRcInNyXCI6IHtcblx0XHRcdFx0XCLRmVwiOiBcImxqXCIsXG5cdFx0XHRcdFwi0ZpcIjogXCJualwiLFxuXHRcdFx0XHRcItCJXCI6IFwiTGpcIixcblx0XHRcdFx0XCLQilwiOiBcIk5qXCIsXG5cdFx0XHRcdFwixJFcIjogXCJkalwiLFxuXHRcdFx0XHRcIsSQXCI6IFwiRGpcIlxuXHRcdFx0fSxcblx0XHRcdFwidHJcIjoge1xuXHRcdFx0XHRcIsOcXCI6IFwiVVwiLFxuXHRcdFx0XHRcIsOWXCI6IFwiT1wiLFxuXHRcdFx0XHRcIsO8XCI6IFwidVwiLFxuXHRcdFx0XHRcIsO2XCI6IFwib1wiXG5cdFx0XHR9XG5cdFx0fTtcblx0XHQvKipcblx0XHQqIHN5bWJvbE1hcCBsYW5ndWFnZSBzcGVjaWZpYyBzeW1ib2wgdHJhbnNsYXRpb25zXG5cdFx0KiB0cmFuc2xhdGlvbnMgbXVzdCBiZSB0cmFuc2xpdGVyYXRlZCBhbHJlYWR5XG5cdFx0KiBAdHlwZSAgIHtPYmplY3R9XG5cdFx0Ki9cblx0XHR2YXIgc3ltYm9sTWFwID0ge1xuXHRcdFx0XCJhclwiOiB7XG5cdFx0XHRcdFwi4oiGXCI6IFwiZGVsdGFcIixcblx0XHRcdFx0XCLiiJ5cIjogXCJsYS1uaWhheWFcIixcblx0XHRcdFx0XCLimaVcIjogXCJob2JcIixcblx0XHRcdFx0XCImXCI6IFwid2FcIixcblx0XHRcdFx0XCJ8XCI6IFwiYXdcIixcblx0XHRcdFx0XCI8XCI6IFwiYXFhbC1tZW5cIixcblx0XHRcdFx0XCI+XCI6IFwiYWtiYXItbWVuXCIsXG5cdFx0XHRcdFwi4oiRXCI6IFwibWFqbW91XCIsXG5cdFx0XHRcdFwiwqRcIjogXCJvbWxhXCJcblx0XHRcdH0sXG5cdFx0XHRcImF6XCI6IHt9LFxuXHRcdFx0XCJjYVwiOiB7XG5cdFx0XHRcdFwi4oiGXCI6IFwiZGVsdGFcIixcblx0XHRcdFx0XCLiiJ5cIjogXCJpbmZpbml0XCIsXG5cdFx0XHRcdFwi4pmlXCI6IFwiYW1vclwiLFxuXHRcdFx0XHRcIiZcIjogXCJpXCIsXG5cdFx0XHRcdFwifFwiOiBcIm9cIixcblx0XHRcdFx0XCI8XCI6IFwibWVueXMgcXVlXCIsXG5cdFx0XHRcdFwiPlwiOiBcIm1lcyBxdWVcIixcblx0XHRcdFx0XCLiiJFcIjogXCJzdW1hIGRlbHNcIixcblx0XHRcdFx0XCLCpFwiOiBcIm1vbmVkYVwiXG5cdFx0XHR9LFxuXHRcdFx0XCJjc1wiOiB7XG5cdFx0XHRcdFwi4oiGXCI6IFwiZGVsdGFcIixcblx0XHRcdFx0XCLiiJ5cIjogXCJuZWtvbmVjbm9cIixcblx0XHRcdFx0XCLimaVcIjogXCJsYXNrYVwiLFxuXHRcdFx0XHRcIiZcIjogXCJhXCIsXG5cdFx0XHRcdFwifFwiOiBcIm5lYm9cIixcblx0XHRcdFx0XCI8XCI6IFwibWVuc2kgbmV6XCIsXG5cdFx0XHRcdFwiPlwiOiBcInZldHNpIG5lelwiLFxuXHRcdFx0XHRcIuKIkVwiOiBcInNvdWNldFwiLFxuXHRcdFx0XHRcIsKkXCI6IFwibWVuYVwiXG5cdFx0XHR9LFxuXHRcdFx0XCJkZVwiOiB7XG5cdFx0XHRcdFwi4oiGXCI6IFwiZGVsdGFcIixcblx0XHRcdFx0XCLiiJ5cIjogXCJ1bmVuZGxpY2hcIixcblx0XHRcdFx0XCLimaVcIjogXCJMaWViZVwiLFxuXHRcdFx0XHRcIiZcIjogXCJ1bmRcIixcblx0XHRcdFx0XCJ8XCI6IFwib2RlclwiLFxuXHRcdFx0XHRcIjxcIjogXCJrbGVpbmVyIGFsc1wiLFxuXHRcdFx0XHRcIj5cIjogXCJncm9lc3NlciBhbHNcIixcblx0XHRcdFx0XCLiiJFcIjogXCJTdW1tZSB2b25cIixcblx0XHRcdFx0XCLCpFwiOiBcIldhZWhydW5nXCJcblx0XHRcdH0sXG5cdFx0XHRcImR2XCI6IHtcblx0XHRcdFx0XCLiiIZcIjogXCJkZWx0YVwiLFxuXHRcdFx0XHRcIuKInlwiOiBcImtvbHVudWxhYVwiLFxuXHRcdFx0XHRcIuKZpVwiOiBcImxvYWJpXCIsXG5cdFx0XHRcdFwiJlwiOiBcImFhaVwiLFxuXHRcdFx0XHRcInxcIjogXCJub29uZWVcIixcblx0XHRcdFx0XCI8XCI6IFwiYWggdnVyZSBrdWRhXCIsXG5cdFx0XHRcdFwiPlwiOiBcImFoIHZ1cmUgYm9kdVwiLFxuXHRcdFx0XHRcIuKIkVwiOiBcImp1bXVsYVwiLFxuXHRcdFx0XHRcIsKkXCI6IFwiZmFpc2FhXCJcblx0XHRcdH0sXG5cdFx0XHRcImVuXCI6IHtcblx0XHRcdFx0XCLiiIZcIjogXCJkZWx0YVwiLFxuXHRcdFx0XHRcIuKInlwiOiBcImluZmluaXR5XCIsXG5cdFx0XHRcdFwi4pmlXCI6IFwibG92ZVwiLFxuXHRcdFx0XHRcIiZcIjogXCJhbmRcIixcblx0XHRcdFx0XCJ8XCI6IFwib3JcIixcblx0XHRcdFx0XCI8XCI6IFwibGVzcyB0aGFuXCIsXG5cdFx0XHRcdFwiPlwiOiBcImdyZWF0ZXIgdGhhblwiLFxuXHRcdFx0XHRcIuKIkVwiOiBcInN1bVwiLFxuXHRcdFx0XHRcIsKkXCI6IFwiY3VycmVuY3lcIlxuXHRcdFx0fSxcblx0XHRcdFwiZXNcIjoge1xuXHRcdFx0XHRcIuKIhlwiOiBcImRlbHRhXCIsXG5cdFx0XHRcdFwi4oieXCI6IFwiaW5maW5pdG9cIixcblx0XHRcdFx0XCLimaVcIjogXCJhbW9yXCIsXG5cdFx0XHRcdFwiJlwiOiBcInlcIixcblx0XHRcdFx0XCJ8XCI6IFwidVwiLFxuXHRcdFx0XHRcIjxcIjogXCJtZW5vcyBxdWVcIixcblx0XHRcdFx0XCI+XCI6IFwibWFzIHF1ZVwiLFxuXHRcdFx0XHRcIuKIkVwiOiBcInN1bWEgZGUgbG9zXCIsXG5cdFx0XHRcdFwiwqRcIjogXCJtb25lZGFcIlxuXHRcdFx0fSxcblx0XHRcdFwiZmFcIjoge1xuXHRcdFx0XHRcIuKIhlwiOiBcImRlbHRhXCIsXG5cdFx0XHRcdFwi4oieXCI6IFwiYmktbmFoYXlhdFwiLFxuXHRcdFx0XHRcIuKZpVwiOiBcImVzaGdoXCIsXG5cdFx0XHRcdFwiJlwiOiBcInZhXCIsXG5cdFx0XHRcdFwifFwiOiBcInlhXCIsXG5cdFx0XHRcdFwiPFwiOiBcImthbXRhci1helwiLFxuXHRcdFx0XHRcIj5cIjogXCJiaXNodGFyLWF6XCIsXG5cdFx0XHRcdFwi4oiRXCI6IFwibWFqbW9vZVwiLFxuXHRcdFx0XHRcIsKkXCI6IFwidmFoZWRcIlxuXHRcdFx0fSxcblx0XHRcdFwiZmlcIjoge1xuXHRcdFx0XHRcIuKIhlwiOiBcImRlbHRhXCIsXG5cdFx0XHRcdFwi4oieXCI6IFwiYWFyZXR0b215eXNcIixcblx0XHRcdFx0XCLimaVcIjogXCJyYWtrYXVzXCIsXG5cdFx0XHRcdFwiJlwiOiBcImphXCIsXG5cdFx0XHRcdFwifFwiOiBcInRhaVwiLFxuXHRcdFx0XHRcIjxcIjogXCJwaWVuZW1waSBrdWluXCIsXG5cdFx0XHRcdFwiPlwiOiBcInN1dXJlbXBpIGt1aW5cIixcblx0XHRcdFx0XCLiiJFcIjogXCJzdW1tYVwiLFxuXHRcdFx0XHRcIsKkXCI6IFwidmFsdXV0dGFcIlxuXHRcdFx0fSxcblx0XHRcdFwiZnJcIjoge1xuXHRcdFx0XHRcIuKIhlwiOiBcImRlbHRhXCIsXG5cdFx0XHRcdFwi4oieXCI6IFwiaW5maW5pbWVudFwiLFxuXHRcdFx0XHRcIuKZpVwiOiBcIkFtb3VyXCIsXG5cdFx0XHRcdFwiJlwiOiBcImV0XCIsXG5cdFx0XHRcdFwifFwiOiBcIm91XCIsXG5cdFx0XHRcdFwiPFwiOiBcIm1vaW5zIHF1ZVwiLFxuXHRcdFx0XHRcIj5cIjogXCJzdXBlcmlldXJlIGFcIixcblx0XHRcdFx0XCLiiJFcIjogXCJzb21tZSBkZXNcIixcblx0XHRcdFx0XCLCpFwiOiBcIm1vbm5haWVcIlxuXHRcdFx0fSxcblx0XHRcdFwiZ2VcIjoge1xuXHRcdFx0XHRcIuKIhlwiOiBcImRlbHRhXCIsXG5cdFx0XHRcdFwi4oieXCI6IFwidXNhc3J1bG9iYVwiLFxuXHRcdFx0XHRcIuKZpVwiOiBcInNpcXZhcnVsaVwiLFxuXHRcdFx0XHRcIiZcIjogXCJkYVwiLFxuXHRcdFx0XHRcInxcIjogXCJhblwiLFxuXHRcdFx0XHRcIjxcIjogXCJuYWtsZWJpXCIsXG5cdFx0XHRcdFwiPlwiOiBcIm1ldGlcIixcblx0XHRcdFx0XCLiiJFcIjogXCJqYW1pXCIsXG5cdFx0XHRcdFwiwqRcIjogXCJ2YWx1dGFcIlxuXHRcdFx0fSxcblx0XHRcdFwiZ3JcIjoge30sXG5cdFx0XHRcImh1XCI6IHtcblx0XHRcdFx0XCLiiIZcIjogXCJkZWx0YVwiLFxuXHRcdFx0XHRcIuKInlwiOiBcInZlZ3RlbGVuXCIsXG5cdFx0XHRcdFwi4pmlXCI6IFwic3plcmVsZW1cIixcblx0XHRcdFx0XCImXCI6IFwiZXNcIixcblx0XHRcdFx0XCJ8XCI6IFwidmFneVwiLFxuXHRcdFx0XHRcIjxcIjogXCJraXNlYmIgbWludFwiLFxuXHRcdFx0XHRcIj5cIjogXCJuYWd5b2JiIG1pbnRcIixcblx0XHRcdFx0XCLiiJFcIjogXCJzenVtbWFcIixcblx0XHRcdFx0XCLCpFwiOiBcInBlbnpuZW1cIlxuXHRcdFx0fSxcblx0XHRcdFwiaXRcIjoge1xuXHRcdFx0XHRcIuKIhlwiOiBcImRlbHRhXCIsXG5cdFx0XHRcdFwi4oieXCI6IFwiaW5maW5pdG9cIixcblx0XHRcdFx0XCLimaVcIjogXCJhbW9yZVwiLFxuXHRcdFx0XHRcIiZcIjogXCJlXCIsXG5cdFx0XHRcdFwifFwiOiBcIm9cIixcblx0XHRcdFx0XCI8XCI6IFwibWlub3JlIGRpXCIsXG5cdFx0XHRcdFwiPlwiOiBcIm1hZ2dpb3JlIGRpXCIsXG5cdFx0XHRcdFwi4oiRXCI6IFwic29tbWFcIixcblx0XHRcdFx0XCLCpFwiOiBcIm1vbmV0YVwiXG5cdFx0XHR9LFxuXHRcdFx0XCJsdFwiOiB7XG5cdFx0XHRcdFwi4oiGXCI6IFwiZGVsdGFcIixcblx0XHRcdFx0XCLiiJ5cIjogXCJiZWdhbHliZVwiLFxuXHRcdFx0XHRcIuKZpVwiOiBcIm1laWxlXCIsXG5cdFx0XHRcdFwiJlwiOiBcImlyXCIsXG5cdFx0XHRcdFwifFwiOiBcImFyXCIsXG5cdFx0XHRcdFwiPFwiOiBcIm1hemlhdSBuZWlcIixcblx0XHRcdFx0XCI+XCI6IFwiZGF1Z2lhdSBuZWlcIixcblx0XHRcdFx0XCLiiJFcIjogXCJzdW1hXCIsXG5cdFx0XHRcdFwiwqRcIjogXCJ2YWxpdXRhXCJcblx0XHRcdH0sXG5cdFx0XHRcImx2XCI6IHtcblx0XHRcdFx0XCLiiIZcIjogXCJkZWx0YVwiLFxuXHRcdFx0XHRcIuKInlwiOiBcImJlemdhbGliYVwiLFxuXHRcdFx0XHRcIuKZpVwiOiBcIm1pbGVzdGliYVwiLFxuXHRcdFx0XHRcIiZcIjogXCJ1blwiLFxuXHRcdFx0XHRcInxcIjogXCJ2YWlcIixcblx0XHRcdFx0XCI8XCI6IFwibWF6YWsgbmVrYVwiLFxuXHRcdFx0XHRcIj5cIjogXCJsaWVsYWtzIG5la2FcIixcblx0XHRcdFx0XCLiiJFcIjogXCJzdW1tYVwiLFxuXHRcdFx0XHRcIsKkXCI6IFwidmFsdXRhXCJcblx0XHRcdH0sXG5cdFx0XHRcIm15XCI6IHtcblx0XHRcdFx0XCLiiIZcIjogXCJrd2Foa2h5YWV0XCIsXG5cdFx0XHRcdFwi4oieXCI6IFwiYXNhb25hc21lXCIsXG5cdFx0XHRcdFwi4pmlXCI6IFwiYWtoeWFpdFwiLFxuXHRcdFx0XHRcIiZcIjogXCJuaGluXCIsXG5cdFx0XHRcdFwifFwiOiBcInRob1wiLFxuXHRcdFx0XHRcIjxcIjogXCJuZ2V0aGF3XCIsXG5cdFx0XHRcdFwiPlwiOiBcImt5aXRoYXdcIixcblx0XHRcdFx0XCLiiJFcIjogXCJwYXVuZ2xkXCIsXG5cdFx0XHRcdFwiwqRcIjogXCJuZ3dla3llXCJcblx0XHRcdH0sXG5cdFx0XHRcIm1rXCI6IHt9LFxuXHRcdFx0XCJubFwiOiB7XG5cdFx0XHRcdFwi4oiGXCI6IFwiZGVsdGFcIixcblx0XHRcdFx0XCLiiJ5cIjogXCJvbmVpbmRpZ1wiLFxuXHRcdFx0XHRcIuKZpVwiOiBcImxpZWZkZVwiLFxuXHRcdFx0XHRcIiZcIjogXCJlblwiLFxuXHRcdFx0XHRcInxcIjogXCJvZlwiLFxuXHRcdFx0XHRcIjxcIjogXCJrbGVpbmVyIGRhblwiLFxuXHRcdFx0XHRcIj5cIjogXCJncm90ZXIgZGFuXCIsXG5cdFx0XHRcdFwi4oiRXCI6IFwic29tXCIsXG5cdFx0XHRcdFwiwqRcIjogXCJ2YWx1dGFcIlxuXHRcdFx0fSxcblx0XHRcdFwicGxcIjoge1xuXHRcdFx0XHRcIuKIhlwiOiBcImRlbHRhXCIsXG5cdFx0XHRcdFwi4oieXCI6IFwibmllc2tvbmN6b25vc2NcIixcblx0XHRcdFx0XCLimaVcIjogXCJtaWxvc2NcIixcblx0XHRcdFx0XCImXCI6IFwiaVwiLFxuXHRcdFx0XHRcInxcIjogXCJsdWJcIixcblx0XHRcdFx0XCI8XCI6IFwibW5pZWpzemUgbml6XCIsXG5cdFx0XHRcdFwiPlwiOiBcIndpZWtzemUgbml6XCIsXG5cdFx0XHRcdFwi4oiRXCI6IFwic3VtYVwiLFxuXHRcdFx0XHRcIsKkXCI6IFwid2FsdXRhXCJcblx0XHRcdH0sXG5cdFx0XHRcInB0XCI6IHtcblx0XHRcdFx0XCLiiIZcIjogXCJkZWx0YVwiLFxuXHRcdFx0XHRcIuKInlwiOiBcImluZmluaXRvXCIsXG5cdFx0XHRcdFwi4pmlXCI6IFwiYW1vclwiLFxuXHRcdFx0XHRcIiZcIjogXCJlXCIsXG5cdFx0XHRcdFwifFwiOiBcIm91XCIsXG5cdFx0XHRcdFwiPFwiOiBcIm1lbm9yIHF1ZVwiLFxuXHRcdFx0XHRcIj5cIjogXCJtYWlvciBxdWVcIixcblx0XHRcdFx0XCLiiJFcIjogXCJzb21hXCIsXG5cdFx0XHRcdFwiwqRcIjogXCJtb2VkYVwiXG5cdFx0XHR9LFxuXHRcdFx0XCJyb1wiOiB7XG5cdFx0XHRcdFwi4oiGXCI6IFwiZGVsdGFcIixcblx0XHRcdFx0XCLiiJ5cIjogXCJpbmZpbml0XCIsXG5cdFx0XHRcdFwi4pmlXCI6IFwiZHJhZ29zdGVcIixcblx0XHRcdFx0XCImXCI6IFwic2lcIixcblx0XHRcdFx0XCJ8XCI6IFwic2F1XCIsXG5cdFx0XHRcdFwiPFwiOiBcIm1haSBtaWMgY2FcIixcblx0XHRcdFx0XCI+XCI6IFwibWFpIG1hcmUgY2FcIixcblx0XHRcdFx0XCLiiJFcIjogXCJzdW1hXCIsXG5cdFx0XHRcdFwiwqRcIjogXCJ2YWx1dGFcIlxuXHRcdFx0fSxcblx0XHRcdFwicnVcIjoge1xuXHRcdFx0XHRcIuKIhlwiOiBcImRlbHRhXCIsXG5cdFx0XHRcdFwi4oieXCI6IFwiYmVza29uZWNobm9cIixcblx0XHRcdFx0XCLimaVcIjogXCJsdWJvdlwiLFxuXHRcdFx0XHRcIiZcIjogXCJpXCIsXG5cdFx0XHRcdFwifFwiOiBcImlsaVwiLFxuXHRcdFx0XHRcIjxcIjogXCJtZW5zaGVcIixcblx0XHRcdFx0XCI+XCI6IFwiYm9sc2hlXCIsXG5cdFx0XHRcdFwi4oiRXCI6IFwic3VtbWFcIixcblx0XHRcdFx0XCLCpFwiOiBcInZhbGp1dGFcIlxuXHRcdFx0fSxcblx0XHRcdFwic2tcIjoge1xuXHRcdFx0XHRcIuKIhlwiOiBcImRlbHRhXCIsXG5cdFx0XHRcdFwi4oieXCI6IFwibmVrb25lY25vXCIsXG5cdFx0XHRcdFwi4pmlXCI6IFwibGFza2FcIixcblx0XHRcdFx0XCImXCI6IFwiYVwiLFxuXHRcdFx0XHRcInxcIjogXCJhbGVib1wiLFxuXHRcdFx0XHRcIjxcIjogXCJtZW5laiBha29cIixcblx0XHRcdFx0XCI+XCI6IFwidmlhYyBha29cIixcblx0XHRcdFx0XCLiiJFcIjogXCJzdWNldFwiLFxuXHRcdFx0XHRcIsKkXCI6IFwibWVuYVwiXG5cdFx0XHR9LFxuXHRcdFx0XCJzclwiOiB7fSxcblx0XHRcdFwidHJcIjoge1xuXHRcdFx0XHRcIuKIhlwiOiBcImRlbHRhXCIsXG5cdFx0XHRcdFwi4oieXCI6IFwic29uc3V6bHVrXCIsXG5cdFx0XHRcdFwi4pmlXCI6IFwiYXNrXCIsXG5cdFx0XHRcdFwiJlwiOiBcInZlXCIsXG5cdFx0XHRcdFwifFwiOiBcInZleWFcIixcblx0XHRcdFx0XCI8XCI6IFwia3VjdWt0dXJcIixcblx0XHRcdFx0XCI+XCI6IFwiYnV5dWt0dXJcIixcblx0XHRcdFx0XCLiiJFcIjogXCJ0b3BsYW1cIixcblx0XHRcdFx0XCLCpFwiOiBcInBhcmEgYmlyaW1pXCJcblx0XHRcdH0sXG5cdFx0XHRcInVrXCI6IHtcblx0XHRcdFx0XCLiiIZcIjogXCJkZWx0YVwiLFxuXHRcdFx0XHRcIuKInlwiOiBcImJlemtpbmVjaG5pc3RcIixcblx0XHRcdFx0XCLimaVcIjogXCJsdWJvdlwiLFxuXHRcdFx0XHRcIiZcIjogXCJpXCIsXG5cdFx0XHRcdFwifFwiOiBcImFib1wiLFxuXHRcdFx0XHRcIjxcIjogXCJtZW5zaGVcIixcblx0XHRcdFx0XCI+XCI6IFwiYmlsc2hlXCIsXG5cdFx0XHRcdFwi4oiRXCI6IFwic3VtYVwiLFxuXHRcdFx0XHRcIsKkXCI6IFwidmFsanV0YVwiXG5cdFx0XHR9LFxuXHRcdFx0XCJ2blwiOiB7XG5cdFx0XHRcdFwi4oiGXCI6IFwiZGVsdGFcIixcblx0XHRcdFx0XCLiiJ5cIjogXCJ2byBjdWNcIixcblx0XHRcdFx0XCLimaVcIjogXCJ5ZXVcIixcblx0XHRcdFx0XCImXCI6IFwidmFcIixcblx0XHRcdFx0XCJ8XCI6IFwiaG9hY1wiLFxuXHRcdFx0XHRcIjxcIjogXCJuaG8gaG9uXCIsXG5cdFx0XHRcdFwiPlwiOiBcImxvbiBob25cIixcblx0XHRcdFx0XCLiiJFcIjogXCJ0b25nXCIsXG5cdFx0XHRcdFwiwqRcIjogXCJ0aWVuIHRlXCJcblx0XHRcdH1cblx0XHR9O1xuXHRcdHZhciB1cmljQ2hhcnMgPSBbXG5cdFx0XHRcIjtcIixcblx0XHRcdFwiP1wiLFxuXHRcdFx0XCI6XCIsXG5cdFx0XHRcIkBcIixcblx0XHRcdFwiJlwiLFxuXHRcdFx0XCI9XCIsXG5cdFx0XHRcIitcIixcblx0XHRcdFwiJFwiLFxuXHRcdFx0XCIsXCIsXG5cdFx0XHRcIi9cIlxuXHRcdF0uam9pbihcIlwiKTtcblx0XHR2YXIgdXJpY05vU2xhc2hDaGFycyA9IFtcblx0XHRcdFwiO1wiLFxuXHRcdFx0XCI/XCIsXG5cdFx0XHRcIjpcIixcblx0XHRcdFwiQFwiLFxuXHRcdFx0XCImXCIsXG5cdFx0XHRcIj1cIixcblx0XHRcdFwiK1wiLFxuXHRcdFx0XCIkXCIsXG5cdFx0XHRcIixcIlxuXHRcdF0uam9pbihcIlwiKTtcblx0XHR2YXIgbWFya0NoYXJzID0gW1xuXHRcdFx0XCIuXCIsXG5cdFx0XHRcIiFcIixcblx0XHRcdFwiflwiLFxuXHRcdFx0XCIqXCIsXG5cdFx0XHRcIidcIixcblx0XHRcdFwiKFwiLFxuXHRcdFx0XCIpXCJcblx0XHRdLmpvaW4oXCJcIik7XG5cdFx0LyoqXG5cdFx0KiBnZXRTbHVnXG5cdFx0KiBAcGFyYW0gIHtzdHJpbmd9IGlucHV0IGlucHV0IHN0cmluZ1xuXHRcdCogQHBhcmFtICB7b2JqZWN0fHN0cmluZ30gb3B0cyBjb25maWcgb2JqZWN0IG9yIHNlcGFyYXRvciBzdHJpbmcvY2hhclxuXHRcdCogQGFwaSAgICBwdWJsaWNcblx0XHQqIEByZXR1cm4ge3N0cmluZ30gIHNsdWdnaWZpZWQgc3RyaW5nXG5cdFx0Ki9cblx0XHR2YXIgZ2V0U2x1ZyA9IGZ1bmN0aW9uIGdldFNsdWcoaW5wdXQsIG9wdHMpIHtcblx0XHRcdHZhciBzZXBhcmF0b3IgPSBcIi1cIjtcblx0XHRcdHZhciByZXN1bHQgPSBcIlwiO1xuXHRcdFx0dmFyIGRpYXRyaWNTdHJpbmcgPSBcIlwiO1xuXHRcdFx0dmFyIGNvbnZlcnRTeW1ib2xzID0gdHJ1ZTtcblx0XHRcdHZhciBjdXN0b21SZXBsYWNlbWVudHMgPSB7fTtcblx0XHRcdHZhciBtYWludGFpbkNhc2U7XG5cdFx0XHR2YXIgdGl0bGVDYXNlO1xuXHRcdFx0dmFyIHRydW5jYXRlO1xuXHRcdFx0dmFyIHVyaWNGbGFnO1xuXHRcdFx0dmFyIHVyaWNOb1NsYXNoRmxhZztcblx0XHRcdHZhciBtYXJrRmxhZztcblx0XHRcdHZhciBzeW1ib2w7XG5cdFx0XHR2YXIgbGFuZ0NoYXI7XG5cdFx0XHR2YXIgbHVja3k7XG5cdFx0XHR2YXIgaTtcblx0XHRcdHZhciBjaDtcblx0XHRcdHZhciBsO1xuXHRcdFx0dmFyIGxhc3RDaGFyV2FzU3ltYm9sO1xuXHRcdFx0dmFyIGxhc3RDaGFyV2FzRGlhdHJpYztcblx0XHRcdHZhciBhbGxvd2VkQ2hhcnMgPSBcIlwiO1xuXHRcdFx0aWYgKHR5cGVvZiBpbnB1dCAhPT0gXCJzdHJpbmdcIikgcmV0dXJuIFwiXCI7XG5cdFx0XHRpZiAodHlwZW9mIG9wdHMgPT09IFwic3RyaW5nXCIpIHNlcGFyYXRvciA9IG9wdHM7XG5cdFx0XHRzeW1ib2wgPSBzeW1ib2xNYXAuZW47XG5cdFx0XHRsYW5nQ2hhciA9IGxhbmdDaGFyTWFwLmVuO1xuXHRcdFx0aWYgKHR5cGVvZiBvcHRzID09PSBcIm9iamVjdFwiKSB7XG5cdFx0XHRcdG1haW50YWluQ2FzZSA9IG9wdHMubWFpbnRhaW5DYXNlIHx8IGZhbHNlO1xuXHRcdFx0XHRjdXN0b21SZXBsYWNlbWVudHMgPSBvcHRzLmN1c3RvbSAmJiB0eXBlb2Ygb3B0cy5jdXN0b20gPT09IFwib2JqZWN0XCIgPyBvcHRzLmN1c3RvbSA6IGN1c3RvbVJlcGxhY2VtZW50cztcblx0XHRcdFx0dHJ1bmNhdGUgPSArb3B0cy50cnVuY2F0ZSA+IDEgJiYgb3B0cy50cnVuY2F0ZSB8fCBmYWxzZTtcblx0XHRcdFx0dXJpY0ZsYWcgPSBvcHRzLnVyaWMgfHwgZmFsc2U7XG5cdFx0XHRcdHVyaWNOb1NsYXNoRmxhZyA9IG9wdHMudXJpY05vU2xhc2ggfHwgZmFsc2U7XG5cdFx0XHRcdG1hcmtGbGFnID0gb3B0cy5tYXJrIHx8IGZhbHNlO1xuXHRcdFx0XHRjb252ZXJ0U3ltYm9scyA9IG9wdHMuc3ltYm9scyA9PT0gZmFsc2UgfHwgb3B0cy5sYW5nID09PSBmYWxzZSA/IGZhbHNlIDogdHJ1ZTtcblx0XHRcdFx0c2VwYXJhdG9yID0gb3B0cy5zZXBhcmF0b3IgfHwgc2VwYXJhdG9yO1xuXHRcdFx0XHRpZiAodXJpY0ZsYWcpIGFsbG93ZWRDaGFycyArPSB1cmljQ2hhcnM7XG5cdFx0XHRcdGlmICh1cmljTm9TbGFzaEZsYWcpIGFsbG93ZWRDaGFycyArPSB1cmljTm9TbGFzaENoYXJzO1xuXHRcdFx0XHRpZiAobWFya0ZsYWcpIGFsbG93ZWRDaGFycyArPSBtYXJrQ2hhcnM7XG5cdFx0XHRcdHN5bWJvbCA9IG9wdHMubGFuZyAmJiBzeW1ib2xNYXBbb3B0cy5sYW5nXSAmJiBjb252ZXJ0U3ltYm9scyA/IHN5bWJvbE1hcFtvcHRzLmxhbmddIDogY29udmVydFN5bWJvbHMgPyBzeW1ib2xNYXAuZW4gOiB7fTtcblx0XHRcdFx0bGFuZ0NoYXIgPSBvcHRzLmxhbmcgJiYgbGFuZ0NoYXJNYXBbb3B0cy5sYW5nXSA/IGxhbmdDaGFyTWFwW29wdHMubGFuZ10gOiBvcHRzLmxhbmcgPT09IGZhbHNlIHx8IG9wdHMubGFuZyA9PT0gdHJ1ZSA/IHt9IDogbGFuZ0NoYXJNYXAuZW47XG5cdFx0XHRcdGlmIChvcHRzLnRpdGxlQ2FzZSAmJiB0eXBlb2Ygb3B0cy50aXRsZUNhc2UubGVuZ3RoID09PSBcIm51bWJlclwiICYmIEFycmF5LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKG9wdHMudGl0bGVDYXNlKSkge1xuXHRcdFx0XHRcdG9wdHMudGl0bGVDYXNlLmZvckVhY2goZnVuY3Rpb24odikge1xuXHRcdFx0XHRcdFx0Y3VzdG9tUmVwbGFjZW1lbnRzW3YgKyBcIlwiXSA9IHYgKyBcIlwiO1xuXHRcdFx0XHRcdH0pO1xuXHRcdFx0XHRcdHRpdGxlQ2FzZSA9IHRydWU7XG5cdFx0XHRcdH0gZWxzZSB0aXRsZUNhc2UgPSAhIW9wdHMudGl0bGVDYXNlO1xuXHRcdFx0XHRpZiAob3B0cy5jdXN0b20gJiYgdHlwZW9mIG9wdHMuY3VzdG9tLmxlbmd0aCA9PT0gXCJudW1iZXJcIiAmJiBBcnJheS5wcm90b3R5cGUudG9TdHJpbmcuY2FsbChvcHRzLmN1c3RvbSkpIG9wdHMuY3VzdG9tLmZvckVhY2goZnVuY3Rpb24odikge1xuXHRcdFx0XHRcdGN1c3RvbVJlcGxhY2VtZW50c1t2ICsgXCJcIl0gPSB2ICsgXCJcIjtcblx0XHRcdFx0fSk7XG5cdFx0XHRcdE9iamVjdC5rZXlzKGN1c3RvbVJlcGxhY2VtZW50cykuZm9yRWFjaChmdW5jdGlvbih2KSB7XG5cdFx0XHRcdFx0dmFyIHI7XG5cdFx0XHRcdFx0aWYgKHYubGVuZ3RoID4gMSkgciA9IG5ldyBSZWdFeHAoXCJcXFxcYlwiICsgZXNjYXBlQ2hhcnModikgKyBcIlxcXFxiXCIsIFwiZ2lcIik7XG5cdFx0XHRcdFx0ZWxzZSByID0gbmV3IFJlZ0V4cChlc2NhcGVDaGFycyh2KSwgXCJnaVwiKTtcblx0XHRcdFx0XHRpbnB1dCA9IGlucHV0LnJlcGxhY2UociwgY3VzdG9tUmVwbGFjZW1lbnRzW3ZdKTtcblx0XHRcdFx0fSk7XG5cdFx0XHRcdGZvciAoY2ggaW4gY3VzdG9tUmVwbGFjZW1lbnRzKSBhbGxvd2VkQ2hhcnMgKz0gY2g7XG5cdFx0XHR9XG5cdFx0XHRhbGxvd2VkQ2hhcnMgKz0gc2VwYXJhdG9yO1xuXHRcdFx0YWxsb3dlZENoYXJzID0gZXNjYXBlQ2hhcnMoYWxsb3dlZENoYXJzKTtcblx0XHRcdGlucHV0ID0gaW5wdXQucmVwbGFjZSgvKF5cXHMrfFxccyskKS9nLCBcIlwiKTtcblx0XHRcdGxhc3RDaGFyV2FzU3ltYm9sID0gZmFsc2U7XG5cdFx0XHRsYXN0Q2hhcldhc0RpYXRyaWMgPSBmYWxzZTtcblx0XHRcdGZvciAoaSA9IDAsIGwgPSBpbnB1dC5sZW5ndGg7IGkgPCBsOyBpKyspIHtcblx0XHRcdFx0Y2ggPSBpbnB1dFtpXTtcblx0XHRcdFx0aWYgKGlzUmVwbGFjZWRDdXN0b21DaGFyKGNoLCBjdXN0b21SZXBsYWNlbWVudHMpKSBsYXN0Q2hhcldhc1N5bWJvbCA9IGZhbHNlO1xuXHRcdFx0XHRlbHNlIGlmIChsYW5nQ2hhcltjaF0pIHtcblx0XHRcdFx0XHRjaCA9IGxhc3RDaGFyV2FzU3ltYm9sICYmIGxhbmdDaGFyW2NoXS5tYXRjaCgvW0EtWmEtejAtOV0vKSA/IFwiIFwiICsgbGFuZ0NoYXJbY2hdIDogbGFuZ0NoYXJbY2hdO1xuXHRcdFx0XHRcdGxhc3RDaGFyV2FzU3ltYm9sID0gZmFsc2U7XG5cdFx0XHRcdH0gZWxzZSBpZiAoY2ggaW4gY2hhck1hcCkge1xuXHRcdFx0XHRcdGlmIChpICsgMSA8IGwgJiYgbG9va0FoZWFkQ2hhckFycmF5LmluZGV4T2YoaW5wdXRbaSArIDFdKSA+PSAwKSB7XG5cdFx0XHRcdFx0XHRkaWF0cmljU3RyaW5nICs9IGNoO1xuXHRcdFx0XHRcdFx0Y2ggPSBcIlwiO1xuXHRcdFx0XHRcdH0gZWxzZSBpZiAobGFzdENoYXJXYXNEaWF0cmljID09PSB0cnVlKSB7XG5cdFx0XHRcdFx0XHRjaCA9IGRpYXRyaWNNYXBbZGlhdHJpY1N0cmluZ10gKyBjaGFyTWFwW2NoXTtcblx0XHRcdFx0XHRcdGRpYXRyaWNTdHJpbmcgPSBcIlwiO1xuXHRcdFx0XHRcdH0gZWxzZSBjaCA9IGxhc3RDaGFyV2FzU3ltYm9sICYmIGNoYXJNYXBbY2hdLm1hdGNoKC9bQS1aYS16MC05XS8pID8gXCIgXCIgKyBjaGFyTWFwW2NoXSA6IGNoYXJNYXBbY2hdO1xuXHRcdFx0XHRcdGxhc3RDaGFyV2FzU3ltYm9sID0gZmFsc2U7XG5cdFx0XHRcdFx0bGFzdENoYXJXYXNEaWF0cmljID0gZmFsc2U7XG5cdFx0XHRcdH0gZWxzZSBpZiAoY2ggaW4gZGlhdHJpY01hcCkge1xuXHRcdFx0XHRcdGRpYXRyaWNTdHJpbmcgKz0gY2g7XG5cdFx0XHRcdFx0Y2ggPSBcIlwiO1xuXHRcdFx0XHRcdGlmIChpID09PSBsIC0gMSkgY2ggPSBkaWF0cmljTWFwW2RpYXRyaWNTdHJpbmddO1xuXHRcdFx0XHRcdGxhc3RDaGFyV2FzRGlhdHJpYyA9IHRydWU7XG5cdFx0XHRcdH0gZWxzZSBpZiAoc3ltYm9sW2NoXSAmJiAhKHVyaWNGbGFnICYmIHVyaWNDaGFycy5pbmRleE9mKGNoKSAhPT0gLTEpICYmICEodXJpY05vU2xhc2hGbGFnICYmIHVyaWNOb1NsYXNoQ2hhcnMuaW5kZXhPZihjaCkgIT09IC0xKSkge1xuXHRcdFx0XHRcdGNoID0gbGFzdENoYXJXYXNTeW1ib2wgfHwgcmVzdWx0LnN1YnN0cigtMSkubWF0Y2goL1tBLVphLXowLTldLykgPyBzZXBhcmF0b3IgKyBzeW1ib2xbY2hdIDogc3ltYm9sW2NoXTtcblx0XHRcdFx0XHRjaCArPSBpbnB1dFtpICsgMV0gIT09IHZvaWQgMCAmJiBpbnB1dFtpICsgMV0ubWF0Y2goL1tBLVphLXowLTldLykgPyBzZXBhcmF0b3IgOiBcIlwiO1xuXHRcdFx0XHRcdGxhc3RDaGFyV2FzU3ltYm9sID0gdHJ1ZTtcblx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRpZiAobGFzdENoYXJXYXNEaWF0cmljID09PSB0cnVlKSB7XG5cdFx0XHRcdFx0XHRjaCA9IGRpYXRyaWNNYXBbZGlhdHJpY1N0cmluZ10gKyBjaDtcblx0XHRcdFx0XHRcdGRpYXRyaWNTdHJpbmcgPSBcIlwiO1xuXHRcdFx0XHRcdFx0bGFzdENoYXJXYXNEaWF0cmljID0gZmFsc2U7XG5cdFx0XHRcdFx0fSBlbHNlIGlmIChsYXN0Q2hhcldhc1N5bWJvbCAmJiAoL1tBLVphLXowLTldLy50ZXN0KGNoKSB8fCByZXN1bHQuc3Vic3RyKC0xKS5tYXRjaCgvQS1aYS16MC05XS8pKSkgY2ggPSBcIiBcIiArIGNoO1xuXHRcdFx0XHRcdGxhc3RDaGFyV2FzU3ltYm9sID0gZmFsc2U7XG5cdFx0XHRcdH1cblx0XHRcdFx0cmVzdWx0ICs9IGNoLnJlcGxhY2UobmV3IFJlZ0V4cChcIlteXFxcXHdcXFxcc1wiICsgYWxsb3dlZENoYXJzICsgXCJfLV1cIiwgXCJnXCIpLCBzZXBhcmF0b3IpO1xuXHRcdFx0fVxuXHRcdFx0aWYgKHRpdGxlQ2FzZSkgcmVzdWx0ID0gcmVzdWx0LnJlcGxhY2UoLyhcXHcpKFxcUyopL2csIGZ1bmN0aW9uKF8sIGksIHIpIHtcblx0XHRcdFx0dmFyIGogPSBpLnRvVXBwZXJDYXNlKCkgKyAociAhPT0gbnVsbCA/IHIgOiBcIlwiKTtcblx0XHRcdFx0cmV0dXJuIE9iamVjdC5rZXlzKGN1c3RvbVJlcGxhY2VtZW50cykuaW5kZXhPZihqLnRvTG93ZXJDYXNlKCkpIDwgMCA/IGogOiBqLnRvTG93ZXJDYXNlKCk7XG5cdFx0XHR9KTtcblx0XHRcdHJlc3VsdCA9IHJlc3VsdC5yZXBsYWNlKC9cXHMrL2csIHNlcGFyYXRvcikucmVwbGFjZShuZXcgUmVnRXhwKFwiXFxcXFwiICsgc2VwYXJhdG9yICsgXCIrXCIsIFwiZ1wiKSwgc2VwYXJhdG9yKS5yZXBsYWNlKG5ldyBSZWdFeHAoXCIoXlxcXFxcIiArIHNlcGFyYXRvciArIFwiK3xcXFxcXCIgKyBzZXBhcmF0b3IgKyBcIiskKVwiLCBcImdcIiksIFwiXCIpO1xuXHRcdFx0aWYgKHRydW5jYXRlICYmIHJlc3VsdC5sZW5ndGggPiB0cnVuY2F0ZSkge1xuXHRcdFx0XHRsdWNreSA9IHJlc3VsdC5jaGFyQXQodHJ1bmNhdGUpID09PSBzZXBhcmF0b3I7XG5cdFx0XHRcdHJlc3VsdCA9IHJlc3VsdC5zbGljZSgwLCB0cnVuY2F0ZSk7XG5cdFx0XHRcdGlmICghbHVja3kpIHJlc3VsdCA9IHJlc3VsdC5zbGljZSgwLCByZXN1bHQubGFzdEluZGV4T2Yoc2VwYXJhdG9yKSk7XG5cdFx0XHR9XG5cdFx0XHRpZiAoIW1haW50YWluQ2FzZSAmJiAhdGl0bGVDYXNlKSByZXN1bHQgPSByZXN1bHQudG9Mb3dlckNhc2UoKTtcblx0XHRcdHJldHVybiByZXN1bHQ7XG5cdFx0fTtcblx0XHQvKipcblx0XHQqIGNyZWF0ZVNsdWcgY3VycmllZChvcHRzKShpbnB1dClcblx0XHQqIEBwYXJhbSAgIHtvYmplY3R8c3RyaW5nfSBvcHRzIGNvbmZpZyBvYmplY3Qgb3IgaW5wdXQgc3RyaW5nXG5cdFx0KiBAcmV0dXJuICB7RnVuY3Rpb259IGZ1bmN0aW9uIGdldFNsdWdXaXRoQ29uZmlnKClcblx0XHQqKi9cblx0XHR2YXIgY3JlYXRlU2x1ZyA9IGZ1bmN0aW9uIGNyZWF0ZVNsdWcob3B0cykge1xuXHRcdFx0LyoqXG5cdFx0XHQqIGdldFNsdWdXaXRoQ29uZmlnXG5cdFx0XHQqIEBwYXJhbSAgIHtzdHJpbmd9IGlucHV0IHN0cmluZ1xuXHRcdFx0KiBAcmV0dXJuICB7c3RyaW5nfSBzbHVnIHN0cmluZ1xuXHRcdFx0Ki9cblx0XHRcdHJldHVybiBmdW5jdGlvbiBnZXRTbHVnV2l0aENvbmZpZyhpbnB1dCkge1xuXHRcdFx0XHRyZXR1cm4gZ2V0U2x1ZyhpbnB1dCwgb3B0cyk7XG5cdFx0XHR9O1xuXHRcdH07XG5cdFx0LyoqXG5cdFx0KiBlc2NhcGUgQ2hhcnNcblx0XHQqIEBwYXJhbSAgIHtzdHJpbmd9IGlucHV0IHN0cmluZ1xuXHRcdCovXG5cdFx0dmFyIGVzY2FwZUNoYXJzID0gZnVuY3Rpb24gZXNjYXBlQ2hhcnMoaW5wdXQpIHtcblx0XHRcdHJldHVybiBpbnB1dC5yZXBsYWNlKC9bLVxcXFxeJCorPy4oKXxbXFxde31cXC9dL2csIFwiXFxcXCQmXCIpO1xuXHRcdH07XG5cdFx0LyoqXG5cdFx0KiBjaGVjayBpZiB0aGUgY2hhciBpcyBhbiBhbHJlYWR5IGNvbnZlcnRlZCBjaGFyIGZyb20gY3VzdG9tIGxpc3Rcblx0XHQqIEBwYXJhbSAgIHtjaGFyfSBjaCBjaGFyYWN0ZXIgdG8gY2hlY2tcblx0XHQqIEBwYXJhbSAgIHtvYmplY3R9IGN1c3RvbVJlcGxhY2VtZW50cyBjdXN0b20gdHJhbnNsYXRpb24gbWFwXG5cdFx0Ki9cblx0XHR2YXIgaXNSZXBsYWNlZEN1c3RvbUNoYXIgPSBmdW5jdGlvbihjaCwgY3VzdG9tUmVwbGFjZW1lbnRzKSB7XG5cdFx0XHRmb3IgKHZhciBjIGluIGN1c3RvbVJlcGxhY2VtZW50cykgaWYgKGN1c3RvbVJlcGxhY2VtZW50c1tjXSA9PT0gY2gpIHJldHVybiB0cnVlO1xuXHRcdH07XG5cdFx0aWYgKHR5cGVvZiBtb2R1bGUgIT09IFwidW5kZWZpbmVkXCIgJiYgbW9kdWxlLmV4cG9ydHMpIHtcblx0XHRcdG1vZHVsZS5leHBvcnRzID0gZ2V0U2x1Zztcblx0XHRcdG1vZHVsZS5leHBvcnRzLmNyZWF0ZVNsdWcgPSBjcmVhdGVTbHVnO1xuXHRcdH0gZWxzZSBpZiAodHlwZW9mIGRlZmluZSAhPT0gXCJ1bmRlZmluZWRcIiAmJiBkZWZpbmUuYW1kKSBkZWZpbmUoW10sIGZ1bmN0aW9uKCkge1xuXHRcdFx0cmV0dXJuIGdldFNsdWc7XG5cdFx0fSk7XG5cdFx0ZWxzZSB0cnkge1xuXHRcdFx0aWYgKHJvb3QuZ2V0U2x1ZyB8fCByb290LmNyZWF0ZVNsdWcpIHRocm93IFwic3BlYWtpbmd1cmw6IGdsb2JhbHMgZXhpc3RzIC8oZ2V0U2x1Z3xjcmVhdGVTbHVnKS9cIjtcblx0XHRcdGVsc2Uge1xuXHRcdFx0XHRyb290LmdldFNsdWcgPSBnZXRTbHVnO1xuXHRcdFx0XHRyb290LmNyZWF0ZVNsdWcgPSBjcmVhdGVTbHVnO1xuXHRcdFx0fVxuXHRcdH0gY2F0Y2ggKGUpIHt9XG5cdH0pKGV4cG9ydHMpO1xufSkpO1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvYXBwL2luZGV4LnRzXG52YXIgaW1wb3J0X3NwZWFraW5ndXJsID0gLyogQF9fUFVSRV9fICovIF9fdG9FU00oKC8qIEBfX1BVUkVfXyAqLyBfX2NvbW1vbkpTTWluKCgoZXhwb3J0cywgbW9kdWxlKSA9PiB7XG5cdG1vZHVsZS5leHBvcnRzID0gcmVxdWlyZV9zcGVha2luZ3VybCQxKCk7XG59KSkpKCksIDEpO1xuY29uc3QgYXBwUmVjb3JkSW5mbyA9IHRhcmdldC5fX1ZVRV9ERVZUT09MU19ORVhUX0FQUF9SRUNPUkRfSU5GT19fID8/PSB7XG5cdGlkOiAwLFxuXHRhcHBJZHM6IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KClcbn07XG5mdW5jdGlvbiBnZXRBcHBSZWNvcmROYW1lKGFwcCwgZmFsbGJhY2tOYW1lKSB7XG5cdHJldHVybiBhcHA/Ll9jb21wb25lbnQ/Lm5hbWUgfHwgYEFwcCAke2ZhbGxiYWNrTmFtZX1gO1xufVxuZnVuY3Rpb24gZ2V0QXBwUm9vdEluc3RhbmNlKGFwcCkge1xuXHRpZiAoYXBwLl9pbnN0YW5jZSkgcmV0dXJuIGFwcC5faW5zdGFuY2U7XG5cdGVsc2UgaWYgKGFwcC5fY29udGFpbmVyPy5fdm5vZGU/LmNvbXBvbmVudCkgcmV0dXJuIGFwcC5fY29udGFpbmVyPy5fdm5vZGU/LmNvbXBvbmVudDtcbn1cbmZ1bmN0aW9uIHJlbW92ZUFwcFJlY29yZElkKGFwcCkge1xuXHRjb25zdCBpZCA9IGFwcC5fX1ZVRV9ERVZUT09MU19ORVhUX0FQUF9SRUNPUkRfSURfXztcblx0aWYgKGlkICE9IG51bGwpIHtcblx0XHRhcHBSZWNvcmRJbmZvLmFwcElkcy5kZWxldGUoaWQpO1xuXHRcdGFwcFJlY29yZEluZm8uaWQtLTtcblx0fVxufVxuZnVuY3Rpb24gZ2V0QXBwUmVjb3JkSWQoYXBwLCBkZWZhdWx0SWQpIHtcblx0aWYgKGFwcC5fX1ZVRV9ERVZUT09MU19ORVhUX0FQUF9SRUNPUkRfSURfXyAhPSBudWxsKSByZXR1cm4gYXBwLl9fVlVFX0RFVlRPT0xTX05FWFRfQVBQX1JFQ09SRF9JRF9fO1xuXHRsZXQgaWQgPSBkZWZhdWx0SWQgPz8gKGFwcFJlY29yZEluZm8uaWQrKykudG9TdHJpbmcoKTtcblx0aWYgKGRlZmF1bHRJZCAmJiBhcHBSZWNvcmRJbmZvLmFwcElkcy5oYXMoaWQpKSB7XG5cdFx0bGV0IGNvdW50ID0gMTtcblx0XHR3aGlsZSAoYXBwUmVjb3JkSW5mby5hcHBJZHMuaGFzKGAke2RlZmF1bHRJZH1fJHtjb3VudH1gKSkgY291bnQrKztcblx0XHRpZCA9IGAke2RlZmF1bHRJZH1fJHtjb3VudH1gO1xuXHR9XG5cdGFwcFJlY29yZEluZm8uYXBwSWRzLmFkZChpZCk7XG5cdGFwcC5fX1ZVRV9ERVZUT09MU19ORVhUX0FQUF9SRUNPUkRfSURfXyA9IGlkO1xuXHRyZXR1cm4gaWQ7XG59XG5mdW5jdGlvbiBjcmVhdGVBcHBSZWNvcmQoYXBwLCB0eXBlcykge1xuXHRjb25zdCByb290SW5zdGFuY2UgPSBnZXRBcHBSb290SW5zdGFuY2UoYXBwKTtcblx0aWYgKHJvb3RJbnN0YW5jZSkge1xuXHRcdGFwcFJlY29yZEluZm8uaWQrKztcblx0XHRjb25zdCBuYW1lID0gZ2V0QXBwUmVjb3JkTmFtZShhcHAsIGFwcFJlY29yZEluZm8uaWQudG9TdHJpbmcoKSk7XG5cdFx0Y29uc3QgaWQgPSBnZXRBcHBSZWNvcmRJZChhcHAsICgwLCBpbXBvcnRfc3BlYWtpbmd1cmwuZGVmYXVsdCkobmFtZSkpO1xuXHRcdGNvbnN0IFtlbF0gPSBnZXRSb290RWxlbWVudHNGcm9tQ29tcG9uZW50SW5zdGFuY2Uocm9vdEluc3RhbmNlKTtcblx0XHRjb25zdCByZWNvcmQgPSB7XG5cdFx0XHRpZCxcblx0XHRcdG5hbWUsXG5cdFx0XHR0eXBlcyxcblx0XHRcdGluc3RhbmNlTWFwOiAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpLFxuXHRcdFx0cGVyZkdyb3VwSWRzOiAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpLFxuXHRcdFx0cm9vdEluc3RhbmNlLFxuXHRcdFx0aWZyYW1lOiBpc0Jyb3dzZXIgJiYgZG9jdW1lbnQgIT09IGVsPy5vd25lckRvY3VtZW50ID8gZWw/Lm93bmVyRG9jdW1lbnQ/LmxvY2F0aW9uPy5wYXRobmFtZSA6IHZvaWQgMFxuXHRcdH07XG5cdFx0YXBwLl9fVlVFX0RFVlRPT0xTX05FWFRfQVBQX1JFQ09SRF9fID0gcmVjb3JkO1xuXHRcdGNvbnN0IHJvb3RJZCA9IGAke3JlY29yZC5pZH06cm9vdGA7XG5cdFx0cmVjb3JkLmluc3RhbmNlTWFwLnNldChyb290SWQsIHJlY29yZC5yb290SW5zdGFuY2UpO1xuXHRcdHJlY29yZC5yb290SW5zdGFuY2UuX19WVUVfREVWVE9PTFNfTkVYVF9VSURfXyA9IHJvb3RJZDtcblx0XHRyZXR1cm4gcmVjb3JkO1xuXHR9IGVsc2UgcmV0dXJuIHt9O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvaWZyYW1lL2luZGV4LnRzXG5mdW5jdGlvbiBkZXRlY3RJZnJhbWVBcHAodGFyZ2V0LCBpbklmcmFtZSA9IGZhbHNlKSB7XG5cdGlmIChpbklmcmFtZSkge1xuXHRcdGZ1bmN0aW9uIHNlbmRFdmVudFRvUGFyZW50KGNiKSB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRjb25zdCBob29rID0gd2luZG93LnBhcmVudC5fX1ZVRV9ERVZUT09MU19HTE9CQUxfSE9PS19fO1xuXHRcdFx0XHRpZiAoaG9vaykgY2IoaG9vayk7XG5cdFx0XHR9IGNhdGNoIChlKSB7fVxuXHRcdH1cblx0XHRjb25zdCBob29rID0ge1xuXHRcdFx0aWQ6IFwidnVlLWRldnRvb2xzLW5leHRcIixcblx0XHRcdGRldnRvb2xzVmVyc2lvbjogXCI3LjBcIixcblx0XHRcdG9uOiAoZXZlbnQsIGNiKSA9PiB7XG5cdFx0XHRcdHNlbmRFdmVudFRvUGFyZW50KChob29rKSA9PiB7XG5cdFx0XHRcdFx0aG9vay5vbihldmVudCwgY2IpO1xuXHRcdFx0XHR9KTtcblx0XHRcdH0sXG5cdFx0XHRvbmNlOiAoZXZlbnQsIGNiKSA9PiB7XG5cdFx0XHRcdHNlbmRFdmVudFRvUGFyZW50KChob29rKSA9PiB7XG5cdFx0XHRcdFx0aG9vay5vbmNlKGV2ZW50LCBjYik7XG5cdFx0XHRcdH0pO1xuXHRcdFx0fSxcblx0XHRcdG9mZjogKGV2ZW50LCBjYikgPT4ge1xuXHRcdFx0XHRzZW5kRXZlbnRUb1BhcmVudCgoaG9vaykgPT4ge1xuXHRcdFx0XHRcdGhvb2sub2ZmKGV2ZW50LCBjYik7XG5cdFx0XHRcdH0pO1xuXHRcdFx0fSxcblx0XHRcdGVtaXQ6IChldmVudCwgLi4ucGF5bG9hZCkgPT4ge1xuXHRcdFx0XHRzZW5kRXZlbnRUb1BhcmVudCgoaG9vaykgPT4ge1xuXHRcdFx0XHRcdGhvb2suZW1pdChldmVudCwgLi4ucGF5bG9hZCk7XG5cdFx0XHRcdH0pO1xuXHRcdFx0fVxuXHRcdH07XG5cdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KHRhcmdldCwgXCJfX1ZVRV9ERVZUT09MU19HTE9CQUxfSE9PS19fXCIsIHtcblx0XHRcdGdldCgpIHtcblx0XHRcdFx0cmV0dXJuIGhvb2s7XG5cdFx0XHR9LFxuXHRcdFx0Y29uZmlndXJhYmxlOiB0cnVlXG5cdFx0fSk7XG5cdH1cblx0ZnVuY3Rpb24gaW5qZWN0VnVlSG9va1RvSWZyYW1lKGlmcmFtZSkge1xuXHRcdGlmIChpZnJhbWUuX192ZGV2dG9vbHNfX2luamVjdGVkKSByZXR1cm47XG5cdFx0dHJ5IHtcblx0XHRcdGlmcmFtZS5fX3ZkZXZ0b29sc19faW5qZWN0ZWQgPSB0cnVlO1xuXHRcdFx0Y29uc3QgaW5qZWN0ID0gKCkgPT4ge1xuXHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdGlmcmFtZS5jb250ZW50V2luZG93Ll9fVlVFX0RFVlRPT0xTX0lGUkFNRV9fID0gaWZyYW1lO1xuXHRcdFx0XHRcdGNvbnN0IHNjcmlwdCA9IGlmcmFtZS5jb250ZW50RG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInNjcmlwdFwiKTtcblx0XHRcdFx0XHRzY3JpcHQudGV4dENvbnRlbnQgPSBgOygke2RldGVjdElmcmFtZUFwcC50b1N0cmluZygpfSkod2luZG93LCB0cnVlKWA7XG5cdFx0XHRcdFx0aWZyYW1lLmNvbnRlbnREb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuYXBwZW5kQ2hpbGQoc2NyaXB0KTtcblx0XHRcdFx0XHRzY3JpcHQucGFyZW50Tm9kZS5yZW1vdmVDaGlsZChzY3JpcHQpO1xuXHRcdFx0XHR9IGNhdGNoIChlKSB7fVxuXHRcdFx0fTtcblx0XHRcdGluamVjdCgpO1xuXHRcdFx0aWZyYW1lLmFkZEV2ZW50TGlzdGVuZXIoXCJsb2FkXCIsICgpID0+IGluamVjdCgpKTtcblx0XHR9IGNhdGNoIChlKSB7fVxuXHR9XG5cdGZ1bmN0aW9uIGluamVjdFZ1ZUhvb2tUb0lmcmFtZXMoKSB7XG5cdFx0aWYgKHR5cGVvZiB3aW5kb3cgPT09IFwidW5kZWZpbmVkXCIpIHJldHVybjtcblx0XHRjb25zdCBpZnJhbWVzID0gQXJyYXkuZnJvbShkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwiaWZyYW1lOm5vdChbZGF0YS12dWUtZGV2dG9vbHMtaWdub3JlXSlcIikpO1xuXHRcdGZvciAoY29uc3QgaWZyYW1lIG9mIGlmcmFtZXMpIGluamVjdFZ1ZUhvb2tUb0lmcmFtZShpZnJhbWUpO1xuXHR9XG5cdGluamVjdFZ1ZUhvb2tUb0lmcmFtZXMoKTtcblx0bGV0IGlmcmFtZUFwcENoZWNrcyA9IDA7XG5cdGNvbnN0IGlmcmFtZUFwcENoZWNrVGltZXIgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XG5cdFx0aW5qZWN0VnVlSG9va1RvSWZyYW1lcygpO1xuXHRcdGlmcmFtZUFwcENoZWNrcysrO1xuXHRcdGlmIChpZnJhbWVBcHBDaGVja3MgPj0gNSkgY2xlYXJJbnRlcnZhbChpZnJhbWVBcHBDaGVja1RpbWVyKTtcblx0fSwgMWUzKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL2luZGV4LnRzXG5mdW5jdGlvbiBpbml0RGV2VG9vbHMoKSB7XG5cdGRldGVjdElmcmFtZUFwcCh0YXJnZXQpO1xuXHR1cGRhdGVEZXZUb29sc1N0YXRlKHsgdml0ZVBsdWdpbkRldGVjdGVkOiBnZXREZXZUb29sc0VudigpLnZpdGVQbHVnaW5EZXRlY3RlZCB9KTtcblx0Y29uc3QgaXNEZXZUb29sc05leHQgPSB0YXJnZXQuX19WVUVfREVWVE9PTFNfR0xPQkFMX0hPT0tfXz8uaWQgPT09IFwidnVlLWRldnRvb2xzLW5leHRcIjtcblx0aWYgKHRhcmdldC5fX1ZVRV9ERVZUT09MU19HTE9CQUxfSE9PS19fICYmIGlzRGV2VG9vbHNOZXh0KSByZXR1cm47XG5cdGNvbnN0IF9kZXZ0b29sc0hvb2sgPSBjcmVhdGVEZXZUb29sc0hvb2soKTtcblx0aWYgKHRhcmdldC5fX1ZVRV9ERVZUT09MU19IT09LX1JFUExBWV9fKSB0cnkge1xuXHRcdHRhcmdldC5fX1ZVRV9ERVZUT09MU19IT09LX1JFUExBWV9fLmZvckVhY2goKGNiKSA9PiBjYihfZGV2dG9vbHNIb29rKSk7XG5cdFx0dGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0hPT0tfUkVQTEFZX18gPSBbXTtcblx0fSBjYXRjaCAoZSkge1xuXHRcdGNvbnNvbGUuZXJyb3IoXCJbdnVlLWRldnRvb2xzXSBFcnJvciBkdXJpbmcgaG9vayByZXBsYXlcIiwgZSk7XG5cdH1cblx0X2RldnRvb2xzSG9vay5vbmNlKFwiaW5pdFwiLCAoVnVlKSA9PiB7XG5cdFx0dGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX1ZVRTJfQVBQX0RFVEVDVEVEX18gPSB0cnVlO1xuXHRcdGNvbnNvbGUubG9nKFwiJWNbX19fX19WdWUgRGV2VG9vbHMgdjcgbG9nX19fX19dXCIsIFwiY29sb3I6IHJlZDsgZm9udC1ib2xkOiA2MDA7IGZvbnQtc2l6ZTogMTZweDtcIik7XG5cdFx0Y29uc29sZS5sb2coXCIlY1Z1ZSBEZXZUb29scyB2NyBkZXRlY3RlZCBpbiB5b3VyIFZ1ZTIgcHJvamVjdC4gdjcgb25seSBzdXBwb3J0cyBWdWUzIGFuZCB3aWxsIG5vdCB3b3JrLlwiLCBcImZvbnQtYm9sZDogNTAwOyBmb250LXNpemU6IDE0cHg7XCIpO1xuXHRcdGNvbnN0IGxlZ2FjeUNocm9tZVVybCA9IFwiaHR0cHM6Ly9jaHJvbWV3ZWJzdG9yZS5nb29nbGUuY29tL2RldGFpbC92dWVqcy1kZXZ0b29scy9pYWFqbWxjZXBsZWNibGppYWxoaGttZWRqbHBkYmxocFwiO1xuXHRcdGNvbnN0IGxlZ2FjeUZpcmVmb3hVcmwgPSBcImh0dHBzOi8vYWRkb25zLm1vemlsbGEub3JnL2ZpcmVmb3gvYWRkb24vdnVlLWpzLWRldnRvb2xzLXY2LWxlZ2FjeVwiO1xuXHRcdGNvbnNvbGUubG9nKGAlY1RoZSBsZWdhY3kgdmVyc2lvbiBvZiBjaHJvbWUgZXh0ZW5zaW9uIHRoYXQgc3VwcG9ydHMgYm90aCBWdWUgMiBhbmQgVnVlIDMgaGFzIGJlZW4gbW92ZWQgdG8gJWMgJHtsZWdhY3lDaHJvbWVVcmx9YCwgXCJmb250LXNpemU6IDE0cHg7XCIsIFwidGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7IGN1cnNvcjogcG9pbnRlcjtmb250LXNpemU6IDE0cHg7XCIpO1xuXHRcdGNvbnNvbGUubG9nKGAlY1RoZSBsZWdhY3kgdmVyc2lvbiBvZiBmaXJlZm94IGV4dGVuc2lvbiB0aGF0IHN1cHBvcnRzIGJvdGggVnVlIDIgYW5kIFZ1ZSAzIGhhcyBiZWVuIG1vdmVkIHRvICVjICR7bGVnYWN5RmlyZWZveFVybH1gLCBcImZvbnQtc2l6ZTogMTRweDtcIiwgXCJ0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTsgY3Vyc29yOiBwb2ludGVyO2ZvbnQtc2l6ZTogMTRweDtcIik7XG5cdFx0Y29uc29sZS5sb2coXCIlY1BsZWFzZSBpbnN0YWxsIGFuZCBlbmFibGUgb25seSB0aGUgbGVnYWN5IHZlcnNpb24gZm9yIHlvdXIgVnVlMiBhcHAuXCIsIFwiZm9udC1ib2xkOiA1MDA7IGZvbnQtc2l6ZTogMTRweDtcIik7XG5cdFx0Y29uc29sZS5sb2coXCIlY1tfX19fX1Z1ZSBEZXZUb29scyB2NyBsb2dfX19fX11cIiwgXCJjb2xvcjogcmVkOyBmb250LWJvbGQ6IDYwMDsgZm9udC1zaXplOiAxNnB4O1wiKTtcblx0fSk7XG5cdGhvb2sub24uc2V0dXBEZXZ0b29sc1BsdWdpbigocGx1Z2luRGVzY3JpcHRvciwgc2V0dXBGbikgPT4ge1xuXHRcdGFkZERldlRvb2xzUGx1Z2luVG9CdWZmZXIocGx1Z2luRGVzY3JpcHRvciwgc2V0dXBGbik7XG5cdFx0Y29uc3QgeyBhcHAgfSA9IGFjdGl2ZUFwcFJlY29yZCA/PyB7fTtcblx0XHRpZiAocGx1Z2luRGVzY3JpcHRvci5zZXR0aW5ncykgaW5pdFBsdWdpblNldHRpbmdzKHBsdWdpbkRlc2NyaXB0b3IuaWQsIHBsdWdpbkRlc2NyaXB0b3Iuc2V0dGluZ3MpO1xuXHRcdGlmICghYXBwKSByZXR1cm47XG5cdFx0Y2FsbERldlRvb2xzUGx1Z2luU2V0dXBGbihbcGx1Z2luRGVzY3JpcHRvciwgc2V0dXBGbl0sIGFwcCk7XG5cdH0pO1xuXHRvbkxlZ2FjeURldlRvb2xzUGx1Z2luQXBpQXZhaWxhYmxlKCgpID0+IHtcblx0XHRkZXZ0b29sc1BsdWdpbkJ1ZmZlci5maWx0ZXIoKFtpdGVtXSkgPT4gaXRlbS5pZCAhPT0gXCJjb21wb25lbnRzXCIpLmZvckVhY2goKFtwbHVnaW5EZXNjcmlwdG9yLCBzZXR1cEZuXSkgPT4ge1xuXHRcdFx0X2RldnRvb2xzSG9vay5lbWl0KERldlRvb2xzSG9va3MuU0VUVVBfREVWVE9PTFNfUExVR0lOLCBwbHVnaW5EZXNjcmlwdG9yLCBzZXR1cEZuLCB7IHRhcmdldDogXCJsZWdhY3lcIiB9KTtcblx0XHR9KTtcblx0fSk7XG5cdGhvb2sub24udnVlQXBwSW5pdChhc3luYyAoYXBwLCB2ZXJzaW9uLCB0eXBlcykgPT4ge1xuXHRcdGNvbnN0IG5vcm1hbGl6ZWRBcHBSZWNvcmQgPSB7XG5cdFx0XHQuLi5jcmVhdGVBcHBSZWNvcmQoYXBwLCB0eXBlcyksXG5cdFx0XHRhcHAsXG5cdFx0XHR2ZXJzaW9uXG5cdFx0fTtcblx0XHRhZGREZXZUb29sc0FwcFJlY29yZChub3JtYWxpemVkQXBwUmVjb3JkKTtcblx0XHRpZiAoZGV2dG9vbHNBcHBSZWNvcmRzLnZhbHVlLmxlbmd0aCA9PT0gMSkge1xuXHRcdFx0c2V0QWN0aXZlQXBwUmVjb3JkKG5vcm1hbGl6ZWRBcHBSZWNvcmQpO1xuXHRcdFx0c2V0QWN0aXZlQXBwUmVjb3JkSWQobm9ybWFsaXplZEFwcFJlY29yZC5pZCk7XG5cdFx0XHRub3JtYWxpemVSb3V0ZXJJbmZvKG5vcm1hbGl6ZWRBcHBSZWNvcmQsIGFjdGl2ZUFwcFJlY29yZCk7XG5cdFx0XHRyZWdpc3RlckRldlRvb2xzUGx1Z2luKG5vcm1hbGl6ZWRBcHBSZWNvcmQuYXBwKTtcblx0XHR9XG5cdFx0c2V0dXBEZXZUb29sc1BsdWdpbiguLi5jcmVhdGVDb21wb25lbnRzRGV2VG9vbHNQbHVnaW4obm9ybWFsaXplZEFwcFJlY29yZC5hcHApKTtcblx0XHR1cGRhdGVEZXZUb29sc1N0YXRlKHsgY29ubmVjdGVkOiB0cnVlIH0pO1xuXHRcdF9kZXZ0b29sc0hvb2suYXBwcy5wdXNoKGFwcCk7XG5cdH0pO1xuXHRob29rLm9uLnZ1ZUFwcFVubW91bnQoYXN5bmMgKGFwcCkgPT4ge1xuXHRcdGNvbnN0IGFjdGl2ZVJlY29yZHMgPSBkZXZ0b29sc0FwcFJlY29yZHMudmFsdWUuZmlsdGVyKChhcHBSZWNvcmQpID0+IGFwcFJlY29yZC5hcHAgIT09IGFwcCk7XG5cdFx0aWYgKGFjdGl2ZVJlY29yZHMubGVuZ3RoID09PSAwKSB1cGRhdGVEZXZUb29sc1N0YXRlKHsgY29ubmVjdGVkOiBmYWxzZSB9KTtcblx0XHRyZW1vdmVEZXZUb29sc0FwcFJlY29yZChhcHApO1xuXHRcdHJlbW92ZUFwcFJlY29yZElkKGFwcCk7XG5cdFx0aWYgKGFjdGl2ZUFwcFJlY29yZC52YWx1ZS5hcHAgPT09IGFwcCkge1xuXHRcdFx0c2V0QWN0aXZlQXBwUmVjb3JkKGFjdGl2ZVJlY29yZHNbMF0pO1xuXHRcdFx0ZGV2dG9vbHNDb250ZXh0Lmhvb2tzLmNhbGxIb29rKERldlRvb2xzTWVzc2FnaW5nSG9va0tleXMuU0VORF9BQ1RJVkVfQVBQX1VOTU9VTlRFRF9UT19DTElFTlQpO1xuXHRcdH1cblx0XHR0YXJnZXQuX19WVUVfREVWVE9PTFNfR0xPQkFMX0hPT0tfXy5hcHBzLnNwbGljZSh0YXJnZXQuX19WVUVfREVWVE9PTFNfR0xPQkFMX0hPT0tfXy5hcHBzLmluZGV4T2YoYXBwKSwgMSk7XG5cdFx0cmVtb3ZlUmVnaXN0ZXJlZFBsdWdpbkFwcChhcHApO1xuXHR9KTtcblx0c3Vic2NyaWJlRGV2VG9vbHNIb29rKF9kZXZ0b29sc0hvb2spO1xuXHRpZiAoIXRhcmdldC5fX1ZVRV9ERVZUT09MU19HTE9CQUxfSE9PS19fKSBPYmplY3QuZGVmaW5lUHJvcGVydHkodGFyZ2V0LCBcIl9fVlVFX0RFVlRPT0xTX0dMT0JBTF9IT09LX19cIiwge1xuXHRcdGdldCgpIHtcblx0XHRcdHJldHVybiBfZGV2dG9vbHNIb29rO1xuXHRcdH0sXG5cdFx0Y29uZmlndXJhYmxlOiB0cnVlXG5cdH0pO1xuXHRlbHNlIGlmICghaXNOdXh0QXBwKSBPYmplY3QuYXNzaWduKF9fVlVFX0RFVlRPT0xTX0dMT0JBTF9IT09LX18sIF9kZXZ0b29sc0hvb2spO1xufVxuZnVuY3Rpb24gb25EZXZUb29sc0NsaWVudENvbm5lY3RlZChmbikge1xuXHRyZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcblx0XHRpZiAoZGV2dG9vbHNTdGF0ZS5jb25uZWN0ZWQgJiYgZGV2dG9vbHNTdGF0ZS5jbGllbnRDb25uZWN0ZWQpIHtcblx0XHRcdGZuKCk7XG5cdFx0XHRyZXNvbHZlKCk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdGRldnRvb2xzQ29udGV4dC5ob29rcy5ob29rKERldlRvb2xzTWVzc2FnaW5nSG9va0tleXMuREVWVE9PTFNfQ09OTkVDVEVEX1VQREFURUQsICh7IHN0YXRlIH0pID0+IHtcblx0XHRcdGlmIChzdGF0ZS5jb25uZWN0ZWQgJiYgc3RhdGUuY2xpZW50Q29ubmVjdGVkKSB7XG5cdFx0XHRcdGZuKCk7XG5cdFx0XHRcdHJlc29sdmUoKTtcblx0XHRcdH1cblx0XHR9KTtcblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9oaWdoLXBlcmYtbW9kZS9pbmRleC50c1xuZnVuY3Rpb24gdG9nZ2xlSGlnaFBlcmZNb2RlKHN0YXRlKSB7XG5cdGRldnRvb2xzU3RhdGUuaGlnaFBlcmZNb2RlRW5hYmxlZCA9IHN0YXRlID8/ICFkZXZ0b29sc1N0YXRlLmhpZ2hQZXJmTW9kZUVuYWJsZWQ7XG5cdGlmICghc3RhdGUgJiYgYWN0aXZlQXBwUmVjb3JkLnZhbHVlKSByZWdpc3RlckRldlRvb2xzUGx1Z2luKGFjdGl2ZUFwcFJlY29yZC52YWx1ZS5hcHApO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvY29tcG9uZW50L3N0YXRlL3Jldml2ZXIudHNcbmZ1bmN0aW9uIHJldml2ZVNldCh2YWwpIHtcblx0Y29uc3QgcmVzdWx0ID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcblx0Y29uc3QgbGlzdCA9IHZhbC5fY3VzdG9tLnZhbHVlO1xuXHRmb3IgKGxldCBpID0gMDsgaSA8IGxpc3QubGVuZ3RoOyBpKyspIHtcblx0XHRjb25zdCB2YWx1ZSA9IGxpc3RbaV07XG5cdFx0cmVzdWx0LmFkZChyZXZpdmUodmFsdWUpKTtcblx0fVxuXHRyZXR1cm4gcmVzdWx0O1xufVxuZnVuY3Rpb24gcmV2aXZlTWFwKHZhbCkge1xuXHRjb25zdCByZXN1bHQgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHRjb25zdCBsaXN0ID0gdmFsLl9jdXN0b20udmFsdWU7XG5cdGZvciAobGV0IGkgPSAwOyBpIDwgbGlzdC5sZW5ndGg7IGkrKykge1xuXHRcdGNvbnN0IHsga2V5LCB2YWx1ZSB9ID0gbGlzdFtpXTtcblx0XHRyZXN1bHQuc2V0KGtleSwgcmV2aXZlKHZhbHVlKSk7XG5cdH1cblx0cmV0dXJuIHJlc3VsdDtcbn1cbmZ1bmN0aW9uIHJldml2ZSh2YWwpIHtcblx0aWYgKHZhbCA9PT0gXCJfX3Z1ZV9kZXZ0b29sX3VuZGVmaW5lZF9fXCIpIHJldHVybjtcblx0ZWxzZSBpZiAodmFsID09PSBcIl9fdnVlX2RldnRvb2xfaW5maW5pdHlfX1wiKSByZXR1cm4gTnVtYmVyLlBPU0lUSVZFX0lORklOSVRZO1xuXHRlbHNlIGlmICh2YWwgPT09IFwiX192dWVfZGV2dG9vbF9uZWdhdGl2ZV9pbmZpbml0eV9fXCIpIHJldHVybiBOdW1iZXIuTkVHQVRJVkVfSU5GSU5JVFk7XG5cdGVsc2UgaWYgKHZhbCA9PT0gXCJfX3Z1ZV9kZXZ0b29sX25hbl9fXCIpIHJldHVybiBOYU47XG5cdGVsc2UgaWYgKHZhbCAmJiB2YWwuX2N1c3RvbSkge1xuXHRcdGNvbnN0IHsgX2N1c3RvbTogY3VzdG9tIH0gPSB2YWw7XG5cdFx0aWYgKGN1c3RvbS50eXBlID09PSBcImNvbXBvbmVudFwiKSByZXR1cm4gYWN0aXZlQXBwUmVjb3JkLnZhbHVlLmluc3RhbmNlTWFwLmdldChjdXN0b20uaWQpO1xuXHRcdGVsc2UgaWYgKGN1c3RvbS50eXBlID09PSBcIm1hcFwiKSByZXR1cm4gcmV2aXZlTWFwKHZhbCk7XG5cdFx0ZWxzZSBpZiAoY3VzdG9tLnR5cGUgPT09IFwic2V0XCIpIHJldHVybiByZXZpdmVTZXQodmFsKTtcblx0XHRlbHNlIGlmIChjdXN0b20udHlwZSA9PT0gXCJiaWdpbnRcIikgcmV0dXJuIEJpZ0ludChjdXN0b20udmFsdWUpO1xuXHRcdGVsc2UgcmV0dXJuIHJldml2ZShjdXN0b20udmFsdWUpO1xuXHR9IGVsc2UgaWYgKHN5bWJvbFJFLnRlc3QodmFsKSkge1xuXHRcdGNvbnN0IFssIHN0cmluZ10gPSBzeW1ib2xSRS5leGVjKHZhbCk7XG5cdFx0cmV0dXJuIFN5bWJvbC5mb3Ioc3RyaW5nKTtcblx0fSBlbHNlIGlmIChzcGVjaWFsVHlwZVJFLnRlc3QodmFsKSkge1xuXHRcdGNvbnN0IFssIHR5cGUsIHN0cmluZywgLCBkZXRhaWxzXSA9IHNwZWNpYWxUeXBlUkUuZXhlYyh2YWwpO1xuXHRcdGNvbnN0IHJlc3VsdCA9IG5ldyB0YXJnZXRbdHlwZV0oc3RyaW5nKTtcblx0XHRpZiAodHlwZSA9PT0gXCJFcnJvclwiICYmIGRldGFpbHMpIHJlc3VsdC5zdGFjayA9IGRldGFpbHM7XG5cdFx0cmV0dXJuIHJlc3VsdDtcblx0fSBlbHNlIHJldHVybiB2YWw7XG59XG5mdW5jdGlvbiByZXZpdmVyKGtleSwgdmFsdWUpIHtcblx0cmV0dXJuIHJldml2ZSh2YWx1ZSk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9jb21wb25lbnQvc3RhdGUvZm9ybWF0LnRzXG5mdW5jdGlvbiBnZXRJbnNwZWN0b3JTdGF0ZVZhbHVlVHlwZSh2YWx1ZSwgcmF3ID0gdHJ1ZSkge1xuXHRjb25zdCB0eXBlID0gdHlwZW9mIHZhbHVlO1xuXHRpZiAodmFsdWUgPT0gbnVsbCB8fCB2YWx1ZSA9PT0gXCJfX3Z1ZV9kZXZ0b29sX3VuZGVmaW5lZF9fXCIgfHwgdmFsdWUgPT09IFwidW5kZWZpbmVkXCIpIHJldHVybiBcIm51bGxcIjtcblx0ZWxzZSBpZiAodHlwZSA9PT0gXCJib29sZWFuXCIgfHwgdHlwZSA9PT0gXCJudW1iZXJcIiB8fCB2YWx1ZSA9PT0gXCJfX3Z1ZV9kZXZ0b29sX2luZmluaXR5X19cIiB8fCB2YWx1ZSA9PT0gXCJfX3Z1ZV9kZXZ0b29sX25lZ2F0aXZlX2luZmluaXR5X19cIiB8fCB2YWx1ZSA9PT0gXCJfX3Z1ZV9kZXZ0b29sX25hbl9fXCIpIHJldHVybiBcImxpdGVyYWxcIjtcblx0ZWxzZSBpZiAodmFsdWU/Ll9jdXN0b20pIGlmIChyYXcgfHwgdmFsdWUuX2N1c3RvbS5kaXNwbGF5ICE9IG51bGwgfHwgdmFsdWUuX2N1c3RvbS5kaXNwbGF5VGV4dCAhPSBudWxsKSByZXR1cm4gXCJjdXN0b21cIjtcblx0ZWxzZSByZXR1cm4gZ2V0SW5zcGVjdG9yU3RhdGVWYWx1ZVR5cGUodmFsdWUuX2N1c3RvbS52YWx1ZSk7XG5cdGVsc2UgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gXCJzdHJpbmdcIikge1xuXHRcdGNvbnN0IHR5cGVNYXRjaCA9IHNwZWNpYWxUeXBlUkUuZXhlYyh2YWx1ZSk7XG5cdFx0aWYgKHR5cGVNYXRjaCkge1xuXHRcdFx0Y29uc3QgWywgdHlwZV0gPSB0eXBlTWF0Y2g7XG5cdFx0XHRyZXR1cm4gYG5hdGl2ZSAke3R5cGV9YDtcblx0XHR9IGVsc2UgcmV0dXJuIFwic3RyaW5nXCI7XG5cdH0gZWxzZSBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkgfHwgdmFsdWU/Ll9pc0FycmF5KSByZXR1cm4gXCJhcnJheVwiO1xuXHRlbHNlIGlmIChpc1BsYWluT2JqZWN0KHZhbHVlKSkgcmV0dXJuIFwicGxhaW4tb2JqZWN0XCI7XG5cdGVsc2UgcmV0dXJuIFwidW5rbm93blwiO1xufVxuZnVuY3Rpb24gZm9ybWF0SW5zcGVjdG9yU3RhdGVWYWx1ZSh2YWx1ZSwgcXVvdGVzID0gZmFsc2UsIG9wdGlvbnMpIHtcblx0Y29uc3QgeyBjdXN0b21DbGFzcyB9ID0gb3B0aW9ucyA/PyB7fTtcblx0bGV0IHJlc3VsdDtcblx0Y29uc3QgdHlwZSA9IGdldEluc3BlY3RvclN0YXRlVmFsdWVUeXBlKHZhbHVlLCBmYWxzZSk7XG5cdGlmICh0eXBlICE9PSBcImN1c3RvbVwiICYmIHZhbHVlPy5fY3VzdG9tKSB2YWx1ZSA9IHZhbHVlLl9jdXN0b20udmFsdWU7XG5cdGlmIChyZXN1bHQgPSBpbnRlcm5hbFN0YXRlVG9rZW5Ub1N0cmluZyh2YWx1ZSkpIHJldHVybiByZXN1bHQ7XG5cdGVsc2UgaWYgKHR5cGUgPT09IFwiY3VzdG9tXCIpIHJldHVybiB2YWx1ZS5fY3VzdG9tLnZhbHVlPy5fY3VzdG9tICYmIGZvcm1hdEluc3BlY3RvclN0YXRlVmFsdWUodmFsdWUuX2N1c3RvbS52YWx1ZSwgcXVvdGVzLCBvcHRpb25zKSB8fCB2YWx1ZS5fY3VzdG9tLmRpc3BsYXlUZXh0IHx8IHZhbHVlLl9jdXN0b20uZGlzcGxheTtcblx0ZWxzZSBpZiAodHlwZSA9PT0gXCJhcnJheVwiKSByZXR1cm4gYEFycmF5WyR7dmFsdWUubGVuZ3RofV1gO1xuXHRlbHNlIGlmICh0eXBlID09PSBcInBsYWluLW9iamVjdFwiKSByZXR1cm4gYE9iamVjdCR7T2JqZWN0LmtleXModmFsdWUpLmxlbmd0aCA/IFwiXCIgOiBcIiAoZW1wdHkpXCJ9YDtcblx0ZWxzZSBpZiAodHlwZT8uaW5jbHVkZXMoXCJuYXRpdmVcIikpIHJldHVybiBlc2NhcGUoc3BlY2lhbFR5cGVSRS5leGVjKHZhbHVlKT8uWzJdKTtcblx0ZWxzZSBpZiAodHlwZW9mIHZhbHVlID09PSBcInN0cmluZ1wiKSB7XG5cdFx0Y29uc3QgdHlwZU1hdGNoID0gdmFsdWUubWF0Y2gocmF3VHlwZVJFKTtcblx0XHRpZiAodHlwZU1hdGNoKSB2YWx1ZSA9IGVzY2FwZVN0cmluZyh0eXBlTWF0Y2hbMV0pO1xuXHRcdGVsc2UgaWYgKHF1b3RlcykgdmFsdWUgPSBgPHNwYW4+XCI8L3NwYW4+JHtjdXN0b21DbGFzcz8uc3RyaW5nID8gYDxzcGFuIGNsYXNzPSR7Y3VzdG9tQ2xhc3Muc3RyaW5nfT4ke2VzY2FwZVN0cmluZyh2YWx1ZSl9PC9zcGFuPmAgOiBlc2NhcGVTdHJpbmcodmFsdWUpfTxzcGFuPlwiPC9zcGFuPmA7XG5cdFx0ZWxzZSB2YWx1ZSA9IGN1c3RvbUNsYXNzPy5zdHJpbmcgPyBgPHNwYW4gY2xhc3M9XCIke2N1c3RvbUNsYXNzPy5zdHJpbmcgPz8gXCJcIn1cIj4ke2VzY2FwZVN0cmluZyh2YWx1ZSl9PC9zcGFuPmAgOiBlc2NhcGVTdHJpbmcodmFsdWUpO1xuXHR9XG5cdHJldHVybiB2YWx1ZTtcbn1cbmZ1bmN0aW9uIGVzY2FwZVN0cmluZyh2YWx1ZSkge1xuXHRyZXR1cm4gZXNjYXBlKHZhbHVlKS5yZXBsYWNlKC8gL2csIFwiJm5ic3A7XCIpLnJlcGxhY2UoL1xcbi9nLCBcIjxzcGFuPlxcXFxuPC9zcGFuPlwiKTtcbn1cbmZ1bmN0aW9uIGdldFJhdyh2YWx1ZSkge1xuXHRsZXQgY3VzdG9tVHlwZTtcblx0Y29uc3QgaXNDdXN0b20gPSBnZXRJbnNwZWN0b3JTdGF0ZVZhbHVlVHlwZSh2YWx1ZSkgPT09IFwiY3VzdG9tXCI7XG5cdGxldCBpbmhlcml0ID0ge307XG5cdGlmIChpc0N1c3RvbSkge1xuXHRcdGNvbnN0IGRhdGEgPSB2YWx1ZTtcblx0XHRjb25zdCBjdXN0b21WYWx1ZSA9IGRhdGEuX2N1c3RvbT8udmFsdWU7XG5cdFx0Y29uc3QgY3VycmVudEN1c3RvbVR5cGUgPSBkYXRhLl9jdXN0b20/LnR5cGU7XG5cdFx0Y29uc3QgbmVzdGVkQ3VzdG9tID0gdHlwZW9mIGN1c3RvbVZhbHVlID09PSBcIm9iamVjdFwiICYmIGN1c3RvbVZhbHVlICE9PSBudWxsICYmIFwiX2N1c3RvbVwiIGluIGN1c3RvbVZhbHVlID8gZ2V0UmF3KGN1c3RvbVZhbHVlKSA6IHtcblx0XHRcdGluaGVyaXQ6IHZvaWQgMCxcblx0XHRcdHZhbHVlOiB2b2lkIDAsXG5cdFx0XHRjdXN0b21UeXBlOiB2b2lkIDBcblx0XHR9O1xuXHRcdGluaGVyaXQgPSBuZXN0ZWRDdXN0b20uaW5oZXJpdCB8fCBkYXRhLl9jdXN0b20/LmZpZWxkcyB8fCB7fTtcblx0XHR2YWx1ZSA9IG5lc3RlZEN1c3RvbS52YWx1ZSB8fCBjdXN0b21WYWx1ZTtcblx0XHRjdXN0b21UeXBlID0gbmVzdGVkQ3VzdG9tLmN1c3RvbVR5cGUgfHwgY3VycmVudEN1c3RvbVR5cGU7XG5cdH1cblx0aWYgKHZhbHVlICYmIHZhbHVlLl9pc0FycmF5KSB2YWx1ZSA9IHZhbHVlLml0ZW1zO1xuXHRyZXR1cm4ge1xuXHRcdHZhbHVlLFxuXHRcdGluaGVyaXQsXG5cdFx0Y3VzdG9tVHlwZVxuXHR9O1xufVxuZnVuY3Rpb24gdG9FZGl0KHZhbHVlLCBjdXN0b21UeXBlKSB7XG5cdGlmIChjdXN0b21UeXBlID09PSBcImJpZ2ludFwiKSByZXR1cm4gdmFsdWU7XG5cdGlmIChjdXN0b21UeXBlID09PSBcImRhdGVcIikgcmV0dXJuIHZhbHVlO1xuXHRyZXR1cm4gcmVwbGFjZVRva2VuVG9TdHJpbmcoSlNPTi5zdHJpbmdpZnkodmFsdWUpKTtcbn1cbmZ1bmN0aW9uIHRvU3VibWl0KHZhbHVlLCBjdXN0b21UeXBlKSB7XG5cdGlmIChjdXN0b21UeXBlID09PSBcImJpZ2ludFwiKSByZXR1cm4gQmlnSW50KHZhbHVlKTtcblx0aWYgKGN1c3RvbVR5cGUgPT09IFwiZGF0ZVwiKSByZXR1cm4gbmV3IERhdGUodmFsdWUpO1xuXHRyZXR1cm4gSlNPTi5wYXJzZShyZXBsYWNlU3RyaW5nVG9Ub2tlbih2YWx1ZSksIHJldml2ZXIpO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvZGV2dG9vbHMtY2xpZW50L2RldGVjdGVkLnRzXG5mdW5jdGlvbiB1cGRhdGVEZXZUb29sc0NsaWVudERldGVjdGVkKHBhcmFtcykge1xuXHRkZXZ0b29sc1N0YXRlLmRldnRvb2xzQ2xpZW50RGV0ZWN0ZWQgPSB7XG5cdFx0Li4uZGV2dG9vbHNTdGF0ZS5kZXZ0b29sc0NsaWVudERldGVjdGVkLFxuXHRcdC4uLnBhcmFtc1xuXHR9O1xuXHR0b2dnbGVIaWdoUGVyZk1vZGUoIU9iamVjdC52YWx1ZXMoZGV2dG9vbHNTdGF0ZS5kZXZ0b29sc0NsaWVudERldGVjdGVkKS5zb21lKEJvb2xlYW4pKTtcbn1cbnRhcmdldC5fX1ZVRV9ERVZUT09MU19VUERBVEVfQ0xJRU5UX0RFVEVDVEVEX18gPz89IHVwZGF0ZURldlRvb2xzQ2xpZW50RGV0ZWN0ZWQ7XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiAuLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vc3VwZXJqc29uQDIuMi4yL25vZGVfbW9kdWxlcy9zdXBlcmpzb24vZGlzdC9kb3VibGUtaW5kZXhlZC1rdi5qc1xudmFyIERvdWJsZUluZGV4ZWRLViA9IGNsYXNzIHtcblx0Y29uc3RydWN0b3IoKSB7XG5cdFx0dGhpcy5rZXlUb1ZhbHVlID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0XHR0aGlzLnZhbHVlVG9LZXkgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHR9XG5cdHNldChrZXksIHZhbHVlKSB7XG5cdFx0dGhpcy5rZXlUb1ZhbHVlLnNldChrZXksIHZhbHVlKTtcblx0XHR0aGlzLnZhbHVlVG9LZXkuc2V0KHZhbHVlLCBrZXkpO1xuXHR9XG5cdGdldEJ5S2V5KGtleSkge1xuXHRcdHJldHVybiB0aGlzLmtleVRvVmFsdWUuZ2V0KGtleSk7XG5cdH1cblx0Z2V0QnlWYWx1ZSh2YWx1ZSkge1xuXHRcdHJldHVybiB0aGlzLnZhbHVlVG9LZXkuZ2V0KHZhbHVlKTtcblx0fVxuXHRjbGVhcigpIHtcblx0XHR0aGlzLmtleVRvVmFsdWUuY2xlYXIoKTtcblx0XHR0aGlzLnZhbHVlVG9LZXkuY2xlYXIoKTtcblx0fVxufTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIC4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9zdXBlcmpzb25AMi4yLjIvbm9kZV9tb2R1bGVzL3N1cGVyanNvbi9kaXN0L3JlZ2lzdHJ5LmpzXG52YXIgUmVnaXN0cnkgPSBjbGFzcyB7XG5cdGNvbnN0cnVjdG9yKGdlbmVyYXRlSWRlbnRpZmllcikge1xuXHRcdHRoaXMuZ2VuZXJhdGVJZGVudGlmaWVyID0gZ2VuZXJhdGVJZGVudGlmaWVyO1xuXHRcdHRoaXMua3YgPSBuZXcgRG91YmxlSW5kZXhlZEtWKCk7XG5cdH1cblx0cmVnaXN0ZXIodmFsdWUsIGlkZW50aWZpZXIpIHtcblx0XHRpZiAodGhpcy5rdi5nZXRCeVZhbHVlKHZhbHVlKSkgcmV0dXJuO1xuXHRcdGlmICghaWRlbnRpZmllcikgaWRlbnRpZmllciA9IHRoaXMuZ2VuZXJhdGVJZGVudGlmaWVyKHZhbHVlKTtcblx0XHR0aGlzLmt2LnNldChpZGVudGlmaWVyLCB2YWx1ZSk7XG5cdH1cblx0Y2xlYXIoKSB7XG5cdFx0dGhpcy5rdi5jbGVhcigpO1xuXHR9XG5cdGdldElkZW50aWZpZXIodmFsdWUpIHtcblx0XHRyZXR1cm4gdGhpcy5rdi5nZXRCeVZhbHVlKHZhbHVlKTtcblx0fVxuXHRnZXRWYWx1ZShpZGVudGlmaWVyKSB7XG5cdFx0cmV0dXJuIHRoaXMua3YuZ2V0QnlLZXkoaWRlbnRpZmllcik7XG5cdH1cbn07XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiAuLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vc3VwZXJqc29uQDIuMi4yL25vZGVfbW9kdWxlcy9zdXBlcmpzb24vZGlzdC9jbGFzcy1yZWdpc3RyeS5qc1xudmFyIENsYXNzUmVnaXN0cnkgPSBjbGFzcyBleHRlbmRzIFJlZ2lzdHJ5IHtcblx0Y29uc3RydWN0b3IoKSB7XG5cdFx0c3VwZXIoKGMpID0+IGMubmFtZSk7XG5cdFx0dGhpcy5jbGFzc1RvQWxsb3dlZFByb3BzID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0fVxuXHRyZWdpc3Rlcih2YWx1ZSwgb3B0aW9ucykge1xuXHRcdGlmICh0eXBlb2Ygb3B0aW9ucyA9PT0gXCJvYmplY3RcIikge1xuXHRcdFx0aWYgKG9wdGlvbnMuYWxsb3dQcm9wcykgdGhpcy5jbGFzc1RvQWxsb3dlZFByb3BzLnNldCh2YWx1ZSwgb3B0aW9ucy5hbGxvd1Byb3BzKTtcblx0XHRcdHN1cGVyLnJlZ2lzdGVyKHZhbHVlLCBvcHRpb25zLmlkZW50aWZpZXIpO1xuXHRcdH0gZWxzZSBzdXBlci5yZWdpc3Rlcih2YWx1ZSwgb3B0aW9ucyk7XG5cdH1cblx0Z2V0QWxsb3dlZFByb3BzKHZhbHVlKSB7XG5cdFx0cmV0dXJuIHRoaXMuY2xhc3NUb0FsbG93ZWRQcm9wcy5nZXQodmFsdWUpO1xuXHR9XG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3N1cGVyanNvbkAyLjIuMi9ub2RlX21vZHVsZXMvc3VwZXJqc29uL2Rpc3QvdXRpbC5qc1xuZnVuY3Rpb24gdmFsdWVzT2ZPYmoocmVjb3JkKSB7XG5cdGlmIChcInZhbHVlc1wiIGluIE9iamVjdCkgcmV0dXJuIE9iamVjdC52YWx1ZXMocmVjb3JkKTtcblx0Y29uc3QgdmFsdWVzID0gW107XG5cdGZvciAoY29uc3Qga2V5IGluIHJlY29yZCkgaWYgKHJlY29yZC5oYXNPd25Qcm9wZXJ0eShrZXkpKSB2YWx1ZXMucHVzaChyZWNvcmRba2V5XSk7XG5cdHJldHVybiB2YWx1ZXM7XG59XG5mdW5jdGlvbiBmaW5kKHJlY29yZCwgcHJlZGljYXRlKSB7XG5cdGNvbnN0IHZhbHVlcyA9IHZhbHVlc09mT2JqKHJlY29yZCk7XG5cdGlmIChcImZpbmRcIiBpbiB2YWx1ZXMpIHJldHVybiB2YWx1ZXMuZmluZChwcmVkaWNhdGUpO1xuXHRjb25zdCB2YWx1ZXNOb3ROZXZlciA9IHZhbHVlcztcblx0Zm9yIChsZXQgaSA9IDA7IGkgPCB2YWx1ZXNOb3ROZXZlci5sZW5ndGg7IGkrKykge1xuXHRcdGNvbnN0IHZhbHVlID0gdmFsdWVzTm90TmV2ZXJbaV07XG5cdFx0aWYgKHByZWRpY2F0ZSh2YWx1ZSkpIHJldHVybiB2YWx1ZTtcblx0fVxufVxuZnVuY3Rpb24gZm9yRWFjaChyZWNvcmQsIHJ1bikge1xuXHRPYmplY3QuZW50cmllcyhyZWNvcmQpLmZvckVhY2goKFtrZXksIHZhbHVlXSkgPT4gcnVuKHZhbHVlLCBrZXkpKTtcbn1cbmZ1bmN0aW9uIGluY2x1ZGVzKGFyciwgdmFsdWUpIHtcblx0cmV0dXJuIGFyci5pbmRleE9mKHZhbHVlKSAhPT0gLTE7XG59XG5mdW5jdGlvbiBmaW5kQXJyKHJlY29yZCwgcHJlZGljYXRlKSB7XG5cdGZvciAobGV0IGkgPSAwOyBpIDwgcmVjb3JkLmxlbmd0aDsgaSsrKSB7XG5cdFx0Y29uc3QgdmFsdWUgPSByZWNvcmRbaV07XG5cdFx0aWYgKHByZWRpY2F0ZSh2YWx1ZSkpIHJldHVybiB2YWx1ZTtcblx0fVxufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3N1cGVyanNvbkAyLjIuMi9ub2RlX21vZHVsZXMvc3VwZXJqc29uL2Rpc3QvY3VzdG9tLXRyYW5zZm9ybWVyLXJlZ2lzdHJ5LmpzXG52YXIgQ3VzdG9tVHJhbnNmb3JtZXJSZWdpc3RyeSA9IGNsYXNzIHtcblx0Y29uc3RydWN0b3IoKSB7XG5cdFx0dGhpcy50cmFuc2ZvbWVycyA9IHt9O1xuXHR9XG5cdHJlZ2lzdGVyKHRyYW5zZm9ybWVyKSB7XG5cdFx0dGhpcy50cmFuc2ZvbWVyc1t0cmFuc2Zvcm1lci5uYW1lXSA9IHRyYW5zZm9ybWVyO1xuXHR9XG5cdGZpbmRBcHBsaWNhYmxlKHYpIHtcblx0XHRyZXR1cm4gZmluZCh0aGlzLnRyYW5zZm9tZXJzLCAodHJhbnNmb3JtZXIpID0+IHRyYW5zZm9ybWVyLmlzQXBwbGljYWJsZSh2KSk7XG5cdH1cblx0ZmluZEJ5TmFtZShuYW1lKSB7XG5cdFx0cmV0dXJuIHRoaXMudHJhbnNmb21lcnNbbmFtZV07XG5cdH1cbn07XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiAuLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vc3VwZXJqc29uQDIuMi4yL25vZGVfbW9kdWxlcy9zdXBlcmpzb24vZGlzdC9pcy5qc1xuY29uc3QgZ2V0VHlwZSQxID0gKHBheWxvYWQpID0+IE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbChwYXlsb2FkKS5zbGljZSg4LCAtMSk7XG5jb25zdCBpc1VuZGVmaW5lZCQxID0gKHBheWxvYWQpID0+IHR5cGVvZiBwYXlsb2FkID09PSBcInVuZGVmaW5lZFwiO1xuY29uc3QgaXNOdWxsJDEgPSAocGF5bG9hZCkgPT4gcGF5bG9hZCA9PT0gbnVsbDtcbmNvbnN0IGlzUGxhaW5PYmplY3QkMiA9IChwYXlsb2FkKSA9PiB7XG5cdGlmICh0eXBlb2YgcGF5bG9hZCAhPT0gXCJvYmplY3RcIiB8fCBwYXlsb2FkID09PSBudWxsKSByZXR1cm4gZmFsc2U7XG5cdGlmIChwYXlsb2FkID09PSBPYmplY3QucHJvdG90eXBlKSByZXR1cm4gZmFsc2U7XG5cdGlmIChPYmplY3QuZ2V0UHJvdG90eXBlT2YocGF5bG9hZCkgPT09IG51bGwpIHJldHVybiB0cnVlO1xuXHRyZXR1cm4gT2JqZWN0LmdldFByb3RvdHlwZU9mKHBheWxvYWQpID09PSBPYmplY3QucHJvdG90eXBlO1xufTtcbmNvbnN0IGlzRW1wdHlPYmplY3QgPSAocGF5bG9hZCkgPT4gaXNQbGFpbk9iamVjdCQyKHBheWxvYWQpICYmIE9iamVjdC5rZXlzKHBheWxvYWQpLmxlbmd0aCA9PT0gMDtcbmNvbnN0IGlzQXJyYXkkMiA9IChwYXlsb2FkKSA9PiBBcnJheS5pc0FycmF5KHBheWxvYWQpO1xuY29uc3QgaXNTdHJpbmcgPSAocGF5bG9hZCkgPT4gdHlwZW9mIHBheWxvYWQgPT09IFwic3RyaW5nXCI7XG5jb25zdCBpc051bWJlciA9IChwYXlsb2FkKSA9PiB0eXBlb2YgcGF5bG9hZCA9PT0gXCJudW1iZXJcIiAmJiAhaXNOYU4ocGF5bG9hZCk7XG5jb25zdCBpc0Jvb2xlYW4gPSAocGF5bG9hZCkgPT4gdHlwZW9mIHBheWxvYWQgPT09IFwiYm9vbGVhblwiO1xuY29uc3QgaXNSZWdFeHAgPSAocGF5bG9hZCkgPT4gcGF5bG9hZCBpbnN0YW5jZW9mIFJlZ0V4cDtcbmNvbnN0IGlzTWFwID0gKHBheWxvYWQpID0+IHBheWxvYWQgaW5zdGFuY2VvZiBNYXA7XG5jb25zdCBpc1NldCA9IChwYXlsb2FkKSA9PiBwYXlsb2FkIGluc3RhbmNlb2YgU2V0O1xuY29uc3QgaXNTeW1ib2wgPSAocGF5bG9hZCkgPT4gZ2V0VHlwZSQxKHBheWxvYWQpID09PSBcIlN5bWJvbFwiO1xuY29uc3QgaXNEYXRlID0gKHBheWxvYWQpID0+IHBheWxvYWQgaW5zdGFuY2VvZiBEYXRlICYmICFpc05hTihwYXlsb2FkLnZhbHVlT2YoKSk7XG5jb25zdCBpc0Vycm9yID0gKHBheWxvYWQpID0+IHBheWxvYWQgaW5zdGFuY2VvZiBFcnJvcjtcbmNvbnN0IGlzTmFOVmFsdWUgPSAocGF5bG9hZCkgPT4gdHlwZW9mIHBheWxvYWQgPT09IFwibnVtYmVyXCIgJiYgaXNOYU4ocGF5bG9hZCk7XG5jb25zdCBpc1ByaW1pdGl2ZSA9IChwYXlsb2FkKSA9PiBpc0Jvb2xlYW4ocGF5bG9hZCkgfHwgaXNOdWxsJDEocGF5bG9hZCkgfHwgaXNVbmRlZmluZWQkMShwYXlsb2FkKSB8fCBpc051bWJlcihwYXlsb2FkKSB8fCBpc1N0cmluZyhwYXlsb2FkKSB8fCBpc1N5bWJvbChwYXlsb2FkKTtcbmNvbnN0IGlzQmlnaW50ID0gKHBheWxvYWQpID0+IHR5cGVvZiBwYXlsb2FkID09PSBcImJpZ2ludFwiO1xuY29uc3QgaXNJbmZpbml0ZSA9IChwYXlsb2FkKSA9PiBwYXlsb2FkID09PSBJbmZpbml0eSB8fCBwYXlsb2FkID09PSAtSW5maW5pdHk7XG5jb25zdCBpc1R5cGVkQXJyYXkgPSAocGF5bG9hZCkgPT4gQXJyYXlCdWZmZXIuaXNWaWV3KHBheWxvYWQpICYmICEocGF5bG9hZCBpbnN0YW5jZW9mIERhdGFWaWV3KTtcbmNvbnN0IGlzVVJMID0gKHBheWxvYWQpID0+IHBheWxvYWQgaW5zdGFuY2VvZiBVUkw7XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiAuLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vc3VwZXJqc29uQDIuMi4yL25vZGVfbW9kdWxlcy9zdXBlcmpzb24vZGlzdC9wYXRoc3RyaW5naWZpZXIuanNcbmNvbnN0IGVzY2FwZUtleSA9IChrZXkpID0+IGtleS5yZXBsYWNlKC9cXC4vZywgXCJcXFxcLlwiKTtcbmNvbnN0IHN0cmluZ2lmeVBhdGggPSAocGF0aCkgPT4gcGF0aC5tYXAoU3RyaW5nKS5tYXAoZXNjYXBlS2V5KS5qb2luKFwiLlwiKTtcbmNvbnN0IHBhcnNlUGF0aCA9IChzdHJpbmcpID0+IHtcblx0Y29uc3QgcmVzdWx0ID0gW107XG5cdGxldCBzZWdtZW50ID0gXCJcIjtcblx0Zm9yIChsZXQgaSA9IDA7IGkgPCBzdHJpbmcubGVuZ3RoOyBpKyspIHtcblx0XHRsZXQgY2hhciA9IHN0cmluZy5jaGFyQXQoaSk7XG5cdFx0aWYgKGNoYXIgPT09IFwiXFxcXFwiICYmIHN0cmluZy5jaGFyQXQoaSArIDEpID09PSBcIi5cIikge1xuXHRcdFx0c2VnbWVudCArPSBcIi5cIjtcblx0XHRcdGkrKztcblx0XHRcdGNvbnRpbnVlO1xuXHRcdH1cblx0XHRpZiAoY2hhciA9PT0gXCIuXCIpIHtcblx0XHRcdHJlc3VsdC5wdXNoKHNlZ21lbnQpO1xuXHRcdFx0c2VnbWVudCA9IFwiXCI7XG5cdFx0XHRjb250aW51ZTtcblx0XHR9XG5cdFx0c2VnbWVudCArPSBjaGFyO1xuXHR9XG5cdGNvbnN0IGxhc3RTZWdtZW50ID0gc2VnbWVudDtcblx0cmVzdWx0LnB1c2gobGFzdFNlZ21lbnQpO1xuXHRyZXR1cm4gcmVzdWx0O1xufTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIC4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9zdXBlcmpzb25AMi4yLjIvbm9kZV9tb2R1bGVzL3N1cGVyanNvbi9kaXN0L3RyYW5zZm9ybWVyLmpzXG5mdW5jdGlvbiBzaW1wbGVUcmFuc2Zvcm1hdGlvbihpc0FwcGxpY2FibGUsIGFubm90YXRpb24sIHRyYW5zZm9ybSwgdW50cmFuc2Zvcm0pIHtcblx0cmV0dXJuIHtcblx0XHRpc0FwcGxpY2FibGUsXG5cdFx0YW5ub3RhdGlvbixcblx0XHR0cmFuc2Zvcm0sXG5cdFx0dW50cmFuc2Zvcm1cblx0fTtcbn1cbmNvbnN0IHNpbXBsZVJ1bGVzID0gW1xuXHRzaW1wbGVUcmFuc2Zvcm1hdGlvbihpc1VuZGVmaW5lZCQxLCBcInVuZGVmaW5lZFwiLCAoKSA9PiBudWxsLCAoKSA9PiB2b2lkIDApLFxuXHRzaW1wbGVUcmFuc2Zvcm1hdGlvbihpc0JpZ2ludCwgXCJiaWdpbnRcIiwgKHYpID0+IHYudG9TdHJpbmcoKSwgKHYpID0+IHtcblx0XHRpZiAodHlwZW9mIEJpZ0ludCAhPT0gXCJ1bmRlZmluZWRcIikgcmV0dXJuIEJpZ0ludCh2KTtcblx0XHRjb25zb2xlLmVycm9yKFwiUGxlYXNlIGFkZCBhIEJpZ0ludCBwb2x5ZmlsbC5cIik7XG5cdFx0cmV0dXJuIHY7XG5cdH0pLFxuXHRzaW1wbGVUcmFuc2Zvcm1hdGlvbihpc0RhdGUsIFwiRGF0ZVwiLCAodikgPT4gdi50b0lTT1N0cmluZygpLCAodikgPT4gbmV3IERhdGUodikpLFxuXHRzaW1wbGVUcmFuc2Zvcm1hdGlvbihpc0Vycm9yLCBcIkVycm9yXCIsICh2LCBzdXBlckpzb24pID0+IHtcblx0XHRjb25zdCBiYXNlRXJyb3IgPSB7XG5cdFx0XHRuYW1lOiB2Lm5hbWUsXG5cdFx0XHRtZXNzYWdlOiB2Lm1lc3NhZ2Vcblx0XHR9O1xuXHRcdHN1cGVySnNvbi5hbGxvd2VkRXJyb3JQcm9wcy5mb3JFYWNoKChwcm9wKSA9PiB7XG5cdFx0XHRiYXNlRXJyb3JbcHJvcF0gPSB2W3Byb3BdO1xuXHRcdH0pO1xuXHRcdHJldHVybiBiYXNlRXJyb3I7XG5cdH0sICh2LCBzdXBlckpzb24pID0+IHtcblx0XHRjb25zdCBlID0gbmV3IEVycm9yKHYubWVzc2FnZSk7XG5cdFx0ZS5uYW1lID0gdi5uYW1lO1xuXHRcdGUuc3RhY2sgPSB2LnN0YWNrO1xuXHRcdHN1cGVySnNvbi5hbGxvd2VkRXJyb3JQcm9wcy5mb3JFYWNoKChwcm9wKSA9PiB7XG5cdFx0XHRlW3Byb3BdID0gdltwcm9wXTtcblx0XHR9KTtcblx0XHRyZXR1cm4gZTtcblx0fSksXG5cdHNpbXBsZVRyYW5zZm9ybWF0aW9uKGlzUmVnRXhwLCBcInJlZ2V4cFwiLCAodikgPT4gXCJcIiArIHYsIChyZWdleCkgPT4ge1xuXHRcdGNvbnN0IGJvZHkgPSByZWdleC5zbGljZSgxLCByZWdleC5sYXN0SW5kZXhPZihcIi9cIikpO1xuXHRcdGNvbnN0IGZsYWdzID0gcmVnZXguc2xpY2UocmVnZXgubGFzdEluZGV4T2YoXCIvXCIpICsgMSk7XG5cdFx0cmV0dXJuIG5ldyBSZWdFeHAoYm9keSwgZmxhZ3MpO1xuXHR9KSxcblx0c2ltcGxlVHJhbnNmb3JtYXRpb24oaXNTZXQsIFwic2V0XCIsICh2KSA9PiBbLi4udi52YWx1ZXMoKV0sICh2KSA9PiBuZXcgU2V0KHYpKSxcblx0c2ltcGxlVHJhbnNmb3JtYXRpb24oaXNNYXAsIFwibWFwXCIsICh2KSA9PiBbLi4udi5lbnRyaWVzKCldLCAodikgPT4gbmV3IE1hcCh2KSksXG5cdHNpbXBsZVRyYW5zZm9ybWF0aW9uKCh2KSA9PiBpc05hTlZhbHVlKHYpIHx8IGlzSW5maW5pdGUodiksIFwibnVtYmVyXCIsICh2KSA9PiB7XG5cdFx0aWYgKGlzTmFOVmFsdWUodikpIHJldHVybiBcIk5hTlwiO1xuXHRcdGlmICh2ID4gMCkgcmV0dXJuIFwiSW5maW5pdHlcIjtcblx0XHRlbHNlIHJldHVybiBcIi1JbmZpbml0eVwiO1xuXHR9LCBOdW1iZXIpLFxuXHRzaW1wbGVUcmFuc2Zvcm1hdGlvbigodikgPT4gdiA9PT0gMCAmJiAxIC8gdiA9PT0gLUluZmluaXR5LCBcIm51bWJlclwiLCAoKSA9PiB7XG5cdFx0cmV0dXJuIFwiLTBcIjtcblx0fSwgTnVtYmVyKSxcblx0c2ltcGxlVHJhbnNmb3JtYXRpb24oaXNVUkwsIFwiVVJMXCIsICh2KSA9PiB2LnRvU3RyaW5nKCksICh2KSA9PiBuZXcgVVJMKHYpKVxuXTtcbmZ1bmN0aW9uIGNvbXBvc2l0ZVRyYW5zZm9ybWF0aW9uKGlzQXBwbGljYWJsZSwgYW5ub3RhdGlvbiwgdHJhbnNmb3JtLCB1bnRyYW5zZm9ybSkge1xuXHRyZXR1cm4ge1xuXHRcdGlzQXBwbGljYWJsZSxcblx0XHRhbm5vdGF0aW9uLFxuXHRcdHRyYW5zZm9ybSxcblx0XHR1bnRyYW5zZm9ybVxuXHR9O1xufVxuY29uc3Qgc3ltYm9sUnVsZSA9IGNvbXBvc2l0ZVRyYW5zZm9ybWF0aW9uKChzLCBzdXBlckpzb24pID0+IHtcblx0aWYgKGlzU3ltYm9sKHMpKSByZXR1cm4gISFzdXBlckpzb24uc3ltYm9sUmVnaXN0cnkuZ2V0SWRlbnRpZmllcihzKTtcblx0cmV0dXJuIGZhbHNlO1xufSwgKHMsIHN1cGVySnNvbikgPT4ge1xuXHRyZXR1cm4gW1wic3ltYm9sXCIsIHN1cGVySnNvbi5zeW1ib2xSZWdpc3RyeS5nZXRJZGVudGlmaWVyKHMpXTtcbn0sICh2KSA9PiB2LmRlc2NyaXB0aW9uLCAoXywgYSwgc3VwZXJKc29uKSA9PiB7XG5cdGNvbnN0IHZhbHVlID0gc3VwZXJKc29uLnN5bWJvbFJlZ2lzdHJ5LmdldFZhbHVlKGFbMV0pO1xuXHRpZiAoIXZhbHVlKSB0aHJvdyBuZXcgRXJyb3IoXCJUcnlpbmcgdG8gZGVzZXJpYWxpemUgdW5rbm93biBzeW1ib2xcIik7XG5cdHJldHVybiB2YWx1ZTtcbn0pO1xuY29uc3QgY29uc3RydWN0b3JUb05hbWUgPSBbXG5cdEludDhBcnJheSxcblx0VWludDhBcnJheSxcblx0SW50MTZBcnJheSxcblx0VWludDE2QXJyYXksXG5cdEludDMyQXJyYXksXG5cdFVpbnQzMkFycmF5LFxuXHRGbG9hdDMyQXJyYXksXG5cdEZsb2F0NjRBcnJheSxcblx0VWludDhDbGFtcGVkQXJyYXlcbl0ucmVkdWNlKChvYmosIGN0b3IpID0+IHtcblx0b2JqW2N0b3IubmFtZV0gPSBjdG9yO1xuXHRyZXR1cm4gb2JqO1xufSwge30pO1xuY29uc3QgdHlwZWRBcnJheVJ1bGUgPSBjb21wb3NpdGVUcmFuc2Zvcm1hdGlvbihpc1R5cGVkQXJyYXksICh2KSA9PiBbXCJ0eXBlZC1hcnJheVwiLCB2LmNvbnN0cnVjdG9yLm5hbWVdLCAodikgPT4gWy4uLnZdLCAodiwgYSkgPT4ge1xuXHRjb25zdCBjdG9yID0gY29uc3RydWN0b3JUb05hbWVbYVsxXV07XG5cdGlmICghY3RvcikgdGhyb3cgbmV3IEVycm9yKFwiVHJ5aW5nIHRvIGRlc2VyaWFsaXplIHVua25vd24gdHlwZWQgYXJyYXlcIik7XG5cdHJldHVybiBuZXcgY3Rvcih2KTtcbn0pO1xuZnVuY3Rpb24gaXNJbnN0YW5jZU9mUmVnaXN0ZXJlZENsYXNzKHBvdGVudGlhbENsYXNzLCBzdXBlckpzb24pIHtcblx0aWYgKHBvdGVudGlhbENsYXNzPy5jb25zdHJ1Y3RvcikgcmV0dXJuICEhc3VwZXJKc29uLmNsYXNzUmVnaXN0cnkuZ2V0SWRlbnRpZmllcihwb3RlbnRpYWxDbGFzcy5jb25zdHJ1Y3Rvcik7XG5cdHJldHVybiBmYWxzZTtcbn1cbmNvbnN0IGNsYXNzUnVsZSA9IGNvbXBvc2l0ZVRyYW5zZm9ybWF0aW9uKGlzSW5zdGFuY2VPZlJlZ2lzdGVyZWRDbGFzcywgKGNsYXp6LCBzdXBlckpzb24pID0+IHtcblx0cmV0dXJuIFtcImNsYXNzXCIsIHN1cGVySnNvbi5jbGFzc1JlZ2lzdHJ5LmdldElkZW50aWZpZXIoY2xhenouY29uc3RydWN0b3IpXTtcbn0sIChjbGF6eiwgc3VwZXJKc29uKSA9PiB7XG5cdGNvbnN0IGFsbG93ZWRQcm9wcyA9IHN1cGVySnNvbi5jbGFzc1JlZ2lzdHJ5LmdldEFsbG93ZWRQcm9wcyhjbGF6ei5jb25zdHJ1Y3Rvcik7XG5cdGlmICghYWxsb3dlZFByb3BzKSByZXR1cm4geyAuLi5jbGF6eiB9O1xuXHRjb25zdCByZXN1bHQgPSB7fTtcblx0YWxsb3dlZFByb3BzLmZvckVhY2goKHByb3ApID0+IHtcblx0XHRyZXN1bHRbcHJvcF0gPSBjbGF6eltwcm9wXTtcblx0fSk7XG5cdHJldHVybiByZXN1bHQ7XG59LCAodiwgYSwgc3VwZXJKc29uKSA9PiB7XG5cdGNvbnN0IGNsYXp6ID0gc3VwZXJKc29uLmNsYXNzUmVnaXN0cnkuZ2V0VmFsdWUoYVsxXSk7XG5cdGlmICghY2xhenopIHRocm93IG5ldyBFcnJvcihgVHJ5aW5nIHRvIGRlc2VyaWFsaXplIHVua25vd24gY2xhc3MgJyR7YVsxXX0nIC0gY2hlY2sgaHR0cHM6Ly9naXRodWIuY29tL2JsaXR6LWpzL3N1cGVyanNvbi9pc3N1ZXMvMTE2I2lzc3VlY29tbWVudC03NzM5OTY1NjRgKTtcblx0cmV0dXJuIE9iamVjdC5hc3NpZ24oT2JqZWN0LmNyZWF0ZShjbGF6ei5wcm90b3R5cGUpLCB2KTtcbn0pO1xuY29uc3QgY3VzdG9tUnVsZSA9IGNvbXBvc2l0ZVRyYW5zZm9ybWF0aW9uKCh2YWx1ZSwgc3VwZXJKc29uKSA9PiB7XG5cdHJldHVybiAhIXN1cGVySnNvbi5jdXN0b21UcmFuc2Zvcm1lclJlZ2lzdHJ5LmZpbmRBcHBsaWNhYmxlKHZhbHVlKTtcbn0sICh2YWx1ZSwgc3VwZXJKc29uKSA9PiB7XG5cdHJldHVybiBbXCJjdXN0b21cIiwgc3VwZXJKc29uLmN1c3RvbVRyYW5zZm9ybWVyUmVnaXN0cnkuZmluZEFwcGxpY2FibGUodmFsdWUpLm5hbWVdO1xufSwgKHZhbHVlLCBzdXBlckpzb24pID0+IHtcblx0cmV0dXJuIHN1cGVySnNvbi5jdXN0b21UcmFuc2Zvcm1lclJlZ2lzdHJ5LmZpbmRBcHBsaWNhYmxlKHZhbHVlKS5zZXJpYWxpemUodmFsdWUpO1xufSwgKHYsIGEsIHN1cGVySnNvbikgPT4ge1xuXHRjb25zdCB0cmFuc2Zvcm1lciA9IHN1cGVySnNvbi5jdXN0b21UcmFuc2Zvcm1lclJlZ2lzdHJ5LmZpbmRCeU5hbWUoYVsxXSk7XG5cdGlmICghdHJhbnNmb3JtZXIpIHRocm93IG5ldyBFcnJvcihcIlRyeWluZyB0byBkZXNlcmlhbGl6ZSB1bmtub3duIGN1c3RvbSB2YWx1ZVwiKTtcblx0cmV0dXJuIHRyYW5zZm9ybWVyLmRlc2VyaWFsaXplKHYpO1xufSk7XG5jb25zdCBjb21wb3NpdGVSdWxlcyA9IFtcblx0Y2xhc3NSdWxlLFxuXHRzeW1ib2xSdWxlLFxuXHRjdXN0b21SdWxlLFxuXHR0eXBlZEFycmF5UnVsZVxuXTtcbmNvbnN0IHRyYW5zZm9ybVZhbHVlID0gKHZhbHVlLCBzdXBlckpzb24pID0+IHtcblx0Y29uc3QgYXBwbGljYWJsZUNvbXBvc2l0ZVJ1bGUgPSBmaW5kQXJyKGNvbXBvc2l0ZVJ1bGVzLCAocnVsZSkgPT4gcnVsZS5pc0FwcGxpY2FibGUodmFsdWUsIHN1cGVySnNvbikpO1xuXHRpZiAoYXBwbGljYWJsZUNvbXBvc2l0ZVJ1bGUpIHJldHVybiB7XG5cdFx0dmFsdWU6IGFwcGxpY2FibGVDb21wb3NpdGVSdWxlLnRyYW5zZm9ybSh2YWx1ZSwgc3VwZXJKc29uKSxcblx0XHR0eXBlOiBhcHBsaWNhYmxlQ29tcG9zaXRlUnVsZS5hbm5vdGF0aW9uKHZhbHVlLCBzdXBlckpzb24pXG5cdH07XG5cdGNvbnN0IGFwcGxpY2FibGVTaW1wbGVSdWxlID0gZmluZEFycihzaW1wbGVSdWxlcywgKHJ1bGUpID0+IHJ1bGUuaXNBcHBsaWNhYmxlKHZhbHVlLCBzdXBlckpzb24pKTtcblx0aWYgKGFwcGxpY2FibGVTaW1wbGVSdWxlKSByZXR1cm4ge1xuXHRcdHZhbHVlOiBhcHBsaWNhYmxlU2ltcGxlUnVsZS50cmFuc2Zvcm0odmFsdWUsIHN1cGVySnNvbiksXG5cdFx0dHlwZTogYXBwbGljYWJsZVNpbXBsZVJ1bGUuYW5ub3RhdGlvblxuXHR9O1xufTtcbmNvbnN0IHNpbXBsZVJ1bGVzQnlBbm5vdGF0aW9uID0ge307XG5zaW1wbGVSdWxlcy5mb3JFYWNoKChydWxlKSA9PiB7XG5cdHNpbXBsZVJ1bGVzQnlBbm5vdGF0aW9uW3J1bGUuYW5ub3RhdGlvbl0gPSBydWxlO1xufSk7XG5jb25zdCB1bnRyYW5zZm9ybVZhbHVlID0gKGpzb24sIHR5cGUsIHN1cGVySnNvbikgPT4ge1xuXHRpZiAoaXNBcnJheSQyKHR5cGUpKSBzd2l0Y2ggKHR5cGVbMF0pIHtcblx0XHRjYXNlIFwic3ltYm9sXCI6IHJldHVybiBzeW1ib2xSdWxlLnVudHJhbnNmb3JtKGpzb24sIHR5cGUsIHN1cGVySnNvbik7XG5cdFx0Y2FzZSBcImNsYXNzXCI6IHJldHVybiBjbGFzc1J1bGUudW50cmFuc2Zvcm0oanNvbiwgdHlwZSwgc3VwZXJKc29uKTtcblx0XHRjYXNlIFwiY3VzdG9tXCI6IHJldHVybiBjdXN0b21SdWxlLnVudHJhbnNmb3JtKGpzb24sIHR5cGUsIHN1cGVySnNvbik7XG5cdFx0Y2FzZSBcInR5cGVkLWFycmF5XCI6IHJldHVybiB0eXBlZEFycmF5UnVsZS51bnRyYW5zZm9ybShqc29uLCB0eXBlLCBzdXBlckpzb24pO1xuXHRcdGRlZmF1bHQ6IHRocm93IG5ldyBFcnJvcihcIlVua25vd24gdHJhbnNmb3JtYXRpb246IFwiICsgdHlwZSk7XG5cdH1cblx0ZWxzZSB7XG5cdFx0Y29uc3QgdHJhbnNmb3JtYXRpb24gPSBzaW1wbGVSdWxlc0J5QW5ub3RhdGlvblt0eXBlXTtcblx0XHRpZiAoIXRyYW5zZm9ybWF0aW9uKSB0aHJvdyBuZXcgRXJyb3IoXCJVbmtub3duIHRyYW5zZm9ybWF0aW9uOiBcIiArIHR5cGUpO1xuXHRcdHJldHVybiB0cmFuc2Zvcm1hdGlvbi51bnRyYW5zZm9ybShqc29uLCBzdXBlckpzb24pO1xuXHR9XG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3N1cGVyanNvbkAyLjIuMi9ub2RlX21vZHVsZXMvc3VwZXJqc29uL2Rpc3QvYWNjZXNzRGVlcC5qc1xuY29uc3QgZ2V0TnRoS2V5ID0gKHZhbHVlLCBuKSA9PiB7XG5cdGlmIChuID4gdmFsdWUuc2l6ZSkgdGhyb3cgbmV3IEVycm9yKFwiaW5kZXggb3V0IG9mIGJvdW5kc1wiKTtcblx0Y29uc3Qga2V5cyA9IHZhbHVlLmtleXMoKTtcblx0d2hpbGUgKG4gPiAwKSB7XG5cdFx0a2V5cy5uZXh0KCk7XG5cdFx0bi0tO1xuXHR9XG5cdHJldHVybiBrZXlzLm5leHQoKS52YWx1ZTtcbn07XG5mdW5jdGlvbiB2YWxpZGF0ZVBhdGgocGF0aCkge1xuXHRpZiAoaW5jbHVkZXMocGF0aCwgXCJfX3Byb3RvX19cIikpIHRocm93IG5ldyBFcnJvcihcIl9fcHJvdG9fXyBpcyBub3QgYWxsb3dlZCBhcyBhIHByb3BlcnR5XCIpO1xuXHRpZiAoaW5jbHVkZXMocGF0aCwgXCJwcm90b3R5cGVcIikpIHRocm93IG5ldyBFcnJvcihcInByb3RvdHlwZSBpcyBub3QgYWxsb3dlZCBhcyBhIHByb3BlcnR5XCIpO1xuXHRpZiAoaW5jbHVkZXMocGF0aCwgXCJjb25zdHJ1Y3RvclwiKSkgdGhyb3cgbmV3IEVycm9yKFwiY29uc3RydWN0b3IgaXMgbm90IGFsbG93ZWQgYXMgYSBwcm9wZXJ0eVwiKTtcbn1cbmNvbnN0IGdldERlZXAgPSAob2JqZWN0LCBwYXRoKSA9PiB7XG5cdHZhbGlkYXRlUGF0aChwYXRoKTtcblx0Zm9yIChsZXQgaSA9IDA7IGkgPCBwYXRoLmxlbmd0aDsgaSsrKSB7XG5cdFx0Y29uc3Qga2V5ID0gcGF0aFtpXTtcblx0XHRpZiAoaXNTZXQob2JqZWN0KSkgb2JqZWN0ID0gZ2V0TnRoS2V5KG9iamVjdCwgK2tleSk7XG5cdFx0ZWxzZSBpZiAoaXNNYXAob2JqZWN0KSkge1xuXHRcdFx0Y29uc3Qgcm93ID0gK2tleTtcblx0XHRcdGNvbnN0IHR5cGUgPSArcGF0aFsrK2ldID09PSAwID8gXCJrZXlcIiA6IFwidmFsdWVcIjtcblx0XHRcdGNvbnN0IGtleU9mUm93ID0gZ2V0TnRoS2V5KG9iamVjdCwgcm93KTtcblx0XHRcdHN3aXRjaCAodHlwZSkge1xuXHRcdFx0XHRjYXNlIFwia2V5XCI6XG5cdFx0XHRcdFx0b2JqZWN0ID0ga2V5T2ZSb3c7XG5cdFx0XHRcdFx0YnJlYWs7XG5cdFx0XHRcdGNhc2UgXCJ2YWx1ZVwiOlxuXHRcdFx0XHRcdG9iamVjdCA9IG9iamVjdC5nZXQoa2V5T2ZSb3cpO1xuXHRcdFx0XHRcdGJyZWFrO1xuXHRcdFx0fVxuXHRcdH0gZWxzZSBvYmplY3QgPSBvYmplY3Rba2V5XTtcblx0fVxuXHRyZXR1cm4gb2JqZWN0O1xufTtcbmNvbnN0IHNldERlZXAgPSAob2JqZWN0LCBwYXRoLCBtYXBwZXIpID0+IHtcblx0dmFsaWRhdGVQYXRoKHBhdGgpO1xuXHRpZiAocGF0aC5sZW5ndGggPT09IDApIHJldHVybiBtYXBwZXIob2JqZWN0KTtcblx0bGV0IHBhcmVudCA9IG9iamVjdDtcblx0Zm9yIChsZXQgaSA9IDA7IGkgPCBwYXRoLmxlbmd0aCAtIDE7IGkrKykge1xuXHRcdGNvbnN0IGtleSA9IHBhdGhbaV07XG5cdFx0aWYgKGlzQXJyYXkkMihwYXJlbnQpKSB7XG5cdFx0XHRjb25zdCBpbmRleCA9ICtrZXk7XG5cdFx0XHRwYXJlbnQgPSBwYXJlbnRbaW5kZXhdO1xuXHRcdH0gZWxzZSBpZiAoaXNQbGFpbk9iamVjdCQyKHBhcmVudCkpIHBhcmVudCA9IHBhcmVudFtrZXldO1xuXHRcdGVsc2UgaWYgKGlzU2V0KHBhcmVudCkpIHtcblx0XHRcdGNvbnN0IHJvdyA9ICtrZXk7XG5cdFx0XHRwYXJlbnQgPSBnZXROdGhLZXkocGFyZW50LCByb3cpO1xuXHRcdH0gZWxzZSBpZiAoaXNNYXAocGFyZW50KSkge1xuXHRcdFx0aWYgKGkgPT09IHBhdGgubGVuZ3RoIC0gMikgYnJlYWs7XG5cdFx0XHRjb25zdCByb3cgPSAra2V5O1xuXHRcdFx0Y29uc3QgdHlwZSA9ICtwYXRoWysraV0gPT09IDAgPyBcImtleVwiIDogXCJ2YWx1ZVwiO1xuXHRcdFx0Y29uc3Qga2V5T2ZSb3cgPSBnZXROdGhLZXkocGFyZW50LCByb3cpO1xuXHRcdFx0c3dpdGNoICh0eXBlKSB7XG5cdFx0XHRcdGNhc2UgXCJrZXlcIjpcblx0XHRcdFx0XHRwYXJlbnQgPSBrZXlPZlJvdztcblx0XHRcdFx0XHRicmVhaztcblx0XHRcdFx0Y2FzZSBcInZhbHVlXCI6XG5cdFx0XHRcdFx0cGFyZW50ID0gcGFyZW50LmdldChrZXlPZlJvdyk7XG5cdFx0XHRcdFx0YnJlYWs7XG5cdFx0XHR9XG5cdFx0fVxuXHR9XG5cdGNvbnN0IGxhc3RLZXkgPSBwYXRoW3BhdGgubGVuZ3RoIC0gMV07XG5cdGlmIChpc0FycmF5JDIocGFyZW50KSkgcGFyZW50WytsYXN0S2V5XSA9IG1hcHBlcihwYXJlbnRbK2xhc3RLZXldKTtcblx0ZWxzZSBpZiAoaXNQbGFpbk9iamVjdCQyKHBhcmVudCkpIHBhcmVudFtsYXN0S2V5XSA9IG1hcHBlcihwYXJlbnRbbGFzdEtleV0pO1xuXHRpZiAoaXNTZXQocGFyZW50KSkge1xuXHRcdGNvbnN0IG9sZFZhbHVlID0gZ2V0TnRoS2V5KHBhcmVudCwgK2xhc3RLZXkpO1xuXHRcdGNvbnN0IG5ld1ZhbHVlID0gbWFwcGVyKG9sZFZhbHVlKTtcblx0XHRpZiAob2xkVmFsdWUgIT09IG5ld1ZhbHVlKSB7XG5cdFx0XHRwYXJlbnQuZGVsZXRlKG9sZFZhbHVlKTtcblx0XHRcdHBhcmVudC5hZGQobmV3VmFsdWUpO1xuXHRcdH1cblx0fVxuXHRpZiAoaXNNYXAocGFyZW50KSkge1xuXHRcdGNvbnN0IHJvdyA9ICtwYXRoW3BhdGgubGVuZ3RoIC0gMl07XG5cdFx0Y29uc3Qga2V5VG9Sb3cgPSBnZXROdGhLZXkocGFyZW50LCByb3cpO1xuXHRcdHN3aXRjaCAoK2xhc3RLZXkgPT09IDAgPyBcImtleVwiIDogXCJ2YWx1ZVwiKSB7XG5cdFx0XHRjYXNlIFwia2V5XCI6IHtcblx0XHRcdFx0Y29uc3QgbmV3S2V5ID0gbWFwcGVyKGtleVRvUm93KTtcblx0XHRcdFx0cGFyZW50LnNldChuZXdLZXksIHBhcmVudC5nZXQoa2V5VG9Sb3cpKTtcblx0XHRcdFx0aWYgKG5ld0tleSAhPT0ga2V5VG9Sb3cpIHBhcmVudC5kZWxldGUoa2V5VG9Sb3cpO1xuXHRcdFx0XHRicmVhaztcblx0XHRcdH1cblx0XHRcdGNhc2UgXCJ2YWx1ZVwiOlxuXHRcdFx0XHRwYXJlbnQuc2V0KGtleVRvUm93LCBtYXBwZXIocGFyZW50LmdldChrZXlUb1JvdykpKTtcblx0XHRcdFx0YnJlYWs7XG5cdFx0fVxuXHR9XG5cdHJldHVybiBvYmplY3Q7XG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3N1cGVyanNvbkAyLjIuMi9ub2RlX21vZHVsZXMvc3VwZXJqc29uL2Rpc3QvcGxhaW5lci5qc1xuZnVuY3Rpb24gdHJhdmVyc2UodHJlZSwgd2Fsa2VyLCBvcmlnaW4gPSBbXSkge1xuXHRpZiAoIXRyZWUpIHJldHVybjtcblx0aWYgKCFpc0FycmF5JDIodHJlZSkpIHtcblx0XHRmb3JFYWNoKHRyZWUsIChzdWJ0cmVlLCBrZXkpID0+IHRyYXZlcnNlKHN1YnRyZWUsIHdhbGtlciwgWy4uLm9yaWdpbiwgLi4ucGFyc2VQYXRoKGtleSldKSk7XG5cdFx0cmV0dXJuO1xuXHR9XG5cdGNvbnN0IFtub2RlVmFsdWUsIGNoaWxkcmVuXSA9IHRyZWU7XG5cdGlmIChjaGlsZHJlbikgZm9yRWFjaChjaGlsZHJlbiwgKGNoaWxkLCBrZXkpID0+IHtcblx0XHR0cmF2ZXJzZShjaGlsZCwgd2Fsa2VyLCBbLi4ub3JpZ2luLCAuLi5wYXJzZVBhdGgoa2V5KV0pO1xuXHR9KTtcblx0d2Fsa2VyKG5vZGVWYWx1ZSwgb3JpZ2luKTtcbn1cbmZ1bmN0aW9uIGFwcGx5VmFsdWVBbm5vdGF0aW9ucyhwbGFpbiwgYW5ub3RhdGlvbnMsIHN1cGVySnNvbikge1xuXHR0cmF2ZXJzZShhbm5vdGF0aW9ucywgKHR5cGUsIHBhdGgpID0+IHtcblx0XHRwbGFpbiA9IHNldERlZXAocGxhaW4sIHBhdGgsICh2KSA9PiB1bnRyYW5zZm9ybVZhbHVlKHYsIHR5cGUsIHN1cGVySnNvbikpO1xuXHR9KTtcblx0cmV0dXJuIHBsYWluO1xufVxuZnVuY3Rpb24gYXBwbHlSZWZlcmVudGlhbEVxdWFsaXR5QW5ub3RhdGlvbnMocGxhaW4sIGFubm90YXRpb25zKSB7XG5cdGZ1bmN0aW9uIGFwcGx5KGlkZW50aWNhbFBhdGhzLCBwYXRoKSB7XG5cdFx0Y29uc3Qgb2JqZWN0ID0gZ2V0RGVlcChwbGFpbiwgcGFyc2VQYXRoKHBhdGgpKTtcblx0XHRpZGVudGljYWxQYXRocy5tYXAocGFyc2VQYXRoKS5mb3JFYWNoKChpZGVudGljYWxPYmplY3RQYXRoKSA9PiB7XG5cdFx0XHRwbGFpbiA9IHNldERlZXAocGxhaW4sIGlkZW50aWNhbE9iamVjdFBhdGgsICgpID0+IG9iamVjdCk7XG5cdFx0fSk7XG5cdH1cblx0aWYgKGlzQXJyYXkkMihhbm5vdGF0aW9ucykpIHtcblx0XHRjb25zdCBbcm9vdCwgb3RoZXJdID0gYW5ub3RhdGlvbnM7XG5cdFx0cm9vdC5mb3JFYWNoKChpZGVudGljYWxQYXRoKSA9PiB7XG5cdFx0XHRwbGFpbiA9IHNldERlZXAocGxhaW4sIHBhcnNlUGF0aChpZGVudGljYWxQYXRoKSwgKCkgPT4gcGxhaW4pO1xuXHRcdH0pO1xuXHRcdGlmIChvdGhlcikgZm9yRWFjaChvdGhlciwgYXBwbHkpO1xuXHR9IGVsc2UgZm9yRWFjaChhbm5vdGF0aW9ucywgYXBwbHkpO1xuXHRyZXR1cm4gcGxhaW47XG59XG5jb25zdCBpc0RlZXAgPSAob2JqZWN0LCBzdXBlckpzb24pID0+IGlzUGxhaW5PYmplY3QkMihvYmplY3QpIHx8IGlzQXJyYXkkMihvYmplY3QpIHx8IGlzTWFwKG9iamVjdCkgfHwgaXNTZXQob2JqZWN0KSB8fCBpc0luc3RhbmNlT2ZSZWdpc3RlcmVkQ2xhc3Mob2JqZWN0LCBzdXBlckpzb24pO1xuZnVuY3Rpb24gYWRkSWRlbnRpdHkob2JqZWN0LCBwYXRoLCBpZGVudGl0aWVzKSB7XG5cdGNvbnN0IGV4aXN0aW5nU2V0ID0gaWRlbnRpdGllcy5nZXQob2JqZWN0KTtcblx0aWYgKGV4aXN0aW5nU2V0KSBleGlzdGluZ1NldC5wdXNoKHBhdGgpO1xuXHRlbHNlIGlkZW50aXRpZXMuc2V0KG9iamVjdCwgW3BhdGhdKTtcbn1cbmZ1bmN0aW9uIGdlbmVyYXRlUmVmZXJlbnRpYWxFcXVhbGl0eUFubm90YXRpb25zKGlkZW50aXRpdGVzLCBkZWR1cGUpIHtcblx0Y29uc3QgcmVzdWx0ID0ge307XG5cdGxldCByb290RXF1YWxpdHlQYXRocyA9IHZvaWQgMDtcblx0aWRlbnRpdGl0ZXMuZm9yRWFjaCgocGF0aHMpID0+IHtcblx0XHRpZiAocGF0aHMubGVuZ3RoIDw9IDEpIHJldHVybjtcblx0XHRpZiAoIWRlZHVwZSkgcGF0aHMgPSBwYXRocy5tYXAoKHBhdGgpID0+IHBhdGgubWFwKFN0cmluZykpLnNvcnQoKGEsIGIpID0+IGEubGVuZ3RoIC0gYi5sZW5ndGgpO1xuXHRcdGNvbnN0IFtyZXByZXNlbnRhdGl2ZVBhdGgsIC4uLmlkZW50aWNhbFBhdGhzXSA9IHBhdGhzO1xuXHRcdGlmIChyZXByZXNlbnRhdGl2ZVBhdGgubGVuZ3RoID09PSAwKSByb290RXF1YWxpdHlQYXRocyA9IGlkZW50aWNhbFBhdGhzLm1hcChzdHJpbmdpZnlQYXRoKTtcblx0XHRlbHNlIHJlc3VsdFtzdHJpbmdpZnlQYXRoKHJlcHJlc2VudGF0aXZlUGF0aCldID0gaWRlbnRpY2FsUGF0aHMubWFwKHN0cmluZ2lmeVBhdGgpO1xuXHR9KTtcblx0aWYgKHJvb3RFcXVhbGl0eVBhdGhzKSBpZiAoaXNFbXB0eU9iamVjdChyZXN1bHQpKSByZXR1cm4gW3Jvb3RFcXVhbGl0eVBhdGhzXTtcblx0ZWxzZSByZXR1cm4gW3Jvb3RFcXVhbGl0eVBhdGhzLCByZXN1bHRdO1xuXHRlbHNlIHJldHVybiBpc0VtcHR5T2JqZWN0KHJlc3VsdCkgPyB2b2lkIDAgOiByZXN1bHQ7XG59XG5jb25zdCB3YWxrZXIgPSAob2JqZWN0LCBpZGVudGl0aWVzLCBzdXBlckpzb24sIGRlZHVwZSwgcGF0aCA9IFtdLCBvYmplY3RzSW5UaGlzUGF0aCA9IFtdLCBzZWVuT2JqZWN0cyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCkpID0+IHtcblx0Y29uc3QgcHJpbWl0aXZlID0gaXNQcmltaXRpdmUob2JqZWN0KTtcblx0aWYgKCFwcmltaXRpdmUpIHtcblx0XHRhZGRJZGVudGl0eShvYmplY3QsIHBhdGgsIGlkZW50aXRpZXMpO1xuXHRcdGNvbnN0IHNlZW4gPSBzZWVuT2JqZWN0cy5nZXQob2JqZWN0KTtcblx0XHRpZiAoc2VlbikgcmV0dXJuIGRlZHVwZSA/IHsgdHJhbnNmb3JtZWRWYWx1ZTogbnVsbCB9IDogc2Vlbjtcblx0fVxuXHRpZiAoIWlzRGVlcChvYmplY3QsIHN1cGVySnNvbikpIHtcblx0XHRjb25zdCB0cmFuc2Zvcm1lZCA9IHRyYW5zZm9ybVZhbHVlKG9iamVjdCwgc3VwZXJKc29uKTtcblx0XHRjb25zdCByZXN1bHQgPSB0cmFuc2Zvcm1lZCA/IHtcblx0XHRcdHRyYW5zZm9ybWVkVmFsdWU6IHRyYW5zZm9ybWVkLnZhbHVlLFxuXHRcdFx0YW5ub3RhdGlvbnM6IFt0cmFuc2Zvcm1lZC50eXBlXVxuXHRcdH0gOiB7IHRyYW5zZm9ybWVkVmFsdWU6IG9iamVjdCB9O1xuXHRcdGlmICghcHJpbWl0aXZlKSBzZWVuT2JqZWN0cy5zZXQob2JqZWN0LCByZXN1bHQpO1xuXHRcdHJldHVybiByZXN1bHQ7XG5cdH1cblx0aWYgKGluY2x1ZGVzKG9iamVjdHNJblRoaXNQYXRoLCBvYmplY3QpKSByZXR1cm4geyB0cmFuc2Zvcm1lZFZhbHVlOiBudWxsIH07XG5cdGNvbnN0IHRyYW5zZm9ybWF0aW9uUmVzdWx0ID0gdHJhbnNmb3JtVmFsdWUob2JqZWN0LCBzdXBlckpzb24pO1xuXHRjb25zdCB0cmFuc2Zvcm1lZCA9IHRyYW5zZm9ybWF0aW9uUmVzdWx0Py52YWx1ZSA/PyBvYmplY3Q7XG5cdGNvbnN0IHRyYW5zZm9ybWVkVmFsdWUgPSBpc0FycmF5JDIodHJhbnNmb3JtZWQpID8gW10gOiB7fTtcblx0Y29uc3QgaW5uZXJBbm5vdGF0aW9ucyA9IHt9O1xuXHRmb3JFYWNoKHRyYW5zZm9ybWVkLCAodmFsdWUsIGluZGV4KSA9PiB7XG5cdFx0aWYgKGluZGV4ID09PSBcIl9fcHJvdG9fX1wiIHx8IGluZGV4ID09PSBcImNvbnN0cnVjdG9yXCIgfHwgaW5kZXggPT09IFwicHJvdG90eXBlXCIpIHRocm93IG5ldyBFcnJvcihgRGV0ZWN0ZWQgcHJvcGVydHkgJHtpbmRleH0uIFRoaXMgaXMgYSBwcm90b3R5cGUgcG9sbHV0aW9uIHJpc2ssIHBsZWFzZSByZW1vdmUgaXQgZnJvbSB5b3VyIG9iamVjdC5gKTtcblx0XHRjb25zdCByZWN1cnNpdmVSZXN1bHQgPSB3YWxrZXIodmFsdWUsIGlkZW50aXRpZXMsIHN1cGVySnNvbiwgZGVkdXBlLCBbLi4ucGF0aCwgaW5kZXhdLCBbLi4ub2JqZWN0c0luVGhpc1BhdGgsIG9iamVjdF0sIHNlZW5PYmplY3RzKTtcblx0XHR0cmFuc2Zvcm1lZFZhbHVlW2luZGV4XSA9IHJlY3Vyc2l2ZVJlc3VsdC50cmFuc2Zvcm1lZFZhbHVlO1xuXHRcdGlmIChpc0FycmF5JDIocmVjdXJzaXZlUmVzdWx0LmFubm90YXRpb25zKSkgaW5uZXJBbm5vdGF0aW9uc1tpbmRleF0gPSByZWN1cnNpdmVSZXN1bHQuYW5ub3RhdGlvbnM7XG5cdFx0ZWxzZSBpZiAoaXNQbGFpbk9iamVjdCQyKHJlY3Vyc2l2ZVJlc3VsdC5hbm5vdGF0aW9ucykpIGZvckVhY2gocmVjdXJzaXZlUmVzdWx0LmFubm90YXRpb25zLCAodHJlZSwga2V5KSA9PiB7XG5cdFx0XHRpbm5lckFubm90YXRpb25zW2VzY2FwZUtleShpbmRleCkgKyBcIi5cIiArIGtleV0gPSB0cmVlO1xuXHRcdH0pO1xuXHR9KTtcblx0Y29uc3QgcmVzdWx0ID0gaXNFbXB0eU9iamVjdChpbm5lckFubm90YXRpb25zKSA/IHtcblx0XHR0cmFuc2Zvcm1lZFZhbHVlLFxuXHRcdGFubm90YXRpb25zOiAhIXRyYW5zZm9ybWF0aW9uUmVzdWx0ID8gW3RyYW5zZm9ybWF0aW9uUmVzdWx0LnR5cGVdIDogdm9pZCAwXG5cdH0gOiB7XG5cdFx0dHJhbnNmb3JtZWRWYWx1ZSxcblx0XHRhbm5vdGF0aW9uczogISF0cmFuc2Zvcm1hdGlvblJlc3VsdCA/IFt0cmFuc2Zvcm1hdGlvblJlc3VsdC50eXBlLCBpbm5lckFubm90YXRpb25zXSA6IGlubmVyQW5ub3RhdGlvbnNcblx0fTtcblx0aWYgKCFwcmltaXRpdmUpIHNlZW5PYmplY3RzLnNldChvYmplY3QsIHJlc3VsdCk7XG5cdHJldHVybiByZXN1bHQ7XG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL2lzLXdoYXRANC4xLjE2L25vZGVfbW9kdWxlcy9pcy13aGF0L2Rpc3QvaW5kZXguanNcbmZ1bmN0aW9uIGdldFR5cGUocGF5bG9hZCkge1xuXHRyZXR1cm4gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKHBheWxvYWQpLnNsaWNlKDgsIC0xKTtcbn1cbmZ1bmN0aW9uIGlzQXJyYXkkMShwYXlsb2FkKSB7XG5cdHJldHVybiBnZXRUeXBlKHBheWxvYWQpID09PSBcIkFycmF5XCI7XG59XG5mdW5jdGlvbiBpc1BsYWluT2JqZWN0JDEocGF5bG9hZCkge1xuXHRpZiAoZ2V0VHlwZShwYXlsb2FkKSAhPT0gXCJPYmplY3RcIikgcmV0dXJuIGZhbHNlO1xuXHRjb25zdCBwcm90b3R5cGUgPSBPYmplY3QuZ2V0UHJvdG90eXBlT2YocGF5bG9hZCk7XG5cdHJldHVybiAhIXByb3RvdHlwZSAmJiBwcm90b3R5cGUuY29uc3RydWN0b3IgPT09IE9iamVjdCAmJiBwcm90b3R5cGUgPT09IE9iamVjdC5wcm90b3R5cGU7XG59XG5mdW5jdGlvbiBpc051bGwocGF5bG9hZCkge1xuXHRyZXR1cm4gZ2V0VHlwZShwYXlsb2FkKSA9PT0gXCJOdWxsXCI7XG59XG5mdW5jdGlvbiBpc09uZU9mKGEsIGIsIGMsIGQsIGUpIHtcblx0cmV0dXJuICh2YWx1ZSkgPT4gYSh2YWx1ZSkgfHwgYih2YWx1ZSkgfHwgISFjICYmIGModmFsdWUpIHx8ICEhZCAmJiBkKHZhbHVlKSB8fCAhIWUgJiYgZSh2YWx1ZSk7XG59XG5mdW5jdGlvbiBpc1VuZGVmaW5lZChwYXlsb2FkKSB7XG5cdHJldHVybiBnZXRUeXBlKHBheWxvYWQpID09PSBcIlVuZGVmaW5lZFwiO1xufVxuaXNPbmVPZihpc051bGwsIGlzVW5kZWZpbmVkKTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIC4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3B5LWFueXRoaW5nQDMuMC41L25vZGVfbW9kdWxlcy9jb3B5LWFueXRoaW5nL2Rpc3QvaW5kZXguanNcbmZ1bmN0aW9uIGFzc2lnblByb3AoY2FycnksIGtleSwgbmV3VmFsLCBvcmlnaW5hbE9iamVjdCwgaW5jbHVkZU5vbmVudW1lcmFibGUpIHtcblx0Y29uc3QgcHJvcFR5cGUgPSB7fS5wcm9wZXJ0eUlzRW51bWVyYWJsZS5jYWxsKG9yaWdpbmFsT2JqZWN0LCBrZXkpID8gXCJlbnVtZXJhYmxlXCIgOiBcIm5vbmVudW1lcmFibGVcIjtcblx0aWYgKHByb3BUeXBlID09PSBcImVudW1lcmFibGVcIikgY2Fycnlba2V5XSA9IG5ld1ZhbDtcblx0aWYgKGluY2x1ZGVOb25lbnVtZXJhYmxlICYmIHByb3BUeXBlID09PSBcIm5vbmVudW1lcmFibGVcIikgT2JqZWN0LmRlZmluZVByb3BlcnR5KGNhcnJ5LCBrZXksIHtcblx0XHR2YWx1ZTogbmV3VmFsLFxuXHRcdGVudW1lcmFibGU6IGZhbHNlLFxuXHRcdHdyaXRhYmxlOiB0cnVlLFxuXHRcdGNvbmZpZ3VyYWJsZTogdHJ1ZVxuXHR9KTtcbn1cbmZ1bmN0aW9uIGNvcHkodGFyZ2V0LCBvcHRpb25zID0ge30pIHtcblx0aWYgKGlzQXJyYXkkMSh0YXJnZXQpKSByZXR1cm4gdGFyZ2V0Lm1hcCgoaXRlbSkgPT4gY29weShpdGVtLCBvcHRpb25zKSk7XG5cdGlmICghaXNQbGFpbk9iamVjdCQxKHRhcmdldCkpIHJldHVybiB0YXJnZXQ7XG5cdGNvbnN0IHByb3BzID0gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXModGFyZ2V0KTtcblx0Y29uc3Qgc3ltYm9scyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHModGFyZ2V0KTtcblx0cmV0dXJuIFsuLi5wcm9wcywgLi4uc3ltYm9sc10ucmVkdWNlKChjYXJyeSwga2V5KSA9PiB7XG5cdFx0aWYgKGlzQXJyYXkkMShvcHRpb25zLnByb3BzKSAmJiAhb3B0aW9ucy5wcm9wcy5pbmNsdWRlcyhrZXkpKSByZXR1cm4gY2Fycnk7XG5cdFx0Y29uc3QgdmFsID0gdGFyZ2V0W2tleV07XG5cdFx0YXNzaWduUHJvcChjYXJyeSwga2V5LCBjb3B5KHZhbCwgb3B0aW9ucyksIHRhcmdldCwgb3B0aW9ucy5ub25lbnVtZXJhYmxlKTtcblx0XHRyZXR1cm4gY2Fycnk7XG5cdH0sIHt9KTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIC4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9zdXBlcmpzb25AMi4yLjIvbm9kZV9tb2R1bGVzL3N1cGVyanNvbi9kaXN0L2luZGV4LmpzXG52YXIgU3VwZXJKU09OID0gY2xhc3Mge1xuXHQvKipcblx0KiBAcGFyYW0gZGVkdXBlUmVmZXJlbnRpYWxFcXVhbGl0aWVzICBJZiB0cnVlLCBTdXBlckpTT04gd2lsbCBtYWtlIHN1cmUgb25seSBvbmUgaW5zdGFuY2Ugb2YgcmVmZXJlbnRpYWxseSBlcXVhbCBvYmplY3RzIGFyZSBzZXJpYWxpemVkIGFuZCB0aGUgcmVzdCBhcmUgcmVwbGFjZWQgd2l0aCBgbnVsbGAuXG5cdCovXG5cdGNvbnN0cnVjdG9yKHsgZGVkdXBlID0gZmFsc2UgfSA9IHt9KSB7XG5cdFx0dGhpcy5jbGFzc1JlZ2lzdHJ5ID0gbmV3IENsYXNzUmVnaXN0cnkoKTtcblx0XHR0aGlzLnN5bWJvbFJlZ2lzdHJ5ID0gbmV3IFJlZ2lzdHJ5KChzKSA9PiBzLmRlc2NyaXB0aW9uID8/IFwiXCIpO1xuXHRcdHRoaXMuY3VzdG9tVHJhbnNmb3JtZXJSZWdpc3RyeSA9IG5ldyBDdXN0b21UcmFuc2Zvcm1lclJlZ2lzdHJ5KCk7XG5cdFx0dGhpcy5hbGxvd2VkRXJyb3JQcm9wcyA9IFtdO1xuXHRcdHRoaXMuZGVkdXBlID0gZGVkdXBlO1xuXHR9XG5cdHNlcmlhbGl6ZShvYmplY3QpIHtcblx0XHRjb25zdCBpZGVudGl0aWVzID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0XHRjb25zdCBvdXRwdXQgPSB3YWxrZXIob2JqZWN0LCBpZGVudGl0aWVzLCB0aGlzLCB0aGlzLmRlZHVwZSk7XG5cdFx0Y29uc3QgcmVzID0geyBqc29uOiBvdXRwdXQudHJhbnNmb3JtZWRWYWx1ZSB9O1xuXHRcdGlmIChvdXRwdXQuYW5ub3RhdGlvbnMpIHJlcy5tZXRhID0ge1xuXHRcdFx0Li4ucmVzLm1ldGEsXG5cdFx0XHR2YWx1ZXM6IG91dHB1dC5hbm5vdGF0aW9uc1xuXHRcdH07XG5cdFx0Y29uc3QgZXF1YWxpdHlBbm5vdGF0aW9ucyA9IGdlbmVyYXRlUmVmZXJlbnRpYWxFcXVhbGl0eUFubm90YXRpb25zKGlkZW50aXRpZXMsIHRoaXMuZGVkdXBlKTtcblx0XHRpZiAoZXF1YWxpdHlBbm5vdGF0aW9ucykgcmVzLm1ldGEgPSB7XG5cdFx0XHQuLi5yZXMubWV0YSxcblx0XHRcdHJlZmVyZW50aWFsRXF1YWxpdGllczogZXF1YWxpdHlBbm5vdGF0aW9uc1xuXHRcdH07XG5cdFx0cmV0dXJuIHJlcztcblx0fVxuXHRkZXNlcmlhbGl6ZShwYXlsb2FkKSB7XG5cdFx0Y29uc3QgeyBqc29uLCBtZXRhIH0gPSBwYXlsb2FkO1xuXHRcdGxldCByZXN1bHQgPSBjb3B5KGpzb24pO1xuXHRcdGlmIChtZXRhPy52YWx1ZXMpIHJlc3VsdCA9IGFwcGx5VmFsdWVBbm5vdGF0aW9ucyhyZXN1bHQsIG1ldGEudmFsdWVzLCB0aGlzKTtcblx0XHRpZiAobWV0YT8ucmVmZXJlbnRpYWxFcXVhbGl0aWVzKSByZXN1bHQgPSBhcHBseVJlZmVyZW50aWFsRXF1YWxpdHlBbm5vdGF0aW9ucyhyZXN1bHQsIG1ldGEucmVmZXJlbnRpYWxFcXVhbGl0aWVzKTtcblx0XHRyZXR1cm4gcmVzdWx0O1xuXHR9XG5cdHN0cmluZ2lmeShvYmplY3QpIHtcblx0XHRyZXR1cm4gSlNPTi5zdHJpbmdpZnkodGhpcy5zZXJpYWxpemUob2JqZWN0KSk7XG5cdH1cblx0cGFyc2Uoc3RyaW5nKSB7XG5cdFx0cmV0dXJuIHRoaXMuZGVzZXJpYWxpemUoSlNPTi5wYXJzZShzdHJpbmcpKTtcblx0fVxuXHRyZWdpc3RlckNsYXNzKHYsIG9wdGlvbnMpIHtcblx0XHR0aGlzLmNsYXNzUmVnaXN0cnkucmVnaXN0ZXIodiwgb3B0aW9ucyk7XG5cdH1cblx0cmVnaXN0ZXJTeW1ib2wodiwgaWRlbnRpZmllcikge1xuXHRcdHRoaXMuc3ltYm9sUmVnaXN0cnkucmVnaXN0ZXIodiwgaWRlbnRpZmllcik7XG5cdH1cblx0cmVnaXN0ZXJDdXN0b20odHJhbnNmb3JtZXIsIG5hbWUpIHtcblx0XHR0aGlzLmN1c3RvbVRyYW5zZm9ybWVyUmVnaXN0cnkucmVnaXN0ZXIoe1xuXHRcdFx0bmFtZSxcblx0XHRcdC4uLnRyYW5zZm9ybWVyXG5cdFx0fSk7XG5cdH1cblx0YWxsb3dFcnJvclByb3BzKC4uLnByb3BzKSB7XG5cdFx0dGhpcy5hbGxvd2VkRXJyb3JQcm9wcy5wdXNoKC4uLnByb3BzKTtcblx0fVxufTtcblN1cGVySlNPTi5kZWZhdWx0SW5zdGFuY2UgPSBuZXcgU3VwZXJKU09OKCk7XG5TdXBlckpTT04uc2VyaWFsaXplID0gU3VwZXJKU09OLmRlZmF1bHRJbnN0YW5jZS5zZXJpYWxpemUuYmluZChTdXBlckpTT04uZGVmYXVsdEluc3RhbmNlKTtcblN1cGVySlNPTi5kZXNlcmlhbGl6ZSA9IFN1cGVySlNPTi5kZWZhdWx0SW5zdGFuY2UuZGVzZXJpYWxpemUuYmluZChTdXBlckpTT04uZGVmYXVsdEluc3RhbmNlKTtcblN1cGVySlNPTi5zdHJpbmdpZnkgPSBTdXBlckpTT04uZGVmYXVsdEluc3RhbmNlLnN0cmluZ2lmeS5iaW5kKFN1cGVySlNPTi5kZWZhdWx0SW5zdGFuY2UpO1xuU3VwZXJKU09OLnBhcnNlID0gU3VwZXJKU09OLmRlZmF1bHRJbnN0YW5jZS5wYXJzZS5iaW5kKFN1cGVySlNPTi5kZWZhdWx0SW5zdGFuY2UpO1xuU3VwZXJKU09OLnJlZ2lzdGVyQ2xhc3MgPSBTdXBlckpTT04uZGVmYXVsdEluc3RhbmNlLnJlZ2lzdGVyQ2xhc3MuYmluZChTdXBlckpTT04uZGVmYXVsdEluc3RhbmNlKTtcblN1cGVySlNPTi5yZWdpc3RlclN5bWJvbCA9IFN1cGVySlNPTi5kZWZhdWx0SW5zdGFuY2UucmVnaXN0ZXJTeW1ib2wuYmluZChTdXBlckpTT04uZGVmYXVsdEluc3RhbmNlKTtcblN1cGVySlNPTi5yZWdpc3RlckN1c3RvbSA9IFN1cGVySlNPTi5kZWZhdWx0SW5zdGFuY2UucmVnaXN0ZXJDdXN0b20uYmluZChTdXBlckpTT04uZGVmYXVsdEluc3RhbmNlKTtcblN1cGVySlNPTi5hbGxvd0Vycm9yUHJvcHMgPSBTdXBlckpTT04uZGVmYXVsdEluc3RhbmNlLmFsbG93RXJyb3JQcm9wcy5iaW5kKFN1cGVySlNPTi5kZWZhdWx0SW5zdGFuY2UpO1xuU3VwZXJKU09OLnNlcmlhbGl6ZTtcblN1cGVySlNPTi5kZXNlcmlhbGl6ZTtcblN1cGVySlNPTi5zdHJpbmdpZnk7XG5TdXBlckpTT04ucGFyc2U7XG5TdXBlckpTT04ucmVnaXN0ZXJDbGFzcztcblN1cGVySlNPTi5yZWdpc3RlckN1c3RvbTtcblN1cGVySlNPTi5yZWdpc3RlclN5bWJvbDtcblN1cGVySlNPTi5hbGxvd0Vycm9yUHJvcHM7XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbWVzc2FnaW5nL3ByZXNldHMvYnJvYWRjYXN0LWNoYW5uZWwvY29udGV4dC50c1xuY29uc3QgX19ERVZUT09MU19LSVRfQlJPQURDQVNUX01FU1NBR0lOR19FVkVOVF9LRVkgPSBcIl9fZGV2dG9vbHMta2l0LWJyb2FkY2FzdC1tZXNzYWdpbmctZXZlbnQta2V5X19cIjtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tZXNzYWdpbmcvcHJlc2V0cy9icm9hZGNhc3QtY2hhbm5lbC9pbmRleC50c1xuY29uc3QgQlJPQURDQVNUX0NIQU5ORUxfTkFNRSA9IFwiX19kZXZ0b29scy1raXQ6YnJvYWRjYXN0LWNoYW5uZWxfX1wiO1xuZnVuY3Rpb24gY3JlYXRlQnJvYWRjYXN0Q2hhbm5lbCgpIHtcblx0Y29uc3QgY2hhbm5lbCA9IG5ldyBCcm9hZGNhc3RDaGFubmVsKEJST0FEQ0FTVF9DSEFOTkVMX05BTUUpO1xuXHRyZXR1cm4ge1xuXHRcdHBvc3Q6IChkYXRhKSA9PiB7XG5cdFx0XHRjaGFubmVsLnBvc3RNZXNzYWdlKFN1cGVySlNPTi5zdHJpbmdpZnkoe1xuXHRcdFx0XHRldmVudDogX19ERVZUT09MU19LSVRfQlJPQURDQVNUX01FU1NBR0lOR19FVkVOVF9LRVksXG5cdFx0XHRcdGRhdGFcblx0XHRcdH0pKTtcblx0XHR9LFxuXHRcdG9uOiAoaGFuZGxlcikgPT4ge1xuXHRcdFx0Y2hhbm5lbC5vbm1lc3NhZ2UgPSAoZXZlbnQpID0+IHtcblx0XHRcdFx0Y29uc3QgcGFyc2VkID0gU3VwZXJKU09OLnBhcnNlKGV2ZW50LmRhdGEpO1xuXHRcdFx0XHRpZiAocGFyc2VkLmV2ZW50ID09PSBcIl9fZGV2dG9vbHMta2l0LWJyb2FkY2FzdC1tZXNzYWdpbmctZXZlbnQta2V5X19cIikgaGFuZGxlcihwYXJzZWQuZGF0YSk7XG5cdFx0XHR9O1xuXHRcdH1cblx0fTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tZXNzYWdpbmcvcHJlc2V0cy9lbGVjdHJvbi9jb250ZXh0LnRzXG5jb25zdCBfX0VMRUNUUk9OX0NMSUVOVF9DT05URVhUX18gPSBcImVsZWN0cm9uOmNsaWVudC1jb250ZXh0XCI7XG5jb25zdCBfX0VMRUNUUk9OX1JQT1hZX0NPTlRFWFRfXyA9IFwiZWxlY3Ryb246cHJveHktY29udGV4dFwiO1xuY29uc3QgX19FTEVDVFJPTl9TRVJWRVJfQ09OVEVYVF9fID0gXCJlbGVjdHJvbjpzZXJ2ZXItY29udGV4dFwiO1xuY29uc3QgX19ERVZUT09MU19LSVRfRUxFQ1RST05fTUVTU0FHSU5HX0VWRU5UX0tFWV9fID0ge1xuXHRDTElFTlRfVE9fUFJPWFk6IFwiY2xpZW50LT5wcm94eVwiLFxuXHRQUk9YWV9UT19DTElFTlQ6IFwicHJveHktPmNsaWVudFwiLFxuXHRQUk9YWV9UT19TRVJWRVI6IFwicHJveHktPnNlcnZlclwiLFxuXHRTRVJWRVJfVE9fUFJPWFk6IFwic2VydmVyLT5wcm94eVwiXG59O1xuZnVuY3Rpb24gZ2V0RWxlY3Ryb25DbGllbnRDb250ZXh0KCkge1xuXHRyZXR1cm4gdGFyZ2V0W19fRUxFQ1RST05fQ0xJRU5UX0NPTlRFWFRfX107XG59XG5mdW5jdGlvbiBzZXRFbGVjdHJvbkNsaWVudENvbnRleHQoY29udGV4dCkge1xuXHR0YXJnZXRbX19FTEVDVFJPTl9DTElFTlRfQ09OVEVYVF9fXSA9IGNvbnRleHQ7XG59XG5mdW5jdGlvbiBnZXRFbGVjdHJvblByb3h5Q29udGV4dCgpIHtcblx0cmV0dXJuIHRhcmdldFtfX0VMRUNUUk9OX1JQT1hZX0NPTlRFWFRfX107XG59XG5mdW5jdGlvbiBzZXRFbGVjdHJvblByb3h5Q29udGV4dChjb250ZXh0KSB7XG5cdHRhcmdldFtfX0VMRUNUUk9OX1JQT1hZX0NPTlRFWFRfX10gPSBjb250ZXh0O1xufVxuZnVuY3Rpb24gZ2V0RWxlY3Ryb25TZXJ2ZXJDb250ZXh0KCkge1xuXHRyZXR1cm4gdGFyZ2V0W19fRUxFQ1RST05fU0VSVkVSX0NPTlRFWFRfX107XG59XG5mdW5jdGlvbiBzZXRFbGVjdHJvblNlcnZlckNvbnRleHQoY29udGV4dCkge1xuXHR0YXJnZXRbX19FTEVDVFJPTl9TRVJWRVJfQ09OVEVYVF9fXSA9IGNvbnRleHQ7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbWVzc2FnaW5nL3ByZXNldHMvZWxlY3Ryb24vY2xpZW50LnRzXG5mdW5jdGlvbiBjcmVhdGVFbGVjdHJvbkNsaWVudENoYW5uZWwoKSB7XG5cdGNvbnN0IHNvY2tldCA9IGdldEVsZWN0cm9uQ2xpZW50Q29udGV4dCgpO1xuXHRyZXR1cm4ge1xuXHRcdHBvc3Q6IChkYXRhKSA9PiB7XG5cdFx0XHRzb2NrZXQuZW1pdChfX0RFVlRPT0xTX0tJVF9FTEVDVFJPTl9NRVNTQUdJTkdfRVZFTlRfS0VZX18uQ0xJRU5UX1RPX1BST1hZLCBTdXBlckpTT04uc3RyaW5naWZ5KGRhdGEpKTtcblx0XHR9LFxuXHRcdG9uOiAoaGFuZGxlcikgPT4ge1xuXHRcdFx0c29ja2V0Lm9uKF9fREVWVE9PTFNfS0lUX0VMRUNUUk9OX01FU1NBR0lOR19FVkVOVF9LRVlfXy5QUk9YWV9UT19DTElFTlQsIChlKSA9PiB7XG5cdFx0XHRcdGhhbmRsZXIoU3VwZXJKU09OLnBhcnNlKGUpKTtcblx0XHRcdH0pO1xuXHRcdH1cblx0fTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tZXNzYWdpbmcvcHJlc2V0cy9lbGVjdHJvbi9wcm94eS50c1xuZnVuY3Rpb24gY3JlYXRlRWxlY3Ryb25Qcm94eUNoYW5uZWwoKSB7XG5cdGNvbnN0IHNvY2tldCA9IGdldEVsZWN0cm9uUHJveHlDb250ZXh0KCk7XG5cdHJldHVybiB7XG5cdFx0cG9zdDogKGRhdGEpID0+IHt9LFxuXHRcdG9uOiAoaGFuZGxlcikgPT4ge1xuXHRcdFx0c29ja2V0Lm9uKF9fREVWVE9PTFNfS0lUX0VMRUNUUk9OX01FU1NBR0lOR19FVkVOVF9LRVlfXy5TRVJWRVJfVE9fUFJPWFksIChkYXRhKSA9PiB7XG5cdFx0XHRcdHNvY2tldC5icm9hZGNhc3QuZW1pdChfX0RFVlRPT0xTX0tJVF9FTEVDVFJPTl9NRVNTQUdJTkdfRVZFTlRfS0VZX18uUFJPWFlfVE9fQ0xJRU5ULCBkYXRhKTtcblx0XHRcdH0pO1xuXHRcdFx0c29ja2V0Lm9uKF9fREVWVE9PTFNfS0lUX0VMRUNUUk9OX01FU1NBR0lOR19FVkVOVF9LRVlfXy5DTElFTlRfVE9fUFJPWFksIChkYXRhKSA9PiB7XG5cdFx0XHRcdHNvY2tldC5icm9hZGNhc3QuZW1pdChfX0RFVlRPT0xTX0tJVF9FTEVDVFJPTl9NRVNTQUdJTkdfRVZFTlRfS0VZX18uUFJPWFlfVE9fU0VSVkVSLCBkYXRhKTtcblx0XHRcdH0pO1xuXHRcdH1cblx0fTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tZXNzYWdpbmcvcHJlc2V0cy9lbGVjdHJvbi9zZXJ2ZXIudHNcbmZ1bmN0aW9uIGNyZWF0ZUVsZWN0cm9uU2VydmVyQ2hhbm5lbCgpIHtcblx0Y29uc3Qgc29ja2V0ID0gZ2V0RWxlY3Ryb25TZXJ2ZXJDb250ZXh0KCk7XG5cdHJldHVybiB7XG5cdFx0cG9zdDogKGRhdGEpID0+IHtcblx0XHRcdHNvY2tldC5lbWl0KF9fREVWVE9PTFNfS0lUX0VMRUNUUk9OX01FU1NBR0lOR19FVkVOVF9LRVlfXy5TRVJWRVJfVE9fUFJPWFksIFN1cGVySlNPTi5zdHJpbmdpZnkoZGF0YSkpO1xuXHRcdH0sXG5cdFx0b246IChoYW5kbGVyKSA9PiB7XG5cdFx0XHRzb2NrZXQub24oX19ERVZUT09MU19LSVRfRUxFQ1RST05fTUVTU0FHSU5HX0VWRU5UX0tFWV9fLlBST1hZX1RPX1NFUlZFUiwgKGRhdGEpID0+IHtcblx0XHRcdFx0aGFuZGxlcihTdXBlckpTT04ucGFyc2UoZGF0YSkpO1xuXHRcdFx0fSk7XG5cdFx0fVxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL21lc3NhZ2luZy9wcmVzZXRzL2V4dGVuc2lvbi9jb250ZXh0LnRzXG5jb25zdCBfX0VYVEVOU0lPTl9DTElFTlRfQ09OVEVYVF9fID0gXCJlbGVjdHJvbjpjbGllbnQtY29udGV4dFwiO1xuY29uc3QgX19ERVZUT09MU19LSVRfRVhURU5TSU9OX01FU1NBR0lOR19FVkVOVF9LRVlfXyA9IHtcblx0Q0xJRU5UX1RPX1BST1hZOiBcImNsaWVudC0+cHJveHlcIixcblx0UFJPWFlfVE9fQ0xJRU5UOiBcInByb3h5LT5jbGllbnRcIixcblx0UFJPWFlfVE9fU0VSVkVSOiBcInByb3h5LT5zZXJ2ZXJcIixcblx0U0VSVkVSX1RPX1BST1hZOiBcInNlcnZlci0+cHJveHlcIlxufTtcbmZ1bmN0aW9uIGdldEV4dGVuc2lvbkNsaWVudENvbnRleHQoKSB7XG5cdHJldHVybiB0YXJnZXRbX19FWFRFTlNJT05fQ0xJRU5UX0NPTlRFWFRfX107XG59XG5mdW5jdGlvbiBzZXRFeHRlbnNpb25DbGllbnRDb250ZXh0KGNvbnRleHQpIHtcblx0dGFyZ2V0W19fRVhURU5TSU9OX0NMSUVOVF9DT05URVhUX19dID0gY29udGV4dDtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tZXNzYWdpbmcvcHJlc2V0cy9leHRlbnNpb24vY2xpZW50LnRzXG5mdW5jdGlvbiBjcmVhdGVFeHRlbnNpb25DbGllbnRDaGFubmVsKCkge1xuXHRsZXQgZGlzY29ubmVjdGVkID0gZmFsc2U7XG5cdGxldCBwb3J0ID0gbnVsbDtcblx0bGV0IHJlY29ubmVjdFRpbWVyID0gbnVsbDtcblx0bGV0IG9uTWVzc2FnZUhhbmRsZXIgPSBudWxsO1xuXHRmdW5jdGlvbiBjb25uZWN0KCkge1xuXHRcdHRyeSB7XG5cdFx0XHRjbGVhclRpbWVvdXQocmVjb25uZWN0VGltZXIpO1xuXHRcdFx0cG9ydCA9IGNocm9tZS5ydW50aW1lLmNvbm5lY3QoeyBuYW1lOiBgJHtjaHJvbWUuZGV2dG9vbHMuaW5zcGVjdGVkV2luZG93LnRhYklkfWAgfSk7XG5cdFx0XHRzZXRFeHRlbnNpb25DbGllbnRDb250ZXh0KHBvcnQpO1xuXHRcdFx0ZGlzY29ubmVjdGVkID0gZmFsc2U7XG5cdFx0XHRwb3J0Py5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIob25NZXNzYWdlSGFuZGxlcik7XG5cdFx0XHRwb3J0Lm9uRGlzY29ubmVjdC5hZGRMaXN0ZW5lcigoKSA9PiB7XG5cdFx0XHRcdGRpc2Nvbm5lY3RlZCA9IHRydWU7XG5cdFx0XHRcdHBvcnQ/Lm9uTWVzc2FnZS5yZW1vdmVMaXN0ZW5lcihvbk1lc3NhZ2VIYW5kbGVyKTtcblx0XHRcdFx0cmVjb25uZWN0VGltZXIgPSBzZXRUaW1lb3V0KGNvbm5lY3QsIDFlMyk7XG5cdFx0XHR9KTtcblx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRkaXNjb25uZWN0ZWQgPSB0cnVlO1xuXHRcdH1cblx0fVxuXHRjb25uZWN0KCk7XG5cdHJldHVybiB7XG5cdFx0cG9zdDogKGRhdGEpID0+IHtcblx0XHRcdGlmIChkaXNjb25uZWN0ZWQpIHJldHVybjtcblx0XHRcdHBvcnQ/LnBvc3RNZXNzYWdlKFN1cGVySlNPTi5zdHJpbmdpZnkoZGF0YSkpO1xuXHRcdH0sXG5cdFx0b246IChoYW5kbGVyKSA9PiB7XG5cdFx0XHRvbk1lc3NhZ2VIYW5kbGVyID0gKGRhdGEpID0+IHtcblx0XHRcdFx0aWYgKGRpc2Nvbm5lY3RlZCkgcmV0dXJuO1xuXHRcdFx0XHRoYW5kbGVyKFN1cGVySlNPTi5wYXJzZShkYXRhKSk7XG5cdFx0XHR9O1xuXHRcdFx0cG9ydD8ub25NZXNzYWdlLmFkZExpc3RlbmVyKG9uTWVzc2FnZUhhbmRsZXIpO1xuXHRcdH1cblx0fTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tZXNzYWdpbmcvcHJlc2V0cy9leHRlbnNpb24vcHJveHkudHNcbmZ1bmN0aW9uIGNyZWF0ZUV4dGVuc2lvblByb3h5Q2hhbm5lbCgpIHtcblx0Y29uc3QgcG9ydCA9IGNocm9tZS5ydW50aW1lLmNvbm5lY3QoeyBuYW1lOiBcImNvbnRlbnQtc2NyaXB0XCIgfSk7XG5cdGZ1bmN0aW9uIHNlbmRNZXNzYWdlVG9Vc2VyQXBwKHBheWxvYWQpIHtcblx0XHR3aW5kb3cucG9zdE1lc3NhZ2Uoe1xuXHRcdFx0c291cmNlOiBfX0RFVlRPT0xTX0tJVF9FWFRFTlNJT05fTUVTU0FHSU5HX0VWRU5UX0tFWV9fLlBST1hZX1RPX1NFUlZFUixcblx0XHRcdHBheWxvYWRcblx0XHR9LCBcIipcIik7XG5cdH1cblx0ZnVuY3Rpb24gc2VuZE1lc3NhZ2VUb0RldlRvb2xzQ2xpZW50KGUpIHtcblx0XHRpZiAoZS5kYXRhICYmIGUuZGF0YS5zb3VyY2UgPT09IF9fREVWVE9PTFNfS0lUX0VYVEVOU0lPTl9NRVNTQUdJTkdfRVZFTlRfS0VZX18uU0VSVkVSX1RPX1BST1hZKSB0cnkge1xuXHRcdFx0cG9ydC5wb3N0TWVzc2FnZShlLmRhdGEucGF5bG9hZCk7XG5cdFx0fSBjYXRjaCAoZSkge31cblx0fVxuXHRwb3J0Lm9uTWVzc2FnZS5hZGRMaXN0ZW5lcihzZW5kTWVzc2FnZVRvVXNlckFwcCk7XG5cdHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwibWVzc2FnZVwiLCBzZW5kTWVzc2FnZVRvRGV2VG9vbHNDbGllbnQpO1xuXHRwb3J0Lm9uRGlzY29ubmVjdC5hZGRMaXN0ZW5lcigoKSA9PiB7XG5cdFx0d2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJtZXNzYWdlXCIsIHNlbmRNZXNzYWdlVG9EZXZUb29sc0NsaWVudCk7XG5cdFx0c2VuZE1lc3NhZ2VUb1VzZXJBcHAoU3VwZXJKU09OLnN0cmluZ2lmeSh7IGV2ZW50OiBcInNodXRkb3duXCIgfSkpO1xuXHR9KTtcblx0c2VuZE1lc3NhZ2VUb1VzZXJBcHAoU3VwZXJKU09OLnN0cmluZ2lmeSh7IGV2ZW50OiBcImluaXRcIiB9KSk7XG5cdHJldHVybiB7XG5cdFx0cG9zdDogKGRhdGEpID0+IHt9LFxuXHRcdG9uOiAoaGFuZGxlcikgPT4ge31cblx0fTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tZXNzYWdpbmcvcHJlc2V0cy9leHRlbnNpb24vc2VydmVyLnRzXG5mdW5jdGlvbiBjcmVhdGVFeHRlbnNpb25TZXJ2ZXJDaGFubmVsKCkge1xuXHRyZXR1cm4ge1xuXHRcdHBvc3Q6IChkYXRhKSA9PiB7XG5cdFx0XHR3aW5kb3cucG9zdE1lc3NhZ2Uoe1xuXHRcdFx0XHRzb3VyY2U6IF9fREVWVE9PTFNfS0lUX0VYVEVOU0lPTl9NRVNTQUdJTkdfRVZFTlRfS0VZX18uU0VSVkVSX1RPX1BST1hZLFxuXHRcdFx0XHRwYXlsb2FkOiBTdXBlckpTT04uc3RyaW5naWZ5KGRhdGEpXG5cdFx0XHR9LCBcIipcIik7XG5cdFx0fSxcblx0XHRvbjogKGhhbmRsZXIpID0+IHtcblx0XHRcdGNvbnN0IGxpc3RlbmVyID0gKGV2ZW50KSA9PiB7XG5cdFx0XHRcdGlmIChldmVudC5kYXRhLnNvdXJjZSA9PT0gX19ERVZUT09MU19LSVRfRVhURU5TSU9OX01FU1NBR0lOR19FVkVOVF9LRVlfXy5QUk9YWV9UT19TRVJWRVIgJiYgZXZlbnQuZGF0YS5wYXlsb2FkKSBoYW5kbGVyKFN1cGVySlNPTi5wYXJzZShldmVudC5kYXRhLnBheWxvYWQpKTtcblx0XHRcdH07XG5cdFx0XHR3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcIm1lc3NhZ2VcIiwgbGlzdGVuZXIpO1xuXHRcdFx0cmV0dXJuICgpID0+IHtcblx0XHRcdFx0d2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJtZXNzYWdlXCIsIGxpc3RlbmVyKTtcblx0XHRcdH07XG5cdFx0fVxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL21lc3NhZ2luZy9wcmVzZXRzL2lmcmFtZS9jb250ZXh0LnRzXG5jb25zdCBfX0RFVlRPT0xTX0tJVF9JRlJBTUVfTUVTU0FHSU5HX0VWRU5UX0tFWSA9IFwiX19kZXZ0b29scy1raXQtaWZyYW1lLW1lc3NhZ2luZy1ldmVudC1rZXlfX1wiO1xuY29uc3QgX19JRlJBTUVfU0VSVkVSX0NPTlRFWFRfXyA9IFwiaWZyYW1lOnNlcnZlci1jb250ZXh0XCI7XG5mdW5jdGlvbiBnZXRJZnJhbWVTZXJ2ZXJDb250ZXh0KCkge1xuXHRyZXR1cm4gdGFyZ2V0W19fSUZSQU1FX1NFUlZFUl9DT05URVhUX19dO1xufVxuZnVuY3Rpb24gc2V0SWZyYW1lU2VydmVyQ29udGV4dChjb250ZXh0KSB7XG5cdHRhcmdldFtfX0lGUkFNRV9TRVJWRVJfQ09OVEVYVF9fXSA9IGNvbnRleHQ7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbWVzc2FnaW5nL3ByZXNldHMvaWZyYW1lL2NsaWVudC50c1xuZnVuY3Rpb24gY3JlYXRlSWZyYW1lQ2xpZW50Q2hhbm5lbCgpIHtcblx0aWYgKCFpc0Jyb3dzZXIpIHJldHVybiB7XG5cdFx0cG9zdDogKGRhdGEpID0+IHt9LFxuXHRcdG9uOiAoaGFuZGxlcikgPT4ge31cblx0fTtcblx0cmV0dXJuIHtcblx0XHRwb3N0OiAoZGF0YSkgPT4gd2luZG93LnBhcmVudC5wb3N0TWVzc2FnZShTdXBlckpTT04uc3RyaW5naWZ5KHtcblx0XHRcdGV2ZW50OiBfX0RFVlRPT0xTX0tJVF9JRlJBTUVfTUVTU0FHSU5HX0VWRU5UX0tFWSxcblx0XHRcdGRhdGFcblx0XHR9KSwgXCIqXCIpLFxuXHRcdG9uOiAoaGFuZGxlcikgPT4gd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJtZXNzYWdlXCIsIChldmVudCkgPT4ge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0Y29uc3QgcGFyc2VkID0gU3VwZXJKU09OLnBhcnNlKGV2ZW50LmRhdGEpO1xuXHRcdFx0XHRpZiAoZXZlbnQuc291cmNlID09PSB3aW5kb3cucGFyZW50ICYmIHBhcnNlZC5ldmVudCA9PT0gXCJfX2RldnRvb2xzLWtpdC1pZnJhbWUtbWVzc2FnaW5nLWV2ZW50LWtleV9fXCIpIGhhbmRsZXIocGFyc2VkLmRhdGEpO1xuXHRcdFx0fSBjYXRjaCAoZSkge31cblx0XHR9KVxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL21lc3NhZ2luZy9wcmVzZXRzL2lmcmFtZS9zZXJ2ZXIudHNcbmZ1bmN0aW9uIGNyZWF0ZUlmcmFtZVNlcnZlckNoYW5uZWwoKSB7XG5cdGlmICghaXNCcm93c2VyKSByZXR1cm4ge1xuXHRcdHBvc3Q6IChkYXRhKSA9PiB7fSxcblx0XHRvbjogKGhhbmRsZXIpID0+IHt9XG5cdH07XG5cdHJldHVybiB7XG5cdFx0cG9zdDogKGRhdGEpID0+IHtcblx0XHRcdGdldElmcmFtZVNlcnZlckNvbnRleHQoKT8uY29udGVudFdpbmRvdz8ucG9zdE1lc3NhZ2UoU3VwZXJKU09OLnN0cmluZ2lmeSh7XG5cdFx0XHRcdGV2ZW50OiBfX0RFVlRPT0xTX0tJVF9JRlJBTUVfTUVTU0FHSU5HX0VWRU5UX0tFWSxcblx0XHRcdFx0ZGF0YVxuXHRcdFx0fSksIFwiKlwiKTtcblx0XHR9LFxuXHRcdG9uOiAoaGFuZGxlcikgPT4ge1xuXHRcdFx0d2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJtZXNzYWdlXCIsIChldmVudCkgPT4ge1xuXHRcdFx0XHRjb25zdCBpZnJhbWUgPSBnZXRJZnJhbWVTZXJ2ZXJDb250ZXh0KCk7XG5cdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0Y29uc3QgcGFyc2VkID0gU3VwZXJKU09OLnBhcnNlKGV2ZW50LmRhdGEpO1xuXHRcdFx0XHRcdGlmIChldmVudC5zb3VyY2UgPT09IGlmcmFtZT8uY29udGVudFdpbmRvdyAmJiBwYXJzZWQuZXZlbnQgPT09IFwiX19kZXZ0b29scy1raXQtaWZyYW1lLW1lc3NhZ2luZy1ldmVudC1rZXlfX1wiKSBoYW5kbGVyKHBhcnNlZC5kYXRhKTtcblx0XHRcdFx0fSBjYXRjaCAoZSkge31cblx0XHRcdH0pO1xuXHRcdH1cblx0fTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tZXNzYWdpbmcvcHJlc2V0cy92aXRlL2NvbnRleHQudHNcbmNvbnN0IF9fREVWVE9PTFNfS0lUX1ZJVEVfTUVTU0FHSU5HX0VWRU5UX0tFWSA9IFwiX19kZXZ0b29scy1raXQtdml0ZS1tZXNzYWdpbmctZXZlbnQta2V5X19cIjtcbmNvbnN0IF9fVklURV9DTElFTlRfQ09OVEVYVF9fID0gXCJ2aXRlOmNsaWVudC1jb250ZXh0XCI7XG5jb25zdCBfX1ZJVEVfU0VSVkVSX0NPTlRFWFRfXyA9IFwidml0ZTpzZXJ2ZXItY29udGV4dFwiO1xuZnVuY3Rpb24gZ2V0Vml0ZUNsaWVudENvbnRleHQoKSB7XG5cdHJldHVybiB0YXJnZXRbX19WSVRFX0NMSUVOVF9DT05URVhUX19dO1xufVxuZnVuY3Rpb24gc2V0Vml0ZUNsaWVudENvbnRleHQoY29udGV4dCkge1xuXHR0YXJnZXRbX19WSVRFX0NMSUVOVF9DT05URVhUX19dID0gY29udGV4dDtcbn1cbmZ1bmN0aW9uIGdldFZpdGVTZXJ2ZXJDb250ZXh0KCkge1xuXHRyZXR1cm4gdGFyZ2V0W19fVklURV9TRVJWRVJfQ09OVEVYVF9fXTtcbn1cbmZ1bmN0aW9uIHNldFZpdGVTZXJ2ZXJDb250ZXh0KGNvbnRleHQpIHtcblx0dGFyZ2V0W19fVklURV9TRVJWRVJfQ09OVEVYVF9fXSA9IGNvbnRleHQ7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbWVzc2FnaW5nL3ByZXNldHMvdml0ZS9jbGllbnQudHNcbmZ1bmN0aW9uIGNyZWF0ZVZpdGVDbGllbnRDaGFubmVsKCkge1xuXHRjb25zdCBjbGllbnQgPSBnZXRWaXRlQ2xpZW50Q29udGV4dCgpO1xuXHRyZXR1cm4ge1xuXHRcdHBvc3Q6IChkYXRhKSA9PiB7XG5cdFx0XHRjbGllbnQ/LnNlbmQoX19ERVZUT09MU19LSVRfVklURV9NRVNTQUdJTkdfRVZFTlRfS0VZLCBTdXBlckpTT04uc3RyaW5naWZ5KGRhdGEpKTtcblx0XHR9LFxuXHRcdG9uOiAoaGFuZGxlcikgPT4ge1xuXHRcdFx0Y2xpZW50Py5vbihfX0RFVlRPT0xTX0tJVF9WSVRFX01FU1NBR0lOR19FVkVOVF9LRVksIChldmVudCkgPT4ge1xuXHRcdFx0XHRoYW5kbGVyKFN1cGVySlNPTi5wYXJzZShldmVudCkpO1xuXHRcdFx0fSk7XG5cdFx0fVxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL21lc3NhZ2luZy9wcmVzZXRzL3ZpdGUvc2VydmVyLnRzXG5mdW5jdGlvbiBjcmVhdGVWaXRlU2VydmVyQ2hhbm5lbCgpIHtcblx0Y29uc3Qgdml0ZVNlcnZlciA9IGdldFZpdGVTZXJ2ZXJDb250ZXh0KCk7XG5cdGNvbnN0IHdzID0gdml0ZVNlcnZlci5ob3QgPz8gdml0ZVNlcnZlci53cztcblx0cmV0dXJuIHtcblx0XHRwb3N0OiAoZGF0YSkgPT4gd3M/LnNlbmQoX19ERVZUT09MU19LSVRfVklURV9NRVNTQUdJTkdfRVZFTlRfS0VZLCBTdXBlckpTT04uc3RyaW5naWZ5KGRhdGEpKSxcblx0XHRvbjogKGhhbmRsZXIpID0+IHdzPy5vbihfX0RFVlRPT0xTX0tJVF9WSVRFX01FU1NBR0lOR19FVkVOVF9LRVksIChldmVudCkgPT4ge1xuXHRcdFx0aGFuZGxlcihTdXBlckpTT04ucGFyc2UoZXZlbnQpKTtcblx0XHR9KVxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL21lc3NhZ2luZy9pbmRleC50c1xudGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9NRVNTQUdFX0NIQU5ORUxTX18gPz89IFtdO1xudGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9SUENfQ0xJRU5UX18gPz89IG51bGw7XG50YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX1JQQ19TRVJWRVJfXyA/Pz0gbnVsbDtcbnRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfVklURV9SUENfQ0xJRU5UX18gPz89IG51bGw7XG50YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX1ZJVEVfUlBDX1NFUlZFUl9fID8/PSBudWxsO1xudGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9CUk9BRENBU1RfUlBDX1NFUlZFUl9fID8/PSBudWxsO1xuZnVuY3Rpb24gc2V0UnBjQ2xpZW50VG9HbG9iYWwocnBjKSB7XG5cdHRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfUlBDX0NMSUVOVF9fID0gcnBjO1xufVxuZnVuY3Rpb24gc2V0UnBjU2VydmVyVG9HbG9iYWwocnBjKSB7XG5cdHRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfUlBDX1NFUlZFUl9fID0gcnBjO1xufVxuZnVuY3Rpb24gZ2V0UnBjQ2xpZW50KCkge1xuXHRyZXR1cm4gdGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9SUENfQ0xJRU5UX187XG59XG5mdW5jdGlvbiBnZXRScGNTZXJ2ZXIoKSB7XG5cdHJldHVybiB0YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX1JQQ19TRVJWRVJfXztcbn1cbmZ1bmN0aW9uIHNldFZpdGVScGNDbGllbnRUb0dsb2JhbChycGMpIHtcblx0dGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9WSVRFX1JQQ19DTElFTlRfXyA9IHJwYztcbn1cbmZ1bmN0aW9uIHNldFZpdGVScGNTZXJ2ZXJUb0dsb2JhbChycGMpIHtcblx0dGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9WSVRFX1JQQ19TRVJWRVJfXyA9IHJwYztcbn1cbmZ1bmN0aW9uIGdldFZpdGVScGNDbGllbnQoKSB7XG5cdHJldHVybiB0YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX1ZJVEVfUlBDX0NMSUVOVF9fO1xufVxuZnVuY3Rpb24gZ2V0Vml0ZVJwY1NlcnZlcigpIHtcblx0cmV0dXJuIHRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfVklURV9SUENfU0VSVkVSX187XG59XG5mdW5jdGlvbiBnZXRDaGFubmVsKHByZXNldCwgaG9zdCA9IFwiY2xpZW50XCIpIHtcblx0Y29uc3QgY2hhbm5lbCA9IHtcblx0XHRpZnJhbWU6IHtcblx0XHRcdGNsaWVudDogY3JlYXRlSWZyYW1lQ2xpZW50Q2hhbm5lbCxcblx0XHRcdHNlcnZlcjogY3JlYXRlSWZyYW1lU2VydmVyQ2hhbm5lbFxuXHRcdH1baG9zdF0sXG5cdFx0ZWxlY3Ryb246IHtcblx0XHRcdGNsaWVudDogY3JlYXRlRWxlY3Ryb25DbGllbnRDaGFubmVsLFxuXHRcdFx0cHJveHk6IGNyZWF0ZUVsZWN0cm9uUHJveHlDaGFubmVsLFxuXHRcdFx0c2VydmVyOiBjcmVhdGVFbGVjdHJvblNlcnZlckNoYW5uZWxcblx0XHR9W2hvc3RdLFxuXHRcdHZpdGU6IHtcblx0XHRcdGNsaWVudDogY3JlYXRlVml0ZUNsaWVudENoYW5uZWwsXG5cdFx0XHRzZXJ2ZXI6IGNyZWF0ZVZpdGVTZXJ2ZXJDaGFubmVsXG5cdFx0fVtob3N0XSxcblx0XHRicm9hZGNhc3Q6IHtcblx0XHRcdGNsaWVudDogY3JlYXRlQnJvYWRjYXN0Q2hhbm5lbCxcblx0XHRcdHNlcnZlcjogY3JlYXRlQnJvYWRjYXN0Q2hhbm5lbFxuXHRcdH1baG9zdF0sXG5cdFx0ZXh0ZW5zaW9uOiB7XG5cdFx0XHRjbGllbnQ6IGNyZWF0ZUV4dGVuc2lvbkNsaWVudENoYW5uZWwsXG5cdFx0XHRwcm94eTogY3JlYXRlRXh0ZW5zaW9uUHJveHlDaGFubmVsLFxuXHRcdFx0c2VydmVyOiBjcmVhdGVFeHRlbnNpb25TZXJ2ZXJDaGFubmVsXG5cdFx0fVtob3N0XVxuXHR9W3ByZXNldF07XG5cdHJldHVybiBjaGFubmVsKCk7XG59XG5mdW5jdGlvbiBjcmVhdGVScGNDbGllbnQoZnVuY3Rpb25zLCBvcHRpb25zID0ge30pIHtcblx0Y29uc3QgeyBjaGFubmVsOiBfY2hhbm5lbCwgb3B0aW9uczogX29wdGlvbnMsIHByZXNldCB9ID0gb3B0aW9ucztcblx0Y29uc3QgY2hhbm5lbCA9IHByZXNldCA/IGdldENoYW5uZWwocHJlc2V0KSA6IF9jaGFubmVsO1xuXHRjb25zdCBycGMgPSBjcmVhdGVCaXJwYyhmdW5jdGlvbnMsIHtcblx0XHQuLi5fb3B0aW9ucyxcblx0XHQuLi5jaGFubmVsLFxuXHRcdHRpbWVvdXQ6IC0xXG5cdH0pO1xuXHRpZiAocHJlc2V0ID09PSBcInZpdGVcIikge1xuXHRcdHNldFZpdGVScGNDbGllbnRUb0dsb2JhbChycGMpO1xuXHRcdHJldHVybjtcblx0fVxuXHRzZXRScGNDbGllbnRUb0dsb2JhbChycGMpO1xuXHRyZXR1cm4gcnBjO1xufVxuZnVuY3Rpb24gY3JlYXRlUnBjU2VydmVyKGZ1bmN0aW9ucywgb3B0aW9ucyA9IHt9KSB7XG5cdGNvbnN0IHsgY2hhbm5lbDogX2NoYW5uZWwsIG9wdGlvbnM6IF9vcHRpb25zLCBwcmVzZXQgfSA9IG9wdGlvbnM7XG5cdGNvbnN0IGNoYW5uZWwgPSBwcmVzZXQgPyBnZXRDaGFubmVsKHByZXNldCwgXCJzZXJ2ZXJcIikgOiBfY2hhbm5lbDtcblx0Y29uc3QgcnBjU2VydmVyID0gZ2V0UnBjU2VydmVyKCk7XG5cdGlmICghcnBjU2VydmVyKSB7XG5cdFx0Y29uc3QgZ3JvdXAgPSBjcmVhdGVCaXJwY0dyb3VwKGZ1bmN0aW9ucywgW2NoYW5uZWxdLCB7XG5cdFx0XHQuLi5fb3B0aW9ucyxcblx0XHRcdHRpbWVvdXQ6IC0xXG5cdFx0fSk7XG5cdFx0aWYgKHByZXNldCA9PT0gXCJ2aXRlXCIpIHtcblx0XHRcdHNldFZpdGVScGNTZXJ2ZXJUb0dsb2JhbChncm91cCk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdHNldFJwY1NlcnZlclRvR2xvYmFsKGdyb3VwKTtcblx0fSBlbHNlIHJwY1NlcnZlci51cGRhdGVDaGFubmVscygoY2hhbm5lbHMpID0+IHtcblx0XHRjaGFubmVscy5wdXNoKGNoYW5uZWwpO1xuXHR9KTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVJwY1Byb3h5KG9wdGlvbnMgPSB7fSkge1xuXHRjb25zdCB7IGNoYW5uZWw6IF9jaGFubmVsLCBvcHRpb25zOiBfb3B0aW9ucywgcHJlc2V0IH0gPSBvcHRpb25zO1xuXHRjb25zdCBjaGFubmVsID0gcHJlc2V0ID8gZ2V0Q2hhbm5lbChwcmVzZXQsIFwicHJveHlcIikgOiBfY2hhbm5lbDtcblx0cmV0dXJuIGNyZWF0ZUJpcnBjKHt9LCB7XG5cdFx0Li4uX29wdGlvbnMsXG5cdFx0Li4uY2hhbm5lbCxcblx0XHR0aW1lb3V0OiAtMVxuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL2NvbXBvbmVudC9zdGF0ZS9jdXN0b20udHNcbmZ1bmN0aW9uIGdldEZ1bmN0aW9uRGV0YWlscyhmdW5jKSB7XG5cdGxldCBzdHJpbmcgPSBcIlwiO1xuXHRsZXQgbWF0Y2hlcyA9IG51bGw7XG5cdHRyeSB7XG5cdFx0c3RyaW5nID0gRnVuY3Rpb24ucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwoZnVuYyk7XG5cdFx0bWF0Y2hlcyA9IFN0cmluZy5wcm90b3R5cGUubWF0Y2guY2FsbChzdHJpbmcsIC9cXChbXFxzXFxTXSo/XFwpLyk7XG5cdH0gY2F0Y2ggKGUpIHt9XG5cdGNvbnN0IG1hdGNoID0gbWF0Y2hlcyAmJiBtYXRjaGVzWzBdO1xuXHRjb25zdCBhcmdzID0gdHlwZW9mIG1hdGNoID09PSBcInN0cmluZ1wiID8gbWF0Y2ggOiBcIig/KVwiO1xuXHRyZXR1cm4geyBfY3VzdG9tOiB7XG5cdFx0dHlwZTogXCJmdW5jdGlvblwiLFxuXHRcdGRpc3BsYXlUZXh0OiBgPHNwYW4gc3R5bGU9XCJvcGFjaXR5Oi44O21hcmdpbi1yaWdodDo1cHg7XCI+ZnVuY3Rpb248L3NwYW4+IDxzcGFuIHN0eWxlPVwid2hpdGUtc3BhY2U6bm93cmFwO1wiPiR7ZXNjYXBlKHR5cGVvZiBmdW5jLm5hbWUgPT09IFwic3RyaW5nXCIgPyBmdW5jLm5hbWUgOiBcIlwiKX0ke2FyZ3N9PC9zcGFuPmAsXG5cdFx0dG9vbHRpcFRleHQ6IHN0cmluZy50cmltKCkgPyBgPHByZT4ke2VzY2FwZShzdHJpbmcpfTwvcHJlPmAgOiBudWxsXG5cdH0gfTtcbn1cbmZ1bmN0aW9uIGdldEJpZ0ludERldGFpbHModmFsKSB7XG5cdGNvbnN0IHN0cmluZ2lmaWVkQmlnSW50ID0gQmlnSW50LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKHZhbCk7XG5cdHJldHVybiB7IF9jdXN0b206IHtcblx0XHR0eXBlOiBcImJpZ2ludFwiLFxuXHRcdGRpc3BsYXlUZXh0OiBgQmlnSW50KCR7c3RyaW5naWZpZWRCaWdJbnR9KWAsXG5cdFx0dmFsdWU6IHN0cmluZ2lmaWVkQmlnSW50XG5cdH0gfTtcbn1cbmZ1bmN0aW9uIGdldERhdGVEZXRhaWxzKHZhbCkge1xuXHRjb25zdCBkYXRlID0gbmV3IERhdGUodmFsLmdldFRpbWUoKSk7XG5cdGRhdGUuc2V0TWludXRlcyhkYXRlLmdldE1pbnV0ZXMoKSAtIGRhdGUuZ2V0VGltZXpvbmVPZmZzZXQoKSk7XG5cdHJldHVybiB7IF9jdXN0b206IHtcblx0XHR0eXBlOiBcImRhdGVcIixcblx0XHRkaXNwbGF5VGV4dDogRGF0ZS5wcm90b3R5cGUudG9TdHJpbmcuY2FsbCh2YWwpLFxuXHRcdHZhbHVlOiBkYXRlLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwgLTEpXG5cdH0gfTtcbn1cbmZ1bmN0aW9uIGdldE1hcERldGFpbHModmFsKSB7XG5cdHJldHVybiB7IF9jdXN0b206IHtcblx0XHR0eXBlOiBcIm1hcFwiLFxuXHRcdGRpc3BsYXlUZXh0OiBcIk1hcFwiLFxuXHRcdHZhbHVlOiBPYmplY3QuZnJvbUVudHJpZXModmFsKSxcblx0XHRyZWFkT25seTogdHJ1ZSxcblx0XHRmaWVsZHM6IHsgYWJzdHJhY3Q6IHRydWUgfVxuXHR9IH07XG59XG5mdW5jdGlvbiBnZXRTZXREZXRhaWxzKHZhbCkge1xuXHRjb25zdCBsaXN0ID0gQXJyYXkuZnJvbSh2YWwpO1xuXHRyZXR1cm4geyBfY3VzdG9tOiB7XG5cdFx0dHlwZTogXCJzZXRcIixcblx0XHRkaXNwbGF5VGV4dDogYFNldFske2xpc3QubGVuZ3RofV1gLFxuXHRcdHZhbHVlOiBsaXN0LFxuXHRcdHJlYWRPbmx5OiB0cnVlXG5cdH0gfTtcbn1cbmZ1bmN0aW9uIGdldENhdWdodEdldHRlcnMoc3RvcmUpIHtcblx0Y29uc3QgZ2V0dGVycyA9IHt9O1xuXHRjb25zdCBvcmlnR2V0dGVycyA9IHN0b3JlLmdldHRlcnMgfHwge307XG5cdGNvbnN0IGtleXMgPSBPYmplY3Qua2V5cyhvcmlnR2V0dGVycyk7XG5cdGZvciAobGV0IGkgPSAwOyBpIDwga2V5cy5sZW5ndGg7IGkrKykge1xuXHRcdGNvbnN0IGtleSA9IGtleXNbaV07XG5cdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGdldHRlcnMsIGtleSwge1xuXHRcdFx0ZW51bWVyYWJsZTogdHJ1ZSxcblx0XHRcdGdldDogKCkgPT4ge1xuXHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdHJldHVybiBvcmlnR2V0dGVyc1trZXldO1xuXHRcdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdFx0cmV0dXJuIGU7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9KTtcblx0fVxuXHRyZXR1cm4gZ2V0dGVycztcbn1cbmZ1bmN0aW9uIHJlZHVjZVN0YXRlTGlzdChsaXN0KSB7XG5cdGlmICghbGlzdC5sZW5ndGgpIHJldHVybiB2b2lkIDA7XG5cdHJldHVybiBsaXN0LnJlZHVjZSgobWFwLCBpdGVtKSA9PiB7XG5cdFx0Y29uc3Qga2V5ID0gaXRlbS50eXBlIHx8IFwiZGF0YVwiO1xuXHRcdGNvbnN0IG9iaiA9IG1hcFtrZXldID0gbWFwW2tleV0gfHwge307XG5cdFx0b2JqW2l0ZW0ua2V5XSA9IGl0ZW0udmFsdWU7XG5cdFx0cmV0dXJuIG1hcDtcblx0fSwge30pO1xufVxuZnVuY3Rpb24gbmFtZWROb2RlTWFwVG9PYmplY3QobWFwKSB7XG5cdGNvbnN0IHJlc3VsdCA9IHt9O1xuXHRjb25zdCBsID0gbWFwLmxlbmd0aDtcblx0Zm9yIChsZXQgaSA9IDA7IGkgPCBsOyBpKyspIHtcblx0XHRjb25zdCBub2RlID0gbWFwLml0ZW0oaSk7XG5cdFx0cmVzdWx0W25vZGUubmFtZV0gPSBub2RlLnZhbHVlO1xuXHR9XG5cdHJldHVybiByZXN1bHQ7XG59XG5mdW5jdGlvbiBnZXRTdG9yZURldGFpbHMoc3RvcmUpIHtcblx0cmV0dXJuIHsgX2N1c3RvbToge1xuXHRcdHR5cGU6IFwic3RvcmVcIixcblx0XHRkaXNwbGF5VGV4dDogXCJTdG9yZVwiLFxuXHRcdHZhbHVlOiB7XG5cdFx0XHRzdGF0ZTogc3RvcmUuc3RhdGUsXG5cdFx0XHRnZXR0ZXJzOiBnZXRDYXVnaHRHZXR0ZXJzKHN0b3JlKVxuXHRcdH0sXG5cdFx0ZmllbGRzOiB7IGFic3RyYWN0OiB0cnVlIH1cblx0fSB9O1xufVxuZnVuY3Rpb24gZ2V0SW5zdGFuY2VEZXRhaWxzKGluc3RhbmNlKSB7XG5cdGlmIChpbnN0YW5jZS5fKSBpbnN0YW5jZSA9IGluc3RhbmNlLl87XG5cdGNvbnN0IHN0YXRlID0gcHJvY2Vzc0luc3RhbmNlU3RhdGUoaW5zdGFuY2UpO1xuXHRyZXR1cm4geyBfY3VzdG9tOiB7XG5cdFx0dHlwZTogXCJjb21wb25lbnRcIixcblx0XHRpZDogaW5zdGFuY2UuX19WVUVfREVWVE9PTFNfTkVYVF9VSURfXyxcblx0XHRkaXNwbGF5VGV4dDogZ2V0SW5zdGFuY2VOYW1lKGluc3RhbmNlKSxcblx0XHR0b29sdGlwVGV4dDogXCJDb21wb25lbnQgaW5zdGFuY2VcIixcblx0XHR2YWx1ZTogcmVkdWNlU3RhdGVMaXN0KHN0YXRlKSxcblx0XHRmaWVsZHM6IHsgYWJzdHJhY3Q6IHRydWUgfVxuXHR9IH07XG59XG5mdW5jdGlvbiBnZXRDb21wb25lbnREZWZpbml0aW9uRGV0YWlscyhkZWZpbml0aW9uKSB7XG5cdGxldCBkaXNwbGF5ID0gZ2V0Q29tcG9uZW50TmFtZShkZWZpbml0aW9uKTtcblx0aWYgKGRpc3BsYXkpIHtcblx0XHRpZiAoZGVmaW5pdGlvbi5uYW1lICYmIGRlZmluaXRpb24uX19maWxlKSBkaXNwbGF5ICs9IGAgPHNwYW4+KCR7ZGVmaW5pdGlvbi5fX2ZpbGV9KTwvc3Bhbj5gO1xuXHR9IGVsc2UgZGlzcGxheSA9IFwiPGk+VW5rbm93biBDb21wb25lbnQ8L2k+XCI7XG5cdHJldHVybiB7IF9jdXN0b206IHtcblx0XHR0eXBlOiBcImNvbXBvbmVudC1kZWZpbml0aW9uXCIsXG5cdFx0ZGlzcGxheVRleHQ6IGRpc3BsYXksXG5cdFx0dG9vbHRpcFRleHQ6IFwiQ29tcG9uZW50IGRlZmluaXRpb25cIixcblx0XHQuLi5kZWZpbml0aW9uLl9fZmlsZSA/IHsgZmlsZTogZGVmaW5pdGlvbi5fX2ZpbGUgfSA6IHt9XG5cdH0gfTtcbn1cbmZ1bmN0aW9uIGdldEhUTUxFbGVtZW50RGV0YWlscyh2YWx1ZSkge1xuXHR0cnkge1xuXHRcdHJldHVybiB7IF9jdXN0b206IHtcblx0XHRcdHR5cGU6IFwiSFRNTEVsZW1lbnRcIixcblx0XHRcdGRpc3BsYXlUZXh0OiBgPHNwYW4gY2xhc3M9XCJvcGFjaXR5LTMwXCI+Jmx0Ozwvc3Bhbj48c3BhbiBjbGFzcz1cInRleHQtYmx1ZS01MDBcIj4ke3ZhbHVlLnRhZ05hbWUudG9Mb3dlckNhc2UoKX08L3NwYW4+PHNwYW4gY2xhc3M9XCJvcGFjaXR5LTMwXCI+Jmd0Ozwvc3Bhbj5gLFxuXHRcdFx0dmFsdWU6IG5hbWVkTm9kZU1hcFRvT2JqZWN0KHZhbHVlLmF0dHJpYnV0ZXMpXG5cdFx0fSB9O1xuXHR9IGNhdGNoIChlKSB7XG5cdFx0cmV0dXJuIHsgX2N1c3RvbToge1xuXHRcdFx0dHlwZTogXCJIVE1MRWxlbWVudFwiLFxuXHRcdFx0ZGlzcGxheVRleHQ6IGA8c3BhbiBjbGFzcz1cInRleHQtYmx1ZS01MDBcIj4ke1N0cmluZyh2YWx1ZSl9PC9zcGFuPmBcblx0XHR9IH07XG5cdH1cbn1cbi8qKlxuKiAtIE9iamVjdFJlZkltcGwsIHRvUmVmKHsgZm9vOiAnZm9vJyB9LCAnZm9vJyksIGBfdmFsdWVgIGlzIHRoZSBhY3R1YWwgdmFsdWUsIChzaW5jZSAzLjUuMClcbiogLSBHZXR0ZXJSZWZJbXBsLCB0b1JlZigoKSA9PiBzdGF0ZS5mb28pLCBgX3ZhbHVlYCBpcyB0aGUgYWN0dWFsIHZhbHVlLCAoc2luY2UgMy41LjApXG4qIC0gUmVmSW1wbCwgcmVmKCdmb28nKSAvIGNvbXB1dGVkKCgpID0+ICdmb28nKSwgYF92YWx1ZWAgaXMgdGhlIGFjdHVhbCB2YWx1ZVxuKi9cbmZ1bmN0aW9uIHRyeUdldFJlZlZhbHVlKHJlZikge1xuXHRpZiAoZW5zdXJlUHJvcGVydHlFeGlzdHMocmVmLCBcIl92YWx1ZVwiLCB0cnVlKSkgcmV0dXJuIHJlZi5fdmFsdWU7XG5cdGlmIChlbnN1cmVQcm9wZXJ0eUV4aXN0cyhyZWYsIFwidmFsdWVcIiwgdHJ1ZSkpIHJldHVybiByZWYudmFsdWU7XG59XG5mdW5jdGlvbiBnZXRPYmplY3REZXRhaWxzKG9iamVjdCkge1xuXHRjb25zdCBpbmZvID0gZ2V0U2V0dXBTdGF0ZVR5cGUob2JqZWN0KTtcblx0aWYgKGluZm8ucmVmIHx8IGluZm8uY29tcHV0ZWQgfHwgaW5mby5yZWFjdGl2ZSkge1xuXHRcdGNvbnN0IHN0YXRlVHlwZU5hbWUgPSBpbmZvLmNvbXB1dGVkID8gXCJDb21wdXRlZFwiIDogaW5mby5yZWYgPyBcIlJlZlwiIDogaW5mby5yZWFjdGl2ZSA/IFwiUmVhY3RpdmVcIiA6IG51bGw7XG5cdFx0Y29uc3QgdmFsdWUgPSB0b1JhdyhpbmZvLnJlYWN0aXZlID8gb2JqZWN0IDogdHJ5R2V0UmVmVmFsdWUob2JqZWN0KSk7XG5cdFx0Y29uc3QgcmF3ID0gZW5zdXJlUHJvcGVydHlFeGlzdHMob2JqZWN0LCBcImVmZmVjdFwiKSA/IG9iamVjdC5lZmZlY3Q/LnJhdz8udG9TdHJpbmcoKSB8fCBvYmplY3QuZWZmZWN0Py5mbj8udG9TdHJpbmcoKSA6IG51bGw7XG5cdFx0cmV0dXJuIHsgX2N1c3RvbToge1xuXHRcdFx0dHlwZTogc3RhdGVUeXBlTmFtZT8udG9Mb3dlckNhc2UoKSxcblx0XHRcdHN0YXRlVHlwZU5hbWUsXG5cdFx0XHR2YWx1ZSxcblx0XHRcdC4uLnJhdyA/IHsgdG9vbHRpcFRleHQ6IGA8cHJlPiR7ZXNjYXBlKHJhdyl9PC9wcmU+YCB9IDoge31cblx0XHR9IH07XG5cdH1cblx0aWYgKGVuc3VyZVByb3BlcnR5RXhpc3RzKG9iamVjdCwgXCJfX2FzeW5jTG9hZGVyXCIpICYmIHR5cGVvZiBvYmplY3QuX19hc3luY0xvYWRlciA9PT0gXCJmdW5jdGlvblwiKSByZXR1cm4geyBfY3VzdG9tOiB7XG5cdFx0dHlwZTogXCJjb21wb25lbnQtZGVmaW5pdGlvblwiLFxuXHRcdGRpc3BsYXk6IFwiQXN5bmMgY29tcG9uZW50IGRlZmluaXRpb25cIlxuXHR9IH07XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9jb21wb25lbnQvc3RhdGUvcmVwbGFjZXIudHNcbmZ1bmN0aW9uIHN0cmluZ2lmeVJlcGxhY2VyKGtleSwgX3ZhbHVlLCBkZXB0aCwgc2Vlbkluc3RhbmNlKSB7XG5cdGlmIChrZXkgPT09IFwiY29tcGlsZXJPcHRpb25zXCIpIHJldHVybjtcblx0Y29uc3QgdmFsID0gdGhpc1trZXldO1xuXHRjb25zdCB0eXBlID0gdHlwZW9mIHZhbDtcblx0aWYgKEFycmF5LmlzQXJyYXkodmFsKSkge1xuXHRcdGNvbnN0IGwgPSB2YWwubGVuZ3RoO1xuXHRcdGlmIChsID4gNWUzKSByZXR1cm4ge1xuXHRcdFx0X2lzQXJyYXk6IHRydWUsXG5cdFx0XHRsZW5ndGg6IGwsXG5cdFx0XHRpdGVtczogdmFsLnNsaWNlKDAsIE1BWF9BUlJBWV9TSVpFKVxuXHRcdH07XG5cdFx0cmV0dXJuIHZhbDtcblx0fSBlbHNlIGlmICh0eXBlb2YgdmFsID09PSBcInN0cmluZ1wiKSBpZiAodmFsLmxlbmd0aCA+IDFlNCkgcmV0dXJuIGAke3ZhbC5zdWJzdHJpbmcoMCwgTUFYX1NUUklOR19TSVpFKX0uLi4gKCR7dmFsLmxlbmd0aH0gdG90YWwgbGVuZ3RoKWA7XG5cdGVsc2UgcmV0dXJuIHZhbDtcblx0ZWxzZSBpZiAodHlwZSA9PT0gXCJ1bmRlZmluZWRcIikgcmV0dXJuIFVOREVGSU5FRDtcblx0ZWxzZSBpZiAodmFsID09PSBOdW1iZXIuUE9TSVRJVkVfSU5GSU5JVFkpIHJldHVybiBJTkZJTklUWTtcblx0ZWxzZSBpZiAodmFsID09PSBOdW1iZXIuTkVHQVRJVkVfSU5GSU5JVFkpIHJldHVybiBORUdBVElWRV9JTkZJTklUWTtcblx0ZWxzZSBpZiAodHlwZW9mIHZhbCA9PT0gXCJmdW5jdGlvblwiKSByZXR1cm4gZ2V0RnVuY3Rpb25EZXRhaWxzKHZhbCk7XG5cdGVsc2UgaWYgKHR5cGUgPT09IFwic3ltYm9sXCIpIHJldHVybiBgW25hdGl2ZSBTeW1ib2wgJHtTeW1ib2wucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwodmFsKX1dYDtcblx0ZWxzZSBpZiAodHlwZW9mIHZhbCA9PT0gXCJiaWdpbnRcIikgcmV0dXJuIGdldEJpZ0ludERldGFpbHModmFsKTtcblx0ZWxzZSBpZiAodmFsICE9PSBudWxsICYmIHR5cGVvZiB2YWwgPT09IFwib2JqZWN0XCIpIHtcblx0XHRjb25zdCBwcm90byA9IE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbCh2YWwpO1xuXHRcdGlmIChwcm90byA9PT0gXCJbb2JqZWN0IE1hcF1cIikgcmV0dXJuIGdldE1hcERldGFpbHModmFsKTtcblx0XHRlbHNlIGlmIChwcm90byA9PT0gXCJbb2JqZWN0IFNldF1cIikgcmV0dXJuIGdldFNldERldGFpbHModmFsKTtcblx0XHRlbHNlIGlmIChwcm90byA9PT0gXCJbb2JqZWN0IFJlZ0V4cF1cIikgcmV0dXJuIGBbbmF0aXZlIFJlZ0V4cCAke1JlZ0V4cC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbCh2YWwpfV1gO1xuXHRcdGVsc2UgaWYgKHByb3RvID09PSBcIltvYmplY3QgRGF0ZV1cIikgcmV0dXJuIGdldERhdGVEZXRhaWxzKHZhbCk7XG5cdFx0ZWxzZSBpZiAocHJvdG8gPT09IFwiW29iamVjdCBFcnJvcl1cIikgcmV0dXJuIGBbbmF0aXZlIEVycm9yICR7dmFsLm1lc3NhZ2V9PD4ke3ZhbC5zdGFja31dYDtcblx0XHRlbHNlIGlmIChlbnN1cmVQcm9wZXJ0eUV4aXN0cyh2YWwsIFwic3RhdGVcIiwgdHJ1ZSkgJiYgZW5zdXJlUHJvcGVydHlFeGlzdHModmFsLCBcIl92bVwiLCB0cnVlKSkgcmV0dXJuIGdldFN0b3JlRGV0YWlscyh2YWwpO1xuXHRcdGVsc2UgaWYgKGlzVnVlSW5zdGFuY2UodmFsKSkge1xuXHRcdFx0Y29uc3QgY29tcG9uZW50VmFsID0gZ2V0SW5zdGFuY2VEZXRhaWxzKHZhbCk7XG5cdFx0XHRjb25zdCBwYXJlbnRJbnN0YW5jZURlcHRoID0gc2Vlbkluc3RhbmNlPy5nZXQodmFsKTtcblx0XHRcdGlmIChwYXJlbnRJbnN0YW5jZURlcHRoICYmIHBhcmVudEluc3RhbmNlRGVwdGggPCBkZXB0aCkgcmV0dXJuIGBbW0NpcmN1bGFyUmVmXV0gPCR7Y29tcG9uZW50VmFsLl9jdXN0b20uZGlzcGxheVRleHR9PmA7XG5cdFx0XHRzZWVuSW5zdGFuY2U/LnNldCh2YWwsIGRlcHRoKTtcblx0XHRcdHJldHVybiBjb21wb25lbnRWYWw7XG5cdFx0fSBlbHNlIGlmIChlbnN1cmVQcm9wZXJ0eUV4aXN0cyh2YWwsIFwicmVuZGVyXCIsIHRydWUpICYmIHR5cGVvZiB2YWwucmVuZGVyID09PSBcImZ1bmN0aW9uXCIpIHJldHVybiBnZXRDb21wb25lbnREZWZpbml0aW9uRGV0YWlscyh2YWwpO1xuXHRcdGVsc2UgaWYgKHZhbC5jb25zdHJ1Y3RvciAmJiB2YWwuY29uc3RydWN0b3IubmFtZSA9PT0gXCJWTm9kZVwiKSByZXR1cm4gYFtuYXRpdmUgVk5vZGUgPCR7dmFsLnRhZ30+XWA7XG5cdFx0ZWxzZSBpZiAodHlwZW9mIEhUTUxFbGVtZW50ICE9PSBcInVuZGVmaW5lZFwiICYmIHZhbCBpbnN0YW5jZW9mIEhUTUxFbGVtZW50KSByZXR1cm4gZ2V0SFRNTEVsZW1lbnREZXRhaWxzKHZhbCk7XG5cdFx0ZWxzZSBpZiAodmFsLmNvbnN0cnVjdG9yPy5uYW1lID09PSBcIlN0b3JlXCIgJiYgXCJfd3JhcHBlZEdldHRlcnNcIiBpbiB2YWwpIHJldHVybiBcIltvYmplY3QgU3RvcmVdXCI7XG5cdFx0Y29uc3QgY3VzdG9tRGV0YWlscyA9IGdldE9iamVjdERldGFpbHModmFsKTtcblx0XHRpZiAoY3VzdG9tRGV0YWlscyAhPSBudWxsKSByZXR1cm4gY3VzdG9tRGV0YWlscztcblx0fSBlbHNlIGlmIChOdW1iZXIuaXNOYU4odmFsKSkgcmV0dXJuIE5BTjtcblx0cmV0dXJuIHNhbml0aXplKHZhbCk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvc2hhcmVkL3RyYW5zZmVyLnRzXG5jb25zdCBNQVhfU0VSSUFMSVpFRF9TSVpFID0gMiAqIDEwMjQgKiAxMDI0O1xuZnVuY3Rpb24gaXNPYmplY3QoX2RhdGEsIHByb3RvKSB7XG5cdHJldHVybiBwcm90byA9PT0gXCJbb2JqZWN0IE9iamVjdF1cIjtcbn1cbmZ1bmN0aW9uIGlzQXJyYXkoX2RhdGEsIHByb3RvKSB7XG5cdHJldHVybiBwcm90byA9PT0gXCJbb2JqZWN0IEFycmF5XVwiO1xufVxuZnVuY3Rpb24gaXNWdWVSZWFjdGl2ZUxpbmtOb2RlKG5vZGUpIHtcblx0Y29uc3QgY29uc3RydWN0b3JOYW1lID0gbm9kZT8uY29uc3RydWN0b3I/Lm5hbWU7XG5cdHJldHVybiBjb25zdHJ1Y3Rvck5hbWUgPT09IFwiRGVwXCIgJiYgXCJhY3RpdmVMaW5rXCIgaW4gbm9kZSB8fCBjb25zdHJ1Y3Rvck5hbWUgPT09IFwiTGlua1wiICYmIFwiZGVwXCIgaW4gbm9kZTtcbn1cbi8qKlxuKiBUaGlzIGZ1bmN0aW9uIGlzIHVzZWQgdG8gc2VyaWFsaXplIG9iamVjdCB3aXRoIGhhbmRsaW5nIGNpcmN1bGFyIHJlZmVyZW5jZXMuXG4qXG4qIGBgYHRzXG4qIGNvbnN0IG9iaiA9IHsgYTogMSwgYjogeyBjOiAyIH0sIGQ6IG9iaiB9XG4qIGNvbnN0IHJlc3VsdCA9IHN0cmluZ2lmeUNpcmN1bGFyQXV0b0NodW5rcyhvYmopIC8vIGNhbGwgYGVuY29kZWAgaW5zaWRlXG4qIGNvbnNvbGUubG9nKHJlc3VsdCkgLy8gW3tcImFcIjoxLFwiYlwiOjIsXCJkXCI6MH0sMSx7XCJjXCI6NH0sMl1cbiogYGBgXG4qXG4qIEVhY2ggb2JqZWN0IGlzIHN0b3JlZCBpbiBhIGxpc3QgYW5kIHRoZSBpbmRleCBpcyB1c2VkIHRvIHJlZmVyZW5jZSB0aGUgb2JqZWN0LlxuKiBXaXRoIHNlZW4gbWFwLCB3ZSBjYW4gY2hlY2sgaWYgdGhlIG9iamVjdCBpcyBhbHJlYWR5IHN0b3JlZCBpbiB0aGUgbGlzdCB0byBhdm9pZCBjaXJjdWxhciByZWZlcmVuY2VzLlxuKlxuKiBOb3RlOiBoZXJlIHdlIGhhdmUgYSBzcGVjaWFsIGNhc2UgZm9yIFZ1ZSBpbnN0YW5jZS5cbiogV2UgY2hlY2sgaWYgYSB2dWUgaW5zdGFuY2UgaW5jbHVkZXMgaXRzZWxmIGluIGl0cyBwcm9wZXJ0aWVzIGFuZCBza2lwIGl0XG4qIGJ5IHVzaW5nIGBzZWVuVnVlSW5zdGFuY2VgIGFuZCBgZGVwdGhgIHRvIGF2b2lkIGluZmluaXRlIGxvb3AuXG4qL1xuZnVuY3Rpb24gZW5jb2RlKGRhdGEsIHJlcGxhY2VyLCBsaXN0LCBzZWVuLCBkZXB0aCA9IDAsIHNlZW5WdWVJbnN0YW5jZSA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCkpIHtcblx0bGV0IHN0b3JlZDtcblx0bGV0IGtleTtcblx0bGV0IHZhbHVlO1xuXHRsZXQgaTtcblx0bGV0IGw7XG5cdGNvbnN0IHNlZW5JbmRleCA9IHNlZW4uZ2V0KGRhdGEpO1xuXHRpZiAoc2VlbkluZGV4ICE9IG51bGwpIHJldHVybiBzZWVuSW5kZXg7XG5cdGNvbnN0IGluZGV4ID0gbGlzdC5sZW5ndGg7XG5cdGNvbnN0IHByb3RvID0gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKGRhdGEpO1xuXHRpZiAoaXNPYmplY3QoZGF0YSwgcHJvdG8pKSB7XG5cdFx0aWYgKGlzVnVlUmVhY3RpdmVMaW5rTm9kZShkYXRhKSkgcmV0dXJuIGluZGV4O1xuXHRcdHN0b3JlZCA9IHt9O1xuXHRcdHNlZW4uc2V0KGRhdGEsIGluZGV4KTtcblx0XHRsaXN0LnB1c2goc3RvcmVkKTtcblx0XHRjb25zdCBrZXlzID0gT2JqZWN0LmtleXMoZGF0YSk7XG5cdFx0Zm9yIChpID0gMCwgbCA9IGtleXMubGVuZ3RoOyBpIDwgbDsgaSsrKSB7XG5cdFx0XHRrZXkgPSBrZXlzW2ldO1xuXHRcdFx0aWYgKGtleSA9PT0gXCJjb21waWxlck9wdGlvbnNcIikgcmV0dXJuIGluZGV4O1xuXHRcdFx0dmFsdWUgPSBkYXRhW2tleV07XG5cdFx0XHRjb25zdCBpc1ZtID0gdmFsdWUgIT0gbnVsbCAmJiBpc09iamVjdCh2YWx1ZSwgT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKGRhdGEpKSAmJiBpc1Z1ZUluc3RhbmNlKHZhbHVlKTtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdGlmIChyZXBsYWNlcikgdmFsdWUgPSByZXBsYWNlci5jYWxsKGRhdGEsIGtleSwgdmFsdWUsIGRlcHRoLCBzZWVuVnVlSW5zdGFuY2UpO1xuXHRcdFx0fSBjYXRjaCAoZSkge1xuXHRcdFx0XHR2YWx1ZSA9IGU7XG5cdFx0XHR9XG5cdFx0XHRzdG9yZWRba2V5XSA9IGVuY29kZSh2YWx1ZSwgcmVwbGFjZXIsIGxpc3QsIHNlZW4sIGRlcHRoICsgMSwgc2VlblZ1ZUluc3RhbmNlKTtcblx0XHRcdGlmIChpc1ZtKSBzZWVuVnVlSW5zdGFuY2UuZGVsZXRlKHZhbHVlKTtcblx0XHR9XG5cdH0gZWxzZSBpZiAoaXNBcnJheShkYXRhLCBwcm90bykpIHtcblx0XHRzdG9yZWQgPSBbXTtcblx0XHRzZWVuLnNldChkYXRhLCBpbmRleCk7XG5cdFx0bGlzdC5wdXNoKHN0b3JlZCk7XG5cdFx0Zm9yIChpID0gMCwgbCA9IGRhdGEubGVuZ3RoOyBpIDwgbDsgaSsrKSB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHR2YWx1ZSA9IGRhdGFbaV07XG5cdFx0XHRcdGlmIChyZXBsYWNlcikgdmFsdWUgPSByZXBsYWNlci5jYWxsKGRhdGEsIGksIHZhbHVlLCBkZXB0aCwgc2VlblZ1ZUluc3RhbmNlKTtcblx0XHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdFx0dmFsdWUgPSBlO1xuXHRcdFx0fVxuXHRcdFx0c3RvcmVkW2ldID0gZW5jb2RlKHZhbHVlLCByZXBsYWNlciwgbGlzdCwgc2VlbiwgZGVwdGggKyAxLCBzZWVuVnVlSW5zdGFuY2UpO1xuXHRcdH1cblx0fSBlbHNlIGxpc3QucHVzaChkYXRhKTtcblx0cmV0dXJuIGluZGV4O1xufVxuZnVuY3Rpb24gZGVjb2RlKGxpc3QsIHJldml2ZXIgPSBudWxsKSB7XG5cdGxldCBpID0gbGlzdC5sZW5ndGg7XG5cdGxldCBqLCBrLCBkYXRhLCBrZXksIHZhbHVlLCBwcm90bztcblx0d2hpbGUgKGktLSkge1xuXHRcdGRhdGEgPSBsaXN0W2ldO1xuXHRcdHByb3RvID0gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKGRhdGEpO1xuXHRcdGlmIChwcm90byA9PT0gXCJbb2JqZWN0IE9iamVjdF1cIikge1xuXHRcdFx0Y29uc3Qga2V5cyA9IE9iamVjdC5rZXlzKGRhdGEpO1xuXHRcdFx0Zm9yIChqID0gMCwgayA9IGtleXMubGVuZ3RoOyBqIDwgazsgaisrKSB7XG5cdFx0XHRcdGtleSA9IGtleXNbal07XG5cdFx0XHRcdHZhbHVlID0gbGlzdFtkYXRhW2tleV1dO1xuXHRcdFx0XHRpZiAocmV2aXZlcikgdmFsdWUgPSByZXZpdmVyLmNhbGwoZGF0YSwga2V5LCB2YWx1ZSk7XG5cdFx0XHRcdGRhdGFba2V5XSA9IHZhbHVlO1xuXHRcdFx0fVxuXHRcdH0gZWxzZSBpZiAocHJvdG8gPT09IFwiW29iamVjdCBBcnJheV1cIikgZm9yIChqID0gMCwgayA9IGRhdGEubGVuZ3RoOyBqIDwgazsgaisrKSB7XG5cdFx0XHR2YWx1ZSA9IGxpc3RbZGF0YVtqXV07XG5cdFx0XHRpZiAocmV2aXZlcikgdmFsdWUgPSByZXZpdmVyLmNhbGwoZGF0YSwgaiwgdmFsdWUpO1xuXHRcdFx0ZGF0YVtqXSA9IHZhbHVlO1xuXHRcdH1cblx0fVxufVxuZnVuY3Rpb24gc3RyaW5naWZ5Q2lyY3VsYXJBdXRvQ2h1bmtzKGRhdGEsIHJlcGxhY2VyID0gbnVsbCwgc3BhY2UgPSBudWxsKSB7XG5cdGxldCByZXN1bHQ7XG5cdHRyeSB7XG5cdFx0cmVzdWx0ID0gYXJndW1lbnRzLmxlbmd0aCA9PT0gMSA/IEpTT04uc3RyaW5naWZ5KGRhdGEpIDogSlNPTi5zdHJpbmdpZnkoZGF0YSwgKGssIHYpID0+IHJlcGxhY2VyPy4oaywgdik/LmNhbGwodGhpcyksIHNwYWNlKTtcblx0fSBjYXRjaCAoZSkge1xuXHRcdHJlc3VsdCA9IHN0cmluZ2lmeVN0cmljdENpcmN1bGFyQXV0b0NodW5rcyhkYXRhLCByZXBsYWNlciwgc3BhY2UpO1xuXHR9XG5cdGlmIChyZXN1bHQubGVuZ3RoID4gTUFYX1NFUklBTElaRURfU0laRSkge1xuXHRcdGNvbnN0IGNodW5rQ291bnQgPSBNYXRoLmNlaWwocmVzdWx0Lmxlbmd0aCAvIE1BWF9TRVJJQUxJWkVEX1NJWkUpO1xuXHRcdGNvbnN0IGNodW5rcyA9IFtdO1xuXHRcdGZvciAobGV0IGkgPSAwOyBpIDwgY2h1bmtDb3VudDsgaSsrKSBjaHVua3MucHVzaChyZXN1bHQuc2xpY2UoaSAqIE1BWF9TRVJJQUxJWkVEX1NJWkUsIChpICsgMSkgKiBNQVhfU0VSSUFMSVpFRF9TSVpFKSk7XG5cdFx0cmV0dXJuIGNodW5rcztcblx0fVxuXHRyZXR1cm4gcmVzdWx0O1xufVxuZnVuY3Rpb24gc3RyaW5naWZ5U3RyaWN0Q2lyY3VsYXJBdXRvQ2h1bmtzKGRhdGEsIHJlcGxhY2VyID0gbnVsbCwgc3BhY2UgPSBudWxsKSB7XG5cdGNvbnN0IGxpc3QgPSBbXTtcblx0ZW5jb2RlKGRhdGEsIHJlcGxhY2VyLCBsaXN0LCAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpKTtcblx0cmV0dXJuIHNwYWNlID8gYCAke0pTT04uc3RyaW5naWZ5KGxpc3QsIG51bGwsIHNwYWNlKX1gIDogYCAke0pTT04uc3RyaW5naWZ5KGxpc3QpfWA7XG59XG5mdW5jdGlvbiBwYXJzZUNpcmN1bGFyQXV0b0NodW5rcyhkYXRhLCByZXZpdmVyID0gbnVsbCkge1xuXHRpZiAoQXJyYXkuaXNBcnJheShkYXRhKSkgZGF0YSA9IGRhdGEuam9pbihcIlwiKTtcblx0aWYgKCEvXlxccy8udGVzdChkYXRhKSkgcmV0dXJuIGFyZ3VtZW50cy5sZW5ndGggPT09IDEgPyBKU09OLnBhcnNlKGRhdGEpIDogSlNPTi5wYXJzZShkYXRhLCByZXZpdmVyKTtcblx0ZWxzZSB7XG5cdFx0Y29uc3QgbGlzdCA9IEpTT04ucGFyc2UoZGF0YSk7XG5cdFx0ZGVjb2RlKGxpc3QsIHJldml2ZXIpO1xuXHRcdHJldHVybiBsaXN0WzBdO1xuXHR9XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvc2hhcmVkL3V0aWwudHNcbmZ1bmN0aW9uIHN0cmluZ2lmeShkYXRhKSB7XG5cdHJldHVybiBzdHJpbmdpZnlDaXJjdWxhckF1dG9DaHVua3MoZGF0YSwgc3RyaW5naWZ5UmVwbGFjZXIpO1xufVxuZnVuY3Rpb24gcGFyc2UoZGF0YSwgcmV2aXZlID0gZmFsc2UpIHtcblx0aWYgKGRhdGEgPT0gdm9pZCAwKSByZXR1cm4ge307XG5cdHJldHVybiByZXZpdmUgPyBwYXJzZUNpcmN1bGFyQXV0b0NodW5rcyhkYXRhLCByZXZpdmVyKSA6IHBhcnNlQ2lyY3VsYXJBdXRvQ2h1bmtzKGRhdGEpO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2luZGV4LnRzXG5jb25zdCBkZXZ0b29scyA9IHtcblx0aG9vayxcblx0aW5pdDogKCkgPT4ge1xuXHRcdGluaXREZXZUb29scygpO1xuXHR9LFxuXHRnZXQgY3R4KCkge1xuXHRcdHJldHVybiBkZXZ0b29sc0NvbnRleHQ7XG5cdH0sXG5cdGdldCBhcGkoKSB7XG5cdFx0cmV0dXJuIGRldnRvb2xzQ29udGV4dC5hcGk7XG5cdH1cbn07XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IERldlRvb2xzQ29udGV4dEhvb2tLZXlzLCBEZXZUb29sc01lc3NhZ2luZ0hvb2tLZXlzLCBEZXZUb29sc1Y2UGx1Z2luQVBJSG9va0tleXMsIElORklOSVRZLCBOQU4sIE5FR0FUSVZFX0lORklOSVRZLCBST1VURVJfSU5GT19LRVksIFJPVVRFUl9LRVksIFVOREVGSU5FRCwgYWN0aXZlQXBwUmVjb3JkLCBhZGRDdXN0b21Db21tYW5kLCBhZGRDdXN0b21UYWIsIGFkZERldlRvb2xzQXBwUmVjb3JkLCBhZGREZXZUb29sc1BsdWdpblRvQnVmZmVyLCBhZGRJbnNwZWN0b3IsIGNhbGxDb25uZWN0ZWRVcGRhdGVkSG9vaywgY2FsbERldlRvb2xzUGx1Z2luU2V0dXBGbiwgY2FsbEluc3BlY3RvclVwZGF0ZWRIb29rLCBjYWxsU3RhdGVVcGRhdGVkSG9vaywgY3JlYXRlQ29tcG9uZW50c0RldlRvb2xzUGx1Z2luLCBjcmVhdGVEZXZUb29sc0FwaSwgY3JlYXRlRGV2VG9vbHNDdHhIb29rcywgY3JlYXRlUnBjQ2xpZW50LCBjcmVhdGVScGNQcm94eSwgY3JlYXRlUnBjU2VydmVyLCBkZXZ0b29scywgZGV2dG9vbHNBcHBSZWNvcmRzLCBkZXZ0b29sc0NvbnRleHQsIGRldnRvb2xzSW5zcGVjdG9yLCBkZXZ0b29sc1BsdWdpbkJ1ZmZlciwgZGV2dG9vbHNSb3V0ZXIsIGRldnRvb2xzUm91dGVySW5mbywgZGV2dG9vbHNTdGF0ZSwgZXNjYXBlLCBmb3JtYXRJbnNwZWN0b3JTdGF0ZVZhbHVlLCBnZXRBY3RpdmVJbnNwZWN0b3JzLCBnZXREZXZUb29sc0VudiwgZ2V0RXh0ZW5zaW9uQ2xpZW50Q29udGV4dCwgZ2V0SW5zcGVjdG9yLCBnZXRJbnNwZWN0b3JBY3Rpb25zLCBnZXRJbnNwZWN0b3JJbmZvLCBnZXRJbnNwZWN0b3JOb2RlQWN0aW9ucywgZ2V0SW5zcGVjdG9yU3RhdGVWYWx1ZVR5cGUsIGdldFJhdywgZ2V0UnBjQ2xpZW50LCBnZXRScGNTZXJ2ZXIsIGdldFZpdGVScGNDbGllbnQsIGdldFZpdGVScGNTZXJ2ZXIsIGluaXREZXZUb29scywgaXNQbGFpbk9iamVjdCwgb25EZXZUb29sc0NsaWVudENvbm5lY3RlZCwgb25EZXZUb29sc0Nvbm5lY3RlZCwgcGFyc2UsIHJlZ2lzdGVyRGV2VG9vbHNQbHVnaW4sIHJlbW92ZUN1c3RvbUNvbW1hbmQsIHJlbW92ZURldlRvb2xzQXBwUmVjb3JkLCByZW1vdmVSZWdpc3RlcmVkUGx1Z2luQXBwLCByZXNldERldlRvb2xzU3RhdGUsIHNldEFjdGl2ZUFwcFJlY29yZCwgc2V0QWN0aXZlQXBwUmVjb3JkSWQsIHNldERldlRvb2xzRW52LCBzZXRFbGVjdHJvbkNsaWVudENvbnRleHQsIHNldEVsZWN0cm9uUHJveHlDb250ZXh0LCBzZXRFbGVjdHJvblNlcnZlckNvbnRleHQsIHNldEV4dGVuc2lvbkNsaWVudENvbnRleHQsIHNldElmcmFtZVNlcnZlckNvbnRleHQsIHNldE9wZW5JbkVkaXRvckJhc2VVcmwsIHNldFJwY1NlcnZlclRvR2xvYmFsLCBzZXRWaXRlQ2xpZW50Q29udGV4dCwgc2V0Vml0ZVJwY0NsaWVudFRvR2xvYmFsLCBzZXRWaXRlUnBjU2VydmVyVG9HbG9iYWwsIHNldFZpdGVTZXJ2ZXJDb250ZXh0LCBzZXR1cERldlRvb2xzUGx1Z2luLCBzdHJpbmdpZnksIHRvRWRpdCwgdG9TdWJtaXQsIHRvZ2dsZUNsaWVudENvbm5lY3RlZCwgdG9nZ2xlQ29tcG9uZW50SW5zcGVjdG9yRW5hYmxlZCwgdG9nZ2xlSGlnaFBlcmZNb2RlLCB1cGRhdGVEZXZUb29sc0NsaWVudERldGVjdGVkLCB1cGRhdGVEZXZUb29sc1N0YXRlLCB1cGRhdGVUaW1lbGluZUxheWVyc1N0YXRlIH07XG4iLCIvKiFcbiogdnVlLXJvdXRlciB2NS4zLjFcbiogKGMpIDIwMjYgRWR1YXJkbyBTYW4gTWFydGluIE1vcm90ZVxuKiBAbGljZW5zZSBNSVRcbiovXG5pbXBvcnQgeyBfIGFzIGlzRVNNb2R1bGUsIGMgYXMgZGlhZ25vc3RpY3MsIGcgYXMgaXNBcnJheSwgaCBhcyBpc0Fic29sdXRlUGF0aCwgcCBhcyBhc3NpZ24sIHIgYXMgbWF0Y2hlZFJvdXRlS2V5LCB1IGFzIGNyZWF0ZVJvdXRlckVycm9yLCB2IGFzIGlzUm91dGVDb21wb25lbnQgfSBmcm9tIFwiLi91c2VBcGktQlB1STZaUjkuanNcIjtcbmltcG9ydCB7IGdldEN1cnJlbnRJbnN0YW5jZSwgaW5qZWN0LCBvbkFjdGl2YXRlZCwgb25EZWFjdGl2YXRlZCwgb25Vbm1vdW50ZWQsIHdhdGNoIH0gZnJvbSBcInZ1ZVwiO1xuaW1wb3J0IHsgc2V0dXBEZXZ0b29sc1BsdWdpbiB9IGZyb20gXCJAdnVlL2RldnRvb2xzLWFwaVwiO1xuLy8jcmVnaW9uIHNyYy91dGlscy9lbnYudHNcbmNvbnN0IGlzQnJvd3NlciA9IHR5cGVvZiBkb2N1bWVudCAhPT0gXCJ1bmRlZmluZWRcIjtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9lbmNvZGluZy50c1xuLyoqXG4qIEVuY29kaW5nIFJ1bGVzICjikKMgPSBTcGFjZSlcbiogLSBQYXRoOiDikKMgXCIgPCA+ICMgPyB7IH1cbiogLSBRdWVyeTog4pCjIFwiIDwgPiAjICYgPVxuKiAtIEhhc2g6IOKQoyBcIiA8ID4gYFxuKlxuKiBPbiB0b3Agb2YgdGhhdCwgdGhlIFJGQzM5ODYgKGh0dHBzOi8vdG9vbHMuaWV0Zi5vcmcvaHRtbC9yZmMzOTg2I3NlY3Rpb24tMi4yKVxuKiBkZWZpbmVzIHNvbWUgZXh0cmEgY2hhcmFjdGVycyB0byBiZSBlbmNvZGVkLiBNb3N0IGJyb3dzZXJzIGRvIG5vdCBlbmNvZGUgdGhlbVxuKiBpbiBlbmNvZGVVUkkgaHR0cHM6Ly9naXRodWIuY29tL3doYXR3Zy91cmwvaXNzdWVzLzM2OSwgc28gaXQgbWF5IGJlIHNhZmVyIHRvXG4qIGFsc28gZW5jb2RlIGAhJygpKmAuIExlYXZpbmcgdW4tZW5jb2RlZCBvbmx5IEFTQ0lJIGFscGhhbnVtZXJpYyhgYS16QS1aMC05YClcbiogcGx1cyBgLS5ffmAuIFRoaXMgZXh0cmEgc2FmZXR5IHNob3VsZCBiZSBhcHBsaWVkIHRvIHF1ZXJ5IGJ5IHBhdGNoaW5nIHRoZVxuKiBzdHJpbmcgcmV0dXJuZWQgYnkgZW5jb2RlVVJJQ29tcG9uZW50IGVuY29kZVVSSSBhbHNvIGVuY29kZXMgYFtcXF1eYC4gYFxcYFxuKiBzaG91bGQgYmUgZW5jb2RlZCB0byBhdm9pZCBhbWJpZ3VpdHkuIEJyb3dzZXJzIChJRSwgRkYsIEMpIHRyYW5zZm9ybSBhIGBcXGBcbiogaW50byBhIGAvYCBpZiBkaXJlY3RseSB0eXBlZCBpbi4gVGhlIF9iYWNrdGlja18gKGBgYGBgKSBzaG91bGQgYWxzbyBiZVxuKiBlbmNvZGVkIGV2ZXJ5d2hlcmUgYmVjYXVzZSBzb21lIGJyb3dzZXJzIGxpa2UgRkYgZW5jb2RlIGl0IHdoZW4gZGlyZWN0bHlcbiogd3JpdHRlbiB3aGlsZSBvdGhlcnMgZG9uJ3QuIFNhZmFyaSBhbmQgSUUgZG9uJ3QgZW5jb2RlIGBgXCI8Pnt9YGBgIGluIGhhc2guXG4qL1xuY29uc3QgSEFTSF9SRSA9IC8jL2c7XG5jb25zdCBBTVBFUlNBTkRfUkUgPSAvJi9nO1xuY29uc3QgU0xBU0hfUkUgPSAvXFwvL2c7XG5jb25zdCBFUVVBTF9SRSA9IC89L2c7XG5jb25zdCBJTV9SRSA9IC9cXD8vZztcbmNvbnN0IFBMVVNfUkUgPSAvXFwrL2c7XG4vKipcbiogTk9URTogSXQncyBub3QgY2xlYXIgdG8gbWUgaWYgd2Ugc2hvdWxkIGVuY29kZSB0aGUgKyBzeW1ib2wgaW4gcXVlcmllcywgaXRcbiogc2VlbXMgdG8gYmUgbGVzcyBmbGV4aWJsZSB0aGFuIG5vdCBkb2luZyBzbyBhbmQgSSBjYW4ndCBmaW5kIG91dCB0aGUgbGVnYWN5XG4qIHN5c3RlbXMgcmVxdWlyaW5nIHRoaXMgZm9yIHJlZ3VsYXIgcmVxdWVzdHMgbGlrZSB0ZXh0L2h0bWwuIEluIHRoZSBzdGFuZGFyZCxcbiogdGhlIGVuY29kaW5nIG9mIHRoZSBwbHVzIGNoYXJhY3RlciBpcyBvbmx5IG1lbnRpb25lZCBmb3JcbiogYXBwbGljYXRpb24veC13d3ctZm9ybS11cmxlbmNvZGVkXG4qIChodHRwczovL3VybC5zcGVjLndoYXR3Zy5vcmcvI3VybGVuY29kZWQtcGFyc2luZykgYW5kIG1vc3QgYnJvd3NlcnMgc2VlbXMgbG9cbiogbGVhdmUgdGhlIHBsdXMgY2hhcmFjdGVyIGFzIGlzIGluIHF1ZXJpZXMuIFRvIGJlIG1vcmUgZmxleGlibGUsIHdlIGFsbG93IHRoZVxuKiBwbHVzIGNoYXJhY3RlciBvbiB0aGUgcXVlcnksIGJ1dCBpdCBjYW4gYWxzbyBiZSBtYW51YWxseSBlbmNvZGVkIGJ5IHRoZSB1c2VyLlxuKlxuKiBSZXNvdXJjZXM6XG4qIC0gaHR0cHM6Ly91cmwuc3BlYy53aGF0d2cub3JnLyN1cmxlbmNvZGVkLXBhcnNpbmdcbiogLSBodHRwczovL3N0YWNrb3ZlcmZsb3cuY29tL3F1ZXN0aW9ucy8xNjM0MjcxL3VybC1lbmNvZGluZy10aGUtc3BhY2UtY2hhcmFjdGVyLW9yLTIwXG4qL1xuY29uc3QgRU5DX0JSQUNLRVRfT1BFTl9SRSA9IC8lNUIvZztcbmNvbnN0IEVOQ19CUkFDS0VUX0NMT1NFX1JFID0gLyU1RC9nO1xuY29uc3QgRU5DX0NBUkVUX1JFID0gLyU1RS9nO1xuY29uc3QgRU5DX0JBQ0tUSUNLX1JFID0gLyU2MC9nO1xuY29uc3QgRU5DX0NVUkxZX09QRU5fUkUgPSAvJTdCL2c7XG5jb25zdCBFTkNfUElQRV9SRSA9IC8lN0MvZztcbmNvbnN0IEVOQ19DVVJMWV9DTE9TRV9SRSA9IC8lN0QvZztcbmNvbnN0IEVOQ19TUEFDRV9SRSA9IC8lMjAvZztcbi8qKlxuKiBFbmNvZGUgY2hhcmFjdGVycyB0aGF0IG5lZWQgdG8gYmUgZW5jb2RlZCBvbiB0aGUgcGF0aCwgc2VhcmNoIGFuZCBoYXNoXG4qIHNlY3Rpb25zIG9mIHRoZSBVUkwuXG4qXG4qIEBpbnRlcm5hbFxuKiBAcGFyYW0gdGV4dCAtIHN0cmluZyB0byBlbmNvZGVcbiogQHJldHVybnMgZW5jb2RlZCBzdHJpbmdcbiovXG5mdW5jdGlvbiBjb21tb25FbmNvZGUodGV4dCkge1xuXHRyZXR1cm4gdGV4dCA9PSBudWxsID8gXCJcIiA6IGVuY29kZVVSSShcIlwiICsgdGV4dCkucmVwbGFjZShFTkNfUElQRV9SRSwgXCJ8XCIpLnJlcGxhY2UoRU5DX0JSQUNLRVRfT1BFTl9SRSwgXCJbXCIpLnJlcGxhY2UoRU5DX0JSQUNLRVRfQ0xPU0VfUkUsIFwiXVwiKTtcbn1cbi8qKlxuKiBFbmNvZGUgY2hhcmFjdGVycyB0aGF0IG5lZWQgdG8gYmUgZW5jb2RlZCBvbiB0aGUgaGFzaCBzZWN0aW9uIG9mIHRoZSBVUkwuXG4qXG4qIEBwYXJhbSB0ZXh0IC0gc3RyaW5nIHRvIGVuY29kZVxuKiBAcmV0dXJucyBlbmNvZGVkIHN0cmluZ1xuKi9cbmZ1bmN0aW9uIGVuY29kZUhhc2godGV4dCkge1xuXHRyZXR1cm4gY29tbW9uRW5jb2RlKHRleHQpLnJlcGxhY2UoRU5DX0NVUkxZX09QRU5fUkUsIFwie1wiKS5yZXBsYWNlKEVOQ19DVVJMWV9DTE9TRV9SRSwgXCJ9XCIpLnJlcGxhY2UoRU5DX0NBUkVUX1JFLCBcIl5cIik7XG59XG4vKipcbiogRW5jb2RlIGNoYXJhY3RlcnMgdGhhdCBuZWVkIHRvIGJlIGVuY29kZWQgcXVlcnkgdmFsdWVzIG9uIHRoZSBxdWVyeVxuKiBzZWN0aW9uIG9mIHRoZSBVUkwuXG4qXG4qIEBwYXJhbSB0ZXh0IC0gc3RyaW5nIHRvIGVuY29kZVxuKiBAcmV0dXJucyBlbmNvZGVkIHN0cmluZ1xuKi9cbmZ1bmN0aW9uIGVuY29kZVF1ZXJ5VmFsdWUodGV4dCkge1xuXHRyZXR1cm4gY29tbW9uRW5jb2RlKHRleHQpLnJlcGxhY2UoUExVU19SRSwgXCIlMkJcIikucmVwbGFjZShFTkNfU1BBQ0VfUkUsIFwiK1wiKS5yZXBsYWNlKEhBU0hfUkUsIFwiJTIzXCIpLnJlcGxhY2UoQU1QRVJTQU5EX1JFLCBcIiUyNlwiKS5yZXBsYWNlKEVOQ19CQUNLVElDS19SRSwgXCJgXCIpLnJlcGxhY2UoRU5DX0NVUkxZX09QRU5fUkUsIFwie1wiKS5yZXBsYWNlKEVOQ19DVVJMWV9DTE9TRV9SRSwgXCJ9XCIpLnJlcGxhY2UoRU5DX0NBUkVUX1JFLCBcIl5cIik7XG59XG4vKipcbiogTGlrZSBgZW5jb2RlUXVlcnlWYWx1ZWAgYnV0IGFsc28gZW5jb2RlcyB0aGUgYD1gIGNoYXJhY3Rlci5cbipcbiogQHBhcmFtIHRleHQgLSBzdHJpbmcgdG8gZW5jb2RlXG4qL1xuZnVuY3Rpb24gZW5jb2RlUXVlcnlLZXkodGV4dCkge1xuXHRyZXR1cm4gZW5jb2RlUXVlcnlWYWx1ZSh0ZXh0KS5yZXBsYWNlKEVRVUFMX1JFLCBcIiUzRFwiKTtcbn1cbi8qKlxuKiBFbmNvZGUgY2hhcmFjdGVycyB0aGF0IG5lZWQgdG8gYmUgZW5jb2RlZCBvbiB0aGUgcGF0aCBzZWN0aW9uIG9mIHRoZSBVUkwuXG4qXG4qIEBwYXJhbSB0ZXh0IC0gc3RyaW5nIHRvIGVuY29kZVxuKiBAcmV0dXJucyBlbmNvZGVkIHN0cmluZ1xuKi9cbmZ1bmN0aW9uIGVuY29kZVBhdGgodGV4dCkge1xuXHRyZXR1cm4gY29tbW9uRW5jb2RlKHRleHQpLnJlcGxhY2UoSEFTSF9SRSwgXCIlMjNcIikucmVwbGFjZShJTV9SRSwgXCIlM0ZcIik7XG59XG4vKipcbiogRW5jb2RlIGNoYXJhY3RlcnMgdGhhdCBuZWVkIHRvIGJlIGVuY29kZWQgb24gdGhlIHBhdGggc2VjdGlvbiBvZiB0aGUgVVJMIGFzIGFcbiogcGFyYW0uIFRoaXMgZnVuY3Rpb24gZW5jb2RlcyBldmVyeXRoaW5nIHtAbGluayBlbmNvZGVQYXRofSBkb2VzIHBsdXMgdGhlXG4qIHNsYXNoIChgL2ApIGNoYXJhY3Rlci4gSWYgYHRleHRgIGlzIGBudWxsYCBvciBgdW5kZWZpbmVkYCwgcmV0dXJucyBhbiBlbXB0eVxuKiBzdHJpbmcgaW5zdGVhZC5cbipcbiogQHBhcmFtIHRleHQgLSBzdHJpbmcgdG8gZW5jb2RlXG4qIEByZXR1cm5zIGVuY29kZWQgc3RyaW5nXG4qL1xuZnVuY3Rpb24gZW5jb2RlUGFyYW0odGV4dCkge1xuXHRyZXR1cm4gZW5jb2RlUGF0aCh0ZXh0KS5yZXBsYWNlKFNMQVNIX1JFLCBcIiUyRlwiKTtcbn1cbmZ1bmN0aW9uIGRlY29kZSh0ZXh0KSB7XG5cdGlmICh0ZXh0ID09IG51bGwpIHJldHVybiBudWxsO1xuXHR0cnkge1xuXHRcdHJldHVybiBkZWNvZGVVUklDb21wb25lbnQoXCJcIiArIHRleHQpO1xuXHR9IGNhdGNoIHtcblx0XHRwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgZGlhZ25vc3RpY3MuVlVFX1JPVVRFUl9SMDA4MCh7IHRleHQ6IFwiXCIgKyB0ZXh0IH0pO1xuXHR9XG5cdHJldHVybiBcIlwiICsgdGV4dDtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9sb2NhdGlvbi50c1xuY29uc3QgVFJBSUxJTkdfU0xBU0hfUkUgPSAvXFwvJC87XG5jb25zdCByZW1vdmVUcmFpbGluZ1NsYXNoID0gKHBhdGgpID0+IHBhdGgucmVwbGFjZShUUkFJTElOR19TTEFTSF9SRSwgXCJcIik7XG4vKipcbiogVHJhbnNmb3JtcyBhIFVSSSBpbnRvIGEgbm9ybWFsaXplZCBoaXN0b3J5IGxvY2F0aW9uXG4qXG4qIEBwYXJhbSBwYXJzZVF1ZXJ5XG4qIEBwYXJhbSBsb2NhdGlvbiAtIFVSSSB0byBub3JtYWxpemVcbiogQHBhcmFtIGN1cnJlbnRMb2NhdGlvbiAtIGN1cnJlbnQgYWJzb2x1dGUgbG9jYXRpb24uIEFsbG93cyByZXNvbHZpbmcgcmVsYXRpdmVcbiogcGF0aHMuIE11c3Qgc3RhcnQgd2l0aCBgL2AuIERlZmF1bHRzIHRvIGAvYFxuKiBAcmV0dXJucyBhIG5vcm1hbGl6ZWQgaGlzdG9yeSBsb2NhdGlvblxuKi9cbmZ1bmN0aW9uIHBhcnNlVVJMKHBhcnNlUXVlcnksIGxvY2F0aW9uLCBjdXJyZW50TG9jYXRpb24gPSBcIi9cIikge1xuXHRsZXQgcGF0aCwgcXVlcnkgPSB7fSwgc2VhcmNoU3RyaW5nID0gXCJcIiwgaGFzaCA9IFwiXCI7XG5cdGNvbnN0IGhhc2hQb3MgPSBsb2NhdGlvbi5pbmRleE9mKFwiI1wiKTtcblx0bGV0IHNlYXJjaFBvcyA9IGxvY2F0aW9uLmluZGV4T2YoXCI/XCIpO1xuXHRzZWFyY2hQb3MgPSBoYXNoUG9zID49IDAgJiYgc2VhcmNoUG9zID4gaGFzaFBvcyA/IC0xIDogc2VhcmNoUG9zO1xuXHRpZiAoc2VhcmNoUG9zID49IDApIHtcblx0XHRwYXRoID0gbG9jYXRpb24uc2xpY2UoMCwgc2VhcmNoUG9zKTtcblx0XHRzZWFyY2hTdHJpbmcgPSBsb2NhdGlvbi5zbGljZShzZWFyY2hQb3MsIGhhc2hQb3MgPiAwID8gaGFzaFBvcyA6IGxvY2F0aW9uLmxlbmd0aCk7XG5cdFx0cXVlcnkgPSBwYXJzZVF1ZXJ5KHNlYXJjaFN0cmluZy5zbGljZSgxKSk7XG5cdH1cblx0aWYgKGhhc2hQb3MgPj0gMCkge1xuXHRcdHBhdGggPSBwYXRoIHx8IGxvY2F0aW9uLnNsaWNlKDAsIGhhc2hQb3MpO1xuXHRcdGhhc2ggPSBsb2NhdGlvbi5zbGljZShoYXNoUG9zLCBsb2NhdGlvbi5sZW5ndGgpO1xuXHR9XG5cdHBhdGggPSByZXNvbHZlUmVsYXRpdmVQYXRoKHBhdGggIT0gbnVsbCA/IHBhdGggOiBsb2NhdGlvbiwgY3VycmVudExvY2F0aW9uKTtcblx0cmV0dXJuIHtcblx0XHRmdWxsUGF0aDogcGF0aCArIHNlYXJjaFN0cmluZyArIGhhc2gsXG5cdFx0cGF0aCxcblx0XHRxdWVyeSxcblx0XHRoYXNoOiBkZWNvZGUoaGFzaClcblx0fTtcbn1cbmZ1bmN0aW9uIE5FV19zdHJpbmdpZnlVUkwoc3RyaW5naWZ5UXVlcnksIHBhdGgsIHF1ZXJ5LCBoYXNoID0gXCJcIikge1xuXHRjb25zdCBzZWFyY2hUZXh0ID0gc3RyaW5naWZ5UXVlcnkocXVlcnkpO1xuXHRyZXR1cm4gcGF0aCArIChzZWFyY2hUZXh0ICYmIFwiP1wiKSArIHNlYXJjaFRleHQgKyBlbmNvZGVIYXNoKGhhc2gpO1xufVxuLyoqXG4qIFN0cmluZ2lmaWVzIGEgVVJMIG9iamVjdFxuKlxuKiBAcGFyYW0gc3RyaW5naWZ5UXVlcnlcbiogQHBhcmFtIGxvY2F0aW9uXG4qL1xuZnVuY3Rpb24gc3RyaW5naWZ5VVJMKHN0cmluZ2lmeVF1ZXJ5LCBsb2NhdGlvbikge1xuXHRjb25zdCBxdWVyeSA9IGxvY2F0aW9uLnF1ZXJ5ID8gc3RyaW5naWZ5UXVlcnkobG9jYXRpb24ucXVlcnkpIDogXCJcIjtcblx0cmV0dXJuIGxvY2F0aW9uLnBhdGggKyAocXVlcnkgJiYgXCI/XCIpICsgcXVlcnkgKyAobG9jYXRpb24uaGFzaCB8fCBcIlwiKTtcbn1cbi8qKlxuKiBTdHJpcHMgb2ZmIHRoZSBiYXNlIGZyb20gdGhlIGJlZ2lubmluZyBvZiBhIGxvY2F0aW9uLnBhdGhuYW1lIGluIGEgbm9uLWNhc2Utc2Vuc2l0aXZlIHdheS5cbipcbiogQHBhcmFtIHBhdGhuYW1lIC0gbG9jYXRpb24ucGF0aG5hbWVcbiogQHBhcmFtIGJhc2UgLSBiYXNlIHRvIHN0cmlwIG9mZlxuKi9cbmZ1bmN0aW9uIHN0cmlwQmFzZShwYXRobmFtZSwgYmFzZSkge1xuXHRpZiAoIWJhc2UgfHwgIXBhdGhuYW1lLnRvTG93ZXJDYXNlKCkuc3RhcnRzV2l0aChiYXNlLnRvTG93ZXJDYXNlKCkpKSByZXR1cm4gcGF0aG5hbWU7XG5cdHJldHVybiBwYXRobmFtZS5zbGljZShiYXNlLmxlbmd0aCkgfHwgXCIvXCI7XG59XG4vKipcbiogQ2hlY2tzIGlmIHR3byBSb3V0ZUxvY2F0aW9uIGFyZSBlcXVhbC4gVGhpcyBtZWFucyB0aGF0IGJvdGggbG9jYXRpb25zIGFyZVxuKiBwb2ludGluZyB0b3dhcmRzIHRoZSBzYW1lIHtAbGluayBSb3V0ZVJlY29yZH0gYW5kIHRoYXQgYWxsIGBwYXJhbXNgLCBgcXVlcnlgXG4qIHBhcmFtZXRlcnMgYW5kIGBoYXNoYCBhcmUgdGhlIHNhbWVcbipcbiogQHBhcmFtIHN0cmluZ2lmeVF1ZXJ5IC0gQSBmdW5jdGlvbiB0aGF0IHRha2VzIGEgcXVlcnkgb2JqZWN0IG9mIHR5cGUgTG9jYXRpb25RdWVyeVJhdyBhbmQgcmV0dXJucyBhIHN0cmluZyByZXByZXNlbnRhdGlvbiBvZiBpdC5cbiogQHBhcmFtIGEgLSBmaXJzdCB7QGxpbmsgUm91dGVMb2NhdGlvbn1cbiogQHBhcmFtIGIgLSBzZWNvbmQge0BsaW5rIFJvdXRlTG9jYXRpb259XG4qL1xuZnVuY3Rpb24gaXNTYW1lUm91dGVMb2NhdGlvbihzdHJpbmdpZnlRdWVyeSwgYSwgYikge1xuXHRjb25zdCBhTGFzdEluZGV4ID0gYS5tYXRjaGVkLmxlbmd0aCAtIDE7XG5cdGNvbnN0IGJMYXN0SW5kZXggPSBiLm1hdGNoZWQubGVuZ3RoIC0gMTtcblx0cmV0dXJuIGFMYXN0SW5kZXggPiAtMSAmJiBhTGFzdEluZGV4ID09PSBiTGFzdEluZGV4ICYmIGlzU2FtZVJvdXRlUmVjb3JkKGEubWF0Y2hlZFthTGFzdEluZGV4XSwgYi5tYXRjaGVkW2JMYXN0SW5kZXhdKSAmJiBpc1NhbWVSb3V0ZUxvY2F0aW9uUGFyYW1zKGEucGFyYW1zLCBiLnBhcmFtcykgJiYgc3RyaW5naWZ5UXVlcnkoYS5xdWVyeSkgPT09IHN0cmluZ2lmeVF1ZXJ5KGIucXVlcnkpICYmIGEuaGFzaCA9PT0gYi5oYXNoO1xufVxuLyoqXG4qIENoZWNrIGlmIHR3byBgUm91dGVSZWNvcmRzYCBhcmUgZXF1YWwuIFRha2VzIGludG8gYWNjb3VudCBhbGlhc2VzOiB0aGV5IGFyZVxuKiBjb25zaWRlcmVkIGVxdWFsIHRvIHRoZSBgUm91dGVSZWNvcmRgIHRoZXkgYXJlIGFsaWFzaW5nLlxuKlxuKiBAcGFyYW0gYSAtIGZpcnN0IHtAbGluayBSb3V0ZVJlY29yZH1cbiogQHBhcmFtIGIgLSBzZWNvbmQge0BsaW5rIFJvdXRlUmVjb3JkfVxuKi9cbmZ1bmN0aW9uIGlzU2FtZVJvdXRlUmVjb3JkKGEsIGIpIHtcblx0cmV0dXJuIChhLmFsaWFzT2YgfHwgYSkgPT09IChiLmFsaWFzT2YgfHwgYik7XG59XG5mdW5jdGlvbiBpc1NhbWVSb3V0ZUxvY2F0aW9uUGFyYW1zKGEsIGIpIHtcblx0aWYgKE9iamVjdC5rZXlzKGEpLmxlbmd0aCAhPT0gT2JqZWN0LmtleXMoYikubGVuZ3RoKSByZXR1cm4gZmFsc2U7XG5cdGZvciAodmFyIGtleSBpbiBhKSBpZiAoIWlzU2FtZVJvdXRlTG9jYXRpb25QYXJhbXNWYWx1ZShhW2tleV0sIGJba2V5XSkpIHJldHVybiBmYWxzZTtcblx0cmV0dXJuIHRydWU7XG59XG5mdW5jdGlvbiBpc1NhbWVSb3V0ZUxvY2F0aW9uUGFyYW1zVmFsdWUoYSwgYikge1xuXHRyZXR1cm4gaXNBcnJheShhKSA/IGlzRXF1aXZhbGVudEFycmF5KGEsIGIpIDogaXNBcnJheShiKSA/IGlzRXF1aXZhbGVudEFycmF5KGIsIGEpIDogKGEgJiYgYS52YWx1ZU9mKCkpID09PSAoYiAmJiBiLnZhbHVlT2YoKSk7XG59XG4vKipcbiogQ2hlY2sgaWYgdHdvIGFycmF5cyBhcmUgdGhlIHNhbWUgb3IgaWYgYW4gYXJyYXkgd2l0aCBvbmUgc2luZ2xlIGVudHJ5IGlzIHRoZVxuKiBzYW1lIGFzIGFub3RoZXIgcHJpbWl0aXZlIHZhbHVlLiBVc2VkIHRvIGNoZWNrIHF1ZXJ5IGFuZCBwYXJhbWV0ZXJzXG4qXG4qIEBwYXJhbSBhIC0gYXJyYXkgb2YgdmFsdWVzXG4qIEBwYXJhbSBiIC0gYXJyYXkgb2YgdmFsdWVzIG9yIGEgc2luZ2xlIHZhbHVlXG4qL1xuZnVuY3Rpb24gaXNFcXVpdmFsZW50QXJyYXkoYSwgYikge1xuXHRyZXR1cm4gaXNBcnJheShiKSA/IGEubGVuZ3RoID09PSBiLmxlbmd0aCAmJiBhLmV2ZXJ5KCh2YWx1ZSwgaSkgPT4gdmFsdWUgPT09IGJbaV0pIDogYS5sZW5ndGggPT09IDEgJiYgYVswXSA9PT0gYjtcbn1cbi8qKlxuKiBSZXNvbHZlcyBhIHJlbGF0aXZlIHBhdGggdGhhdCBzdGFydHMgd2l0aCBgLmAuXG4qXG4qIEBwYXJhbSB0byAtIHBhdGggbG9jYXRpb24gd2UgYXJlIHJlc29sdmluZ1xuKiBAcGFyYW0gZnJvbSAtIGN1cnJlbnRMb2NhdGlvbi5wYXRoLCBzaG91bGQgc3RhcnQgd2l0aCBgL2BcbiovXG5mdW5jdGlvbiByZXNvbHZlUmVsYXRpdmVQYXRoKHRvLCBmcm9tKSB7XG5cdGlmIChpc0Fic29sdXRlUGF0aCh0bykpIHJldHVybiB0bztcblx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiAhaXNBYnNvbHV0ZVBhdGgoZnJvbSkpIHtcblx0XHRkaWFnbm9zdGljcy5WVUVfUk9VVEVSX1IwMDcwKHtcblx0XHRcdHRvLFxuXHRcdFx0ZnJvbVxuXHRcdH0pO1xuXHRcdHJldHVybiB0bztcblx0fVxuXHRpZiAoIXRvKSByZXR1cm4gZnJvbTtcblx0Y29uc3QgZnJvbVNlZ21lbnRzID0gZnJvbS5zcGxpdChcIi9cIik7XG5cdGNvbnN0IHRvU2VnbWVudHMgPSB0by5zcGxpdChcIi9cIik7XG5cdGNvbnN0IGxhc3RUb1NlZ21lbnQgPSB0b1NlZ21lbnRzW3RvU2VnbWVudHMubGVuZ3RoIC0gMV07XG5cdGlmIChsYXN0VG9TZWdtZW50ID09PSBcIi4uXCIgfHwgbGFzdFRvU2VnbWVudCA9PT0gXCIuXCIpIHRvU2VnbWVudHMucHVzaChcIlwiKTtcblx0bGV0IHBvc2l0aW9uID0gZnJvbVNlZ21lbnRzLmxlbmd0aCAtIDE7XG5cdGxldCB0b1Bvc2l0aW9uO1xuXHRsZXQgc2VnbWVudDtcblx0Zm9yICh0b1Bvc2l0aW9uID0gMDsgdG9Qb3NpdGlvbiA8IHRvU2VnbWVudHMubGVuZ3RoOyB0b1Bvc2l0aW9uKyspIHtcblx0XHRzZWdtZW50ID0gdG9TZWdtZW50c1t0b1Bvc2l0aW9uXTtcblx0XHRpZiAoc2VnbWVudCA9PT0gXCIuXCIpIGNvbnRpbnVlO1xuXHRcdGlmIChzZWdtZW50ID09PSBcIi4uXCIpIHtcblx0XHRcdGlmIChwb3NpdGlvbiA+IDEpIHBvc2l0aW9uLS07XG5cdFx0fSBlbHNlIGJyZWFrO1xuXHR9XG5cdHJldHVybiBmcm9tU2VnbWVudHMuc2xpY2UoMCwgcG9zaXRpb24pLmpvaW4oXCIvXCIpICsgXCIvXCIgKyB0b1NlZ21lbnRzLnNsaWNlKHRvUG9zaXRpb24pLmpvaW4oXCIvXCIpO1xufVxuLyoqXG4qIEluaXRpYWwgcm91dGUgbG9jYXRpb24gd2hlcmUgdGhlIHJvdXRlciBpcy4gQ2FuIGJlIHVzZWQgaW4gbmF2aWdhdGlvbiBndWFyZHNcbiogdG8gZGlmZmVyZW50aWF0ZSB0aGUgaW5pdGlhbCBuYXZpZ2F0aW9uLlxuKlxuKiBAZXhhbXBsZVxuKiBgYGBqc1xuKiBpbXBvcnQgeyBTVEFSVF9MT0NBVElPTiB9IGZyb20gJ3Z1ZS1yb3V0ZXInXG4qXG4qIHJvdXRlci5iZWZvcmVFYWNoKCh0bywgZnJvbSkgPT4ge1xuKiAgIGlmIChmcm9tID09PSBTVEFSVF9MT0NBVElPTikge1xuKiAgICAgLy8gaW5pdGlhbCBuYXZpZ2F0aW9uXG4qICAgfVxuKiB9KVxuKiBgYGBcbiovXG5jb25zdCBTVEFSVF9MT0NBVElPTl9OT1JNQUxJWkVEID0ge1xuXHRwYXRoOiBcIi9cIixcblx0bmFtZTogdm9pZCAwLFxuXHRwYXJhbXM6IHt9LFxuXHRxdWVyeToge30sXG5cdGhhc2g6IFwiXCIsXG5cdGZ1bGxQYXRoOiBcIi9cIixcblx0bWF0Y2hlZDogW10sXG5cdG1ldGE6IHt9LFxuXHRyZWRpcmVjdGVkRnJvbTogdm9pZCAwXG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2hpc3RvcnkvY29tbW9uLnRzXG4vKipcbiogTm9ybWFsaXplcyBhIGJhc2UgYnkgcmVtb3ZpbmcgYW55IHRyYWlsaW5nIHNsYXNoIGFuZCByZWFkaW5nIHRoZSBiYXNlIHRhZyBpZlxuKiBwcmVzZW50LlxuKlxuKiBAcGFyYW0gYmFzZSAtIGJhc2UgdG8gbm9ybWFsaXplXG4qL1xuZnVuY3Rpb24gbm9ybWFsaXplQmFzZShiYXNlKSB7XG5cdGlmICghYmFzZSkge1xuXHRcdGlmIChpc0Jyb3dzZXIpIHtcblx0XHRcdGNvbnN0IGJhc2VFbCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCJiYXNlXCIpO1xuXHRcdFx0YmFzZSA9IGJhc2VFbCAmJiBiYXNlRWwuZ2V0QXR0cmlidXRlKFwiaHJlZlwiKSB8fCBcIi9cIjtcblx0XHRcdGJhc2UgPSBiYXNlLnJlcGxhY2UoL15cXHcrOlxcL1xcL1teL10rLywgXCJcIik7XG5cdFx0fSBlbHNlIGJhc2UgPSBcIi9cIjtcblx0fVxuXHRpZiAoYmFzZVswXSAhPT0gXCIvXCIgJiYgYmFzZVswXSAhPT0gXCIjXCIpIGJhc2UgPSBcIi9cIiArIGJhc2U7XG5cdHJldHVybiByZW1vdmVUcmFpbGluZ1NsYXNoKGJhc2UpO1xufVxuY29uc3QgQkVGT1JFX0hBU0hfUkUgPSAvXlteI10rIy87XG5mdW5jdGlvbiBjcmVhdGVIcmVmKGJhc2UsIGxvY2F0aW9uKSB7XG5cdHJldHVybiBiYXNlLnJlcGxhY2UoQkVGT1JFX0hBU0hfUkUsIFwiI1wiKSArIGxvY2F0aW9uO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3Njcm9sbEJlaGF2aW9yLnRzXG5mdW5jdGlvbiBnZXRFbGVtZW50UG9zaXRpb24oZWwsIG9mZnNldCkge1xuXHRjb25zdCBkb2NSZWN0ID0gZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuXHRjb25zdCBlbFJlY3QgPSBlbC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcblx0cmV0dXJuIHtcblx0XHRiZWhhdmlvcjogb2Zmc2V0LmJlaGF2aW9yLFxuXHRcdGxlZnQ6IGVsUmVjdC5sZWZ0IC0gZG9jUmVjdC5sZWZ0IC0gKG9mZnNldC5sZWZ0IHx8IDApLFxuXHRcdHRvcDogZWxSZWN0LnRvcCAtIGRvY1JlY3QudG9wIC0gKG9mZnNldC50b3AgfHwgMClcblx0fTtcbn1cbmNvbnN0IGNvbXB1dGVTY3JvbGxQb3NpdGlvbiA9ICgpID0+IGhpc3Rvcnkuc2Nyb2xsUmVzdG9yYXRpb24gPT09IFwibWFudWFsXCIgPyB7XG5cdGxlZnQ6IHdpbmRvdy5zY3JvbGxYLFxuXHR0b3A6IHdpbmRvdy5zY3JvbGxZXG59IDogbnVsbDtcbmZ1bmN0aW9uIHNjcm9sbFRvUG9zaXRpb24ocG9zaXRpb24pIHtcblx0bGV0IHNjcm9sbFRvT3B0aW9ucztcblx0aWYgKFwiZWxcIiBpbiBwb3NpdGlvbikge1xuXHRcdGNvbnN0IHBvc2l0aW9uRWwgPSBwb3NpdGlvbi5lbDtcblx0XHRjb25zdCBpc0lkU2VsZWN0b3IgPSB0eXBlb2YgcG9zaXRpb25FbCA9PT0gXCJzdHJpbmdcIiAmJiBwb3NpdGlvbkVsLnN0YXJ0c1dpdGgoXCIjXCIpO1xuXHRcdC8qKlxuXHRcdCogYGlkYHMgY2FuIGFjY2VwdCBwcmV0dHkgbXVjaCBhbnkgY2hhcmFjdGVycywgaW5jbHVkaW5nIENTUyBjb21iaW5hdG9yc1xuXHRcdCogbGlrZSBgPmAgb3IgYH5gLiBJdCdzIHN0aWxsIHBvc3NpYmxlIHRvIHJldHJpZXZlIGVsZW1lbnRzIHVzaW5nXG5cdFx0KiBgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ34nKWAgYnV0IGl0IG5lZWRzIHRvIGJlIGVzY2FwZWQgd2hlbiB1c2luZ1xuXHRcdCogYGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJyNcXFxcficpYCBmb3IgaXQgdG8gYmUgdmFsaWQuIFRoZSBvbmx5XG5cdFx0KiByZXF1aXJlbWVudHMgZm9yIGBpZGBzIGFyZSB0aGVtIHRvIGJlIHVuaXF1ZSBvbiB0aGUgcGFnZSBhbmQgdG8gbm90IGJlXG5cdFx0KiBlbXB0eSAoYGlkPVwiXCJgKS4gQmVjYXVzZSBvZiB0aGF0LCB3aGVuIHBhc3NpbmcgYW4gaWQgc2VsZWN0b3IsIGl0IHNob3VsZFxuXHRcdCogYmUgcHJvcGVybHkgZXNjYXBlZCBmb3IgaXQgdG8gd29yayB3aXRoIGBxdWVyeVNlbGVjdG9yYC4gV2UgY291bGQgY2hlY2tcblx0XHQqIGZvciB0aGUgaWQgc2VsZWN0b3IgdG8gYmUgc2ltcGxlIChubyBDU1MgY29tYmluYXRvcnMgYCsgPn5gKSBidXQgdGhhdFxuXHRcdCogd291bGQgbWFrZSB0aGluZ3MgaW5jb25zaXN0ZW50IHNpbmNlIHRoZXkgYXJlIHZhbGlkIGNoYXJhY3RlcnMgZm9yIGFuXG5cdFx0KiBgaWRgIGJ1dCB3b3VsZCBuZWVkIHRvIGJlIGVzY2FwZWQgd2hlbiB1c2luZyBgcXVlcnlTZWxlY3RvcmAsIGJyZWFraW5nXG5cdFx0KiB0aGVpciB1c2FnZSBhbmQgZW5kaW5nIHVwIGluIG5vIHNlbGVjdG9yIHJldHVybmVkLiBTZWxlY3RvcnMgbmVlZCB0byBiZVxuXHRcdCogZXNjYXBlZDpcblx0XHQqXG5cdFx0KiAtIGAjMS10aGluZ2AgYmVjb21lcyBgI1xcMzEgLXRoaW5nYFxuXHRcdCogLSBgI3dpdGh+c3ltYm9sc2AgYmVjb21lcyBgI3dpdGhcXFxcfnN5bWJvbHNgXG5cdFx0KlxuXHRcdCogLSBNb3JlIGluZm9ybWF0aW9uIGFib3V0ICB0aGUgdG9waWMgY2FuIGJlIGZvdW5kIGF0XG5cdFx0KiAgIGh0dHBzOi8vbWF0aGlhc2J5bmVucy5iZS9ub3Rlcy9odG1sNS1pZC1jbGFzcy5cblx0XHQqIC0gUHJhY3RpY2FsIGV4YW1wbGU6IGh0dHBzOi8vbWF0aGlhc2J5bmVucy5iZS9kZW1vL2h0bWw1LWlkXG5cdFx0Ki9cblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIHR5cGVvZiBwb3NpdGlvbi5lbCA9PT0gXCJzdHJpbmdcIikge1xuXHRcdFx0aWYgKCFpc0lkU2VsZWN0b3IgfHwgIWRvY3VtZW50LmdldEVsZW1lbnRCeUlkKHBvc2l0aW9uLmVsLnNsaWNlKDEpKSkgdHJ5IHtcblx0XHRcdFx0Y29uc3QgZm91bmRFbCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IocG9zaXRpb24uZWwpO1xuXHRcdFx0XHRpZiAoaXNJZFNlbGVjdG9yICYmIGZvdW5kRWwpIHtcblx0XHRcdFx0XHRkaWFnbm9zdGljcy5WVUVfUk9VVEVSX1IwMDQwKHsgZWw6IHBvc2l0aW9uLmVsIH0pO1xuXHRcdFx0XHRcdHJldHVybjtcblx0XHRcdFx0fVxuXHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdGRpYWdub3N0aWNzLlZVRV9ST1VURVJfUjAwNDEoeyBlbDogcG9zaXRpb24uZWwgfSk7XG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblx0XHR9XG5cdFx0Y29uc3QgZWwgPSB0eXBlb2YgcG9zaXRpb25FbCA9PT0gXCJzdHJpbmdcIiA/IGlzSWRTZWxlY3RvciA/IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKHBvc2l0aW9uRWwuc2xpY2UoMSkpIDogZG9jdW1lbnQucXVlcnlTZWxlY3Rvcihwb3NpdGlvbkVsKSA6IHBvc2l0aW9uRWw7XG5cdFx0aWYgKCFlbCkge1xuXHRcdFx0cHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIGRpYWdub3N0aWNzLlZVRV9ST1VURVJfUjAwNDIoeyBlbDogcG9zaXRpb24uZWwgfSk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdHNjcm9sbFRvT3B0aW9ucyA9IGdldEVsZW1lbnRQb3NpdGlvbihlbCwgcG9zaXRpb24pO1xuXHR9IGVsc2Ugc2Nyb2xsVG9PcHRpb25zID0gcG9zaXRpb247XG5cdGlmIChcInNjcm9sbEJlaGF2aW9yXCIgaW4gZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LnN0eWxlKSB3aW5kb3cuc2Nyb2xsVG8oc2Nyb2xsVG9PcHRpb25zKTtcblx0ZWxzZSB3aW5kb3cuc2Nyb2xsVG8oc2Nyb2xsVG9PcHRpb25zLmxlZnQgIT0gbnVsbCA/IHNjcm9sbFRvT3B0aW9ucy5sZWZ0IDogd2luZG93LnNjcm9sbFgsIHNjcm9sbFRvT3B0aW9ucy50b3AgIT0gbnVsbCA/IHNjcm9sbFRvT3B0aW9ucy50b3AgOiB3aW5kb3cuc2Nyb2xsWSk7XG59XG5mdW5jdGlvbiBnZXRTY3JvbGxLZXkocGF0aCwgZGVsdGEpIHtcblx0cmV0dXJuIChoaXN0b3J5LnN0YXRlID8gaGlzdG9yeS5zdGF0ZS5wb3NpdGlvbiAtIGRlbHRhIDogLTEpICsgcGF0aDtcbn1cbmNvbnN0IHNjcm9sbFBvc2l0aW9ucyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5mdW5jdGlvbiBzYXZlU2Nyb2xsUG9zaXRpb24oa2V5KSB7XG5cdHNjcm9sbFBvc2l0aW9ucy5zZXQoa2V5LCBjb21wdXRlU2Nyb2xsUG9zaXRpb24oKSk7XG59XG5mdW5jdGlvbiBnZXRTYXZlZFNjcm9sbFBvc2l0aW9uKGtleSkge1xuXHRjb25zdCBzY3JvbGwgPSBzY3JvbGxQb3NpdGlvbnMuZ2V0KGtleSk7XG5cdHNjcm9sbFBvc2l0aW9ucy5kZWxldGUoa2V5KTtcblx0cmV0dXJuIHNjcm9sbDtcbn1cbi8qKlxuKiBTY3JvbGxCZWhhdmlvciBpbnN0YW5jZSB1c2VkIGJ5IHRoZSByb3V0ZXIgdG8gY29tcHV0ZSBhbmQgcmVzdG9yZSB0aGUgc2Nyb2xsXG4qIHBvc2l0aW9uIHdoZW4gbmF2aWdhdGluZy5cbiovXG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvdHlwZXMvdHlwZUd1YXJkcy50c1xuZnVuY3Rpb24gaXNSb3V0ZUxvY2F0aW9uKHJvdXRlKSB7XG5cdHJldHVybiB0eXBlb2Ygcm91dGUgPT09IFwic3RyaW5nXCIgfHwgcm91dGUgJiYgdHlwZW9mIHJvdXRlID09PSBcIm9iamVjdFwiO1xufVxuZnVuY3Rpb24gaXNSb3V0ZU5hbWUobmFtZSkge1xuXHRyZXR1cm4gdHlwZW9mIG5hbWUgPT09IFwic3RyaW5nXCIgfHwgdHlwZW9mIG5hbWUgPT09IFwic3ltYm9sXCI7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvcXVlcnkudHNcbi8qKlxuKiBUcmFuc2Zvcm1zIGEgcXVlcnlTdHJpbmcgaW50byBhIHtAbGluayBMb2NhdGlvblF1ZXJ5fSBvYmplY3QuIEFjY2VwdCBib3RoLCBhXG4qIHZlcnNpb24gd2l0aCB0aGUgbGVhZGluZyBgP2AgYW5kIHdpdGhvdXQgU2hvdWxkIHdvcmsgYXMgVVJMU2VhcmNoUGFyYW1zXG5cbiogQGludGVybmFsXG4qXG4qIEBwYXJhbSBzZWFyY2ggLSBzZWFyY2ggc3RyaW5nIHRvIHBhcnNlXG4qIEByZXR1cm5zIGEgcXVlcnkgb2JqZWN0XG4qL1xuZnVuY3Rpb24gcGFyc2VRdWVyeShzZWFyY2gpIHtcblx0Y29uc3QgcXVlcnkgPSB7fTtcblx0aWYgKHNlYXJjaCA9PT0gXCJcIiB8fCBzZWFyY2ggPT09IFwiP1wiKSByZXR1cm4gcXVlcnk7XG5cdGNvbnN0IHNlYXJjaFBhcmFtcyA9IChzZWFyY2hbMF0gPT09IFwiP1wiID8gc2VhcmNoLnNsaWNlKDEpIDogc2VhcmNoKS5zcGxpdChcIiZcIik7XG5cdGZvciAobGV0IGkgPSAwOyBpIDwgc2VhcmNoUGFyYW1zLmxlbmd0aDsgKytpKSB7XG5cdFx0Y29uc3Qgc2VhcmNoUGFyYW0gPSBzZWFyY2hQYXJhbXNbaV0ucmVwbGFjZShQTFVTX1JFLCBcIiBcIik7XG5cdFx0Y29uc3QgZXFQb3MgPSBzZWFyY2hQYXJhbS5pbmRleE9mKFwiPVwiKTtcblx0XHRjb25zdCBrZXkgPSBkZWNvZGUoZXFQb3MgPCAwID8gc2VhcmNoUGFyYW0gOiBzZWFyY2hQYXJhbS5zbGljZSgwLCBlcVBvcykpO1xuXHRcdGNvbnN0IHZhbHVlID0gZXFQb3MgPCAwID8gbnVsbCA6IGRlY29kZShzZWFyY2hQYXJhbS5zbGljZShlcVBvcyArIDEpKTtcblx0XHRpZiAoa2V5IGluIHF1ZXJ5KSB7XG5cdFx0XHRsZXQgY3VycmVudFZhbHVlID0gcXVlcnlba2V5XTtcblx0XHRcdGlmICghaXNBcnJheShjdXJyZW50VmFsdWUpKSBjdXJyZW50VmFsdWUgPSBxdWVyeVtrZXldID0gW2N1cnJlbnRWYWx1ZV07XG5cdFx0XHRjdXJyZW50VmFsdWUucHVzaCh2YWx1ZSk7XG5cdFx0fSBlbHNlIHF1ZXJ5W2tleV0gPSB2YWx1ZTtcblx0fVxuXHRyZXR1cm4gcXVlcnk7XG59XG4vKipcbiogU3RyaW5naWZpZXMgYSB7QGxpbmsgTG9jYXRpb25RdWVyeVJhd30gb2JqZWN0LiBMaWtlIGBVUkxTZWFyY2hQYXJhbXNgLCBpdFxuKiBkb2Vzbid0IHByZXBlbmQgYSBgP2BcbipcbiogQGludGVybmFsXG4qXG4qIEBwYXJhbSBxdWVyeSAtIHF1ZXJ5IG9iamVjdCB0byBzdHJpbmdpZnlcbiogQHJldHVybnMgc3RyaW5nIHZlcnNpb24gb2YgdGhlIHF1ZXJ5IHdpdGhvdXQgdGhlIGxlYWRpbmcgYD9gXG4qL1xuZnVuY3Rpb24gc3RyaW5naWZ5UXVlcnkocXVlcnkpIHtcblx0bGV0IHNlYXJjaCA9IFwiXCI7XG5cdGZvciAobGV0IGtleSBpbiBxdWVyeSkge1xuXHRcdGNvbnN0IHZhbHVlID0gcXVlcnlba2V5XTtcblx0XHRrZXkgPSBlbmNvZGVRdWVyeUtleShrZXkpO1xuXHRcdGlmICh2YWx1ZSA9PSBudWxsKSB7XG5cdFx0XHRpZiAodmFsdWUgIT09IHZvaWQgMCkgc2VhcmNoICs9IChzZWFyY2gubGVuZ3RoID8gXCImXCIgOiBcIlwiKSArIGtleTtcblx0XHRcdGNvbnRpbnVlO1xuXHRcdH1cblx0XHQoaXNBcnJheSh2YWx1ZSkgPyB2YWx1ZS5tYXAoKHYpID0+IHYgJiYgZW5jb2RlUXVlcnlWYWx1ZSh2KSkgOiBbdmFsdWUgJiYgZW5jb2RlUXVlcnlWYWx1ZSh2YWx1ZSldKS5mb3JFYWNoKCh2YWx1ZSkgPT4ge1xuXHRcdFx0aWYgKHZhbHVlICE9PSB2b2lkIDApIHtcblx0XHRcdFx0c2VhcmNoICs9IChzZWFyY2gubGVuZ3RoID8gXCImXCIgOiBcIlwiKSArIGtleTtcblx0XHRcdFx0aWYgKHZhbHVlICE9IG51bGwpIHNlYXJjaCArPSBcIj1cIiArIHZhbHVlO1xuXHRcdFx0fVxuXHRcdH0pO1xuXHR9XG5cdHJldHVybiBzZWFyY2g7XG59XG4vKipcbiogVHJhbnNmb3JtcyBhIHtAbGluayBMb2NhdGlvblF1ZXJ5UmF3fSBpbnRvIGEge0BsaW5rIExvY2F0aW9uUXVlcnl9IGJ5IGNhc3RpbmdcbiogbnVtYmVycyBpbnRvIHN0cmluZ3MsIHJlbW92aW5nIGtleXMgd2l0aCBhbiB1bmRlZmluZWQgdmFsdWUgYW5kIHJlcGxhY2luZ1xuKiB1bmRlZmluZWQgd2l0aCBudWxsIGluIGFycmF5c1xuKlxuKiBAcGFyYW0gcXVlcnkgLSBxdWVyeSBvYmplY3QgdG8gbm9ybWFsaXplXG4qIEByZXR1cm5zIGEgbm9ybWFsaXplZCBxdWVyeSBvYmplY3RcbiovXG5mdW5jdGlvbiBub3JtYWxpemVRdWVyeShxdWVyeSkge1xuXHRjb25zdCBub3JtYWxpemVkUXVlcnkgPSB7fTtcblx0Zm9yIChjb25zdCBrZXkgaW4gcXVlcnkpIHtcblx0XHRjb25zdCB2YWx1ZSA9IHF1ZXJ5W2tleV07XG5cdFx0aWYgKHZhbHVlICE9PSB2b2lkIDApIG5vcm1hbGl6ZWRRdWVyeVtrZXldID0gaXNBcnJheSh2YWx1ZSkgPyB2YWx1ZS5tYXAoKHYpID0+IHYgPT0gbnVsbCA/IG51bGwgOiBcIlwiICsgdikgOiB2YWx1ZSA9PSBudWxsID8gdmFsdWUgOiBcIlwiICsgdmFsdWU7XG5cdH1cblx0cmV0dXJuIG5vcm1hbGl6ZWRRdWVyeTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy91dGlscy9jYWxsYmFja3MudHNcbi8qKlxuKiBDcmVhdGUgYSBsaXN0IG9mIGNhbGxiYWNrcyB0aGF0IGNhbiBiZSByZXNldC4gVXNlZCB0byBjcmVhdGUgYmVmb3JlIGFuZCBhZnRlciBuYXZpZ2F0aW9uIGd1YXJkcyBsaXN0XG4qL1xuZnVuY3Rpb24gdXNlQ2FsbGJhY2tzKCkge1xuXHRsZXQgaGFuZGxlcnMgPSBbXTtcblx0ZnVuY3Rpb24gYWRkKGhhbmRsZXIpIHtcblx0XHRoYW5kbGVycy5wdXNoKGhhbmRsZXIpO1xuXHRcdHJldHVybiAoKSA9PiB7XG5cdFx0XHRjb25zdCBpID0gaGFuZGxlcnMuaW5kZXhPZihoYW5kbGVyKTtcblx0XHRcdGlmIChpID4gLTEpIGhhbmRsZXJzLnNwbGljZShpLCAxKTtcblx0XHR9O1xuXHR9XG5cdGZ1bmN0aW9uIHJlc2V0KCkge1xuXHRcdGhhbmRsZXJzID0gW107XG5cdH1cblx0cmV0dXJuIHtcblx0XHRhZGQsXG5cdFx0bGlzdDogKCkgPT4gaGFuZGxlcnMuc2xpY2UoKSxcblx0XHRyZXNldFxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL25hdmlnYXRpb25HdWFyZHMudHNcbmZ1bmN0aW9uIHJlZ2lzdGVyR3VhcmQoYWN0aXZlUmVjb3JkUmVmLCBuYW1lLCBndWFyZCkge1xuXHRjb25zdCByZWNvcmQgPSBhY3RpdmVSZWNvcmRSZWYudmFsdWU7XG5cdGlmICghcmVjb3JkKSB7XG5cdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuXHRcdFx0Y29uc3QgZm5OYW1lID0gbmFtZSA9PT0gXCJ1cGRhdGVHdWFyZHNcIiA/IFwib25CZWZvcmVSb3V0ZVVwZGF0ZVwiIDogXCJvbkJlZm9yZVJvdXRlTGVhdmVcIjtcblx0XHRcdGRpYWdub3N0aWNzLlZVRV9ST1VURVJfUjAwMjAoeyBmbjogZm5OYW1lIH0pO1xuXHRcdH1cblx0XHRyZXR1cm47XG5cdH1cblx0bGV0IGN1cnJlbnRSZWNvcmQgPSByZWNvcmQ7XG5cdGNvbnN0IHJlbW92ZUZyb21MaXN0ID0gKCkgPT4ge1xuXHRcdGN1cnJlbnRSZWNvcmRbbmFtZV0uZGVsZXRlKGd1YXJkKTtcblx0fTtcblx0b25Vbm1vdW50ZWQocmVtb3ZlRnJvbUxpc3QpO1xuXHRvbkRlYWN0aXZhdGVkKHJlbW92ZUZyb21MaXN0KTtcblx0b25BY3RpdmF0ZWQoKCkgPT4ge1xuXHRcdGNvbnN0IG5ld1JlY29yZCA9IGFjdGl2ZVJlY29yZFJlZi52YWx1ZTtcblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmICFuZXdSZWNvcmQpIGRpYWdub3N0aWNzLlZVRV9ST1VURVJfUjAwMjEoKTtcblx0XHRpZiAobmV3UmVjb3JkKSBjdXJyZW50UmVjb3JkID0gbmV3UmVjb3JkO1xuXHRcdGN1cnJlbnRSZWNvcmRbbmFtZV0uYWRkKGd1YXJkKTtcblx0fSk7XG5cdGN1cnJlbnRSZWNvcmRbbmFtZV0uYWRkKGd1YXJkKTtcbn1cbi8qKlxuKiBBZGQgYSBuYXZpZ2F0aW9uIGd1YXJkIHRoYXQgdHJpZ2dlcnMgd2hlbmV2ZXIgdGhlIGNvbXBvbmVudCBmb3IgdGhlIGN1cnJlbnRcbiogbG9jYXRpb24gaXMgYWJvdXQgdG8gYmUgbGVmdC4gU2ltaWxhciB0byB7QGxpbmsgYmVmb3JlUm91dGVMZWF2ZX0gYnV0IGNhbiBiZVxuKiB1c2VkIGluIGFueSBjb21wb25lbnQuIFRoZSBndWFyZCBpcyByZW1vdmVkIHdoZW4gdGhlIGNvbXBvbmVudCBpcyB1bm1vdW50ZWQuXG4qXG4qIEBwYXJhbSBsZWF2ZUd1YXJkIC0ge0BsaW5rIE5hdmlnYXRpb25HdWFyZH1cbiovXG5mdW5jdGlvbiBvbkJlZm9yZVJvdXRlTGVhdmUobGVhdmVHdWFyZCkge1xuXHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmICFnZXRDdXJyZW50SW5zdGFuY2UoKSkge1xuXHRcdGRpYWdub3N0aWNzLlZVRV9ST1VURVJfUjAwMjIoeyBmbjogXCJvbkJlZm9yZVJvdXRlTGVhdmVcIiB9KTtcblx0XHRyZXR1cm47XG5cdH1cblx0cmVnaXN0ZXJHdWFyZChpbmplY3QobWF0Y2hlZFJvdXRlS2V5LCB7fSksIFwibGVhdmVHdWFyZHNcIiwgbGVhdmVHdWFyZCk7XG59XG4vKipcbiogQWRkIGEgbmF2aWdhdGlvbiBndWFyZCB0aGF0IHRyaWdnZXJzIHdoZW5ldmVyIHRoZSBjdXJyZW50IGxvY2F0aW9uIGlzIGFib3V0XG4qIHRvIGJlIHVwZGF0ZWQuIFNpbWlsYXIgdG8ge0BsaW5rIGJlZm9yZVJvdXRlVXBkYXRlfSBidXQgY2FuIGJlIHVzZWQgaW4gYW55XG4qIGNvbXBvbmVudC4gVGhlIGd1YXJkIGlzIHJlbW92ZWQgd2hlbiB0aGUgY29tcG9uZW50IGlzIHVubW91bnRlZC5cbipcbiogQHBhcmFtIHVwZGF0ZUd1YXJkIC0ge0BsaW5rIE5hdmlnYXRpb25HdWFyZH1cbiovXG5mdW5jdGlvbiBvbkJlZm9yZVJvdXRlVXBkYXRlKHVwZGF0ZUd1YXJkKSB7XG5cdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgIWdldEN1cnJlbnRJbnN0YW5jZSgpKSB7XG5cdFx0ZGlhZ25vc3RpY3MuVlVFX1JPVVRFUl9SMDAyMih7IGZuOiBcIm9uQmVmb3JlUm91dGVVcGRhdGVcIiB9KTtcblx0XHRyZXR1cm47XG5cdH1cblx0cmVnaXN0ZXJHdWFyZChpbmplY3QobWF0Y2hlZFJvdXRlS2V5LCB7fSksIFwidXBkYXRlR3VhcmRzXCIsIHVwZGF0ZUd1YXJkKTtcbn1cbmZ1bmN0aW9uIGd1YXJkVG9Qcm9taXNlRm4oZ3VhcmQsIHRvLCBmcm9tLCByZWNvcmQsIG5hbWUsIHJ1bldpdGhDb250ZXh0ID0gKGZuKSA9PiBmbigpKSB7XG5cdGNvbnN0IGVudGVyQ2FsbGJhY2tBcnJheSA9IHJlY29yZCAmJiAocmVjb3JkLmVudGVyQ2FsbGJhY2tzW25hbWVdID0gcmVjb3JkLmVudGVyQ2FsbGJhY2tzW25hbWVdIHx8IFtdKTtcblx0cmV0dXJuICgpID0+IG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcblx0XHRjb25zdCBuZXh0ID0gKHZhbGlkKSA9PiB7XG5cdFx0XHRpZiAodmFsaWQgPT09IGZhbHNlKSByZWplY3QoY3JlYXRlUm91dGVyRXJyb3IoNCwge1xuXHRcdFx0XHRmcm9tLFxuXHRcdFx0XHR0b1xuXHRcdFx0fSkpO1xuXHRcdFx0ZWxzZSBpZiAodmFsaWQgaW5zdGFuY2VvZiBFcnJvcikgcmVqZWN0KHZhbGlkKTtcblx0XHRcdGVsc2UgaWYgKGlzUm91dGVMb2NhdGlvbih2YWxpZCkpIHJlamVjdChjcmVhdGVSb3V0ZXJFcnJvcigyLCB7XG5cdFx0XHRcdGZyb206IHRvLFxuXHRcdFx0XHR0bzogdmFsaWRcblx0XHRcdH0pKTtcblx0XHRcdGVsc2Uge1xuXHRcdFx0XHRpZiAoZW50ZXJDYWxsYmFja0FycmF5ICYmIHJlY29yZC5lbnRlckNhbGxiYWNrc1tuYW1lXSA9PT0gZW50ZXJDYWxsYmFja0FycmF5ICYmIHR5cGVvZiB2YWxpZCA9PT0gXCJmdW5jdGlvblwiKSBlbnRlckNhbGxiYWNrQXJyYXkucHVzaCh2YWxpZCk7XG5cdFx0XHRcdHJlc29sdmUoKTtcblx0XHRcdH1cblx0XHR9O1xuXHRcdGNvbnN0IGd1YXJkUmV0dXJuID0gcnVuV2l0aENvbnRleHQoKCkgPT4gZ3VhcmQuY2FsbChyZWNvcmQgJiYgcmVjb3JkLmluc3RhbmNlc1tuYW1lXSwgdG8sIGZyb20sIHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IHdpdGhEZXByZWNhdGlvbldhcm5pbmcoY2FuT25seUJlQ2FsbGVkT25jZShuZXh0LCB0bywgZnJvbSkpIDogbmV4dCkpO1xuXHRcdGxldCBndWFyZENhbGwgPSBQcm9taXNlLnJlc29sdmUoZ3VhcmRSZXR1cm4pO1xuXHRcdGlmIChndWFyZC5sZW5ndGggPCAzKSBndWFyZENhbGwgPSBndWFyZENhbGwudGhlbihuZXh0KTtcblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIGd1YXJkLmxlbmd0aCA+IDIpIHtcblx0XHRcdGNvbnN0IGd1YXJkSW5mbyA9IHtcblx0XHRcdFx0bmFtZTogZ3VhcmQubmFtZSxcblx0XHRcdFx0Z3VhcmQ6IGd1YXJkLnRvU3RyaW5nKClcblx0XHRcdH07XG5cdFx0XHRpZiAodHlwZW9mIGd1YXJkUmV0dXJuID09PSBcIm9iamVjdFwiICYmIFwidGhlblwiIGluIGd1YXJkUmV0dXJuKSBndWFyZENhbGwgPSBndWFyZENhbGwudGhlbigocmVzb2x2ZWRWYWx1ZSkgPT4ge1xuXHRcdFx0XHRpZiAoIW5leHQuX2NhbGxlZCkge1xuXHRcdFx0XHRcdGRpYWdub3N0aWNzLlZVRV9ST1VURVJfUjAwMjMoZ3VhcmRJbmZvKTtcblx0XHRcdFx0XHRyZXR1cm4gUHJvbWlzZS5yZWplY3QoLyogQF9fUFVSRV9fICovIG5ldyBFcnJvcihcIkludmFsaWQgbmF2aWdhdGlvbiBndWFyZFwiKSk7XG5cdFx0XHRcdH1cblx0XHRcdFx0cmV0dXJuIHJlc29sdmVkVmFsdWU7XG5cdFx0XHR9KTtcblx0XHRcdGVsc2UgaWYgKGd1YXJkUmV0dXJuICE9PSB2b2lkIDApIHtcblx0XHRcdFx0aWYgKCFuZXh0Ll9jYWxsZWQpIHtcblx0XHRcdFx0XHRkaWFnbm9zdGljcy5WVUVfUk9VVEVSX1IwMDIzKGd1YXJkSW5mbyk7XG5cdFx0XHRcdFx0cmVqZWN0KC8qIEBfX1BVUkVfXyAqLyBuZXcgRXJyb3IoXCJJbnZhbGlkIG5hdmlnYXRpb24gZ3VhcmRcIikpO1xuXHRcdFx0XHRcdHJldHVybjtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblx0XHRndWFyZENhbGwuY2F0Y2goKGVycikgPT4gcmVqZWN0KGVycikpO1xuXHR9KTtcbn1cbi8qKlxuKiBXcmFwcyB0aGUgbmV4dCBjYWxsYmFjayB0byB3YXJuIHdoZW4gaXQgaXMgdXNlZC4gRGV2LW9ubHk6IHdoZW4gX19ERVZfXyBpc1xuKiBmYWxzZSAocHJvZHVjdGlvbiBidWlsZHMpLCB0aGlzIGJyYW5jaCBpcyBkZWFkIGNvZGUgYW5kIGlzIHN0cmlwcGVkIGZyb20gdGhlXG4qIGJ1bmRsZS5cbipcbiogQGludGVybmFsXG4qL1xuZnVuY3Rpb24gd2l0aERlcHJlY2F0aW9uV2FybmluZyhuZXh0KSB7XG5cdGxldCB3YXJuZWQgPSBmYWxzZTtcblx0cmV0dXJuIGZ1bmN0aW9uKCkge1xuXHRcdGlmICghd2FybmVkKSB7XG5cdFx0XHR3YXJuZWQgPSB0cnVlO1xuXHRcdFx0ZGlhZ25vc3RpY3MuVlVFX1JPVVRFUl9SMDAyNSgpO1xuXHRcdH1cblx0XHRyZXR1cm4gbmV4dC5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuXHR9O1xufVxuZnVuY3Rpb24gY2FuT25seUJlQ2FsbGVkT25jZShuZXh0LCB0bywgZnJvbSkge1xuXHRsZXQgY2FsbGVkID0gMDtcblx0cmV0dXJuIGZ1bmN0aW9uKCkge1xuXHRcdGlmIChjYWxsZWQrKyA9PT0gMSkgZGlhZ25vc3RpY3MuVlVFX1JPVVRFUl9SMDAyNCh7XG5cdFx0XHRmcm9tOiBmcm9tLmZ1bGxQYXRoLFxuXHRcdFx0dG86IHRvLmZ1bGxQYXRoXG5cdFx0fSk7XG5cdFx0bmV4dC5fY2FsbGVkID0gdHJ1ZTtcblx0XHRpZiAoY2FsbGVkID09PSAxKSBuZXh0LmFwcGx5KG51bGwsIGFyZ3VtZW50cyk7XG5cdH07XG59XG5mdW5jdGlvbiBleHRyYWN0Q29tcG9uZW50c0d1YXJkcyhtYXRjaGVkLCBndWFyZFR5cGUsIHRvLCBmcm9tLCBydW5XaXRoQ29udGV4dCA9IChmbikgPT4gZm4oKSkge1xuXHRjb25zdCBndWFyZHMgPSBbXTtcblx0Zm9yIChjb25zdCByZWNvcmQgb2YgbWF0Y2hlZCkge1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgIXJlY29yZC5jb21wb25lbnRzICYmIHJlY29yZC5jaGlsZHJlbiAmJiAhcmVjb3JkLmNoaWxkcmVuLmxlbmd0aCkgZGlhZ25vc3RpY3MuVlVFX1JPVVRFUl9SMDAyNih7IHBhdGg6IHJlY29yZC5wYXRoIH0pO1xuXHRcdGZvciAoY29uc3QgbmFtZSBpbiByZWNvcmQuY29tcG9uZW50cykge1xuXHRcdFx0bGV0IHJhd0NvbXBvbmVudCA9IHJlY29yZC5jb21wb25lbnRzW25hbWVdO1xuXHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuXHRcdFx0XHRpZiAoIXJhd0NvbXBvbmVudCB8fCB0eXBlb2YgcmF3Q29tcG9uZW50ICE9PSBcIm9iamVjdFwiICYmIHR5cGVvZiByYXdDb21wb25lbnQgIT09IFwiZnVuY3Rpb25cIikge1xuXHRcdFx0XHRcdGRpYWdub3N0aWNzLlZVRV9ST1VURVJfUjAwMjcoe1xuXHRcdFx0XHRcdFx0bmFtZSxcblx0XHRcdFx0XHRcdHBhdGg6IHJlY29yZC5wYXRoLFxuXHRcdFx0XHRcdFx0cmVjZWl2ZWQ6IFN0cmluZyhyYXdDb21wb25lbnQpXG5cdFx0XHRcdFx0fSk7XG5cdFx0XHRcdFx0dGhyb3cgbmV3IEVycm9yKFwiSW52YWxpZCByb3V0ZSBjb21wb25lbnRcIik7XG5cdFx0XHRcdH0gZWxzZSBpZiAoXCJ0aGVuXCIgaW4gcmF3Q29tcG9uZW50KSB7XG5cdFx0XHRcdFx0ZGlhZ25vc3RpY3MuVlVFX1JPVVRFUl9SMDAyOCh7XG5cdFx0XHRcdFx0XHRuYW1lLFxuXHRcdFx0XHRcdFx0cGF0aDogcmVjb3JkLnBhdGhcblx0XHRcdFx0XHR9KTtcblx0XHRcdFx0XHRjb25zdCBwcm9taXNlID0gcmF3Q29tcG9uZW50O1xuXHRcdFx0XHRcdHJhd0NvbXBvbmVudCA9ICgpID0+IHByb21pc2U7XG5cdFx0XHRcdH0gZWxzZSBpZiAocmF3Q29tcG9uZW50Ll9fYXN5bmNMb2FkZXIgJiYgIXJhd0NvbXBvbmVudC5fX3dhcm5lZERlZmluZUFzeW5jKSB7XG5cdFx0XHRcdFx0cmF3Q29tcG9uZW50Ll9fd2FybmVkRGVmaW5lQXN5bmMgPSB0cnVlO1xuXHRcdFx0XHRcdGRpYWdub3N0aWNzLlZVRV9ST1VURVJfUjAwMjkoe1xuXHRcdFx0XHRcdFx0bmFtZSxcblx0XHRcdFx0XHRcdHBhdGg6IHJlY29yZC5wYXRoXG5cdFx0XHRcdFx0fSk7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdGlmIChndWFyZFR5cGUgIT09IFwiYmVmb3JlUm91dGVFbnRlclwiICYmICFyZWNvcmQuaW5zdGFuY2VzW25hbWVdKSBjb250aW51ZTtcblx0XHRcdGlmIChpc1JvdXRlQ29tcG9uZW50KHJhd0NvbXBvbmVudCkpIHtcblx0XHRcdFx0Y29uc3QgZ3VhcmQgPSAocmF3Q29tcG9uZW50Ll9fdmNjT3B0cyB8fCByYXdDb21wb25lbnQpW2d1YXJkVHlwZV07XG5cdFx0XHRcdGd1YXJkICYmIGd1YXJkcy5wdXNoKGd1YXJkVG9Qcm9taXNlRm4oZ3VhcmQsIHRvLCBmcm9tLCByZWNvcmQsIG5hbWUsIHJ1bldpdGhDb250ZXh0KSk7XG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRsZXQgY29tcG9uZW50UHJvbWlzZSA9IHJhd0NvbXBvbmVudCgpO1xuXHRcdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmICEoXCJjYXRjaFwiIGluIGNvbXBvbmVudFByb21pc2UpKSB7XG5cdFx0XHRcdFx0ZGlhZ25vc3RpY3MuVlVFX1JPVVRFUl9SMDAzMCh7XG5cdFx0XHRcdFx0XHRuYW1lLFxuXHRcdFx0XHRcdFx0cGF0aDogcmVjb3JkLnBhdGhcblx0XHRcdFx0XHR9KTtcblx0XHRcdFx0XHRjb21wb25lbnRQcm9taXNlID0gUHJvbWlzZS5yZXNvbHZlKGNvbXBvbmVudFByb21pc2UpO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGd1YXJkcy5wdXNoKCgpID0+IGNvbXBvbmVudFByb21pc2UudGhlbigocmVzb2x2ZWQpID0+IHtcblx0XHRcdFx0XHRpZiAoIXJlc29sdmVkKSB0aHJvdyBuZXcgRXJyb3IoYENvdWxkbid0IHJlc29sdmUgY29tcG9uZW50IFwiJHtuYW1lfVwiIGF0IFwiJHtyZWNvcmQucGF0aH1cImApO1xuXHRcdFx0XHRcdGNvbnN0IHJlc29sdmVkQ29tcG9uZW50ID0gaXNFU01vZHVsZShyZXNvbHZlZCkgPyByZXNvbHZlZC5kZWZhdWx0IDogcmVzb2x2ZWQ7XG5cdFx0XHRcdFx0cmVjb3JkLm1vZHNbbmFtZV0gPSByZXNvbHZlZDtcblx0XHRcdFx0XHRyZWNvcmQuY29tcG9uZW50c1tuYW1lXSA9IHJlc29sdmVkQ29tcG9uZW50O1xuXHRcdFx0XHRcdGNvbnN0IGd1YXJkID0gKHJlc29sdmVkQ29tcG9uZW50Ll9fdmNjT3B0cyB8fCByZXNvbHZlZENvbXBvbmVudClbZ3VhcmRUeXBlXTtcblx0XHRcdFx0XHRyZXR1cm4gZ3VhcmQgJiYgZ3VhcmRUb1Byb21pc2VGbihndWFyZCwgdG8sIGZyb20sIHJlY29yZCwgbmFtZSwgcnVuV2l0aENvbnRleHQpKCk7XG5cdFx0XHRcdH0pKTtcblx0XHRcdH1cblx0XHR9XG5cdH1cblx0cmV0dXJuIGd1YXJkcztcbn1cbi8qKlxuKiBFbnN1cmVzIGEgcm91dGUgaXMgbG9hZGVkLCBzbyBpdCBjYW4gYmUgcGFzc2VkIGFzIG8gcHJvcCB0byBgPFJvdXRlclZpZXc+YC5cbipcbiogQHBhcmFtIHJvdXRlIC0gcmVzb2x2ZWQgcm91dGUgdG8gbG9hZFxuKi9cbmZ1bmN0aW9uIGxvYWRSb3V0ZUxvY2F0aW9uKHJvdXRlKSB7XG5cdHJldHVybiByb3V0ZS5tYXRjaGVkLmV2ZXJ5KChyZWNvcmQpID0+IHJlY29yZC5yZWRpcmVjdCkgPyBQcm9taXNlLnJlamVjdCgvKiBAX19QVVJFX18gKi8gbmV3IEVycm9yKFwiQ2Fubm90IGxvYWQgYSByb3V0ZSB0aGF0IHJlZGlyZWN0cy5cIikpIDogUHJvbWlzZS5hbGwocm91dGUubWF0Y2hlZC5tYXAoKHJlY29yZCkgPT4gcmVjb3JkLmNvbXBvbmVudHMgJiYgUHJvbWlzZS5hbGwoT2JqZWN0LmtleXMocmVjb3JkLmNvbXBvbmVudHMpLnJlZHVjZSgocHJvbWlzZXMsIG5hbWUpID0+IHtcblx0XHRjb25zdCByYXdDb21wb25lbnQgPSByZWNvcmQuY29tcG9uZW50c1tuYW1lXTtcblx0XHRpZiAodHlwZW9mIHJhd0NvbXBvbmVudCA9PT0gXCJmdW5jdGlvblwiICYmICEoXCJkaXNwbGF5TmFtZVwiIGluIHJhd0NvbXBvbmVudCkpIHByb21pc2VzLnB1c2gocmF3Q29tcG9uZW50KCkudGhlbigocmVzb2x2ZWQpID0+IHtcblx0XHRcdGlmICghcmVzb2x2ZWQpIHJldHVybiBQcm9taXNlLnJlamVjdCgvKiBAX19QVVJFX18gKi8gbmV3IEVycm9yKGBDb3VsZG4ndCByZXNvbHZlIGNvbXBvbmVudCBcIiR7bmFtZX1cIiBhdCBcIiR7cmVjb3JkLnBhdGh9XCIuIEVuc3VyZSB5b3UgcGFzc2VkIGEgZnVuY3Rpb24gdGhhdCByZXR1cm5zIGEgcHJvbWlzZS5gKSk7XG5cdFx0XHRjb25zdCByZXNvbHZlZENvbXBvbmVudCA9IGlzRVNNb2R1bGUocmVzb2x2ZWQpID8gcmVzb2x2ZWQuZGVmYXVsdCA6IHJlc29sdmVkO1xuXHRcdFx0cmVjb3JkLm1vZHNbbmFtZV0gPSByZXNvbHZlZDtcblx0XHRcdHJlY29yZC5jb21wb25lbnRzW25hbWVdID0gcmVzb2x2ZWRDb21wb25lbnQ7XG5cdFx0fSkpO1xuXHRcdHJldHVybiBwcm9taXNlcztcblx0fSwgW10pKSkpLnRoZW4oKCkgPT4gcm91dGUpO1xufVxuLyoqXG4qIFNwbGl0IHRoZSBsZWF2aW5nLCB1cGRhdGluZywgYW5kIGVudGVyaW5nIHJlY29yZHMuXG4qIEBpbnRlcm5hbFxuKlxuKiBAcGFyYW0gIHRvIC0gTG9jYXRpb24gd2UgYXJlIG5hdmlnYXRpbmcgdG9cbiogQHBhcmFtIGZyb20gLSBMb2NhdGlvbiB3ZSBhcmUgbmF2aWdhdGluZyBmcm9tXG4qL1xuZnVuY3Rpb24gZXh0cmFjdENoYW5naW5nUmVjb3Jkcyh0bywgZnJvbSkge1xuXHRjb25zdCBsZWF2aW5nUmVjb3JkcyA9IFtdO1xuXHRjb25zdCB1cGRhdGluZ1JlY29yZHMgPSBbXTtcblx0Y29uc3QgZW50ZXJpbmdSZWNvcmRzID0gW107XG5cdGNvbnN0IGxlbiA9IE1hdGgubWF4KGZyb20ubWF0Y2hlZC5sZW5ndGgsIHRvLm1hdGNoZWQubGVuZ3RoKTtcblx0Zm9yIChsZXQgaSA9IDA7IGkgPCBsZW47IGkrKykge1xuXHRcdGNvbnN0IHJlY29yZEZyb20gPSBmcm9tLm1hdGNoZWRbaV07XG5cdFx0aWYgKHJlY29yZEZyb20pIHtcblx0XHRcdGlmICh0by5tYXRjaGVkLmZpbmQoKHJlY29yZCkgPT4gaXNTYW1lUm91dGVSZWNvcmQocmVjb3JkLCByZWNvcmRGcm9tKSkpIHVwZGF0aW5nUmVjb3Jkcy5wdXNoKHJlY29yZEZyb20pO1xuXHRcdFx0ZWxzZSBsZWF2aW5nUmVjb3Jkcy5wdXNoKHJlY29yZEZyb20pO1xuXHRcdH1cblx0XHRjb25zdCByZWNvcmRUbyA9IHRvLm1hdGNoZWRbaV07XG5cdFx0aWYgKHJlY29yZFRvKSB7XG5cdFx0XHRpZiAoIWZyb20ubWF0Y2hlZC5maW5kKChyZWNvcmQpID0+IGlzU2FtZVJvdXRlUmVjb3JkKHJlY29yZCwgcmVjb3JkVG8pKSkgZW50ZXJpbmdSZWNvcmRzLnB1c2gocmVjb3JkVG8pO1xuXHRcdH1cblx0fVxuXHRyZXR1cm4gW1xuXHRcdGxlYXZpbmdSZWNvcmRzLFxuXHRcdHVwZGF0aW5nUmVjb3Jkcyxcblx0XHRlbnRlcmluZ1JlY29yZHNcblx0XTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9kZXZ0b29scy50c1xuLyoqXG4qIENvcGllcyBhIHJvdXRlIGxvY2F0aW9uIGFuZCByZW1vdmVzIGFueSBwcm9ibGVtYXRpYyBwcm9wZXJ0aWVzIHRoYXQgY2Fubm90IGJlIHNob3duIGluIGRldnRvb2xzIChlLmcuIFZ1ZSBpbnN0YW5jZXMpLlxuKlxuKiBAcGFyYW0gcm91dGVMb2NhdGlvbiAtIHJvdXRlTG9jYXRpb24gdG8gZm9ybWF0XG4qIEBwYXJhbSB0b29sdGlwIC0gb3B0aW9uYWwgdG9vbHRpcFxuKiBAcmV0dXJucyBhIGNvcHkgb2YgdGhlIHJvdXRlTG9jYXRpb25cbiovXG5mdW5jdGlvbiBmb3JtYXRSb3V0ZUxvY2F0aW9uKHJvdXRlTG9jYXRpb24sIHRvb2x0aXApIHtcblx0Y29uc3QgY29weSA9IGFzc2lnbih7fSwgcm91dGVMb2NhdGlvbiwgeyBtYXRjaGVkOiByb3V0ZUxvY2F0aW9uLm1hdGNoZWQubWFwKChtYXRjaGVkKSA9PiBvbWl0KG1hdGNoZWQsIFtcblx0XHRcImluc3RhbmNlc1wiLFxuXHRcdFwiY2hpbGRyZW5cIixcblx0XHRcImFsaWFzT2ZcIlxuXHRdKSkgfSk7XG5cdHJldHVybiB7IF9jdXN0b206IHtcblx0XHR0eXBlOiBudWxsLFxuXHRcdHJlYWRPbmx5OiB0cnVlLFxuXHRcdGRpc3BsYXk6IHJvdXRlTG9jYXRpb24uZnVsbFBhdGgsXG5cdFx0dG9vbHRpcCxcblx0XHR2YWx1ZTogY29weVxuXHR9IH07XG59XG5mdW5jdGlvbiBmb3JtYXREaXNwbGF5KGRpc3BsYXkpIHtcblx0cmV0dXJuIHsgX2N1c3RvbTogeyBkaXNwbGF5IH0gfTtcbn1cbmxldCByb3V0ZXJJZCA9IDA7XG5mdW5jdGlvbiBhZGREZXZ0b29scyhhcHAsIHJvdXRlciwgbWF0Y2hlcikge1xuXHRpZiAocm91dGVyLl9faGFzRGV2dG9vbHMpIHJldHVybjtcblx0cm91dGVyLl9faGFzRGV2dG9vbHMgPSB0cnVlO1xuXHRjb25zdCBpZCA9IHJvdXRlcklkKys7XG5cdHNldHVwRGV2dG9vbHNQbHVnaW4oe1xuXHRcdGlkOiBcIm9yZy52dWVqcy5yb3V0ZXJcIiArIChpZCA/IFwiLlwiICsgaWQgOiBcIlwiKSxcblx0XHRsYWJlbDogXCJWdWUgUm91dGVyXCIsXG5cdFx0cGFja2FnZU5hbWU6IFwidnVlLXJvdXRlclwiLFxuXHRcdGhvbWVwYWdlOiBcImh0dHBzOi8vcm91dGVyLnZ1ZWpzLm9yZ1wiLFxuXHRcdGxvZ286IFwiaHR0cHM6Ly9yb3V0ZXIudnVlanMub3JnL2xvZ28ucG5nXCIsXG5cdFx0Y29tcG9uZW50U3RhdGVUeXBlczogW1wiUm91dGluZ1wiXSxcblx0XHRhcHBcblx0fSwgKGFwaSkgPT4ge1xuXHRcdGFwaS5vbi5pbnNwZWN0Q29tcG9uZW50KChwYXlsb2FkKSA9PiB7XG5cdFx0XHRpZiAocGF5bG9hZC5pbnN0YW5jZURhdGEpIHBheWxvYWQuaW5zdGFuY2VEYXRhLnN0YXRlLnB1c2goe1xuXHRcdFx0XHR0eXBlOiBcIlJvdXRpbmdcIixcblx0XHRcdFx0a2V5OiBcIiRyb3V0ZVwiLFxuXHRcdFx0XHRlZGl0YWJsZTogZmFsc2UsXG5cdFx0XHRcdHZhbHVlOiBmb3JtYXRSb3V0ZUxvY2F0aW9uKHJvdXRlci5jdXJyZW50Um91dGUudmFsdWUsIFwiQ3VycmVudCBSb3V0ZVwiKVxuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdFx0YXBpLm9uLnZpc2l0Q29tcG9uZW50VHJlZSgoeyB0cmVlTm9kZTogbm9kZSwgY29tcG9uZW50SW5zdGFuY2UgfSkgPT4ge1xuXHRcdFx0aWYgKGNvbXBvbmVudEluc3RhbmNlLl9fdnJ2X2RldnRvb2xzKSB7XG5cdFx0XHRcdGNvbnN0IGluZm8gPSBjb21wb25lbnRJbnN0YW5jZS5fX3Zydl9kZXZ0b29scztcblx0XHRcdFx0bm9kZS50YWdzLnB1c2goe1xuXHRcdFx0XHRcdGxhYmVsOiAoaW5mby5uYW1lID8gYCR7aW5mby5uYW1lLnRvU3RyaW5nKCl9OiBgIDogXCJcIikgKyBpbmZvLnBhdGgsXG5cdFx0XHRcdFx0dGV4dENvbG9yOiAwLFxuXHRcdFx0XHRcdHRvb2x0aXA6IFwiVGhpcyBjb21wb25lbnQgaXMgcmVuZGVyZWQgYnkgJmx0O3JvdXRlci12aWV3Jmd0O1wiLFxuXHRcdFx0XHRcdGJhY2tncm91bmRDb2xvcjogUElOS181MDBcblx0XHRcdFx0fSk7XG5cdFx0XHR9XG5cdFx0XHRpZiAoaXNBcnJheShjb21wb25lbnRJbnN0YW5jZS5fX3ZybF9kZXZ0b29scykpIHtcblx0XHRcdFx0Y29tcG9uZW50SW5zdGFuY2UuX19kZXZ0b29sc0FwaSA9IGFwaTtcblx0XHRcdFx0Y29tcG9uZW50SW5zdGFuY2UuX192cmxfZGV2dG9vbHMuZm9yRWFjaCgoZGV2dG9vbHNEYXRhKSA9PiB7XG5cdFx0XHRcdFx0bGV0IGxhYmVsID0gZGV2dG9vbHNEYXRhLnJvdXRlLnBhdGg7XG5cdFx0XHRcdFx0bGV0IGJhY2tncm91bmRDb2xvciA9IE9SQU5HRV80MDA7XG5cdFx0XHRcdFx0bGV0IHRvb2x0aXAgPSBcIlwiO1xuXHRcdFx0XHRcdGxldCB0ZXh0Q29sb3IgPSAwO1xuXHRcdFx0XHRcdGlmIChkZXZ0b29sc0RhdGEuZXJyb3IpIHtcblx0XHRcdFx0XHRcdGxhYmVsID0gZGV2dG9vbHNEYXRhLmVycm9yO1xuXHRcdFx0XHRcdFx0YmFja2dyb3VuZENvbG9yID0gUkVEXzEwMDtcblx0XHRcdFx0XHRcdHRleHRDb2xvciA9IFJFRF83MDA7XG5cdFx0XHRcdFx0fSBlbHNlIGlmIChkZXZ0b29sc0RhdGEuaXNFeGFjdEFjdGl2ZSkge1xuXHRcdFx0XHRcdFx0YmFja2dyb3VuZENvbG9yID0gTElNRV81MDA7XG5cdFx0XHRcdFx0XHR0b29sdGlwID0gXCJUaGlzIGlzIGV4YWN0bHkgYWN0aXZlXCI7XG5cdFx0XHRcdFx0fSBlbHNlIGlmIChkZXZ0b29sc0RhdGEuaXNBY3RpdmUpIHtcblx0XHRcdFx0XHRcdGJhY2tncm91bmRDb2xvciA9IEJMVUVfNjAwO1xuXHRcdFx0XHRcdFx0dG9vbHRpcCA9IFwiVGhpcyBsaW5rIGlzIGFjdGl2ZVwiO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRub2RlLnRhZ3MucHVzaCh7XG5cdFx0XHRcdFx0XHRsYWJlbCxcblx0XHRcdFx0XHRcdHRleHRDb2xvcixcblx0XHRcdFx0XHRcdHRvb2x0aXAsXG5cdFx0XHRcdFx0XHRiYWNrZ3JvdW5kQ29sb3Jcblx0XHRcdFx0XHR9KTtcblx0XHRcdFx0fSk7XG5cdFx0XHR9XG5cdFx0fSk7XG5cdFx0d2F0Y2gocm91dGVyLmN1cnJlbnRSb3V0ZSwgKCkgPT4ge1xuXHRcdFx0cmVmcmVzaFJvdXRlc1ZpZXcoKTtcblx0XHRcdGFwaS5ub3RpZnlDb21wb25lbnRVcGRhdGUoKTtcblx0XHRcdGFwaS5zZW5kSW5zcGVjdG9yVHJlZShyb3V0ZXJJbnNwZWN0b3JJZCk7XG5cdFx0XHRhcGkuc2VuZEluc3BlY3RvclN0YXRlKHJvdXRlckluc3BlY3RvcklkKTtcblx0XHR9KTtcblx0XHRjb25zdCBuYXZpZ2F0aW9uc0xheWVySWQgPSBcInJvdXRlcjpuYXZpZ2F0aW9uczpcIiArIGlkO1xuXHRcdGFwaS5hZGRUaW1lbGluZUxheWVyKHtcblx0XHRcdGlkOiBuYXZpZ2F0aW9uc0xheWVySWQsXG5cdFx0XHRsYWJlbDogYFJvdXRlciR7aWQgPyBcIiBcIiArIGlkIDogXCJcIn0gTmF2aWdhdGlvbnNgLFxuXHRcdFx0Y29sb3I6IDQyMzc1MDhcblx0XHR9KTtcblx0XHRyb3V0ZXIub25FcnJvcigoZXJyb3IsIHRvKSA9PiB7XG5cdFx0XHRhcGkuYWRkVGltZWxpbmVFdmVudCh7XG5cdFx0XHRcdGxheWVySWQ6IG5hdmlnYXRpb25zTGF5ZXJJZCxcblx0XHRcdFx0ZXZlbnQ6IHtcblx0XHRcdFx0XHR0aXRsZTogXCJFcnJvciBkdXJpbmcgTmF2aWdhdGlvblwiLFxuXHRcdFx0XHRcdHN1YnRpdGxlOiB0by5mdWxsUGF0aCxcblx0XHRcdFx0XHRsb2dUeXBlOiBcImVycm9yXCIsXG5cdFx0XHRcdFx0dGltZTogYXBpLm5vdygpLFxuXHRcdFx0XHRcdGRhdGE6IHsgZXJyb3IgfSxcblx0XHRcdFx0XHRncm91cElkOiB0by5tZXRhLl9fbmF2aWdhdGlvbklkXG5cdFx0XHRcdH1cblx0XHRcdH0pO1xuXHRcdH0pO1xuXHRcdGxldCBuYXZpZ2F0aW9uSWQgPSAwO1xuXHRcdHJvdXRlci5iZWZvcmVFYWNoKCh0bywgZnJvbSkgPT4ge1xuXHRcdFx0Y29uc3QgZGF0YSA9IHtcblx0XHRcdFx0Z3VhcmQ6IGZvcm1hdERpc3BsYXkoXCJiZWZvcmVFYWNoXCIpLFxuXHRcdFx0XHRmcm9tOiBmb3JtYXRSb3V0ZUxvY2F0aW9uKGZyb20sIFwiQ3VycmVudCBMb2NhdGlvbiBkdXJpbmcgdGhpcyBuYXZpZ2F0aW9uXCIpLFxuXHRcdFx0XHR0bzogZm9ybWF0Um91dGVMb2NhdGlvbih0bywgXCJUYXJnZXQgbG9jYXRpb25cIilcblx0XHRcdH07XG5cdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkodG8ubWV0YSwgXCJfX25hdmlnYXRpb25JZFwiLCB7IHZhbHVlOiBuYXZpZ2F0aW9uSWQrKyB9KTtcblx0XHRcdGFwaS5hZGRUaW1lbGluZUV2ZW50KHtcblx0XHRcdFx0bGF5ZXJJZDogbmF2aWdhdGlvbnNMYXllcklkLFxuXHRcdFx0XHRldmVudDoge1xuXHRcdFx0XHRcdHRpbWU6IGFwaS5ub3coKSxcblx0XHRcdFx0XHR0aXRsZTogXCJTdGFydCBvZiBuYXZpZ2F0aW9uXCIsXG5cdFx0XHRcdFx0c3VidGl0bGU6IHRvLmZ1bGxQYXRoLFxuXHRcdFx0XHRcdGRhdGEsXG5cdFx0XHRcdFx0Z3JvdXBJZDogdG8ubWV0YS5fX25hdmlnYXRpb25JZFxuXHRcdFx0XHR9XG5cdFx0XHR9KTtcblx0XHR9KTtcblx0XHRyb3V0ZXIuYWZ0ZXJFYWNoKCh0bywgZnJvbSwgZmFpbHVyZSkgPT4ge1xuXHRcdFx0Y29uc3QgZGF0YSA9IHsgZ3VhcmQ6IGZvcm1hdERpc3BsYXkoXCJhZnRlckVhY2hcIikgfTtcblx0XHRcdGlmIChmYWlsdXJlKSB7XG5cdFx0XHRcdGRhdGEuZmFpbHVyZSA9IHsgX2N1c3RvbToge1xuXHRcdFx0XHRcdHR5cGU6IEVycm9yLFxuXHRcdFx0XHRcdHJlYWRPbmx5OiB0cnVlLFxuXHRcdFx0XHRcdGRpc3BsYXk6IGZhaWx1cmUgPyBmYWlsdXJlLm1lc3NhZ2UgOiBcIlwiLFxuXHRcdFx0XHRcdHRvb2x0aXA6IFwiTmF2aWdhdGlvbiBGYWlsdXJlXCIsXG5cdFx0XHRcdFx0dmFsdWU6IGZhaWx1cmVcblx0XHRcdFx0fSB9O1xuXHRcdFx0XHRkYXRhLnN0YXR1cyA9IGZvcm1hdERpc3BsYXkoXCLinYxcIik7XG5cdFx0XHR9IGVsc2UgZGF0YS5zdGF0dXMgPSBmb3JtYXREaXNwbGF5KFwi4pyFXCIpO1xuXHRcdFx0ZGF0YS5mcm9tID0gZm9ybWF0Um91dGVMb2NhdGlvbihmcm9tLCBcIkN1cnJlbnQgTG9jYXRpb24gZHVyaW5nIHRoaXMgbmF2aWdhdGlvblwiKTtcblx0XHRcdGRhdGEudG8gPSBmb3JtYXRSb3V0ZUxvY2F0aW9uKHRvLCBcIlRhcmdldCBsb2NhdGlvblwiKTtcblx0XHRcdGFwaS5hZGRUaW1lbGluZUV2ZW50KHtcblx0XHRcdFx0bGF5ZXJJZDogbmF2aWdhdGlvbnNMYXllcklkLFxuXHRcdFx0XHRldmVudDoge1xuXHRcdFx0XHRcdHRpdGxlOiBcIkVuZCBvZiBuYXZpZ2F0aW9uXCIsXG5cdFx0XHRcdFx0c3VidGl0bGU6IHRvLmZ1bGxQYXRoLFxuXHRcdFx0XHRcdHRpbWU6IGFwaS5ub3coKSxcblx0XHRcdFx0XHRkYXRhLFxuXHRcdFx0XHRcdGxvZ1R5cGU6IGZhaWx1cmUgPyBcIndhcm5pbmdcIiA6IFwiZGVmYXVsdFwiLFxuXHRcdFx0XHRcdGdyb3VwSWQ6IHRvLm1ldGEuX19uYXZpZ2F0aW9uSWRcblx0XHRcdFx0fVxuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdFx0LyoqXG5cdFx0KiBJbnNwZWN0b3Igb2YgRXhpc3Rpbmcgcm91dGVzXG5cdFx0Ki9cblx0XHRjb25zdCByb3V0ZXJJbnNwZWN0b3JJZCA9IFwicm91dGVyLWluc3BlY3RvcjpcIiArIGlkO1xuXHRcdGFwaS5hZGRJbnNwZWN0b3Ioe1xuXHRcdFx0aWQ6IHJvdXRlckluc3BlY3RvcklkLFxuXHRcdFx0bGFiZWw6IFwiUm91dGVzXCIgKyAoaWQgPyBcIiBcIiArIGlkIDogXCJcIiksXG5cdFx0XHRpY29uOiBcImJvb2tcIixcblx0XHRcdHRyZWVGaWx0ZXJQbGFjZWhvbGRlcjogXCJTZWFyY2ggcm91dGVzXCJcblx0XHR9KTtcblx0XHRmdW5jdGlvbiByZWZyZXNoUm91dGVzVmlldygpIHtcblx0XHRcdGlmICghYWN0aXZlUm91dGVzUGF5bG9hZCkgcmV0dXJuO1xuXHRcdFx0Y29uc3QgcGF5bG9hZCA9IGFjdGl2ZVJvdXRlc1BheWxvYWQ7XG5cdFx0XHRsZXQgcm91dGVzID0gbWF0Y2hlci5nZXRSb3V0ZXMoKS5maWx0ZXIoKHJvdXRlKSA9PiAhcm91dGUucGFyZW50IHx8ICFyb3V0ZS5wYXJlbnQucmVjb3JkLmNvbXBvbmVudHMpO1xuXHRcdFx0cm91dGVzLmZvckVhY2gocmVzZXRNYXRjaFN0YXRlT25Sb3V0ZVJlY29yZCk7XG5cdFx0XHRpZiAocGF5bG9hZC5maWx0ZXIpIHJvdXRlcyA9IHJvdXRlcy5maWx0ZXIoKHJvdXRlKSA9PiBpc1JvdXRlTWF0Y2hpbmcocm91dGUsIHBheWxvYWQuZmlsdGVyLnRvTG93ZXJDYXNlKCkpKTtcblx0XHRcdHJvdXRlcy5mb3JFYWNoKChyb3V0ZSkgPT4gbWFya1JvdXRlUmVjb3JkQWN0aXZlKHJvdXRlLCByb3V0ZXIuY3VycmVudFJvdXRlLnZhbHVlKSk7XG5cdFx0XHRwYXlsb2FkLnJvb3ROb2RlcyA9IHJvdXRlcy5tYXAoZm9ybWF0Um91dGVSZWNvcmRGb3JJbnNwZWN0b3IpO1xuXHRcdH1cblx0XHRsZXQgYWN0aXZlUm91dGVzUGF5bG9hZDtcblx0XHRhcGkub24uZ2V0SW5zcGVjdG9yVHJlZSgocGF5bG9hZCkgPT4ge1xuXHRcdFx0YWN0aXZlUm91dGVzUGF5bG9hZCA9IHBheWxvYWQ7XG5cdFx0XHRpZiAocGF5bG9hZC5hcHAgPT09IGFwcCAmJiBwYXlsb2FkLmluc3BlY3RvcklkID09PSByb3V0ZXJJbnNwZWN0b3JJZCkgcmVmcmVzaFJvdXRlc1ZpZXcoKTtcblx0XHR9KTtcblx0XHQvKipcblx0XHQqIERpc3BsYXkgaW5mb3JtYXRpb24gYWJvdXQgdGhlIGN1cnJlbnRseSBzZWxlY3RlZCByb3V0ZSByZWNvcmRcblx0XHQqL1xuXHRcdGFwaS5vbi5nZXRJbnNwZWN0b3JTdGF0ZSgocGF5bG9hZCkgPT4ge1xuXHRcdFx0aWYgKHBheWxvYWQuYXBwID09PSBhcHAgJiYgcGF5bG9hZC5pbnNwZWN0b3JJZCA9PT0gcm91dGVySW5zcGVjdG9ySWQpIHtcblx0XHRcdFx0Y29uc3Qgcm91dGUgPSBtYXRjaGVyLmdldFJvdXRlcygpLmZpbmQoKHJvdXRlKSA9PiByb3V0ZS5yZWNvcmQuX192ZF9pZCA9PT0gcGF5bG9hZC5ub2RlSWQpO1xuXHRcdFx0XHRpZiAocm91dGUpIHBheWxvYWQuc3RhdGUgPSB7IG9wdGlvbnM6IGZvcm1hdFJvdXRlUmVjb3JkTWF0Y2hlckZvclN0YXRlSW5zcGVjdG9yKHJvdXRlKSB9O1xuXHRcdFx0fVxuXHRcdH0pO1xuXHRcdGFwaS5zZW5kSW5zcGVjdG9yVHJlZShyb3V0ZXJJbnNwZWN0b3JJZCk7XG5cdFx0YXBpLnNlbmRJbnNwZWN0b3JTdGF0ZShyb3V0ZXJJbnNwZWN0b3JJZCk7XG5cdH0pO1xufVxuZnVuY3Rpb24gbW9kaWZpZXJGb3JLZXkoa2V5KSB7XG5cdGlmIChrZXkub3B0aW9uYWwpIHJldHVybiBrZXkucmVwZWF0YWJsZSA/IFwiKlwiIDogXCI/XCI7XG5cdGVsc2UgcmV0dXJuIGtleS5yZXBlYXRhYmxlID8gXCIrXCIgOiBcIlwiO1xufVxuZnVuY3Rpb24gZm9ybWF0Um91dGVSZWNvcmRNYXRjaGVyRm9yU3RhdGVJbnNwZWN0b3Iocm91dGUpIHtcblx0Y29uc3QgeyByZWNvcmQgfSA9IHJvdXRlO1xuXHRjb25zdCBmaWVsZHMgPSBbe1xuXHRcdGVkaXRhYmxlOiBmYWxzZSxcblx0XHRrZXk6IFwicGF0aFwiLFxuXHRcdHZhbHVlOiByZWNvcmQucGF0aFxuXHR9XTtcblx0aWYgKHJlY29yZC5uYW1lICE9IG51bGwpIGZpZWxkcy5wdXNoKHtcblx0XHRlZGl0YWJsZTogZmFsc2UsXG5cdFx0a2V5OiBcIm5hbWVcIixcblx0XHR2YWx1ZTogcmVjb3JkLm5hbWVcblx0fSk7XG5cdGZpZWxkcy5wdXNoKHtcblx0XHRlZGl0YWJsZTogZmFsc2UsXG5cdFx0a2V5OiBcInJlZ2V4cFwiLFxuXHRcdHZhbHVlOiByb3V0ZS5yZVxuXHR9KTtcblx0aWYgKHJvdXRlLmtleXMubGVuZ3RoKSBmaWVsZHMucHVzaCh7XG5cdFx0ZWRpdGFibGU6IGZhbHNlLFxuXHRcdGtleTogXCJrZXlzXCIsXG5cdFx0dmFsdWU6IHsgX2N1c3RvbToge1xuXHRcdFx0dHlwZTogbnVsbCxcblx0XHRcdHJlYWRPbmx5OiB0cnVlLFxuXHRcdFx0ZGlzcGxheTogcm91dGUua2V5cy5tYXAoKGtleSkgPT4gYCR7a2V5Lm5hbWV9JHttb2RpZmllckZvcktleShrZXkpfWApLmpvaW4oXCIgXCIpLFxuXHRcdFx0dG9vbHRpcDogXCJQYXJhbSBrZXlzXCIsXG5cdFx0XHR2YWx1ZTogcm91dGUua2V5c1xuXHRcdH0gfVxuXHR9KTtcblx0aWYgKHJlY29yZC5yZWRpcmVjdCAhPSBudWxsKSBmaWVsZHMucHVzaCh7XG5cdFx0ZWRpdGFibGU6IGZhbHNlLFxuXHRcdGtleTogXCJyZWRpcmVjdFwiLFxuXHRcdHZhbHVlOiByZWNvcmQucmVkaXJlY3Rcblx0fSk7XG5cdGlmIChyb3V0ZS5hbGlhcy5sZW5ndGgpIGZpZWxkcy5wdXNoKHtcblx0XHRlZGl0YWJsZTogZmFsc2UsXG5cdFx0a2V5OiBcImFsaWFzZXNcIixcblx0XHR2YWx1ZTogcm91dGUuYWxpYXMubWFwKChhbGlhcykgPT4gYWxpYXMucmVjb3JkLnBhdGgpXG5cdH0pO1xuXHRpZiAoT2JqZWN0LmtleXMocm91dGUucmVjb3JkLm1ldGEpLmxlbmd0aCkgZmllbGRzLnB1c2goe1xuXHRcdGVkaXRhYmxlOiBmYWxzZSxcblx0XHRrZXk6IFwibWV0YVwiLFxuXHRcdHZhbHVlOiByb3V0ZS5yZWNvcmQubWV0YVxuXHR9KTtcblx0ZmllbGRzLnB1c2goe1xuXHRcdGtleTogXCJzY29yZVwiLFxuXHRcdGVkaXRhYmxlOiBmYWxzZSxcblx0XHR2YWx1ZTogeyBfY3VzdG9tOiB7XG5cdFx0XHR0eXBlOiBudWxsLFxuXHRcdFx0cmVhZE9ubHk6IHRydWUsXG5cdFx0XHRkaXNwbGF5OiByb3V0ZS5zY29yZS5tYXAoKHNjb3JlKSA9PiBzY29yZS5qb2luKFwiLCBcIikpLmpvaW4oXCIgfCBcIiksXG5cdFx0XHR0b29sdGlwOiBcIlNjb3JlIHVzZWQgdG8gc29ydCByb3V0ZXNcIixcblx0XHRcdHZhbHVlOiByb3V0ZS5zY29yZVxuXHRcdH0gfVxuXHR9KTtcblx0cmV0dXJuIGZpZWxkcztcbn1cbi8qKlxuKiBFeHRyYWN0ZWQgZnJvbSB0YWlsd2luZCBwYWxldHRlXG4qL1xuY29uc3QgUElOS181MDAgPSAxNTQ4NTA4MTtcbmNvbnN0IEJMVUVfNjAwID0gMjQ1MDQxMTtcbmNvbnN0IExJTUVfNTAwID0gODcwMjk5ODtcbmNvbnN0IENZQU5fNDAwID0gMjI4MjQ3ODtcbmNvbnN0IE9SQU5HRV80MDAgPSAxNjQ4Njk3MjtcbmNvbnN0IERBUksgPSA2NzEwODg2O1xuY29uc3QgUkVEXzEwMCA9IDE2NzA0MjI2O1xuY29uc3QgUkVEXzcwMCA9IDEyMTMxMzU2O1xuZnVuY3Rpb24gZm9ybWF0Um91dGVSZWNvcmRGb3JJbnNwZWN0b3Iocm91dGUpIHtcblx0Y29uc3QgdGFncyA9IFtdO1xuXHRjb25zdCB7IHJlY29yZCB9ID0gcm91dGU7XG5cdGlmIChyZWNvcmQubmFtZSAhPSBudWxsKSB0YWdzLnB1c2goe1xuXHRcdGxhYmVsOiBTdHJpbmcocmVjb3JkLm5hbWUpLFxuXHRcdHRleHRDb2xvcjogMCxcblx0XHRiYWNrZ3JvdW5kQ29sb3I6IENZQU5fNDAwXG5cdH0pO1xuXHRpZiAocmVjb3JkLmFsaWFzT2YpIHRhZ3MucHVzaCh7XG5cdFx0bGFiZWw6IFwiYWxpYXNcIixcblx0XHR0ZXh0Q29sb3I6IDAsXG5cdFx0YmFja2dyb3VuZENvbG9yOiBPUkFOR0VfNDAwXG5cdH0pO1xuXHRpZiAocm91dGUuX192ZF9tYXRjaCkgdGFncy5wdXNoKHtcblx0XHRsYWJlbDogXCJtYXRjaGVzXCIsXG5cdFx0dGV4dENvbG9yOiAwLFxuXHRcdGJhY2tncm91bmRDb2xvcjogUElOS181MDBcblx0fSk7XG5cdGlmIChyb3V0ZS5fX3ZkX2V4YWN0QWN0aXZlKSB0YWdzLnB1c2goe1xuXHRcdGxhYmVsOiBcImV4YWN0XCIsXG5cdFx0dGV4dENvbG9yOiAwLFxuXHRcdGJhY2tncm91bmRDb2xvcjogTElNRV81MDBcblx0fSk7XG5cdGlmIChyb3V0ZS5fX3ZkX2FjdGl2ZSkgdGFncy5wdXNoKHtcblx0XHRsYWJlbDogXCJhY3RpdmVcIixcblx0XHR0ZXh0Q29sb3I6IDAsXG5cdFx0YmFja2dyb3VuZENvbG9yOiBCTFVFXzYwMFxuXHR9KTtcblx0aWYgKHJlY29yZC5yZWRpcmVjdCkgdGFncy5wdXNoKHtcblx0XHRsYWJlbDogdHlwZW9mIHJlY29yZC5yZWRpcmVjdCA9PT0gXCJzdHJpbmdcIiA/IGByZWRpcmVjdDogJHtyZWNvcmQucmVkaXJlY3R9YCA6IFwicmVkaXJlY3RzXCIsXG5cdFx0dGV4dENvbG9yOiAxNjc3NzIxNSxcblx0XHRiYWNrZ3JvdW5kQ29sb3I6IERBUktcblx0fSk7XG5cdGxldCBpZCA9IHJlY29yZC5fX3ZkX2lkO1xuXHRpZiAoaWQgPT0gbnVsbCkge1xuXHRcdGlkID0gU3RyaW5nKHJvdXRlUmVjb3JkSWQrKyk7XG5cdFx0cmVjb3JkLl9fdmRfaWQgPSBpZDtcblx0fVxuXHRyZXR1cm4ge1xuXHRcdGlkLFxuXHRcdGxhYmVsOiByZWNvcmQucGF0aCxcblx0XHR0YWdzLFxuXHRcdGNoaWxkcmVuOiByb3V0ZS5jaGlsZHJlbi5tYXAoZm9ybWF0Um91dGVSZWNvcmRGb3JJbnNwZWN0b3IpXG5cdH07XG59XG5sZXQgcm91dGVSZWNvcmRJZCA9IDA7XG5jb25zdCBFWFRSQUNUX1JFR0VYUF9SRSA9IC9eXFwvKC4qKVxcLyhbYS16XSopJC87XG5mdW5jdGlvbiBtYXJrUm91dGVSZWNvcmRBY3RpdmUocm91dGUsIGN1cnJlbnRSb3V0ZSkge1xuXHRjb25zdCBpc0V4YWN0QWN0aXZlID0gY3VycmVudFJvdXRlLm1hdGNoZWQubGVuZ3RoICYmIGlzU2FtZVJvdXRlUmVjb3JkKGN1cnJlbnRSb3V0ZS5tYXRjaGVkW2N1cnJlbnRSb3V0ZS5tYXRjaGVkLmxlbmd0aCAtIDFdLCByb3V0ZS5yZWNvcmQpO1xuXHRyb3V0ZS5fX3ZkX2V4YWN0QWN0aXZlID0gcm91dGUuX192ZF9hY3RpdmUgPSBpc0V4YWN0QWN0aXZlO1xuXHRpZiAoIWlzRXhhY3RBY3RpdmUpIHJvdXRlLl9fdmRfYWN0aXZlID0gY3VycmVudFJvdXRlLm1hdGNoZWQuc29tZSgobWF0Y2gpID0+IGlzU2FtZVJvdXRlUmVjb3JkKG1hdGNoLCByb3V0ZS5yZWNvcmQpKTtcblx0cm91dGUuY2hpbGRyZW4uZm9yRWFjaCgoY2hpbGRSb3V0ZSkgPT4gbWFya1JvdXRlUmVjb3JkQWN0aXZlKGNoaWxkUm91dGUsIGN1cnJlbnRSb3V0ZSkpO1xufVxuZnVuY3Rpb24gcmVzZXRNYXRjaFN0YXRlT25Sb3V0ZVJlY29yZChyb3V0ZSkge1xuXHRyb3V0ZS5fX3ZkX21hdGNoID0gZmFsc2U7XG5cdHJvdXRlLmNoaWxkcmVuLmZvckVhY2gocmVzZXRNYXRjaFN0YXRlT25Sb3V0ZVJlY29yZCk7XG59XG5mdW5jdGlvbiBpc1JvdXRlTWF0Y2hpbmcocm91dGUsIGZpbHRlcikge1xuXHRjb25zdCBmb3VuZCA9IFN0cmluZyhyb3V0ZS5yZSkubWF0Y2goRVhUUkFDVF9SRUdFWFBfUkUpO1xuXHRyb3V0ZS5fX3ZkX21hdGNoID0gZmFsc2U7XG5cdGlmICghZm91bmQgfHwgZm91bmQubGVuZ3RoIDwgMykgcmV0dXJuIGZhbHNlO1xuXHRpZiAobmV3IFJlZ0V4cChmb3VuZFsxXS5yZXBsYWNlKC9cXCQkLywgXCJcIiksIGZvdW5kWzJdKS50ZXN0KGZpbHRlcikpIHtcblx0XHRyb3V0ZS5jaGlsZHJlbi5mb3JFYWNoKChjaGlsZCkgPT4gaXNSb3V0ZU1hdGNoaW5nKGNoaWxkLCBmaWx0ZXIpKTtcblx0XHRpZiAocm91dGUucmVjb3JkLnBhdGggIT09IFwiL1wiIHx8IGZpbHRlciA9PT0gXCIvXCIpIHtcblx0XHRcdHJvdXRlLl9fdmRfbWF0Y2ggPSByb3V0ZS5yZS50ZXN0KGZpbHRlcik7XG5cdFx0XHRyZXR1cm4gdHJ1ZTtcblx0XHR9XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9XG5cdGNvbnN0IHBhdGggPSByb3V0ZS5yZWNvcmQucGF0aC50b0xvd2VyQ2FzZSgpO1xuXHRjb25zdCBkZWNvZGVkUGF0aCA9IGRlY29kZShwYXRoKTtcblx0aWYgKCFpc0Fic29sdXRlUGF0aChmaWx0ZXIpICYmIChkZWNvZGVkUGF0aC5pbmNsdWRlcyhmaWx0ZXIpIHx8IHBhdGguaW5jbHVkZXMoZmlsdGVyKSkpIHJldHVybiB0cnVlO1xuXHRpZiAoZGVjb2RlZFBhdGguc3RhcnRzV2l0aChmaWx0ZXIpIHx8IHBhdGguc3RhcnRzV2l0aChmaWx0ZXIpKSByZXR1cm4gdHJ1ZTtcblx0aWYgKHJvdXRlLnJlY29yZC5uYW1lICYmIFN0cmluZyhyb3V0ZS5yZWNvcmQubmFtZSkuaW5jbHVkZXMoZmlsdGVyKSkgcmV0dXJuIHRydWU7XG5cdHJldHVybiByb3V0ZS5jaGlsZHJlbi5zb21lKChjaGlsZCkgPT4gaXNSb3V0ZU1hdGNoaW5nKGNoaWxkLCBmaWx0ZXIpKTtcbn1cbmZ1bmN0aW9uIG9taXQob2JqLCBrZXlzKSB7XG5cdGNvbnN0IHJldCA9IHt9O1xuXHRmb3IgKGNvbnN0IGtleSBpbiBvYmopIGlmICgha2V5cy5pbmNsdWRlcyhrZXkpKSByZXRba2V5XSA9IG9ialtrZXldO1xuXHRyZXR1cm4gcmV0O1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBQTFVTX1JFIGFzIEEsIGlzU2FtZVJvdXRlTG9jYXRpb24gYXMgQywgcmVzb2x2ZVJlbGF0aXZlUGF0aCBhcyBELCBwYXJzZVVSTCBhcyBFLCBpc0Jyb3dzZXIgYXMgRiwgZW5jb2RlSGFzaCBhcyBNLCBlbmNvZGVQYXJhbSBhcyBOLCBzdHJpbmdpZnlVUkwgYXMgTywgZW5jb2RlUGF0aCBhcyBQLCBTVEFSVF9MT0NBVElPTl9OT1JNQUxJWkVEIGFzIFMsIGlzU2FtZVJvdXRlUmVjb3JkIGFzIFQsIHNhdmVTY3JvbGxQb3NpdGlvbiBhcyBfLCBsb2FkUm91dGVMb2NhdGlvbiBhcyBhLCBub3JtYWxpemVCYXNlIGFzIGIsIHVzZUNhbGxiYWNrcyBhcyBjLCBzdHJpbmdpZnlRdWVyeSBhcyBkLCBpc1JvdXRlTG9jYXRpb24gYXMgZiwgZ2V0U2Nyb2xsS2V5IGFzIGcsIGdldFNhdmVkU2Nyb2xsUG9zaXRpb24gYXMgaCwgZ3VhcmRUb1Byb21pc2VGbiBhcyBpLCBkZWNvZGUgYXMgaiwgc3RyaXBCYXNlIGFzIGssIG5vcm1hbGl6ZVF1ZXJ5IGFzIGwsIGNvbXB1dGVTY3JvbGxQb3NpdGlvbiBhcyBtLCBleHRyYWN0Q2hhbmdpbmdSZWNvcmRzIGFzIG4sIG9uQmVmb3JlUm91dGVMZWF2ZSBhcyBvLCBpc1JvdXRlTmFtZSBhcyBwLCBleHRyYWN0Q29tcG9uZW50c0d1YXJkcyBhcyByLCBvbkJlZm9yZVJvdXRlVXBkYXRlIGFzIHMsIGFkZERldnRvb2xzIGFzIHQsIHBhcnNlUXVlcnkgYXMgdSwgc2Nyb2xsVG9Qb3NpdGlvbiBhcyB2LCBpc1NhbWVSb3V0ZUxvY2F0aW9uUGFyYW1zIGFzIHcsIE5FV19zdHJpbmdpZnlVUkwgYXMgeCwgY3JlYXRlSHJlZiBhcyB5IH07XG4iLCIvKiFcbiogdnVlLXJvdXRlciB2NS4zLjFcbiogKGMpIDIwMjYgRWR1YXJkbyBTYW4gTWFydGluIE1vcm90ZVxuKiBAbGljZW5zZSBNSVRcbiovXG5pbXBvcnQgeyBDIGFzIGlzU2FtZVJvdXRlTG9jYXRpb24sIEUgYXMgcGFyc2VVUkwsIEYgYXMgaXNCcm93c2VyLCBNIGFzIGVuY29kZUhhc2gsIE4gYXMgZW5jb2RlUGFyYW0sIE8gYXMgc3RyaW5naWZ5VVJMLCBTIGFzIFNUQVJUX0xPQ0FUSU9OX05PUk1BTElaRUQsIFQgYXMgaXNTYW1lUm91dGVSZWNvcmQsIF8gYXMgc2F2ZVNjcm9sbFBvc2l0aW9uLCBhIGFzIGxvYWRSb3V0ZUxvY2F0aW9uLCBiIGFzIG5vcm1hbGl6ZUJhc2UsIGMgYXMgdXNlQ2FsbGJhY2tzLCBkIGFzIHN0cmluZ2lmeVF1ZXJ5LCBmIGFzIGlzUm91dGVMb2NhdGlvbiwgZyBhcyBnZXRTY3JvbGxLZXksIGggYXMgZ2V0U2F2ZWRTY3JvbGxQb3NpdGlvbiwgaSBhcyBndWFyZFRvUHJvbWlzZUZuLCBqIGFzIGRlY29kZSwgayBhcyBzdHJpcEJhc2UsIGwgYXMgbm9ybWFsaXplUXVlcnksIG0gYXMgY29tcHV0ZVNjcm9sbFBvc2l0aW9uLCBuIGFzIGV4dHJhY3RDaGFuZ2luZ1JlY29yZHMsIG8gYXMgb25CZWZvcmVSb3V0ZUxlYXZlLCBwIGFzIGlzUm91dGVOYW1lLCByIGFzIGV4dHJhY3RDb21wb25lbnRzR3VhcmRzLCBzIGFzIG9uQmVmb3JlUm91dGVVcGRhdGUsIHQgYXMgYWRkRGV2dG9vbHMsIHUgYXMgcGFyc2VRdWVyeSwgdiBhcyBzY3JvbGxUb1Bvc2l0aW9uLCB3IGFzIGlzU2FtZVJvdXRlTG9jYXRpb25QYXJhbXMsIHkgYXMgY3JlYXRlSHJlZiB9IGZyb20gXCIuL2RldnRvb2xzLUNONXVXSmFILmpzXCI7XG5pbXBvcnQgeyBhIGFzIHJvdXRlcktleSwgYiBhcyBub29wLCBjIGFzIGRpYWdub3N0aWNzLCBkIGFzIGlzTmF2aWdhdGlvbkZhaWx1cmUsIGYgYXMgYXBwbHlUb1BhcmFtcywgZyBhcyBpc0FycmF5LCBoIGFzIGlzQWJzb2x1dGVQYXRoLCBpIGFzIHJvdXRlTG9jYXRpb25LZXksIGwgYXMgTmF2aWdhdGlvbkZhaWx1cmVUeXBlLCBuIGFzIHVzZVJvdXRlciwgbyBhcyByb3V0ZXJWaWV3TG9jYXRpb25LZXksIHAgYXMgYXNzaWduLCByIGFzIG1hdGNoZWRSb3V0ZUtleSwgcyBhcyB2aWV3RGVwdGhLZXksIHQgYXMgdXNlUm91dGUsIHUgYXMgY3JlYXRlUm91dGVyRXJyb3IsIHkgYXMgbWVyZ2VPcHRpb25zIH0gZnJvbSBcIi4vdXNlQXBpLUJQdUk2WlI5LmpzXCI7XG5pbXBvcnQgeyBjb21wdXRlZCwgZGVmaW5lQ29tcG9uZW50LCBnZXRDdXJyZW50SW5zdGFuY2UsIGgsIGluamVjdCwgbmV4dFRpY2ssIHByb3ZpZGUsIHJlYWN0aXZlLCByZWYsIHNoYWxsb3dSZWFjdGl2ZSwgc2hhbGxvd1JlZiwgdW5yZWYsIHdhdGNoLCB3YXRjaEVmZmVjdCB9IGZyb20gXCJ2dWVcIjtcbi8vI3JlZ2lvbiBzcmMvaGlzdG9yeS9odG1sNS50c1xubGV0IGNyZWF0ZUJhc2VMb2NhdGlvbiA9ICgpID0+IGxvY2F0aW9uLnByb3RvY29sICsgXCIvL1wiICsgbG9jYXRpb24uaG9zdDtcbi8qKlxuKiBDcmVhdGVzIGEgbm9ybWFsaXplZCBoaXN0b3J5IGxvY2F0aW9uIGZyb20gYSB3aW5kb3cubG9jYXRpb24gb2JqZWN0XG4qIEBwYXJhbSBiYXNlIC0gVGhlIGJhc2UgcGF0aFxuKiBAcGFyYW0gbG9jYXRpb24gLSBUaGUgd2luZG93LmxvY2F0aW9uIG9iamVjdFxuKi9cbmZ1bmN0aW9uIGNyZWF0ZUN1cnJlbnRMb2NhdGlvbihiYXNlLCBsb2NhdGlvbikge1xuXHRjb25zdCB7IHBhdGhuYW1lLCBzZWFyY2gsIGhhc2ggfSA9IGxvY2F0aW9uO1xuXHRjb25zdCBoYXNoUG9zID0gYmFzZS5pbmRleE9mKFwiI1wiKTtcblx0aWYgKGhhc2hQb3MgPiAtMSkge1xuXHRcdGxldCBzbGljZVBvcyA9IGhhc2guaW5jbHVkZXMoYmFzZS5zbGljZShoYXNoUG9zKSkgPyBiYXNlLnNsaWNlKGhhc2hQb3MpLmxlbmd0aCA6IDE7XG5cdFx0bGV0IHBhdGhGcm9tSGFzaCA9IGhhc2guc2xpY2Uoc2xpY2VQb3MpO1xuXHRcdGlmIChwYXRoRnJvbUhhc2hbMF0gIT09IFwiL1wiKSBwYXRoRnJvbUhhc2ggPSBcIi9cIiArIHBhdGhGcm9tSGFzaDtcblx0XHRyZXR1cm4gc3RyaXBCYXNlKHBhdGhGcm9tSGFzaCwgXCJcIik7XG5cdH1cblx0cmV0dXJuIHN0cmlwQmFzZShwYXRobmFtZSwgYmFzZSkgKyBzZWFyY2ggKyBoYXNoO1xufVxuZnVuY3Rpb24gdXNlSGlzdG9yeUxpc3RlbmVycyhiYXNlLCBoaXN0b3J5U3RhdGUsIGN1cnJlbnRMb2NhdGlvbiwgcmVwbGFjZSkge1xuXHRsZXQgbGlzdGVuZXJzID0gW107XG5cdGxldCB0ZWFyZG93bnMgPSBbXTtcblx0bGV0IHBhdXNlU3RhdGUgPSBudWxsO1xuXHRjb25zdCBwb3BTdGF0ZUhhbmRsZXIgPSAoeyBzdGF0ZSB9KSA9PiB7XG5cdFx0Y29uc3QgdG8gPSBjcmVhdGVDdXJyZW50TG9jYXRpb24oYmFzZSwgbG9jYXRpb24pO1xuXHRcdGNvbnN0IGZyb20gPSBjdXJyZW50TG9jYXRpb24udmFsdWU7XG5cdFx0Y29uc3QgZnJvbVN0YXRlID0gaGlzdG9yeVN0YXRlLnZhbHVlO1xuXHRcdGxldCBkZWx0YSA9IDA7XG5cdFx0aWYgKHN0YXRlKSB7XG5cdFx0XHRjdXJyZW50TG9jYXRpb24udmFsdWUgPSB0bztcblx0XHRcdGhpc3RvcnlTdGF0ZS52YWx1ZSA9IHN0YXRlO1xuXHRcdFx0aWYgKHBhdXNlU3RhdGUgJiYgcGF1c2VTdGF0ZSA9PT0gZnJvbSkge1xuXHRcdFx0XHRwYXVzZVN0YXRlID0gbnVsbDtcblx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0fVxuXHRcdFx0ZGVsdGEgPSBmcm9tU3RhdGUgPyBzdGF0ZS5wb3NpdGlvbiAtIGZyb21TdGF0ZS5wb3NpdGlvbiA6IDA7XG5cdFx0fSBlbHNlIHJlcGxhY2UodG8pO1xuXHRcdGxpc3RlbmVycy5mb3JFYWNoKChsaXN0ZW5lcikgPT4ge1xuXHRcdFx0bGlzdGVuZXIoY3VycmVudExvY2F0aW9uLnZhbHVlLCBmcm9tLCB7XG5cdFx0XHRcdGRlbHRhLFxuXHRcdFx0XHR0eXBlOiBcInBvcFwiLFxuXHRcdFx0XHRkaXJlY3Rpb246IGRlbHRhID8gZGVsdGEgPiAwID8gXCJmb3J3YXJkXCIgOiBcImJhY2tcIiA6IFwiXCJcblx0XHRcdH0pO1xuXHRcdH0pO1xuXHR9O1xuXHRmdW5jdGlvbiBwYXVzZUxpc3RlbmVycygpIHtcblx0XHRwYXVzZVN0YXRlID0gY3VycmVudExvY2F0aW9uLnZhbHVlO1xuXHR9XG5cdGZ1bmN0aW9uIGxpc3RlbihjYWxsYmFjaykge1xuXHRcdGxpc3RlbmVycy5wdXNoKGNhbGxiYWNrKTtcblx0XHRjb25zdCB0ZWFyZG93biA9ICgpID0+IHtcblx0XHRcdGNvbnN0IGluZGV4ID0gbGlzdGVuZXJzLmluZGV4T2YoY2FsbGJhY2spO1xuXHRcdFx0aWYgKGluZGV4ID4gLTEpIGxpc3RlbmVycy5zcGxpY2UoaW5kZXgsIDEpO1xuXHRcdH07XG5cdFx0dGVhcmRvd25zLnB1c2godGVhcmRvd24pO1xuXHRcdHJldHVybiB0ZWFyZG93bjtcblx0fVxuXHRmdW5jdGlvbiBiZWZvcmVVbmxvYWRMaXN0ZW5lcigpIHtcblx0XHRjb25zdCB7IGhpc3RvcnkgfSA9IHdpbmRvdztcblx0XHRpZiAoIWhpc3Rvcnkuc3RhdGUpIHJldHVybjtcblx0XHRoaXN0b3J5LnJlcGxhY2VTdGF0ZShhc3NpZ24oe30sIGhpc3Rvcnkuc3RhdGUsIHsgc2Nyb2xsOiBjb21wdXRlU2Nyb2xsUG9zaXRpb24oKSB9KSwgXCJcIik7XG5cdH1cblx0ZnVuY3Rpb24gZGVzdHJveSgpIHtcblx0XHRmb3IgKGNvbnN0IHRlYXJkb3duIG9mIHRlYXJkb3ducykgdGVhcmRvd24oKTtcblx0XHR0ZWFyZG93bnMgPSBbXTtcblx0XHR3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInBvcHN0YXRlXCIsIHBvcFN0YXRlSGFuZGxlcik7XG5cdFx0d2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJwYWdlaGlkZVwiLCBiZWZvcmVVbmxvYWRMaXN0ZW5lcik7XG5cdH1cblx0d2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJwb3BzdGF0ZVwiLCBwb3BTdGF0ZUhhbmRsZXIpO1xuXHR3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcInBhZ2VoaWRlXCIsIGJlZm9yZVVubG9hZExpc3RlbmVyKTtcblx0cmV0dXJuIHtcblx0XHRwYXVzZUxpc3RlbmVycyxcblx0XHRsaXN0ZW4sXG5cdFx0ZGVzdHJveVxuXHR9O1xufVxuLyoqXG4qIENyZWF0ZXMgYSBzdGF0ZSBvYmplY3RcbiovXG5mdW5jdGlvbiBidWlsZFN0YXRlKGJhY2ssIGN1cnJlbnQsIGZvcndhcmQsIHJlcGxhY2VkID0gZmFsc2UpIHtcblx0cmV0dXJuIHtcblx0XHRiYWNrLFxuXHRcdGN1cnJlbnQsXG5cdFx0Zm9yd2FyZCxcblx0XHRyZXBsYWNlZCxcblx0XHRwb3NpdGlvbjogd2luZG93Lmhpc3RvcnkubGVuZ3RoLFxuXHRcdHNjcm9sbDogbnVsbFxuXHR9O1xufVxuZnVuY3Rpb24gdXNlSGlzdG9yeVN0YXRlTmF2aWdhdGlvbihiYXNlKSB7XG5cdGNvbnN0IHsgaGlzdG9yeSwgbG9jYXRpb24gfSA9IHdpbmRvdztcblx0Y29uc3QgY3VycmVudExvY2F0aW9uID0geyB2YWx1ZTogY3JlYXRlQ3VycmVudExvY2F0aW9uKGJhc2UsIGxvY2F0aW9uKSB9O1xuXHRjb25zdCBoaXN0b3J5U3RhdGUgPSB7IHZhbHVlOiBoaXN0b3J5LnN0YXRlIH07XG5cdGlmICghaGlzdG9yeVN0YXRlLnZhbHVlKSBjaGFuZ2VMb2NhdGlvbihjdXJyZW50TG9jYXRpb24udmFsdWUsIHtcblx0XHRiYWNrOiBudWxsLFxuXHRcdGN1cnJlbnQ6IGN1cnJlbnRMb2NhdGlvbi52YWx1ZSxcblx0XHRmb3J3YXJkOiBudWxsLFxuXHRcdHBvc2l0aW9uOiBoaXN0b3J5Lmxlbmd0aCAtIDEsXG5cdFx0cmVwbGFjZWQ6IHRydWUsXG5cdFx0c2Nyb2xsOiBudWxsXG5cdH0sIHRydWUpO1xuXHRmdW5jdGlvbiBjaGFuZ2VMb2NhdGlvbih0bywgc3RhdGUsIHJlcGxhY2UpIHtcblx0XHQvKipcblx0XHQqIGlmIGEgYmFzZSB0YWcgaXMgcHJvdmlkZWQsIGFuZCB3ZSBhcmUgb24gYSBub3JtYWwgZG9tYWluLCB3ZSBoYXZlIHRvXG5cdFx0KiByZXNwZWN0IHRoZSBwcm92aWRlZCBgYmFzZWAgYXR0cmlidXRlIGJlY2F1c2UgcHVzaFN0YXRlKCkgd2lsbCB1c2UgaXQgYW5kXG5cdFx0KiBwb3RlbnRpYWxseSBlcmFzZSBhbnl0aGluZyBiZWZvcmUgdGhlIGAjYCBsaWtlIGF0XG5cdFx0KiBodHRwczovL2dpdGh1Yi5jb20vdnVlanMvcm91dGVyL2lzc3Vlcy82ODUgd2hlcmUgYSBiYXNlIG9mXG5cdFx0KiBgL2ZvbGRlci8jYCBidXQgYSBiYXNlIG9mIGAvYCB3b3VsZCBlcmFzZSB0aGUgYC9mb2xkZXIvYCBzZWN0aW9uLiBJZlxuXHRcdCogdGhlcmUgaXMgbm8gaG9zdCwgdGhlIGA8YmFzZT5gIHRhZyBtYWtlcyBubyBzZW5zZSBhbmQgaWYgdGhlcmUgaXNuJ3QgYVxuXHRcdCogYmFzZSB0YWcgd2UgY2FuIGp1c3QgdXNlIGV2ZXJ5dGhpbmcgYWZ0ZXIgdGhlIGAjYC5cblx0XHQqL1xuXHRcdGNvbnN0IGhhc2hJbmRleCA9IGJhc2UuaW5kZXhPZihcIiNcIik7XG5cdFx0Y29uc3QgdXJsID0gaGFzaEluZGV4ID4gLTEgPyAobG9jYXRpb24uaG9zdCAmJiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiYmFzZVwiKSA/IGJhc2UgOiBiYXNlLnNsaWNlKGhhc2hJbmRleCkpICsgdG8gOiBjcmVhdGVCYXNlTG9jYXRpb24oKSArIGJhc2UgKyB0bztcblx0XHR0cnkge1xuXHRcdFx0aGlzdG9yeVtyZXBsYWNlID8gXCJyZXBsYWNlU3RhdGVcIiA6IFwicHVzaFN0YXRlXCJdKHN0YXRlLCBcIlwiLCB1cmwpO1xuXHRcdFx0aGlzdG9yeVN0YXRlLnZhbHVlID0gc3RhdGU7XG5cdFx0fSBjYXRjaCAoZXJyKSB7XG5cdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBkaWFnbm9zdGljcy5WVUVfUk9VVEVSX1IwMTIwKHsgY2F1c2U6IGVyciB9KTtcblx0XHRcdGVsc2UgY29uc29sZS5lcnJvcihlcnIpO1xuXHRcdFx0bG9jYXRpb25bcmVwbGFjZSA/IFwicmVwbGFjZVwiIDogXCJhc3NpZ25cIl0odXJsKTtcblx0XHR9XG5cdH1cblx0ZnVuY3Rpb24gcmVwbGFjZSh0bywgZGF0YSkge1xuXHRcdGNoYW5nZUxvY2F0aW9uKHRvLCBhc3NpZ24oe30sIGhpc3Rvcnkuc3RhdGUsIGJ1aWxkU3RhdGUoaGlzdG9yeVN0YXRlLnZhbHVlLmJhY2ssIHRvLCBoaXN0b3J5U3RhdGUudmFsdWUuZm9yd2FyZCwgdHJ1ZSksIGRhdGEsIHsgcG9zaXRpb246IGhpc3RvcnlTdGF0ZS52YWx1ZS5wb3NpdGlvbiB9KSwgdHJ1ZSk7XG5cdFx0Y3VycmVudExvY2F0aW9uLnZhbHVlID0gdG87XG5cdH1cblx0ZnVuY3Rpb24gcHVzaCh0bywgZGF0YSkge1xuXHRcdGNvbnN0IGN1cnJlbnRTdGF0ZSA9IGFzc2lnbih7fSwgaGlzdG9yeVN0YXRlLnZhbHVlLCBoaXN0b3J5LnN0YXRlLCB7XG5cdFx0XHRmb3J3YXJkOiB0byxcblx0XHRcdHNjcm9sbDogY29tcHV0ZVNjcm9sbFBvc2l0aW9uKClcblx0XHR9KTtcblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmICFoaXN0b3J5LnN0YXRlKSBkaWFnbm9zdGljcy5WVUVfUk9VVEVSX1IwMTIxKCk7XG5cdFx0Y2hhbmdlTG9jYXRpb24oY3VycmVudFN0YXRlLmN1cnJlbnQsIGN1cnJlbnRTdGF0ZSwgdHJ1ZSk7XG5cdFx0Y2hhbmdlTG9jYXRpb24odG8sIGFzc2lnbih7fSwgYnVpbGRTdGF0ZShjdXJyZW50TG9jYXRpb24udmFsdWUsIHRvLCBudWxsKSwgeyBwb3NpdGlvbjogY3VycmVudFN0YXRlLnBvc2l0aW9uICsgMSB9LCBkYXRhKSwgZmFsc2UpO1xuXHRcdGN1cnJlbnRMb2NhdGlvbi52YWx1ZSA9IHRvO1xuXHR9XG5cdHJldHVybiB7XG5cdFx0bG9jYXRpb246IGN1cnJlbnRMb2NhdGlvbixcblx0XHRzdGF0ZTogaGlzdG9yeVN0YXRlLFxuXHRcdHB1c2gsXG5cdFx0cmVwbGFjZVxuXHR9O1xufVxuLyoqXG4qIENyZWF0ZXMgYW4gSFRNTDUgaGlzdG9yeS4gTW9zdCBjb21tb24gaGlzdG9yeSBmb3Igc2luZ2xlIHBhZ2UgYXBwbGljYXRpb25zLlxuKlxuKiBAcGFyYW0gYmFzZSAtXG4qL1xuZnVuY3Rpb24gY3JlYXRlV2ViSGlzdG9yeShiYXNlKSB7XG5cdGJhc2UgPSBub3JtYWxpemVCYXNlKGJhc2UpO1xuXHRjb25zdCBoaXN0b3J5TmF2aWdhdGlvbiA9IHVzZUhpc3RvcnlTdGF0ZU5hdmlnYXRpb24oYmFzZSk7XG5cdGNvbnN0IGhpc3RvcnlMaXN0ZW5lcnMgPSB1c2VIaXN0b3J5TGlzdGVuZXJzKGJhc2UsIGhpc3RvcnlOYXZpZ2F0aW9uLnN0YXRlLCBoaXN0b3J5TmF2aWdhdGlvbi5sb2NhdGlvbiwgaGlzdG9yeU5hdmlnYXRpb24ucmVwbGFjZSk7XG5cdGZ1bmN0aW9uIGdvKGRlbHRhLCB0cmlnZ2VyTGlzdGVuZXJzID0gdHJ1ZSkge1xuXHRcdGlmICghdHJpZ2dlckxpc3RlbmVycykgaGlzdG9yeUxpc3RlbmVycy5wYXVzZUxpc3RlbmVycygpO1xuXHRcdGhpc3RvcnkuZ28oZGVsdGEpO1xuXHR9XG5cdGNvbnN0IHJvdXRlckhpc3RvcnkgPSBhc3NpZ24oe1xuXHRcdGxvY2F0aW9uOiBcIlwiLFxuXHRcdGJhc2UsXG5cdFx0Z28sXG5cdFx0Y3JlYXRlSHJlZjogY3JlYXRlSHJlZi5iaW5kKG51bGwsIGJhc2UpXG5cdH0sIGhpc3RvcnlOYXZpZ2F0aW9uLCBoaXN0b3J5TGlzdGVuZXJzKTtcblx0T2JqZWN0LmRlZmluZVByb3BlcnR5KHJvdXRlckhpc3RvcnksIFwibG9jYXRpb25cIiwge1xuXHRcdGVudW1lcmFibGU6IHRydWUsXG5cdFx0Z2V0OiAoKSA9PiBoaXN0b3J5TmF2aWdhdGlvbi5sb2NhdGlvbi52YWx1ZVxuXHR9KTtcblx0T2JqZWN0LmRlZmluZVByb3BlcnR5KHJvdXRlckhpc3RvcnksIFwic3RhdGVcIiwge1xuXHRcdGVudW1lcmFibGU6IHRydWUsXG5cdFx0Z2V0OiAoKSA9PiBoaXN0b3J5TmF2aWdhdGlvbi5zdGF0ZS52YWx1ZVxuXHR9KTtcblx0cmV0dXJuIHJvdXRlckhpc3Rvcnk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvaGlzdG9yeS9oYXNoLnRzXG4vKipcbiogQ3JlYXRlcyBhIGhhc2ggaGlzdG9yeS4gVXNlZnVsIGZvciB3ZWIgYXBwbGljYXRpb25zIHdpdGggbm8gaG9zdCAoZS5nLiBgZmlsZTovL2ApIG9yIHdoZW4gY29uZmlndXJpbmcgYSBzZXJ2ZXIgdG9cbiogaGFuZGxlIGFueSBVUkwgaXMgbm90IHBvc3NpYmxlLlxuKlxuKiBAcGFyYW0gYmFzZSAtIG9wdGlvbmFsIGJhc2UgdG8gcHJvdmlkZS4gRGVmYXVsdHMgdG8gYGxvY2F0aW9uLnBhdGhuYW1lICsgbG9jYXRpb24uc2VhcmNoYCBJZiB0aGVyZSBpcyBhIGA8YmFzZT5gIHRhZ1xuKiBpbiB0aGUgYGhlYWRgLCBpdHMgdmFsdWUgd2lsbCBiZSBpZ25vcmVkIGluIGZhdm9yIG9mIHRoaXMgcGFyYW1ldGVyICoqYnV0IG5vdGUgaXQgYWZmZWN0cyBhbGwgdGhlIGhpc3RvcnkucHVzaFN0YXRlKClcbiogY2FsbHMqKiwgbWVhbmluZyB0aGF0IGlmIHlvdSB1c2UgYSBgPGJhc2U+YCB0YWcsIGl0J3MgYGhyZWZgIHZhbHVlICoqaGFzIHRvIG1hdGNoIHRoaXMgcGFyYW1ldGVyKiogKGlnbm9yaW5nIGFueXRoaW5nXG4qIGFmdGVyIHRoZSBgI2ApLlxuKlxuKiBAZXhhbXBsZVxuKiBgYGBqc1xuKiAvLyBhdCBodHRwczovL2V4YW1wbGUuY29tL2ZvbGRlclxuKiBjcmVhdGVXZWJIYXNoSGlzdG9yeSgpIC8vIGdpdmVzIGEgdXJsIG9mIGBodHRwczovL2V4YW1wbGUuY29tL2ZvbGRlciNgXG4qIGNyZWF0ZVdlYkhhc2hIaXN0b3J5KCcvZm9sZGVyLycpIC8vIGdpdmVzIGEgdXJsIG9mIGBodHRwczovL2V4YW1wbGUuY29tL2ZvbGRlci8jYFxuKiAvLyBpZiB0aGUgYCNgIGlzIHByb3ZpZGVkIGluIHRoZSBiYXNlLCBpdCB3b24ndCBiZSBhZGRlZCBieSBgY3JlYXRlV2ViSGFzaEhpc3RvcnlgXG4qIGNyZWF0ZVdlYkhhc2hIaXN0b3J5KCcvZm9sZGVyLyMvYXBwLycpIC8vIGdpdmVzIGEgdXJsIG9mIGBodHRwczovL2V4YW1wbGUuY29tL2ZvbGRlci8jL2FwcC9gXG4qIC8vIHlvdSBzaG91bGQgYXZvaWQgZG9pbmcgdGhpcyBiZWNhdXNlIGl0IGNoYW5nZXMgdGhlIG9yaWdpbmFsIHVybCBhbmQgYnJlYWtzIGNvcHlpbmcgdXJsc1xuKiBjcmVhdGVXZWJIYXNoSGlzdG9yeSgnL290aGVyLWZvbGRlci8nKSAvLyBnaXZlcyBhIHVybCBvZiBgaHR0cHM6Ly9leGFtcGxlLmNvbS9vdGhlci1mb2xkZXIvI2BcbipcbiogLy8gYXQgZmlsZTovLy91c3IvZXRjL2ZvbGRlci9pbmRleC5odG1sXG4qIC8vIGZvciBsb2NhdGlvbnMgd2l0aCBubyBgaG9zdGAsIHRoZSBiYXNlIGlzIGlnbm9yZWRcbiogY3JlYXRlV2ViSGFzaEhpc3RvcnkoJy9pQW1JZ25vcmVkJykgLy8gZ2l2ZXMgYSB1cmwgb2YgYGZpbGU6Ly8vdXNyL2V0Yy9mb2xkZXIvaW5kZXguaHRtbCNgXG4qIGBgYFxuKi9cbmZ1bmN0aW9uIGNyZWF0ZVdlYkhhc2hIaXN0b3J5KGJhc2UpIHtcblx0YmFzZSA9IGxvY2F0aW9uLmhvc3QgPyBiYXNlIHx8IGxvY2F0aW9uLnBhdGhuYW1lICsgbG9jYXRpb24uc2VhcmNoIDogXCJcIjtcblx0aWYgKCFiYXNlLmluY2x1ZGVzKFwiI1wiKSkgYmFzZSArPSBcIiNcIjtcblx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiAhYmFzZS5lbmRzV2l0aChcIiMvXCIpICYmICFiYXNlLmVuZHNXaXRoKFwiI1wiKSkgZGlhZ25vc3RpY3MuVlVFX1JPVVRFUl9SMDExMCh7XG5cdFx0YmFzZSxcblx0XHRzdWdnZXN0aW9uOiBiYXNlLnJlcGxhY2UoLyMuKiQvLCBcIiNcIilcblx0fSk7XG5cdHJldHVybiBjcmVhdGVXZWJIaXN0b3J5KGJhc2UpO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2hpc3RvcnkvbWVtb3J5LnRzXG4vKipcbiogQ3JlYXRlcyBhbiBpbi1tZW1vcnkgYmFzZWQgaGlzdG9yeS4gVGhlIG1haW4gcHVycG9zZSBvZiB0aGlzIGhpc3RvcnkgaXMgdG8gaGFuZGxlIFNTUi4gSXQgc3RhcnRzIGluIGEgc3BlY2lhbCBsb2NhdGlvbiB0aGF0IGlzIG5vd2hlcmUuXG4qIEl0J3MgdXAgdG8gdGhlIHVzZXIgdG8gcmVwbGFjZSB0aGF0IGxvY2F0aW9uIHdpdGggdGhlIHN0YXJ0ZXIgbG9jYXRpb24gYnkgZWl0aGVyIGNhbGxpbmcgYHJvdXRlci5wdXNoYCBvciBgcm91dGVyLnJlcGxhY2VgLlxuKlxuKiBAcGFyYW0gYmFzZSAtIEJhc2UgYXBwbGllZCB0byBhbGwgdXJscywgZGVmYXVsdHMgdG8gJy8nXG4qIEByZXR1cm5zIGEgaGlzdG9yeSBvYmplY3QgdGhhdCBjYW4gYmUgcGFzc2VkIHRvIHRoZSByb3V0ZXIgY29uc3RydWN0b3JcbiovXG5mdW5jdGlvbiBjcmVhdGVNZW1vcnlIaXN0b3J5KGJhc2UgPSBcIlwiKSB7XG5cdGxldCBsaXN0ZW5lcnMgPSBbXTtcblx0bGV0IHF1ZXVlID0gW1tcIlwiLCB7fV1dO1xuXHRsZXQgcG9zaXRpb24gPSAwO1xuXHRiYXNlID0gbm9ybWFsaXplQmFzZShiYXNlKTtcblx0ZnVuY3Rpb24gc2V0TG9jYXRpb24obG9jYXRpb24sIHN0YXRlID0ge30pIHtcblx0XHRwb3NpdGlvbisrO1xuXHRcdGlmIChwb3NpdGlvbiAhPT0gcXVldWUubGVuZ3RoKSBxdWV1ZS5zcGxpY2UocG9zaXRpb24pO1xuXHRcdHF1ZXVlLnB1c2goW2xvY2F0aW9uLCBzdGF0ZV0pO1xuXHR9XG5cdGZ1bmN0aW9uIHRyaWdnZXJMaXN0ZW5lcnModG8sIGZyb20sIHsgZGlyZWN0aW9uLCBkZWx0YSB9KSB7XG5cdFx0Y29uc3QgaW5mbyA9IHtcblx0XHRcdGRpcmVjdGlvbixcblx0XHRcdGRlbHRhLFxuXHRcdFx0dHlwZTogXCJwb3BcIlxuXHRcdH07XG5cdFx0Zm9yIChjb25zdCBjYWxsYmFjayBvZiBsaXN0ZW5lcnMpIGNhbGxiYWNrKHRvLCBmcm9tLCBpbmZvKTtcblx0fVxuXHRjb25zdCByb3V0ZXJIaXN0b3J5ID0ge1xuXHRcdGxvY2F0aW9uOiBcIlwiLFxuXHRcdHN0YXRlOiB7fSxcblx0XHRiYXNlLFxuXHRcdGNyZWF0ZUhyZWY6IGNyZWF0ZUhyZWYuYmluZChudWxsLCBiYXNlKSxcblx0XHRyZXBsYWNlKHRvLCBzdGF0ZSkge1xuXHRcdFx0cXVldWUuc3BsaWNlKHBvc2l0aW9uLS0sIDEpO1xuXHRcdFx0c2V0TG9jYXRpb24odG8sIHN0YXRlKTtcblx0XHR9LFxuXHRcdHB1c2godG8sIHN0YXRlKSB7XG5cdFx0XHRzZXRMb2NhdGlvbih0bywgc3RhdGUpO1xuXHRcdH0sXG5cdFx0bGlzdGVuKGNhbGxiYWNrKSB7XG5cdFx0XHRsaXN0ZW5lcnMucHVzaChjYWxsYmFjayk7XG5cdFx0XHRyZXR1cm4gKCkgPT4ge1xuXHRcdFx0XHRjb25zdCBpbmRleCA9IGxpc3RlbmVycy5pbmRleE9mKGNhbGxiYWNrKTtcblx0XHRcdFx0aWYgKGluZGV4ID4gLTEpIGxpc3RlbmVycy5zcGxpY2UoaW5kZXgsIDEpO1xuXHRcdFx0fTtcblx0XHR9LFxuXHRcdGRlc3Ryb3koKSB7XG5cdFx0XHRsaXN0ZW5lcnMgPSBbXTtcblx0XHRcdHF1ZXVlID0gW1tcIlwiLCB7fV1dO1xuXHRcdFx0cG9zaXRpb24gPSAwO1xuXHRcdH0sXG5cdFx0Z28oZGVsdGEsIHNob3VsZFRyaWdnZXIgPSB0cnVlKSB7XG5cdFx0XHRjb25zdCBmcm9tID0gdGhpcy5sb2NhdGlvbjtcblx0XHRcdGNvbnN0IGRpcmVjdGlvbiA9IGRlbHRhIDwgMCA/IFwiYmFja1wiIDogXCJmb3J3YXJkXCI7XG5cdFx0XHRwb3NpdGlvbiA9IE1hdGgubWF4KDAsIE1hdGgubWluKHBvc2l0aW9uICsgZGVsdGEsIHF1ZXVlLmxlbmd0aCAtIDEpKTtcblx0XHRcdGlmIChzaG91bGRUcmlnZ2VyKSB0cmlnZ2VyTGlzdGVuZXJzKHRoaXMubG9jYXRpb24sIGZyb20sIHtcblx0XHRcdFx0ZGlyZWN0aW9uLFxuXHRcdFx0XHRkZWx0YVxuXHRcdFx0fSk7XG5cdFx0fVxuXHR9O1xuXHRPYmplY3QuZGVmaW5lUHJvcGVydHkocm91dGVySGlzdG9yeSwgXCJsb2NhdGlvblwiLCB7XG5cdFx0ZW51bWVyYWJsZTogdHJ1ZSxcblx0XHRnZXQ6ICgpID0+IHF1ZXVlW3Bvc2l0aW9uXVswXVxuXHR9KTtcblx0T2JqZWN0LmRlZmluZVByb3BlcnR5KHJvdXRlckhpc3RvcnksIFwic3RhdGVcIiwge1xuXHRcdGVudW1lcmFibGU6IHRydWUsXG5cdFx0Z2V0OiAoKSA9PiBxdWV1ZVtwb3NpdGlvbl1bMV1cblx0fSk7XG5cdHJldHVybiByb3V0ZXJIaXN0b3J5O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL21hdGNoZXIvcGF0aFRva2VuaXplci50c1xuY29uc3QgUk9PVF9UT0tFTiA9IHtcblx0dHlwZTogMCxcblx0dmFsdWU6IFwiXCJcbn07XG5jb25zdCBWQUxJRF9QQVJBTV9SRSA9IC9bYS16QS1aMC05X10vO1xuZnVuY3Rpb24gdG9rZW5pemVQYXRoKHBhdGgpIHtcblx0aWYgKCFwYXRoKSByZXR1cm4gW1tdXTtcblx0aWYgKHBhdGggPT09IFwiL1wiKSByZXR1cm4gW1tST09UX1RPS0VOXV07XG5cdGlmICghaXNBYnNvbHV0ZVBhdGgocGF0aCkpIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyBgUm91dGUgcGF0aHMgc2hvdWxkIHN0YXJ0IHdpdGggYSBcIi9cIjogXCIke3BhdGh9XCIgc2hvdWxkIGJlIFwiLyR7cGF0aH1cIi5gIDogYEludmFsaWQgcGF0aCBcIiR7cGF0aH1cImApO1xuXHRmdW5jdGlvbiBjcmFzaChtZXNzYWdlKSB7XG5cdFx0dGhyb3cgbmV3IEVycm9yKGBFUlIgKCR7c3RhdGV9KS9cIiR7YnVmZmVyfVwiOiAke21lc3NhZ2V9YCk7XG5cdH1cblx0bGV0IHN0YXRlID0gMDtcblx0bGV0IHByZXZpb3VzU3RhdGUgPSBzdGF0ZTtcblx0Y29uc3QgdG9rZW5zID0gW107XG5cdGxldCBzZWdtZW50O1xuXHRmdW5jdGlvbiBmaW5hbGl6ZVNlZ21lbnQoKSB7XG5cdFx0aWYgKHNlZ21lbnQpIHRva2Vucy5wdXNoKHNlZ21lbnQpO1xuXHRcdHNlZ21lbnQgPSBbXTtcblx0fVxuXHRsZXQgaSA9IDA7XG5cdGxldCBjaGFyO1xuXHRsZXQgYnVmZmVyID0gXCJcIjtcblx0bGV0IGN1c3RvbVJlID0gXCJcIjtcblx0ZnVuY3Rpb24gY29uc3VtZUJ1ZmZlcigpIHtcblx0XHRpZiAoIWJ1ZmZlcikgcmV0dXJuO1xuXHRcdGlmIChzdGF0ZSA9PT0gMCkgc2VnbWVudC5wdXNoKHtcblx0XHRcdHR5cGU6IDAsXG5cdFx0XHR2YWx1ZTogYnVmZmVyXG5cdFx0fSk7XG5cdFx0ZWxzZSBpZiAoc3RhdGUgPT09IDEgfHwgc3RhdGUgPT09IDIgfHwgc3RhdGUgPT09IDMpIHtcblx0XHRcdGlmIChzZWdtZW50Lmxlbmd0aCA+IDEgJiYgKGNoYXIgPT09IFwiKlwiIHx8IGNoYXIgPT09IFwiK1wiKSkgY3Jhc2goYEEgcmVwZWF0YWJsZSBwYXJhbSAoJHtidWZmZXJ9KSBtdXN0IGJlIGFsb25lIGluIGl0cyBzZWdtZW50LiBlZzogJy86aWRzKy5gKTtcblx0XHRcdHNlZ21lbnQucHVzaCh7XG5cdFx0XHRcdHR5cGU6IDEsXG5cdFx0XHRcdHZhbHVlOiBidWZmZXIsXG5cdFx0XHRcdHJlZ2V4cDogY3VzdG9tUmUsXG5cdFx0XHRcdHJlcGVhdGFibGU6IGNoYXIgPT09IFwiKlwiIHx8IGNoYXIgPT09IFwiK1wiLFxuXHRcdFx0XHRvcHRpb25hbDogY2hhciA9PT0gXCIqXCIgfHwgY2hhciA9PT0gXCI/XCJcblx0XHRcdH0pO1xuXHRcdH0gZWxzZSBjcmFzaChcIkludmFsaWQgc3RhdGUgdG8gY29uc3VtZSBidWZmZXJcIik7XG5cdFx0YnVmZmVyID0gXCJcIjtcblx0fVxuXHRmdW5jdGlvbiBhZGRDaGFyVG9CdWZmZXIoKSB7XG5cdFx0YnVmZmVyICs9IGNoYXI7XG5cdH1cblx0d2hpbGUgKGkgPCBwYXRoLmxlbmd0aCkge1xuXHRcdGNoYXIgPSBwYXRoW2krK107XG5cdFx0c3dpdGNoIChzdGF0ZSkge1xuXHRcdFx0Y2FzZSAwOlxuXHRcdFx0XHRpZiAoY2hhciA9PT0gXCJcXFxcXCIpIHtcblx0XHRcdFx0XHRwcmV2aW91c1N0YXRlID0gc3RhdGU7XG5cdFx0XHRcdFx0c3RhdGUgPSA0O1xuXHRcdFx0XHR9IGVsc2UgaWYgKGNoYXIgPT09IFwiL1wiKSB7XG5cdFx0XHRcdFx0aWYgKGJ1ZmZlcikgY29uc3VtZUJ1ZmZlcigpO1xuXHRcdFx0XHRcdGZpbmFsaXplU2VnbWVudCgpO1xuXHRcdFx0XHR9IGVsc2UgaWYgKGNoYXIgPT09IFwiOlwiKSB7XG5cdFx0XHRcdFx0Y29uc3VtZUJ1ZmZlcigpO1xuXHRcdFx0XHRcdHN0YXRlID0gMTtcblx0XHRcdFx0fSBlbHNlIGFkZENoYXJUb0J1ZmZlcigpO1xuXHRcdFx0XHRicmVhaztcblx0XHRcdGNhc2UgNDpcblx0XHRcdFx0YWRkQ2hhclRvQnVmZmVyKCk7XG5cdFx0XHRcdHN0YXRlID0gcHJldmlvdXNTdGF0ZTtcblx0XHRcdFx0YnJlYWs7XG5cdFx0XHRjYXNlIDE6XG5cdFx0XHRcdGlmIChjaGFyID09PSBcIihcIikgc3RhdGUgPSAyO1xuXHRcdFx0XHRlbHNlIGlmIChWQUxJRF9QQVJBTV9SRS50ZXN0KGNoYXIpKSBhZGRDaGFyVG9CdWZmZXIoKTtcblx0XHRcdFx0ZWxzZSB7XG5cdFx0XHRcdFx0Y29uc3VtZUJ1ZmZlcigpO1xuXHRcdFx0XHRcdHN0YXRlID0gMDtcblx0XHRcdFx0XHRpZiAoY2hhciAhPT0gXCIqXCIgJiYgY2hhciAhPT0gXCI/XCIgJiYgY2hhciAhPT0gXCIrXCIpIGktLTtcblx0XHRcdFx0fVxuXHRcdFx0XHRicmVhaztcblx0XHRcdGNhc2UgMjpcblx0XHRcdFx0aWYgKGNoYXIgPT09IFwiKVwiKSB7XG5cdFx0XHRcdFx0aWYgKGN1c3RvbVJlW2N1c3RvbVJlLmxlbmd0aCAtIDFdID09IFwiXFxcXFwiKSBjdXN0b21SZSA9IGN1c3RvbVJlLnNsaWNlKDAsIC0xKSArIGNoYXI7XG5cdFx0XHRcdFx0ZWxzZSBzdGF0ZSA9IDM7XG5cdFx0XHRcdH0gZWxzZSBjdXN0b21SZSArPSBjaGFyO1xuXHRcdFx0XHRicmVhaztcblx0XHRcdGNhc2UgMzpcblx0XHRcdFx0Y29uc3VtZUJ1ZmZlcigpO1xuXHRcdFx0XHRzdGF0ZSA9IDA7XG5cdFx0XHRcdGlmIChjaGFyICE9PSBcIipcIiAmJiBjaGFyICE9PSBcIj9cIiAmJiBjaGFyICE9PSBcIitcIikgaS0tO1xuXHRcdFx0XHRjdXN0b21SZSA9IFwiXCI7XG5cdFx0XHRcdGJyZWFrO1xuXHRcdFx0ZGVmYXVsdDogY3Jhc2goXCJVbmtub3duIHN0YXRlXCIpO1xuXHRcdH1cblx0fVxuXHRpZiAoc3RhdGUgPT09IDIpIGNyYXNoKGBVbmZpbmlzaGVkIGN1c3RvbSBSZWdFeHAgZm9yIHBhcmFtIFwiJHtidWZmZXJ9XCJgKTtcblx0Y29uc3VtZUJ1ZmZlcigpO1xuXHRmaW5hbGl6ZVNlZ21lbnQoKTtcblx0cmV0dXJuIHRva2Vucztcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tYXRjaGVyL3BhdGhQYXJzZXJSYW5rZXIudHNcbmNvbnN0IEJBU0VfUEFSQU1fUEFUVEVSTiA9IFwiW14vXSs/XCI7XG5jb25zdCBCQVNFX1BBVEhfUEFSU0VSX09QVElPTlMgPSB7XG5cdHNlbnNpdGl2ZTogZmFsc2UsXG5cdHN0cmljdDogZmFsc2UsXG5cdHN0YXJ0OiB0cnVlLFxuXHRlbmQ6IHRydWVcbn07XG5jb25zdCBSRUdFWF9DSEFSU19SRSA9IC9bLisqP14ke30oKVtcXF0vXFxcXF0vZztcbi8qKlxuKiBDcmVhdGVzIGEgcGF0aCBwYXJzZXIgZnJvbSBhbiBhcnJheSBvZiBTZWdtZW50cyAoYSBzZWdtZW50IGlzIGFuIGFycmF5IG9mIFRva2VucylcbipcbiogQHBhcmFtIHNlZ21lbnRzIC0gYXJyYXkgb2Ygc2VnbWVudHMgcmV0dXJuZWQgYnkgdG9rZW5pemVQYXRoXG4qIEBwYXJhbSBleHRyYU9wdGlvbnMgLSBvcHRpb25hbCBvcHRpb25zIGZvciB0aGUgcmVnZXhwXG4qIEByZXR1cm5zIGEgUGF0aFBhcnNlclxuKi9cbmZ1bmN0aW9uIHRva2Vuc1RvUGFyc2VyKHNlZ21lbnRzLCBleHRyYU9wdGlvbnMpIHtcblx0Y29uc3Qgb3B0aW9ucyA9IGFzc2lnbih7fSwgQkFTRV9QQVRIX1BBUlNFUl9PUFRJT05TLCBleHRyYU9wdGlvbnMpO1xuXHRjb25zdCBzY29yZSA9IFtdO1xuXHRsZXQgcGF0dGVybiA9IG9wdGlvbnMuc3RhcnQgPyBcIl5cIiA6IFwiXCI7XG5cdGNvbnN0IGtleXMgPSBbXTtcblx0Zm9yIChjb25zdCBzZWdtZW50IG9mIHNlZ21lbnRzKSB7XG5cdFx0Y29uc3Qgc2VnbWVudFNjb3JlcyA9IHNlZ21lbnQubGVuZ3RoID8gW10gOiBbOTBdO1xuXHRcdGlmIChvcHRpb25zLnN0cmljdCAmJiAhc2VnbWVudC5sZW5ndGgpIHBhdHRlcm4gKz0gXCIvXCI7XG5cdFx0Zm9yIChsZXQgdG9rZW5JbmRleCA9IDA7IHRva2VuSW5kZXggPCBzZWdtZW50Lmxlbmd0aDsgdG9rZW5JbmRleCsrKSB7XG5cdFx0XHRjb25zdCB0b2tlbiA9IHNlZ21lbnRbdG9rZW5JbmRleF07XG5cdFx0XHRsZXQgc3ViU2VnbWVudFNjb3JlID0gNDAgKyAob3B0aW9ucy5zZW5zaXRpdmUgPyAuMjUgOiAwKTtcblx0XHRcdGlmICh0b2tlbi50eXBlID09PSAwKSB7XG5cdFx0XHRcdGlmICghdG9rZW5JbmRleCkgcGF0dGVybiArPSBcIi9cIjtcblx0XHRcdFx0cGF0dGVybiArPSB0b2tlbi52YWx1ZS5yZXBsYWNlKFJFR0VYX0NIQVJTX1JFLCBcIlxcXFwkJlwiKTtcblx0XHRcdFx0c3ViU2VnbWVudFNjb3JlICs9IDQwO1xuXHRcdFx0fSBlbHNlIGlmICh0b2tlbi50eXBlID09PSAxKSB7XG5cdFx0XHRcdGNvbnN0IHsgdmFsdWUsIHJlcGVhdGFibGUsIG9wdGlvbmFsLCByZWdleHAgfSA9IHRva2VuO1xuXHRcdFx0XHRrZXlzLnB1c2goe1xuXHRcdFx0XHRcdG5hbWU6IHZhbHVlLFxuXHRcdFx0XHRcdHJlcGVhdGFibGUsXG5cdFx0XHRcdFx0b3B0aW9uYWxcblx0XHRcdFx0fSk7XG5cdFx0XHRcdGNvbnN0IHJlID0gcmVnZXhwID8gcmVnZXhwIDogQkFTRV9QQVJBTV9QQVRURVJOO1xuXHRcdFx0XHRpZiAocmUgIT09IEJBU0VfUEFSQU1fUEFUVEVSTikge1xuXHRcdFx0XHRcdHN1YlNlZ21lbnRTY29yZSArPSAxMDtcblx0XHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdFx0bmV3IFJlZ0V4cChgKCR7cmV9KWApO1xuXHRcdFx0XHRcdH0gY2F0Y2ggKGVycikge1xuXHRcdFx0XHRcdFx0dGhyb3cgbmV3IEVycm9yKGBJbnZhbGlkIGN1c3RvbSBSZWdFeHAgZm9yIHBhcmFtIFwiJHt2YWx1ZX1cIiAoJHtyZX0pOiBgICsgZXJyLm1lc3NhZ2UpO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHRsZXQgc3ViUGF0dGVybiA9IHJlcGVhdGFibGUgPyBgKCg/OiR7cmV9KSg/Oi8oPzoke3JlfSkpKilgIDogYCgke3JlfSlgO1xuXHRcdFx0XHRpZiAoIXRva2VuSW5kZXgpIHN1YlBhdHRlcm4gPSBvcHRpb25hbCAmJiBzZWdtZW50Lmxlbmd0aCA8IDIgPyBgKD86LyR7c3ViUGF0dGVybn0pYCA6IFwiL1wiICsgc3ViUGF0dGVybjtcblx0XHRcdFx0aWYgKG9wdGlvbmFsKSBzdWJQYXR0ZXJuICs9IFwiP1wiO1xuXHRcdFx0XHRwYXR0ZXJuICs9IHN1YlBhdHRlcm47XG5cdFx0XHRcdHN1YlNlZ21lbnRTY29yZSArPSAyMDtcblx0XHRcdFx0aWYgKG9wdGlvbmFsKSBzdWJTZWdtZW50U2NvcmUgKz0gLTg7XG5cdFx0XHRcdGlmIChyZXBlYXRhYmxlKSBzdWJTZWdtZW50U2NvcmUgKz0gLTIwO1xuXHRcdFx0XHRpZiAocmUgPT09IFwiLipcIikgc3ViU2VnbWVudFNjb3JlICs9IC01MDtcblx0XHRcdH1cblx0XHRcdHNlZ21lbnRTY29yZXMucHVzaChzdWJTZWdtZW50U2NvcmUpO1xuXHRcdH1cblx0XHRzY29yZS5wdXNoKHNlZ21lbnRTY29yZXMpO1xuXHR9XG5cdGlmIChvcHRpb25zLnN0cmljdCAmJiBvcHRpb25zLmVuZCkge1xuXHRcdGNvbnN0IGkgPSBzY29yZS5sZW5ndGggLSAxO1xuXHRcdHNjb3JlW2ldW3Njb3JlW2ldLmxlbmd0aCAtIDFdICs9IC43MDAwMDAwMDAwMDAwMDAxO1xuXHR9XG5cdGlmICghb3B0aW9ucy5zdHJpY3QpIHBhdHRlcm4gKz0gXCIvP1wiO1xuXHRpZiAob3B0aW9ucy5lbmQpIHBhdHRlcm4gKz0gXCIkXCI7XG5cdGVsc2UgaWYgKG9wdGlvbnMuc3RyaWN0ICYmICFwYXR0ZXJuLmVuZHNXaXRoKFwiL1wiKSkgcGF0dGVybiArPSBcIig/Oi98JClcIjtcblx0Y29uc3QgcmUgPSBuZXcgUmVnRXhwKHBhdHRlcm4sIG9wdGlvbnMuc2Vuc2l0aXZlID8gXCJcIiA6IFwiaVwiKTtcblx0ZnVuY3Rpb24gcGFyc2UocGF0aCkge1xuXHRcdGNvbnN0IG1hdGNoID0gcGF0aC5tYXRjaChyZSk7XG5cdFx0Y29uc3QgcGFyYW1zID0ge307XG5cdFx0aWYgKCFtYXRjaCkgcmV0dXJuIG51bGw7XG5cdFx0Zm9yIChsZXQgaSA9IDE7IGkgPCBtYXRjaC5sZW5ndGg7IGkrKykge1xuXHRcdFx0Y29uc3QgdmFsdWUgPSBtYXRjaFtpXSB8fCBcIlwiO1xuXHRcdFx0Y29uc3Qga2V5ID0ga2V5c1tpIC0gMV07XG5cdFx0XHRwYXJhbXNba2V5Lm5hbWVdID0gdmFsdWUgJiYga2V5LnJlcGVhdGFibGUgPyB2YWx1ZS5zcGxpdChcIi9cIikgOiB2YWx1ZTtcblx0XHR9XG5cdFx0cmV0dXJuIHBhcmFtcztcblx0fVxuXHRmdW5jdGlvbiBzdHJpbmdpZnkocGFyYW1zKSB7XG5cdFx0bGV0IHBhdGggPSBcIlwiO1xuXHRcdGxldCBhdm9pZER1cGxpY2F0ZWRTbGFzaCA9IGZhbHNlO1xuXHRcdGZvciAoY29uc3Qgc2VnbWVudCBvZiBzZWdtZW50cykge1xuXHRcdFx0aWYgKCFhdm9pZER1cGxpY2F0ZWRTbGFzaCB8fCAhcGF0aC5lbmRzV2l0aChcIi9cIikpIHBhdGggKz0gXCIvXCI7XG5cdFx0XHRhdm9pZER1cGxpY2F0ZWRTbGFzaCA9IGZhbHNlO1xuXHRcdFx0Zm9yIChjb25zdCB0b2tlbiBvZiBzZWdtZW50KSBpZiAodG9rZW4udHlwZSA9PT0gMCkgcGF0aCArPSB0b2tlbi52YWx1ZTtcblx0XHRcdGVsc2UgaWYgKHRva2VuLnR5cGUgPT09IDEpIHtcblx0XHRcdFx0Y29uc3QgeyB2YWx1ZSwgcmVwZWF0YWJsZSwgb3B0aW9uYWwgfSA9IHRva2VuO1xuXHRcdFx0XHRjb25zdCBwYXJhbSA9IHZhbHVlIGluIHBhcmFtcyA/IHBhcmFtc1t2YWx1ZV0gOiBcIlwiO1xuXHRcdFx0XHRpZiAoaXNBcnJheShwYXJhbSkgJiYgIXJlcGVhdGFibGUpIHRocm93IG5ldyBFcnJvcihgUHJvdmlkZWQgcGFyYW0gXCIke3ZhbHVlfVwiIGlzIGFuIGFycmF5IGJ1dCBpdCBpcyBub3QgcmVwZWF0YWJsZSAoKiBvciArIG1vZGlmaWVycylgKTtcblx0XHRcdFx0Y29uc3QgdGV4dCA9IGlzQXJyYXkocGFyYW0pID8gcGFyYW0uam9pbihcIi9cIikgOiBwYXJhbTtcblx0XHRcdFx0aWYgKCF0ZXh0KSB7XG5cdFx0XHRcdFx0aWYgKG9wdGlvbmFsKSB7XG5cdFx0XHRcdFx0XHRpZiAoc2VnbWVudC5sZW5ndGggPCAyKSB7XG5cdFx0XHRcdFx0XHRcdGlmIChwYXRoLmVuZHNXaXRoKFwiL1wiKSkgcGF0aCA9IHBhdGguc2xpY2UoMCwgLTEpO1xuXHRcdFx0XHRcdFx0XHRlbHNlIGF2b2lkRHVwbGljYXRlZFNsYXNoID0gdHJ1ZTtcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9IGVsc2UgdGhyb3cgbmV3IEVycm9yKGBNaXNzaW5nIHJlcXVpcmVkIHBhcmFtIFwiJHt2YWx1ZX1cImApO1xuXHRcdFx0XHR9XG5cdFx0XHRcdHBhdGggKz0gdGV4dDtcblx0XHRcdH1cblx0XHR9XG5cdFx0cmV0dXJuIHBhdGggfHwgXCIvXCI7XG5cdH1cblx0cmV0dXJuIHtcblx0XHRyZSxcblx0XHRzY29yZSxcblx0XHRrZXlzLFxuXHRcdHBhcnNlLFxuXHRcdHN0cmluZ2lmeVxuXHR9O1xufVxuLyoqXG4qIENvbXBhcmVzIGFuIGFycmF5IG9mIG51bWJlcnMgYXMgdXNlZCBpbiBQYXRoUGFyc2VyLnNjb3JlIGFuZCByZXR1cm5zIGFcbiogbnVtYmVyLiBUaGlzIGZ1bmN0aW9uIGNhbiBiZSB1c2VkIHRvIGBzb3J0YCBhbiBhcnJheVxuKlxuKiBAcGFyYW0gYSAtIGZpcnN0IGFycmF5IG9mIG51bWJlcnNcbiogQHBhcmFtIGIgLSBzZWNvbmQgYXJyYXkgb2YgbnVtYmVyc1xuKiBAcmV0dXJucyAwIGlmIGJvdGggYXJlIGVxdWFsLCA8IDAgaWYgYSBzaG91bGQgYmUgc29ydGVkIGZpcnN0LCA+IDAgaWYgYlxuKiBzaG91bGQgYmUgc29ydGVkIGZpcnN0XG4qL1xuZnVuY3Rpb24gY29tcGFyZVNjb3JlQXJyYXkoYSwgYikge1xuXHRsZXQgaSA9IDA7XG5cdHdoaWxlIChpIDwgYS5sZW5ndGggJiYgaSA8IGIubGVuZ3RoKSB7XG5cdFx0Y29uc3QgZGlmZiA9IGJbaV0gLSBhW2ldO1xuXHRcdGlmIChkaWZmKSByZXR1cm4gZGlmZjtcblx0XHRpKys7XG5cdH1cblx0aWYgKGEubGVuZ3RoIDwgYi5sZW5ndGgpIHJldHVybiBhLmxlbmd0aCA9PT0gMSAmJiBhWzBdID09PSA4MCA/IC0xIDogMTtcblx0ZWxzZSBpZiAoYS5sZW5ndGggPiBiLmxlbmd0aCkgcmV0dXJuIGIubGVuZ3RoID09PSAxICYmIGJbMF0gPT09IDgwID8gMSA6IC0xO1xuXHRyZXR1cm4gMDtcbn1cbi8qKlxuKiBDb21wYXJlIGZ1bmN0aW9uIHRoYXQgY2FuIGJlIHVzZWQgd2l0aCBgc29ydGAgdG8gc29ydCBhbiBhcnJheSBvZiBQYXRoUGFyc2VyXG4qXG4qIEBwYXJhbSBhIC0gZmlyc3QgUGF0aFBhcnNlclxuKiBAcGFyYW0gYiAtIHNlY29uZCBQYXRoUGFyc2VyXG4qIEByZXR1cm5zIDAgaWYgYm90aCBhcmUgZXF1YWwsIDwgMCBpZiBhIHNob3VsZCBiZSBzb3J0ZWQgZmlyc3QsID4gMCBpZiBiXG4qL1xuZnVuY3Rpb24gY29tcGFyZVBhdGhQYXJzZXJTY29yZShhLCBiKSB7XG5cdGxldCBpID0gMDtcblx0Y29uc3QgYVNjb3JlID0gYS5zY29yZTtcblx0Y29uc3QgYlNjb3JlID0gYi5zY29yZTtcblx0d2hpbGUgKGkgPCBhU2NvcmUubGVuZ3RoICYmIGkgPCBiU2NvcmUubGVuZ3RoKSB7XG5cdFx0Y29uc3QgY29tcCA9IGNvbXBhcmVTY29yZUFycmF5KGFTY29yZVtpXSwgYlNjb3JlW2ldKTtcblx0XHRpZiAoY29tcCkgcmV0dXJuIGNvbXA7XG5cdFx0aSsrO1xuXHR9XG5cdGlmIChNYXRoLmFicyhiU2NvcmUubGVuZ3RoIC0gYVNjb3JlLmxlbmd0aCkgPT09IDEpIHtcblx0XHRpZiAoaXNMYXN0U2NvcmVOZWdhdGl2ZShhU2NvcmUpKSByZXR1cm4gMTtcblx0XHRpZiAoaXNMYXN0U2NvcmVOZWdhdGl2ZShiU2NvcmUpKSByZXR1cm4gLTE7XG5cdH1cblx0cmV0dXJuIGJTY29yZS5sZW5ndGggLSBhU2NvcmUubGVuZ3RoO1xufVxuLyoqXG4qIFRoaXMgYWxsb3dzIGRldGVjdGluZyBzcGxhdHMgYXQgdGhlIGVuZCBvZiBhIHBhdGg6IC9ob21lLzppZCguKikqXG4qXG4qIEBwYXJhbSBzY29yZSAtIHNjb3JlIHRvIGNoZWNrXG4qIEByZXR1cm5zIHRydWUgaWYgdGhlIGxhc3QgZW50cnkgaXMgbmVnYXRpdmVcbiovXG5mdW5jdGlvbiBpc0xhc3RTY29yZU5lZ2F0aXZlKHNjb3JlKSB7XG5cdGNvbnN0IGxhc3QgPSBzY29yZVtzY29yZS5sZW5ndGggLSAxXTtcblx0cmV0dXJuIHNjb3JlLmxlbmd0aCA+IDAgJiYgbGFzdFtsYXN0Lmxlbmd0aCAtIDFdIDwgMDtcbn1cbmNvbnN0IFBBVEhfUEFSU0VSX09QVElPTlNfREVGQVVMVFMgPSB7XG5cdHN0cmljdDogZmFsc2UsXG5cdGVuZDogdHJ1ZSxcblx0c2Vuc2l0aXZlOiBmYWxzZVxufTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tYXRjaGVyL3BhdGhNYXRjaGVyLnRzXG5mdW5jdGlvbiBjcmVhdGVSb3V0ZVJlY29yZE1hdGNoZXIocmVjb3JkLCBwYXJlbnQsIG9wdGlvbnMpIHtcblx0Y29uc3QgcGFyc2VyID0gdG9rZW5zVG9QYXJzZXIodG9rZW5pemVQYXRoKHJlY29yZC5wYXRoKSwgb3B0aW9ucyk7XG5cdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcblx0XHRjb25zdCBleGlzdGluZ0tleXMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuXHRcdGZvciAoY29uc3Qga2V5IG9mIHBhcnNlci5rZXlzKSB7XG5cdFx0XHRpZiAoZXhpc3RpbmdLZXlzLmhhcyhrZXkubmFtZSkpIGRpYWdub3N0aWNzLlZVRV9ST1VURVJfUjAwOTAoe1xuXHRcdFx0XHRuYW1lOiBrZXkubmFtZSxcblx0XHRcdFx0cGF0aDogcmVjb3JkLnBhdGhcblx0XHRcdH0pO1xuXHRcdFx0ZXhpc3RpbmdLZXlzLmFkZChrZXkubmFtZSk7XG5cdFx0fVxuXHR9XG5cdGNvbnN0IG1hdGNoZXIgPSBhc3NpZ24ocGFyc2VyLCB7XG5cdFx0cmVjb3JkLFxuXHRcdHBhcmVudCxcblx0XHRjaGlsZHJlbjogW10sXG5cdFx0YWxpYXM6IFtdXG5cdH0pO1xuXHRpZiAocGFyZW50KSB7XG5cdFx0aWYgKCFtYXRjaGVyLnJlY29yZC5hbGlhc09mID09PSAhcGFyZW50LnJlY29yZC5hbGlhc09mKSBwYXJlbnQuY2hpbGRyZW4ucHVzaChtYXRjaGVyKTtcblx0fVxuXHRyZXR1cm4gbWF0Y2hlcjtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tYXRjaGVyL2luZGV4LnRzXG4vKipcbiogQ3JlYXRlcyBhIFJvdXRlciBNYXRjaGVyLlxuKlxuKiBAaW50ZXJuYWxcbiogQHBhcmFtIHJvdXRlcyAtIGFycmF5IG9mIGluaXRpYWwgcm91dGVzXG4qIEBwYXJhbSBnbG9iYWxPcHRpb25zIC0gZ2xvYmFsIHJvdXRlIG9wdGlvbnNcbiovXG5mdW5jdGlvbiBjcmVhdGVSb3V0ZXJNYXRjaGVyKHJvdXRlcywgZ2xvYmFsT3B0aW9ucykge1xuXHRjb25zdCBtYXRjaGVycyA9IFtdO1xuXHRjb25zdCBtYXRjaGVyTWFwID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0Z2xvYmFsT3B0aW9ucyA9IG1lcmdlT3B0aW9ucyhQQVRIX1BBUlNFUl9PUFRJT05TX0RFRkFVTFRTLCBnbG9iYWxPcHRpb25zKTtcblx0ZnVuY3Rpb24gZ2V0UmVjb3JkTWF0Y2hlcihuYW1lKSB7XG5cdFx0cmV0dXJuIG1hdGNoZXJNYXAuZ2V0KG5hbWUpO1xuXHR9XG5cdGZ1bmN0aW9uIGFkZFJvdXRlKHJlY29yZCwgcGFyZW50LCBvcmlnaW5hbFJlY29yZCkge1xuXHRcdGNvbnN0IGlzUm9vdEFkZCA9ICFvcmlnaW5hbFJlY29yZDtcblx0XHRjb25zdCBtYWluTm9ybWFsaXplZFJlY29yZCA9IG5vcm1hbGl6ZVJvdXRlUmVjb3JkKHJlY29yZCk7XG5cdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgY2hlY2tDaGlsZE1pc3NpbmdOYW1lV2l0aEVtcHR5UGF0aChtYWluTm9ybWFsaXplZFJlY29yZCwgcGFyZW50KTtcblx0XHRtYWluTm9ybWFsaXplZFJlY29yZC5hbGlhc09mID0gb3JpZ2luYWxSZWNvcmQgJiYgb3JpZ2luYWxSZWNvcmQucmVjb3JkO1xuXHRcdGNvbnN0IG9wdGlvbnMgPSBtZXJnZU9wdGlvbnMoZ2xvYmFsT3B0aW9ucywgcmVjb3JkKTtcblx0XHRjb25zdCBub3JtYWxpemVkUmVjb3JkcyA9IFttYWluTm9ybWFsaXplZFJlY29yZF07XG5cdFx0aWYgKFwiYWxpYXNcIiBpbiByZWNvcmQpIHtcblx0XHRcdGNvbnN0IGFsaWFzZXMgPSB0eXBlb2YgcmVjb3JkLmFsaWFzID09PSBcInN0cmluZ1wiID8gW3JlY29yZC5hbGlhc10gOiByZWNvcmQuYWxpYXM7XG5cdFx0XHRmb3IgKGNvbnN0IGFsaWFzIG9mIGFsaWFzZXMpIG5vcm1hbGl6ZWRSZWNvcmRzLnB1c2gobm9ybWFsaXplUm91dGVSZWNvcmQoYXNzaWduKHt9LCBtYWluTm9ybWFsaXplZFJlY29yZCwge1xuXHRcdFx0XHRjb21wb25lbnRzOiBvcmlnaW5hbFJlY29yZCA/IG9yaWdpbmFsUmVjb3JkLnJlY29yZC5jb21wb25lbnRzIDogbWFpbk5vcm1hbGl6ZWRSZWNvcmQuY29tcG9uZW50cyxcblx0XHRcdFx0cGF0aDogYWxpYXMsXG5cdFx0XHRcdGFsaWFzT2Y6IG9yaWdpbmFsUmVjb3JkID8gb3JpZ2luYWxSZWNvcmQucmVjb3JkIDogbWFpbk5vcm1hbGl6ZWRSZWNvcmRcblx0XHRcdH0pKSk7XG5cdFx0fVxuXHRcdGxldCBtYXRjaGVyO1xuXHRcdGxldCBvcmlnaW5hbE1hdGNoZXI7XG5cdFx0Zm9yIChjb25zdCBub3JtYWxpemVkUmVjb3JkIG9mIG5vcm1hbGl6ZWRSZWNvcmRzKSB7XG5cdFx0XHRjb25zdCB7IHBhdGggfSA9IG5vcm1hbGl6ZWRSZWNvcmQ7XG5cdFx0XHRpZiAocGFyZW50ICYmICFpc0Fic29sdXRlUGF0aChwYXRoKSkge1xuXHRcdFx0XHRjb25zdCBwYXJlbnRQYXRoID0gcGFyZW50LnJlY29yZC5wYXRoO1xuXHRcdFx0XHRjb25zdCBjb25uZWN0aW5nU2xhc2ggPSBwYXJlbnRQYXRoW3BhcmVudFBhdGgubGVuZ3RoIC0gMV0gPT09IFwiL1wiID8gXCJcIiA6IFwiL1wiO1xuXHRcdFx0XHRub3JtYWxpemVkUmVjb3JkLnBhdGggPSBwYXJlbnQucmVjb3JkLnBhdGggKyAocGF0aCAmJiBjb25uZWN0aW5nU2xhc2ggKyBwYXRoKTtcblx0XHRcdH1cblx0XHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgbm9ybWFsaXplZFJlY29yZC5wYXRoID09PSBcIipcIikgdGhyb3cgbmV3IEVycm9yKFwiQ2F0Y2ggYWxsIHJvdXRlcyAoXFxcIipcXFwiKSBtdXN0IG5vdyBiZSBkZWZpbmVkIHVzaW5nIGEgcGFyYW0gd2l0aCBhIGN1c3RvbSByZWdleHAuXFxuU2VlIG1vcmUgYXQgaHR0cHM6Ly9yb3V0ZXIudnVlanMub3JnL2d1aWRlL21pZ3JhdGlvbi8jUmVtb3ZlZC1zdGFyLW9yLWNhdGNoLWFsbC1yb3V0ZXMuXCIpO1xuXHRcdFx0bWF0Y2hlciA9IGNyZWF0ZVJvdXRlUmVjb3JkTWF0Y2hlcihub3JtYWxpemVkUmVjb3JkLCBwYXJlbnQsIG9wdGlvbnMpO1xuXHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiBwYXJlbnQgJiYgaXNBYnNvbHV0ZVBhdGgocGF0aCkpIGNoZWNrTWlzc2luZ1BhcmFtc0luQWJzb2x1dGVQYXRoKG1hdGNoZXIsIHBhcmVudCk7XG5cdFx0XHRpZiAob3JpZ2luYWxSZWNvcmQpIHtcblx0XHRcdFx0b3JpZ2luYWxSZWNvcmQuYWxpYXMucHVzaChtYXRjaGVyKTtcblx0XHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgY2hlY2tTYW1lUGFyYW1zKG9yaWdpbmFsUmVjb3JkLCBtYXRjaGVyKTtcblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdG9yaWdpbmFsTWF0Y2hlciA9IG9yaWdpbmFsTWF0Y2hlciB8fCBtYXRjaGVyO1xuXHRcdFx0XHRpZiAob3JpZ2luYWxNYXRjaGVyICE9PSBtYXRjaGVyKSBvcmlnaW5hbE1hdGNoZXIuYWxpYXMucHVzaChtYXRjaGVyKTtcblx0XHRcdFx0aWYgKGlzUm9vdEFkZCAmJiByZWNvcmQubmFtZSAmJiAhaXNBbGlhc1JlY29yZChtYXRjaGVyKSkge1xuXHRcdFx0XHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIGNoZWNrU2FtZU5hbWVBc0FuY2VzdG9yKHJlY29yZCwgcGFyZW50KTtcblx0XHRcdFx0XHRyZW1vdmVSb3V0ZShyZWNvcmQubmFtZSk7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdGlmIChpc01hdGNoYWJsZShtYXRjaGVyKSkgaW5zZXJ0TWF0Y2hlcihtYXRjaGVyKTtcblx0XHRcdGlmIChtYWluTm9ybWFsaXplZFJlY29yZC5jaGlsZHJlbikge1xuXHRcdFx0XHRjb25zdCBjaGlsZHJlbiA9IG1haW5Ob3JtYWxpemVkUmVjb3JkLmNoaWxkcmVuO1xuXHRcdFx0XHRmb3IgKGxldCBpID0gMDsgaSA8IGNoaWxkcmVuLmxlbmd0aDsgaSsrKSBhZGRSb3V0ZShjaGlsZHJlbltpXSwgbWF0Y2hlciwgb3JpZ2luYWxSZWNvcmQgJiYgb3JpZ2luYWxSZWNvcmQuY2hpbGRyZW5baV0pO1xuXHRcdFx0fVxuXHRcdFx0b3JpZ2luYWxSZWNvcmQgPSBvcmlnaW5hbFJlY29yZCB8fCBtYXRjaGVyO1xuXHRcdH1cblx0XHRyZXR1cm4gb3JpZ2luYWxNYXRjaGVyID8gKCkgPT4ge1xuXHRcdFx0cmVtb3ZlUm91dGUob3JpZ2luYWxNYXRjaGVyKTtcblx0XHR9IDogbm9vcDtcblx0fVxuXHRmdW5jdGlvbiByZW1vdmVSb3V0ZShtYXRjaGVyUmVmKSB7XG5cdFx0aWYgKGlzUm91dGVOYW1lKG1hdGNoZXJSZWYpKSB7XG5cdFx0XHRjb25zdCBtYXRjaGVyID0gbWF0Y2hlck1hcC5nZXQobWF0Y2hlclJlZik7XG5cdFx0XHRpZiAobWF0Y2hlcikge1xuXHRcdFx0XHRtYXRjaGVyTWFwLmRlbGV0ZShtYXRjaGVyUmVmKTtcblx0XHRcdFx0bWF0Y2hlcnMuc3BsaWNlKG1hdGNoZXJzLmluZGV4T2YobWF0Y2hlciksIDEpO1xuXHRcdFx0XHRtYXRjaGVyLmNoaWxkcmVuLmZvckVhY2gocmVtb3ZlUm91dGUpO1xuXHRcdFx0XHRtYXRjaGVyLmFsaWFzLmZvckVhY2gocmVtb3ZlUm91dGUpO1xuXHRcdFx0fVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRjb25zdCBpbmRleCA9IG1hdGNoZXJzLmluZGV4T2YobWF0Y2hlclJlZik7XG5cdFx0XHRpZiAoaW5kZXggPiAtMSkge1xuXHRcdFx0XHRtYXRjaGVycy5zcGxpY2UoaW5kZXgsIDEpO1xuXHRcdFx0XHRpZiAobWF0Y2hlclJlZi5yZWNvcmQubmFtZSkgbWF0Y2hlck1hcC5kZWxldGUobWF0Y2hlclJlZi5yZWNvcmQubmFtZSk7XG5cdFx0XHRcdG1hdGNoZXJSZWYuY2hpbGRyZW4uZm9yRWFjaChyZW1vdmVSb3V0ZSk7XG5cdFx0XHRcdG1hdGNoZXJSZWYuYWxpYXMuZm9yRWFjaChyZW1vdmVSb3V0ZSk7XG5cdFx0XHR9XG5cdFx0fVxuXHR9XG5cdGZ1bmN0aW9uIGdldFJvdXRlcygpIHtcblx0XHRyZXR1cm4gbWF0Y2hlcnM7XG5cdH1cblx0ZnVuY3Rpb24gaW5zZXJ0TWF0Y2hlcihtYXRjaGVyKSB7XG5cdFx0Y29uc3QgaW5kZXggPSBmaW5kSW5zZXJ0aW9uSW5kZXgobWF0Y2hlciwgbWF0Y2hlcnMpO1xuXHRcdG1hdGNoZXJzLnNwbGljZShpbmRleCwgMCwgbWF0Y2hlcik7XG5cdFx0aWYgKG1hdGNoZXIucmVjb3JkLm5hbWUgJiYgIWlzQWxpYXNSZWNvcmQobWF0Y2hlcikpIG1hdGNoZXJNYXAuc2V0KG1hdGNoZXIucmVjb3JkLm5hbWUsIG1hdGNoZXIpO1xuXHR9XG5cdGZ1bmN0aW9uIHJlc29sdmUobG9jYXRpb24sIGN1cnJlbnRMb2NhdGlvbikge1xuXHRcdGxldCBtYXRjaGVyO1xuXHRcdGxldCBwYXJhbXMgPSB7fTtcblx0XHRsZXQgcGF0aDtcblx0XHRsZXQgbmFtZTtcblx0XHRpZiAoXCJuYW1lXCIgaW4gbG9jYXRpb24gJiYgbG9jYXRpb24ubmFtZSkge1xuXHRcdFx0bWF0Y2hlciA9IG1hdGNoZXJNYXAuZ2V0KGxvY2F0aW9uLm5hbWUpO1xuXHRcdFx0aWYgKCFtYXRjaGVyKSB0aHJvdyBjcmVhdGVSb3V0ZXJFcnJvcigxLCB7IGxvY2F0aW9uIH0pO1xuXHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuXHRcdFx0XHRjb25zdCBpbnZhbGlkUGFyYW1zID0gT2JqZWN0LmtleXMobG9jYXRpb24ucGFyYW1zIHx8IHt9KS5maWx0ZXIoKHBhcmFtTmFtZSkgPT4gIW1hdGNoZXIua2V5cy5maW5kKChrKSA9PiBrLm5hbWUgPT09IHBhcmFtTmFtZSkpO1xuXHRcdFx0XHRpZiAoaW52YWxpZFBhcmFtcy5sZW5ndGgpIHtcblx0XHRcdFx0XHRjb25zdCBpc0luaGVyaXRlZCA9ICFtYXRjaGVyLmtleXMubGVuZ3RoICYmIGludmFsaWRQYXJhbXMuc29tZSgobmFtZSkgPT4gbmFtZSBpbiBjdXJyZW50TG9jYXRpb24ucGFyYW1zKTtcblx0XHRcdFx0XHRkaWFnbm9zdGljcy5WVUVfUk9VVEVSX1IwMTAwKHtcblx0XHRcdFx0XHRcdHBhcmFtczogaW52YWxpZFBhcmFtcy5qb2luKFwiXFxcIiwgXFxcIlwiKSxcblx0XHRcdFx0XHRcdGluaGVyaXRlZDogaXNJbmhlcml0ZWQgPyBgIElmIHlvdSBhcmUgdXNpbmcgYSBjYXRjaC1hbGwgcm91dGUgd2l0aCBhIG5hbWVkIHJlZGlyZWN0LCBwYXNzIGFuIGVtcHR5IFxcYHBhcmFtc1xcYCBvYmplY3Q6IFxcYHJlZGlyZWN0OiB7IG5hbWU6ICcuLi4nLCBwYXJhbXM6IHt9IH1cXGAuYCA6IFwiXCJcblx0XHRcdFx0XHR9KTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0bmFtZSA9IG1hdGNoZXIucmVjb3JkLm5hbWU7XG5cdFx0XHRwYXJhbXMgPSBhc3NpZ24ocGlja1BhcmFtcyhjdXJyZW50TG9jYXRpb24ucGFyYW1zLCBtYXRjaGVyLmtleXMuZmlsdGVyKChrKSA9PiAhay5vcHRpb25hbCkuY29uY2F0KG1hdGNoZXIucGFyZW50ID8gbWF0Y2hlci5wYXJlbnQua2V5cy5maWx0ZXIoKGspID0+IGsub3B0aW9uYWwpIDogW10pLm1hcCgoaykgPT4gay5uYW1lKSksIGxvY2F0aW9uLnBhcmFtcyAmJiBwaWNrUGFyYW1zKGxvY2F0aW9uLnBhcmFtcywgbWF0Y2hlci5rZXlzLm1hcCgoaykgPT4gay5uYW1lKSkpO1xuXHRcdFx0cGF0aCA9IG1hdGNoZXIuc3RyaW5naWZ5KHBhcmFtcyk7XG5cdFx0fSBlbHNlIGlmIChsb2NhdGlvbi5wYXRoICE9IG51bGwpIHtcblx0XHRcdHBhdGggPSBsb2NhdGlvbi5wYXRoO1xuXHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiAhaXNBYnNvbHV0ZVBhdGgocGF0aCkpIGRpYWdub3N0aWNzLlZVRV9ST1VURVJfUjAxMDEoeyBwYXRoIH0pO1xuXHRcdFx0bWF0Y2hlciA9IG1hdGNoZXJzLmZpbmQoKG0pID0+IG0ucmUudGVzdChwYXRoKSk7XG5cdFx0XHRpZiAobWF0Y2hlcikge1xuXHRcdFx0XHRwYXJhbXMgPSBtYXRjaGVyLnBhcnNlKHBhdGgpO1xuXHRcdFx0XHRuYW1lID0gbWF0Y2hlci5yZWNvcmQubmFtZTtcblx0XHRcdFx0bWF0Y2hlci5rZXlzLmZvckVhY2goKGtleSkgPT4ge1xuXHRcdFx0XHRcdGlmIChrZXkub3B0aW9uYWwgJiYgIXBhcmFtc1trZXkubmFtZV0pIGRlbGV0ZSBwYXJhbXNba2V5Lm5hbWVdO1xuXHRcdFx0XHR9KTtcblx0XHRcdH1cblx0XHR9IGVsc2Uge1xuXHRcdFx0bWF0Y2hlciA9IGN1cnJlbnRMb2NhdGlvbi5uYW1lID8gbWF0Y2hlck1hcC5nZXQoY3VycmVudExvY2F0aW9uLm5hbWUpIDogbWF0Y2hlcnMuZmluZCgobSkgPT4gbS5yZS50ZXN0KGN1cnJlbnRMb2NhdGlvbi5wYXRoKSk7XG5cdFx0XHRpZiAoIW1hdGNoZXIpIHRocm93IGNyZWF0ZVJvdXRlckVycm9yKDEsIHtcblx0XHRcdFx0bG9jYXRpb24sXG5cdFx0XHRcdGN1cnJlbnRMb2NhdGlvblxuXHRcdFx0fSk7XG5cdFx0XHRuYW1lID0gbWF0Y2hlci5yZWNvcmQubmFtZTtcblx0XHRcdHBhcmFtcyA9IGFzc2lnbih7fSwgY3VycmVudExvY2F0aW9uLnBhcmFtcywgbG9jYXRpb24ucGFyYW1zKTtcblx0XHRcdHBhdGggPSBtYXRjaGVyLnN0cmluZ2lmeShwYXJhbXMpO1xuXHRcdH1cblx0XHRjb25zdCBtYXRjaGVkID0gW107XG5cdFx0bGV0IHBhcmVudE1hdGNoZXIgPSBtYXRjaGVyO1xuXHRcdHdoaWxlIChwYXJlbnRNYXRjaGVyKSB7XG5cdFx0XHRtYXRjaGVkLnVuc2hpZnQocGFyZW50TWF0Y2hlci5yZWNvcmQpO1xuXHRcdFx0cGFyZW50TWF0Y2hlciA9IHBhcmVudE1hdGNoZXIucGFyZW50O1xuXHRcdH1cblx0XHRyZXR1cm4ge1xuXHRcdFx0bmFtZSxcblx0XHRcdHBhdGgsXG5cdFx0XHRwYXJhbXMsXG5cdFx0XHRtYXRjaGVkLFxuXHRcdFx0bWV0YTogbWVyZ2VNZXRhRmllbGRzKG1hdGNoZWQpXG5cdFx0fTtcblx0fVxuXHRyb3V0ZXMuZm9yRWFjaCgocm91dGUpID0+IGFkZFJvdXRlKHJvdXRlKSk7XG5cdGZ1bmN0aW9uIGNsZWFyUm91dGVzKCkge1xuXHRcdG1hdGNoZXJzLmxlbmd0aCA9IDA7XG5cdFx0bWF0Y2hlck1hcC5jbGVhcigpO1xuXHR9XG5cdHJldHVybiB7XG5cdFx0YWRkUm91dGUsXG5cdFx0cmVzb2x2ZSxcblx0XHRyZW1vdmVSb3V0ZSxcblx0XHRjbGVhclJvdXRlcyxcblx0XHRnZXRSb3V0ZXMsXG5cdFx0Z2V0UmVjb3JkTWF0Y2hlclxuXHR9O1xufVxuLyoqXG4qIFBpY2tzIGFuIG9iamVjdCBwYXJhbSB0byBjb250YWluIG9ubHkgc3BlY2lmaWVkIGtleXMuXG4qXG4qIEBwYXJhbSBwYXJhbXMgLSBwYXJhbXMgb2JqZWN0IHRvIHBpY2sgZnJvbVxuKiBAcGFyYW0ga2V5cyAtIGtleXMgdG8gcGlja1xuKi9cbmZ1bmN0aW9uIHBpY2tQYXJhbXMocGFyYW1zLCBrZXlzKSB7XG5cdGNvbnN0IG5ld1BhcmFtcyA9IHt9O1xuXHRmb3IgKGNvbnN0IGtleSBvZiBrZXlzKSBpZiAoa2V5IGluIHBhcmFtcykgbmV3UGFyYW1zW2tleV0gPSBwYXJhbXNba2V5XTtcblx0cmV0dXJuIG5ld1BhcmFtcztcbn1cbi8qKlxuKiBOb3JtYWxpemVzIGEgUm91dGVSZWNvcmRSYXcuIENyZWF0ZXMgYSBjb3B5XG4qXG4qIEBwYXJhbSByZWNvcmRcbiogQHJldHVybnMgdGhlIG5vcm1hbGl6ZWQgdmVyc2lvblxuKi9cbmZ1bmN0aW9uIG5vcm1hbGl6ZVJvdXRlUmVjb3JkKHJlY29yZCkge1xuXHRjb25zdCBub3JtYWxpemVkID0ge1xuXHRcdHBhdGg6IHJlY29yZC5wYXRoLFxuXHRcdHJlZGlyZWN0OiByZWNvcmQucmVkaXJlY3QsXG5cdFx0bmFtZTogcmVjb3JkLm5hbWUsXG5cdFx0bWV0YTogcmVjb3JkLm1ldGEgfHwge30sXG5cdFx0YWxpYXNPZjogcmVjb3JkLmFsaWFzT2YsXG5cdFx0YmVmb3JlRW50ZXI6IHJlY29yZC5iZWZvcmVFbnRlcixcblx0XHRwcm9wczogbm9ybWFsaXplUmVjb3JkUHJvcHMocmVjb3JkKSxcblx0XHRjaGlsZHJlbjogcmVjb3JkLmNoaWxkcmVuIHx8IFtdLFxuXHRcdGluc3RhbmNlczoge30sXG5cdFx0bGVhdmVHdWFyZHM6IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCksXG5cdFx0dXBkYXRlR3VhcmRzOiAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpLFxuXHRcdGVudGVyQ2FsbGJhY2tzOiB7fSxcblx0XHRjb21wb25lbnRzOiBcImNvbXBvbmVudHNcIiBpbiByZWNvcmQgPyByZWNvcmQuY29tcG9uZW50cyB8fCBudWxsIDogcmVjb3JkLmNvbXBvbmVudCAmJiB7IGRlZmF1bHQ6IHJlY29yZC5jb21wb25lbnQgfVxuXHR9O1xuXHRPYmplY3QuZGVmaW5lUHJvcGVydHkobm9ybWFsaXplZCwgXCJtb2RzXCIsIHsgdmFsdWU6IHt9IH0pO1xuXHRyZXR1cm4gbm9ybWFsaXplZDtcbn1cbi8qKlxuKiBOb3JtYWxpemUgdGhlIG9wdGlvbmFsIGBwcm9wc2AgaW4gYSByZWNvcmQgdG8gYWx3YXlzIGJlIGFuIG9iamVjdCBzaW1pbGFyIHRvXG4qIGNvbXBvbmVudHMuIEFsc28gYWNjZXB0IGEgYm9vbGVhbiBmb3IgY29tcG9uZW50cy5cbiogQHBhcmFtIHJlY29yZFxuKi9cbmZ1bmN0aW9uIG5vcm1hbGl6ZVJlY29yZFByb3BzKHJlY29yZCkge1xuXHRjb25zdCBwcm9wc09iamVjdCA9IHt9O1xuXHRjb25zdCBwcm9wcyA9IHJlY29yZC5wcm9wcyB8fCBmYWxzZTtcblx0aWYgKFwiY29tcG9uZW50XCIgaW4gcmVjb3JkKSBwcm9wc09iamVjdC5kZWZhdWx0ID0gcHJvcHM7XG5cdGVsc2UgZm9yIChjb25zdCBuYW1lIGluIHJlY29yZC5jb21wb25lbnRzKSBwcm9wc09iamVjdFtuYW1lXSA9IHR5cGVvZiBwcm9wcyA9PT0gXCJvYmplY3RcIiA/IHByb3BzW25hbWVdIDogcHJvcHM7XG5cdHJldHVybiBwcm9wc09iamVjdDtcbn1cbi8qKlxuKiBDaGVja3MgaWYgYSByZWNvcmQgb3IgYW55IG9mIGl0cyBwYXJlbnQgaXMgYW4gYWxpYXNcbiogQHBhcmFtIHJlY29yZFxuKi9cbmZ1bmN0aW9uIGlzQWxpYXNSZWNvcmQocmVjb3JkKSB7XG5cdHdoaWxlIChyZWNvcmQpIHtcblx0XHRpZiAocmVjb3JkLnJlY29yZC5hbGlhc09mKSByZXR1cm4gdHJ1ZTtcblx0XHRyZWNvcmQgPSByZWNvcmQucGFyZW50O1xuXHR9XG5cdHJldHVybiBmYWxzZTtcbn1cbi8qKlxuKiBNZXJnZSBtZXRhIGZpZWxkcyBvZiBhbiBhcnJheSBvZiByZWNvcmRzXG4qXG4qIEBwYXJhbSBtYXRjaGVkIC0gYXJyYXkgb2YgbWF0Y2hlZCByZWNvcmRzXG4qL1xuZnVuY3Rpb24gbWVyZ2VNZXRhRmllbGRzKG1hdGNoZWQpIHtcblx0cmV0dXJuIG1hdGNoZWQucmVkdWNlKChtZXRhLCByZWNvcmQpID0+IGFzc2lnbihtZXRhLCByZWNvcmQubWV0YSksIHt9KTtcbn1cbmZ1bmN0aW9uIGlzU2FtZVBhcmFtKGEsIGIpIHtcblx0cmV0dXJuIGEubmFtZSA9PT0gYi5uYW1lICYmIGEub3B0aW9uYWwgPT09IGIub3B0aW9uYWwgJiYgYS5yZXBlYXRhYmxlID09PSBiLnJlcGVhdGFibGU7XG59XG4vKipcbiogQ2hlY2sgaWYgYSBwYXRoIGFuZCBpdHMgYWxpYXMgaGF2ZSB0aGUgc2FtZSByZXF1aXJlZCBwYXJhbXNcbipcbiogQHBhcmFtIGEgLSBvcmlnaW5hbCByZWNvcmRcbiogQHBhcmFtIGIgLSBhbGlhcyByZWNvcmRcbiovXG5mdW5jdGlvbiBjaGVja1NhbWVQYXJhbXMoYSwgYikge1xuXHRmb3IgKGNvbnN0IGtleSBvZiBhLmtleXMpIGlmICgha2V5Lm9wdGlvbmFsICYmICFiLmtleXMuZmluZChpc1NhbWVQYXJhbS5iaW5kKG51bGwsIGtleSkpKSB7XG5cdFx0ZGlhZ25vc3RpY3MuVlVFX1JPVVRFUl9SMDEwMih7XG5cdFx0XHRhbGlhczogYi5yZWNvcmQucGF0aCxcblx0XHRcdG9yaWdpbmFsOiBhLnJlY29yZC5wYXRoLFxuXHRcdFx0bmFtZToga2V5Lm5hbWVcblx0XHR9KTtcblx0XHRyZXR1cm47XG5cdH1cblx0Zm9yIChjb25zdCBrZXkgb2YgYi5rZXlzKSBpZiAoIWtleS5vcHRpb25hbCAmJiAhYS5rZXlzLmZpbmQoaXNTYW1lUGFyYW0uYmluZChudWxsLCBrZXkpKSkge1xuXHRcdGRpYWdub3N0aWNzLlZVRV9ST1VURVJfUjAxMDIoe1xuXHRcdFx0YWxpYXM6IGIucmVjb3JkLnBhdGgsXG5cdFx0XHRvcmlnaW5hbDogYS5yZWNvcmQucGF0aCxcblx0XHRcdG5hbWU6IGtleS5uYW1lXG5cdFx0fSk7XG5cdFx0cmV0dXJuO1xuXHR9XG59XG4vKipcbiogQSByb3V0ZSB3aXRoIGEgbmFtZSBhbmQgYSBjaGlsZCB3aXRoIGFuIGVtcHR5IHBhdGggd2l0aG91dCBhIG5hbWUgc2hvdWxkIHdhcm4gd2hlbiBhZGRpbmcgdGhlIHJvdXRlXG4qXG4qIEBwYXJhbSBtYWluTm9ybWFsaXplZFJlY29yZCAtIFJvdXRlUmVjb3JkTm9ybWFsaXplZFxuKiBAcGFyYW0gcGFyZW50IC0gUm91dGVSZWNvcmRNYXRjaGVyXG4qL1xuZnVuY3Rpb24gY2hlY2tDaGlsZE1pc3NpbmdOYW1lV2l0aEVtcHR5UGF0aChtYWluTm9ybWFsaXplZFJlY29yZCwgcGFyZW50KSB7XG5cdGlmIChwYXJlbnQgJiYgcGFyZW50LnJlY29yZC5uYW1lICYmICFtYWluTm9ybWFsaXplZFJlY29yZC5uYW1lICYmICFtYWluTm9ybWFsaXplZFJlY29yZC5wYXRoICYmIG1haW5Ob3JtYWxpemVkUmVjb3JkLmNoaWxkcmVuLmxlbmd0aCA9PT0gMCkgZGlhZ25vc3RpY3MuVlVFX1JPVVRFUl9SMDEwMyh7IG5hbWU6IFN0cmluZyhwYXJlbnQucmVjb3JkLm5hbWUpIH0pO1xufVxuZnVuY3Rpb24gY2hlY2tTYW1lTmFtZUFzQW5jZXN0b3IocmVjb3JkLCBwYXJlbnQpIHtcblx0Zm9yIChsZXQgYW5jZXN0b3IgPSBwYXJlbnQ7IGFuY2VzdG9yOyBhbmNlc3RvciA9IGFuY2VzdG9yLnBhcmVudCkgaWYgKGFuY2VzdG9yLnJlY29yZC5uYW1lID09PSByZWNvcmQubmFtZSkgdGhyb3cgbmV3IEVycm9yKGBBIHJvdXRlIG5hbWVkIFwiJHtTdHJpbmcocmVjb3JkLm5hbWUpfVwiIGhhcyBiZWVuIGFkZGVkIGFzIGEgJHtwYXJlbnQgPT09IGFuY2VzdG9yID8gXCJjaGlsZFwiIDogXCJkZXNjZW5kYW50XCJ9IG9mIGEgcm91dGUgd2l0aCB0aGUgc2FtZSBuYW1lLiBSb3V0ZSBuYW1lcyBtdXN0IGJlIHVuaXF1ZSBhbmQgYSBuZXN0ZWQgcm91dGUgY2Fubm90IHVzZSB0aGUgc2FtZSBuYW1lIGFzIGFuIGFuY2VzdG9yLmApO1xufVxuZnVuY3Rpb24gY2hlY2tNaXNzaW5nUGFyYW1zSW5BYnNvbHV0ZVBhdGgocmVjb3JkLCBwYXJlbnQpIHtcblx0Zm9yIChjb25zdCBrZXkgb2YgcGFyZW50LmtleXMpIGlmICghcmVjb3JkLmtleXMuZmluZChpc1NhbWVQYXJhbS5iaW5kKG51bGwsIGtleSkpKSB7XG5cdFx0ZGlhZ25vc3RpY3MuVlVFX1JPVVRFUl9SMDEwNCh7XG5cdFx0XHRwYXRoOiByZWNvcmQucmVjb3JkLnBhdGgsXG5cdFx0XHRuYW1lOiBrZXkubmFtZSxcblx0XHRcdHBhcmVudDogcGFyZW50LnJlY29yZC5wYXRoXG5cdFx0fSk7XG5cdFx0cmV0dXJuO1xuXHR9XG59XG4vKipcbiogUGVyZm9ybXMgYSBiaW5hcnkgc2VhcmNoIHRvIGZpbmQgdGhlIGNvcnJlY3QgaW5zZXJ0aW9uIGluZGV4IGZvciBhIG5ldyBtYXRjaGVyLlxuKlxuKiBNYXRjaGVycyBhcmUgcHJpbWFyaWx5IHNvcnRlZCBieSB0aGVpciBzY29yZS4gSWYgc2NvcmVzIGFyZSB0aWVkIHRoZW4gd2UgYWxzbyBjb25zaWRlciBwYXJlbnQvY2hpbGQgcmVsYXRpb25zaGlwcyxcbiogd2l0aCBkZXNjZW5kYW50cyBjb21pbmcgYmVmb3JlIGFuY2VzdG9ycy4gSWYgdGhlcmUncyBzdGlsbCBhIHRpZSwgbmV3IHJvdXRlcyBhcmUgaW5zZXJ0ZWQgYWZ0ZXIgZXhpc3Rpbmcgcm91dGVzLlxuKlxuKiBAcGFyYW0gbWF0Y2hlciAtIG5ldyBtYXRjaGVyIHRvIGJlIGluc2VydGVkXG4qIEBwYXJhbSBtYXRjaGVycyAtIGV4aXN0aW5nIG1hdGNoZXJzXG4qL1xuZnVuY3Rpb24gZmluZEluc2VydGlvbkluZGV4KG1hdGNoZXIsIG1hdGNoZXJzKSB7XG5cdGxldCBsb3dlciA9IDA7XG5cdGxldCB1cHBlciA9IG1hdGNoZXJzLmxlbmd0aDtcblx0d2hpbGUgKGxvd2VyICE9PSB1cHBlcikge1xuXHRcdGNvbnN0IG1pZCA9IGxvd2VyICsgdXBwZXIgPj4gMTtcblx0XHRpZiAoY29tcGFyZVBhdGhQYXJzZXJTY29yZShtYXRjaGVyLCBtYXRjaGVyc1ttaWRdKSA8IDApIHVwcGVyID0gbWlkO1xuXHRcdGVsc2UgbG93ZXIgPSBtaWQgKyAxO1xuXHR9XG5cdGNvbnN0IGluc2VydGlvbkFuY2VzdG9yID0gZ2V0SW5zZXJ0aW9uQW5jZXN0b3IobWF0Y2hlcik7XG5cdGlmIChpbnNlcnRpb25BbmNlc3Rvcikge1xuXHRcdHVwcGVyID0gbWF0Y2hlcnMubGFzdEluZGV4T2YoaW5zZXJ0aW9uQW5jZXN0b3IsIHVwcGVyIC0gMSk7XG5cdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiB1cHBlciA8IDApIGRpYWdub3N0aWNzLlZVRV9ST1VURVJfUjAxMDUoe1xuXHRcdFx0YW5jZXN0b3I6IGluc2VydGlvbkFuY2VzdG9yLnJlY29yZC5wYXRoLFxuXHRcdFx0cmVjb3JkOiBtYXRjaGVyLnJlY29yZC5wYXRoXG5cdFx0fSk7XG5cdH1cblx0cmV0dXJuIHVwcGVyO1xufVxuZnVuY3Rpb24gZ2V0SW5zZXJ0aW9uQW5jZXN0b3IobWF0Y2hlcikge1xuXHRsZXQgYW5jZXN0b3IgPSBtYXRjaGVyO1xuXHR3aGlsZSAoYW5jZXN0b3IgPSBhbmNlc3Rvci5wYXJlbnQpIGlmIChpc01hdGNoYWJsZShhbmNlc3RvcikgJiYgY29tcGFyZVBhdGhQYXJzZXJTY29yZShtYXRjaGVyLCBhbmNlc3RvcikgPT09IDApIHJldHVybiBhbmNlc3Rvcjtcbn1cbi8qKlxuKiBDaGVja3MgaWYgYSBtYXRjaGVyIGNhbiBiZSByZWFjaGFibGUuIFRoaXMgbWVhbnMgaWYgaXQncyBwb3NzaWJsZSB0byByZWFjaCBpdCBhcyBhIHJvdXRlLiBGb3IgZXhhbXBsZSwgcm91dGVzIHdpdGhvdXRcbiogYSBjb21wb25lbnQsIG9yIG5hbWUsIG9yIHJlZGlyZWN0LCBhcmUganVzdCB1c2VkIHRvIGdyb3VwIG90aGVyIHJvdXRlcy5cbiogQHBhcmFtIG1hdGNoZXJcbiogQHBhcmFtIG1hdGNoZXIucmVjb3JkIHJlY29yZCBvZiB0aGUgbWF0Y2hlclxuKiBAcmV0dXJuc1xuKi9cbmZ1bmN0aW9uIGlzTWF0Y2hhYmxlKHsgcmVjb3JkIH0pIHtcblx0cmV0dXJuICEhKHJlY29yZC5uYW1lIHx8IHJlY29yZC5jb21wb25lbnRzICYmIE9iamVjdC5rZXlzKHJlY29yZC5jb21wb25lbnRzKS5sZW5ndGggfHwgcmVjb3JkLnJlZGlyZWN0KTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9Sb3V0ZXJMaW5rLnRzXG4vKipcbiogUmV0dXJucyB0aGUgaW50ZXJuYWwgYmVoYXZpb3Igb2YgYSB7QGxpbmsgUm91dGVyTGlua30gd2l0aG91dCB0aGUgcmVuZGVyaW5nIHBhcnQuXG4qXG4qIEBwYXJhbSBwcm9wcyAtIGEgYHRvYCBsb2NhdGlvbiBhbmQgYW4gb3B0aW9uYWwgYHJlcGxhY2VgIGZsYWdcbiovXG5mdW5jdGlvbiB1c2VMaW5rKHByb3BzKSB7XG5cdGNvbnN0IHJvdXRlciA9IGluamVjdChyb3V0ZXJLZXkpO1xuXHRjb25zdCBjdXJyZW50Um91dGUgPSBpbmplY3Qocm91dGVMb2NhdGlvbktleSk7XG5cdGxldCBoYXNQcmV2aW91cyA9IGZhbHNlO1xuXHRsZXQgcHJldmlvdXNUbyA9IG51bGw7XG5cdGNvbnN0IHJvdXRlID0gY29tcHV0ZWQoKCkgPT4ge1xuXHRcdGNvbnN0IHRvID0gdW5yZWYocHJvcHMudG8pO1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgKCFoYXNQcmV2aW91cyB8fCB0byAhPT0gcHJldmlvdXNUbykpIHtcblx0XHRcdGlmICghaXNSb3V0ZUxvY2F0aW9uKHRvKSkgZGlhZ25vc3RpY3MuVlVFX1JPVVRFUl9SMDA1MCh7IHRvIH0pO1xuXHRcdFx0cHJldmlvdXNUbyA9IHRvO1xuXHRcdFx0aGFzUHJldmlvdXMgPSB0cnVlO1xuXHRcdH1cblx0XHRyZXR1cm4gcm91dGVyLnJlc29sdmUodG8pO1xuXHR9KTtcblx0Y29uc3QgYWN0aXZlUmVjb3JkSW5kZXggPSBjb21wdXRlZCgoKSA9PiB7XG5cdFx0Y29uc3QgeyBtYXRjaGVkIH0gPSByb3V0ZS52YWx1ZTtcblx0XHRjb25zdCB7IGxlbmd0aCB9ID0gbWF0Y2hlZDtcblx0XHRjb25zdCByb3V0ZU1hdGNoZWQgPSBtYXRjaGVkW2xlbmd0aCAtIDFdO1xuXHRcdGNvbnN0IGN1cnJlbnRNYXRjaGVkID0gY3VycmVudFJvdXRlLm1hdGNoZWQ7XG5cdFx0aWYgKCFyb3V0ZU1hdGNoZWQgfHwgIWN1cnJlbnRNYXRjaGVkLmxlbmd0aCkgcmV0dXJuIC0xO1xuXHRcdGNvbnN0IGluZGV4ID0gY3VycmVudE1hdGNoZWQuZmluZEluZGV4KGlzU2FtZVJvdXRlUmVjb3JkLmJpbmQobnVsbCwgcm91dGVNYXRjaGVkKSk7XG5cdFx0aWYgKGluZGV4ID4gLTEpIHJldHVybiBpbmRleDtcblx0XHRjb25zdCBwYXJlbnRSZWNvcmRQYXRoID0gZ2V0T3JpZ2luYWxQYXRoKG1hdGNoZWRbbGVuZ3RoIC0gMl0pO1xuXHRcdHJldHVybiBsZW5ndGggPiAxICYmIGdldE9yaWdpbmFsUGF0aChyb3V0ZU1hdGNoZWQpID09PSBwYXJlbnRSZWNvcmRQYXRoICYmIGN1cnJlbnRNYXRjaGVkW2N1cnJlbnRNYXRjaGVkLmxlbmd0aCAtIDFdLnBhdGggIT09IHBhcmVudFJlY29yZFBhdGggPyBjdXJyZW50TWF0Y2hlZC5maW5kSW5kZXgoaXNTYW1lUm91dGVSZWNvcmQuYmluZChudWxsLCBtYXRjaGVkW2xlbmd0aCAtIDJdKSkgOiBpbmRleDtcblx0fSk7XG5cdGNvbnN0IGlzQWN0aXZlID0gY29tcHV0ZWQoKCkgPT4gYWN0aXZlUmVjb3JkSW5kZXgudmFsdWUgPiAtMSAmJiBpbmNsdWRlc1BhcmFtcyhjdXJyZW50Um91dGUucGFyYW1zLCByb3V0ZS52YWx1ZS5wYXJhbXMpKTtcblx0Y29uc3QgaXNFeGFjdEFjdGl2ZSA9IGNvbXB1dGVkKCgpID0+IGFjdGl2ZVJlY29yZEluZGV4LnZhbHVlID4gLTEgJiYgYWN0aXZlUmVjb3JkSW5kZXgudmFsdWUgPT09IGN1cnJlbnRSb3V0ZS5tYXRjaGVkLmxlbmd0aCAtIDEgJiYgaXNTYW1lUm91dGVMb2NhdGlvblBhcmFtcyhjdXJyZW50Um91dGUucGFyYW1zLCByb3V0ZS52YWx1ZS5wYXJhbXMpKTtcblx0ZnVuY3Rpb24gbmF2aWdhdGUoZSA9IHt9KSB7XG5cdFx0aWYgKGd1YXJkRXZlbnQoZSkpIHtcblx0XHRcdGNvbnN0IHAgPSByb3V0ZXJbdW5yZWYocHJvcHMucmVwbGFjZSkgPyBcInJlcGxhY2VcIiA6IFwicHVzaFwiXSh1bnJlZihwcm9wcy50bykpLmNhdGNoKG5vb3ApO1xuXHRcdFx0aWYgKHByb3BzLnZpZXdUcmFuc2l0aW9uICYmIHR5cGVvZiBkb2N1bWVudCAhPT0gXCJ1bmRlZmluZWRcIiAmJiBcInN0YXJ0Vmlld1RyYW5zaXRpb25cIiBpbiBkb2N1bWVudCkgZG9jdW1lbnQuc3RhcnRWaWV3VHJhbnNpdGlvbigoKSA9PiBwKTtcblx0XHRcdHJldHVybiBwO1xuXHRcdH1cblx0XHRyZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG5cdH1cblx0aWYgKChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgfHwgX19WVUVfUFJPRF9ERVZUT09MU19fKSAmJiBpc0Jyb3dzZXIpIHtcblx0XHRjb25zdCBpbnN0YW5jZSA9IGdldEN1cnJlbnRJbnN0YW5jZSgpO1xuXHRcdGlmIChpbnN0YW5jZSkge1xuXHRcdFx0Y29uc3QgbGlua0NvbnRleHREZXZ0b29scyA9IHtcblx0XHRcdFx0cm91dGU6IHJvdXRlLnZhbHVlLFxuXHRcdFx0XHRpc0FjdGl2ZTogaXNBY3RpdmUudmFsdWUsXG5cdFx0XHRcdGlzRXhhY3RBY3RpdmU6IGlzRXhhY3RBY3RpdmUudmFsdWUsXG5cdFx0XHRcdGVycm9yOiBudWxsXG5cdFx0XHR9O1xuXHRcdFx0aW5zdGFuY2UuX192cmxfZGV2dG9vbHMgPSBpbnN0YW5jZS5fX3ZybF9kZXZ0b29scyB8fCBbXTtcblx0XHRcdGluc3RhbmNlLl9fdnJsX2RldnRvb2xzLnB1c2gobGlua0NvbnRleHREZXZ0b29scyk7XG5cdFx0XHR3YXRjaEVmZmVjdCgoKSA9PiB7XG5cdFx0XHRcdGxpbmtDb250ZXh0RGV2dG9vbHMucm91dGUgPSByb3V0ZS52YWx1ZTtcblx0XHRcdFx0bGlua0NvbnRleHREZXZ0b29scy5pc0FjdGl2ZSA9IGlzQWN0aXZlLnZhbHVlO1xuXHRcdFx0XHRsaW5rQ29udGV4dERldnRvb2xzLmlzRXhhY3RBY3RpdmUgPSBpc0V4YWN0QWN0aXZlLnZhbHVlO1xuXHRcdFx0XHRsaW5rQ29udGV4dERldnRvb2xzLmVycm9yID0gaXNSb3V0ZUxvY2F0aW9uKHVucmVmKHByb3BzLnRvKSkgPyBudWxsIDogXCJJbnZhbGlkIFxcXCJ0b1xcXCIgdmFsdWVcIjtcblx0XHRcdH0sIHsgZmx1c2g6IFwicG9zdFwiIH0pO1xuXHRcdH1cblx0fVxuXHQvKipcblx0KiBOT1RFOiB1cGRhdGUge0BsaW5rIF9Sb3V0ZXJMaW5rSX0ncyBgJHNsb3RzYCB0eXBlIHdoZW4gdXBkYXRpbmcgdGhpc1xuXHQqL1xuXHRyZXR1cm4ge1xuXHRcdHJvdXRlLFxuXHRcdGhyZWY6IGNvbXB1dGVkKCgpID0+IHJvdXRlLnZhbHVlLmhyZWYpLFxuXHRcdGlzQWN0aXZlLFxuXHRcdGlzRXhhY3RBY3RpdmUsXG5cdFx0bmF2aWdhdGVcblx0fTtcbn1cbmZ1bmN0aW9uIHByZWZlclNpbmdsZVZOb2RlKHZub2Rlcykge1xuXHRyZXR1cm4gdm5vZGVzLmxlbmd0aCA9PT0gMSA/IHZub2Rlc1swXSA6IHZub2Rlcztcbn1cbi8qKlxuKiBDb21wb25lbnQgdG8gcmVuZGVyIGEgbGluayB0aGF0IHRyaWdnZXJzIGEgbmF2aWdhdGlvbiBvbiBjbGljay5cbiovXG5jb25zdCBSb3V0ZXJMaW5rID0gLyogQF9fUFVSRV9fICovIGRlZmluZUNvbXBvbmVudCh7XG5cdG5hbWU6IFwiUm91dGVyTGlua1wiLFxuXHRjb21wYXRDb25maWc6IHsgTU9ERTogMyB9LFxuXHRwcm9wczoge1xuXHRcdHRvOiB7XG5cdFx0XHR0eXBlOiBbU3RyaW5nLCBPYmplY3RdLFxuXHRcdFx0cmVxdWlyZWQ6IHRydWVcblx0XHR9LFxuXHRcdHJlcGxhY2U6IEJvb2xlYW4sXG5cdFx0YWN0aXZlQ2xhc3M6IFN0cmluZyxcblx0XHRleGFjdEFjdGl2ZUNsYXNzOiBTdHJpbmcsXG5cdFx0Y3VzdG9tOiBCb29sZWFuLFxuXHRcdGFyaWFDdXJyZW50VmFsdWU6IHtcblx0XHRcdHR5cGU6IFN0cmluZyxcblx0XHRcdGRlZmF1bHQ6IFwicGFnZVwiXG5cdFx0fSxcblx0XHR2aWV3VHJhbnNpdGlvbjogQm9vbGVhblxuXHR9LFxuXHR1c2VMaW5rLFxuXHRzZXR1cChwcm9wcywgeyBzbG90cyB9KSB7XG5cdFx0Y29uc3QgbGluayA9IHJlYWN0aXZlKHVzZUxpbmsocHJvcHMpKTtcblx0XHRjb25zdCB7IG9wdGlvbnMgfSA9IGluamVjdChyb3V0ZXJLZXkpO1xuXHRcdGNvbnN0IGVsQ2xhc3MgPSBjb21wdXRlZCgoKSA9PiAoe1xuXHRcdFx0W2dldExpbmtDbGFzcyhwcm9wcy5hY3RpdmVDbGFzcywgb3B0aW9ucy5saW5rQWN0aXZlQ2xhc3MsIFwicm91dGVyLWxpbmstYWN0aXZlXCIpXTogbGluay5pc0FjdGl2ZSxcblx0XHRcdFtnZXRMaW5rQ2xhc3MocHJvcHMuZXhhY3RBY3RpdmVDbGFzcywgb3B0aW9ucy5saW5rRXhhY3RBY3RpdmVDbGFzcywgXCJyb3V0ZXItbGluay1leGFjdC1hY3RpdmVcIildOiBsaW5rLmlzRXhhY3RBY3RpdmVcblx0XHR9KSk7XG5cdFx0cmV0dXJuICgpID0+IHtcblx0XHRcdGNvbnN0IGNoaWxkcmVuID0gc2xvdHMuZGVmYXVsdCAmJiBwcmVmZXJTaW5nbGVWTm9kZShzbG90cy5kZWZhdWx0KGxpbmspKTtcblx0XHRcdHJldHVybiBwcm9wcy5jdXN0b20gPyBjaGlsZHJlbiA6IGgoXCJhXCIsIHtcblx0XHRcdFx0XCJhcmlhLWN1cnJlbnRcIjogbGluay5pc0V4YWN0QWN0aXZlID8gcHJvcHMuYXJpYUN1cnJlbnRWYWx1ZSA6IG51bGwsXG5cdFx0XHRcdGhyZWY6IGxpbmsuaHJlZixcblx0XHRcdFx0b25DbGljazogbGluay5uYXZpZ2F0ZSxcblx0XHRcdFx0Y2xhc3M6IGVsQ2xhc3MudmFsdWVcblx0XHRcdH0sIGNoaWxkcmVuKTtcblx0XHR9O1xuXHR9XG59KTtcbmZ1bmN0aW9uIGd1YXJkRXZlbnQoZSkge1xuXHRpZiAoZS5tZXRhS2V5IHx8IGUuYWx0S2V5IHx8IGUuY3RybEtleSB8fCBlLnNoaWZ0S2V5KSByZXR1cm47XG5cdGlmIChlLmRlZmF1bHRQcmV2ZW50ZWQpIHJldHVybjtcblx0aWYgKGUuYnV0dG9uICE9PSB2b2lkIDAgJiYgZS5idXR0b24gIT09IDApIHJldHVybjtcblx0aWYgKGUuY3VycmVudFRhcmdldCAmJiBlLmN1cnJlbnRUYXJnZXQuZ2V0QXR0cmlidXRlKSB7XG5cdFx0Y29uc3QgdGFyZ2V0ID0gZS5jdXJyZW50VGFyZ2V0LmdldEF0dHJpYnV0ZShcInRhcmdldFwiKTtcblx0XHRpZiAoL1xcYl9ibGFua1xcYi9pLnRlc3QodGFyZ2V0KSkgcmV0dXJuO1xuXHR9XG5cdGlmIChlLnByZXZlbnREZWZhdWx0KSBlLnByZXZlbnREZWZhdWx0KCk7XG5cdHJldHVybiB0cnVlO1xufVxuZnVuY3Rpb24gaW5jbHVkZXNQYXJhbXMob3V0ZXIsIGlubmVyKSB7XG5cdGZvciAoY29uc3Qga2V5IGluIGlubmVyKSB7XG5cdFx0Y29uc3QgaW5uZXJWYWx1ZSA9IGlubmVyW2tleV07XG5cdFx0Y29uc3Qgb3V0ZXJWYWx1ZSA9IG91dGVyW2tleV07XG5cdFx0aWYgKGlzQXJyYXkoaW5uZXJWYWx1ZSkpIHtcblx0XHRcdGlmICghaXNBcnJheShvdXRlclZhbHVlKSB8fCBvdXRlclZhbHVlLmxlbmd0aCAhPT0gaW5uZXJWYWx1ZS5sZW5ndGggfHwgaW5uZXJWYWx1ZS5zb21lKCh2YWx1ZSwgaSkgPT4gdmFsdWUudmFsdWVPZigpICE9PSBvdXRlclZhbHVlW2ldLnZhbHVlT2YoKSkpIHJldHVybiBmYWxzZTtcblx0XHR9IGVsc2UgaWYgKGlubmVyVmFsdWUgIT09IG91dGVyVmFsdWUpIHJldHVybiBmYWxzZTtcblx0fVxuXHRyZXR1cm4gdHJ1ZTtcbn1cbi8qKlxuKiBHZXQgdGhlIG9yaWdpbmFsIHBhdGggdmFsdWUgb2YgYSByZWNvcmQgYnkgZm9sbG93aW5nIGl0cyBhbGlhc09mXG4qIEBwYXJhbSByZWNvcmRcbiovXG5mdW5jdGlvbiBnZXRPcmlnaW5hbFBhdGgocmVjb3JkKSB7XG5cdHJldHVybiByZWNvcmQgPyByZWNvcmQuYWxpYXNPZiA/IHJlY29yZC5hbGlhc09mLnBhdGggOiByZWNvcmQucGF0aCA6IFwiXCI7XG59XG4vKipcbiogVXRpbGl0eSBjbGFzcyB0byBnZXQgdGhlIGFjdGl2ZSBjbGFzcyBiYXNlZCBvbiBkZWZhdWx0cy5cbiogQHBhcmFtIHByb3BDbGFzc1xuKiBAcGFyYW0gZ2xvYmFsQ2xhc3NcbiogQHBhcmFtIGRlZmF1bHRDbGFzc1xuKi9cbmNvbnN0IGdldExpbmtDbGFzcyA9IChwcm9wQ2xhc3MsIGdsb2JhbENsYXNzLCBkZWZhdWx0Q2xhc3MpID0+IHByb3BDbGFzcyAhPSBudWxsID8gcHJvcENsYXNzIDogZ2xvYmFsQ2xhc3MgIT0gbnVsbCA/IGdsb2JhbENsYXNzIDogZGVmYXVsdENsYXNzO1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL1JvdXRlclZpZXcudHNcbmNvbnN0IFJvdXRlclZpZXdJbXBsID0gLyojX19QVVJFX18qLyBkZWZpbmVDb21wb25lbnQoe1xuXHRuYW1lOiBcIlJvdXRlclZpZXdcIixcblx0aW5oZXJpdEF0dHJzOiBmYWxzZSxcblx0cHJvcHM6IHtcblx0XHRuYW1lOiB7XG5cdFx0XHR0eXBlOiBTdHJpbmcsXG5cdFx0XHRkZWZhdWx0OiBcImRlZmF1bHRcIlxuXHRcdH0sXG5cdFx0cm91dGU6IE9iamVjdFxuXHR9LFxuXHRjb21wYXRDb25maWc6IHsgTU9ERTogMyB9LFxuXHRzZXR1cChwcm9wcywgeyBhdHRycywgc2xvdHMgfSkge1xuXHRcdHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiB3YXJuRGVwcmVjYXRlZFVzYWdlKCk7XG5cdFx0Y29uc3QgaW5qZWN0ZWRSb3V0ZSA9IGluamVjdChyb3V0ZXJWaWV3TG9jYXRpb25LZXkpO1xuXHRcdGNvbnN0IHJvdXRlVG9EaXNwbGF5ID0gY29tcHV0ZWQoKCkgPT4gcHJvcHMucm91dGUgfHwgaW5qZWN0ZWRSb3V0ZS52YWx1ZSk7XG5cdFx0Y29uc3QgaW5qZWN0ZWREZXB0aCA9IGluamVjdCh2aWV3RGVwdGhLZXksIDApO1xuXHRcdGNvbnN0IGRlcHRoID0gY29tcHV0ZWQoKCkgPT4ge1xuXHRcdFx0bGV0IGluaXRpYWxEZXB0aCA9IHVucmVmKGluamVjdGVkRGVwdGgpO1xuXHRcdFx0Y29uc3QgeyBtYXRjaGVkIH0gPSByb3V0ZVRvRGlzcGxheS52YWx1ZTtcblx0XHRcdGxldCBtYXRjaGVkUm91dGU7XG5cdFx0XHR3aGlsZSAoKG1hdGNoZWRSb3V0ZSA9IG1hdGNoZWRbaW5pdGlhbERlcHRoXSkgJiYgIW1hdGNoZWRSb3V0ZS5jb21wb25lbnRzKSBpbml0aWFsRGVwdGgrKztcblx0XHRcdHJldHVybiBpbml0aWFsRGVwdGg7XG5cdFx0fSk7XG5cdFx0Y29uc3QgbWF0Y2hlZFJvdXRlUmVmID0gY29tcHV0ZWQoKCkgPT4gcm91dGVUb0Rpc3BsYXkudmFsdWUubWF0Y2hlZFtkZXB0aC52YWx1ZV0pO1xuXHRcdHByb3ZpZGUodmlld0RlcHRoS2V5LCBjb21wdXRlZCgoKSA9PiBkZXB0aC52YWx1ZSArIDEpKTtcblx0XHRwcm92aWRlKG1hdGNoZWRSb3V0ZUtleSwgbWF0Y2hlZFJvdXRlUmVmKTtcblx0XHRwcm92aWRlKHJvdXRlclZpZXdMb2NhdGlvbktleSwgcm91dGVUb0Rpc3BsYXkpO1xuXHRcdGNvbnN0IHZpZXdSZWYgPSByZWYoKTtcblx0XHR3YXRjaCgoKSA9PiBbXG5cdFx0XHR2aWV3UmVmLnZhbHVlLFxuXHRcdFx0bWF0Y2hlZFJvdXRlUmVmLnZhbHVlLFxuXHRcdFx0cHJvcHMubmFtZVxuXHRcdF0sIChbaW5zdGFuY2UsIHRvLCBuYW1lXSwgW29sZEluc3RhbmNlLCBmcm9tLCBfb2xkTmFtZV0pID0+IHtcblx0XHRcdGlmICh0bykge1xuXHRcdFx0XHR0by5pbnN0YW5jZXNbbmFtZV0gPSBpbnN0YW5jZTtcblx0XHRcdFx0aWYgKGZyb20gJiYgZnJvbSAhPT0gdG8gJiYgaW5zdGFuY2UgJiYgaW5zdGFuY2UgPT09IG9sZEluc3RhbmNlKSB7XG5cdFx0XHRcdFx0aWYgKCF0by5sZWF2ZUd1YXJkcy5zaXplKSB0by5sZWF2ZUd1YXJkcyA9IGZyb20ubGVhdmVHdWFyZHM7XG5cdFx0XHRcdFx0aWYgKCF0by51cGRhdGVHdWFyZHMuc2l6ZSkgdG8udXBkYXRlR3VhcmRzID0gZnJvbS51cGRhdGVHdWFyZHM7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdGlmIChpbnN0YW5jZSAmJiB0byAmJiAoIWZyb20gfHwgIWlzU2FtZVJvdXRlUmVjb3JkKHRvLCBmcm9tKSB8fCAhb2xkSW5zdGFuY2UpKSAodG8uZW50ZXJDYWxsYmFja3NbbmFtZV0gfHwgW10pLmZvckVhY2goKGNhbGxiYWNrKSA9PiBjYWxsYmFjayhpbnN0YW5jZSkpO1xuXHRcdH0sIHsgZmx1c2g6IFwicG9zdFwiIH0pO1xuXHRcdHJldHVybiAoKSA9PiB7XG5cdFx0XHRjb25zdCByb3V0ZSA9IHJvdXRlVG9EaXNwbGF5LnZhbHVlO1xuXHRcdFx0Y29uc3QgY3VycmVudE5hbWUgPSBwcm9wcy5uYW1lO1xuXHRcdFx0Y29uc3QgbWF0Y2hlZFJvdXRlID0gbWF0Y2hlZFJvdXRlUmVmLnZhbHVlO1xuXHRcdFx0Y29uc3QgVmlld0NvbXBvbmVudCA9IG1hdGNoZWRSb3V0ZSAmJiBtYXRjaGVkUm91dGUuY29tcG9uZW50c1tjdXJyZW50TmFtZV07XG5cdFx0XHRpZiAoIVZpZXdDb21wb25lbnQpIHJldHVybiBub3JtYWxpemVTbG90KHNsb3RzLmRlZmF1bHQsIHtcblx0XHRcdFx0Q29tcG9uZW50OiBWaWV3Q29tcG9uZW50LFxuXHRcdFx0XHRyb3V0ZVxuXHRcdFx0fSk7XG5cdFx0XHRjb25zdCByb3V0ZVByb3BzT3B0aW9uID0gbWF0Y2hlZFJvdXRlLnByb3BzW2N1cnJlbnROYW1lXTtcblx0XHRcdGNvbnN0IHJvdXRlUHJvcHMgPSByb3V0ZVByb3BzT3B0aW9uID8gcm91dGVQcm9wc09wdGlvbiA9PT0gdHJ1ZSA/IHJvdXRlLnBhcmFtcyA6IHR5cGVvZiByb3V0ZVByb3BzT3B0aW9uID09PSBcImZ1bmN0aW9uXCIgPyByb3V0ZVByb3BzT3B0aW9uKHJvdXRlKSA6IHJvdXRlUHJvcHNPcHRpb24gOiBudWxsO1xuXHRcdFx0Y29uc3Qgb25Wbm9kZVVubW91bnRlZCA9ICh2bm9kZSkgPT4ge1xuXHRcdFx0XHRpZiAodm5vZGUuY29tcG9uZW50LmlzVW5tb3VudGVkKSBtYXRjaGVkUm91dGUuaW5zdGFuY2VzW2N1cnJlbnROYW1lXSA9IG51bGw7XG5cdFx0XHR9O1xuXHRcdFx0Y29uc3QgY29tcG9uZW50ID0gaChWaWV3Q29tcG9uZW50LCBhc3NpZ24oe30sIHJvdXRlUHJvcHMsIGF0dHJzLCB7XG5cdFx0XHRcdG9uVm5vZGVVbm1vdW50ZWQsXG5cdFx0XHRcdHJlZjogdmlld1JlZlxuXHRcdFx0fSkpO1xuXHRcdFx0aWYgKChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgfHwgX19WVUVfUFJPRF9ERVZUT09MU19fKSAmJiBpc0Jyb3dzZXIgJiYgY29tcG9uZW50LnJlZikge1xuXHRcdFx0XHRjb25zdCBpbmZvID0ge1xuXHRcdFx0XHRcdGRlcHRoOiBkZXB0aC52YWx1ZSxcblx0XHRcdFx0XHRuYW1lOiBtYXRjaGVkUm91dGUubmFtZSxcblx0XHRcdFx0XHRwYXRoOiBtYXRjaGVkUm91dGUucGF0aCxcblx0XHRcdFx0XHRtZXRhOiBtYXRjaGVkUm91dGUubWV0YVxuXHRcdFx0XHR9O1xuXHRcdFx0XHQoaXNBcnJheShjb21wb25lbnQucmVmKSA/IGNvbXBvbmVudC5yZWYubWFwKChyKSA9PiByLmkpIDogW2NvbXBvbmVudC5yZWYuaV0pLmZvckVhY2goKGluc3RhbmNlKSA9PiB7XG5cdFx0XHRcdFx0aWYgKGluc3RhbmNlKSBpbnN0YW5jZS5fX3Zydl9kZXZ0b29scyA9IGluZm87XG5cdFx0XHRcdH0pO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIG5vcm1hbGl6ZVNsb3Qoc2xvdHMuZGVmYXVsdCwge1xuXHRcdFx0XHRDb21wb25lbnQ6IGNvbXBvbmVudCxcblx0XHRcdFx0cm91dGVcblx0XHRcdH0pIHx8IGNvbXBvbmVudDtcblx0XHR9O1xuXHR9XG59KTtcbmZ1bmN0aW9uIG5vcm1hbGl6ZVNsb3Qoc2xvdCwgZGF0YSkge1xuXHRpZiAoIXNsb3QpIHJldHVybiBudWxsO1xuXHRjb25zdCBzbG90Q29udGVudCA9IHNsb3QoZGF0YSk7XG5cdHJldHVybiBzbG90Q29udGVudC5sZW5ndGggPT09IDEgPyBzbG90Q29udGVudFswXSA6IHNsb3RDb250ZW50O1xufVxuLyoqXG4qIENvbXBvbmVudCB0byBkaXNwbGF5IHRoZSBjdXJyZW50IHJvdXRlIHRoZSB1c2VyIGlzIGF0LlxuKi9cbmNvbnN0IFJvdXRlclZpZXcgPSBSb3V0ZXJWaWV3SW1wbDtcbmZ1bmN0aW9uIHdhcm5EZXByZWNhdGVkVXNhZ2UoKSB7XG5cdGNvbnN0IGluc3RhbmNlID0gZ2V0Q3VycmVudEluc3RhbmNlKCk7XG5cdGNvbnN0IHBhcmVudE5hbWUgPSBpbnN0YW5jZS5wYXJlbnQgJiYgaW5zdGFuY2UucGFyZW50LnR5cGUubmFtZTtcblx0Y29uc3QgcGFyZW50U3ViVHJlZVR5cGUgPSBpbnN0YW5jZS5wYXJlbnQgJiYgaW5zdGFuY2UucGFyZW50LnN1YlRyZWUgJiYgaW5zdGFuY2UucGFyZW50LnN1YlRyZWUudHlwZTtcblx0aWYgKHBhcmVudE5hbWUgJiYgKHBhcmVudE5hbWUgPT09IFwiS2VlcEFsaXZlXCIgfHwgcGFyZW50TmFtZS5pbmNsdWRlcyhcIlRyYW5zaXRpb25cIikpICYmIHR5cGVvZiBwYXJlbnRTdWJUcmVlVHlwZSA9PT0gXCJvYmplY3RcIiAmJiBwYXJlbnRTdWJUcmVlVHlwZS5uYW1lID09PSBcIlJvdXRlclZpZXdcIikge1xuXHRcdGNvbnN0IGNvbXAgPSBwYXJlbnROYW1lID09PSBcIktlZXBBbGl2ZVwiID8gXCJrZWVwLWFsaXZlXCIgOiBcInRyYW5zaXRpb25cIjtcblx0XHRkaWFnbm9zdGljcy5WVUVfUk9VVEVSX1IwMDYwKHsgY29tcCB9KTtcblx0fVxufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3JvdXRlci50c1xuLyoqXG4qIENyZWF0ZXMgYSBSb3V0ZXIgaW5zdGFuY2UgdGhhdCBjYW4gYmUgdXNlZCBieSBhIFZ1ZSBhcHAuXG4qXG4qIEBwYXJhbSBvcHRpb25zIC0ge0BsaW5rIFJvdXRlck9wdGlvbnN9XG4qL1xuZnVuY3Rpb24gY3JlYXRlUm91dGVyKG9wdGlvbnMpIHtcblx0Y29uc3QgbWF0Y2hlciA9IGNyZWF0ZVJvdXRlck1hdGNoZXIob3B0aW9ucy5yb3V0ZXMsIG9wdGlvbnMpO1xuXHRjb25zdCBwYXJzZVF1ZXJ5JDEgPSBvcHRpb25zLnBhcnNlUXVlcnkgfHwgcGFyc2VRdWVyeTtcblx0Y29uc3Qgc3RyaW5naWZ5UXVlcnkkMSA9IG9wdGlvbnMuc3RyaW5naWZ5UXVlcnkgfHwgc3RyaW5naWZ5UXVlcnk7XG5cdGNvbnN0IHJvdXRlckhpc3RvcnkgPSBvcHRpb25zLmhpc3Rvcnk7XG5cdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgIXJvdXRlckhpc3RvcnkpIHRocm93IG5ldyBFcnJvcihcIlByb3ZpZGUgdGhlIFxcXCJoaXN0b3J5XFxcIiBvcHRpb24gd2hlbiBjYWxsaW5nIFxcXCJjcmVhdGVSb3V0ZXIoKVxcXCI6IGh0dHBzOi8vcm91dGVyLnZ1ZWpzLm9yZy9hcGkvaW50ZXJmYWNlcy9Sb3V0ZXJPcHRpb25zLmh0bWwjaGlzdG9yeVwiKTtcblx0Y29uc3QgYmVmb3JlR3VhcmRzID0gdXNlQ2FsbGJhY2tzKCk7XG5cdGNvbnN0IGJlZm9yZVJlc29sdmVHdWFyZHMgPSB1c2VDYWxsYmFja3MoKTtcblx0Y29uc3QgYWZ0ZXJHdWFyZHMgPSB1c2VDYWxsYmFja3MoKTtcblx0Y29uc3QgY3VycmVudFJvdXRlID0gc2hhbGxvd1JlZihTVEFSVF9MT0NBVElPTl9OT1JNQUxJWkVEKTtcblx0Y29uc3Qgcm91dGVzVmVyc2lvbiA9IHNoYWxsb3dSZWYoMCk7XG5cdGxldCBwZW5kaW5nTG9jYXRpb24gPSBTVEFSVF9MT0NBVElPTl9OT1JNQUxJWkVEO1xuXHRpZiAoaXNCcm93c2VyICYmIG9wdGlvbnMuc2Nyb2xsQmVoYXZpb3IgJiYgXCJzY3JvbGxSZXN0b3JhdGlvblwiIGluIGhpc3RvcnkpIGhpc3Rvcnkuc2Nyb2xsUmVzdG9yYXRpb24gPSBcIm1hbnVhbFwiO1xuXHRjb25zdCBub3JtYWxpemVQYXJhbXMgPSBhcHBseVRvUGFyYW1zLmJpbmQobnVsbCwgKHBhcmFtVmFsdWUpID0+IFwiXCIgKyBwYXJhbVZhbHVlKTtcblx0Y29uc3QgZW5jb2RlUGFyYW1zID0gYXBwbHlUb1BhcmFtcy5iaW5kKG51bGwsIGVuY29kZVBhcmFtKTtcblx0Y29uc3QgZGVjb2RlUGFyYW1zID0gYXBwbHlUb1BhcmFtcy5iaW5kKG51bGwsIGRlY29kZSk7XG5cdGZ1bmN0aW9uIGFkZFJvdXRlKHBhcmVudE9yUm91dGUsIHJvdXRlKSB7XG5cdFx0bGV0IHBhcmVudDtcblx0XHRsZXQgcmVjb3JkO1xuXHRcdGlmIChpc1JvdXRlTmFtZShwYXJlbnRPclJvdXRlKSkge1xuXHRcdFx0cGFyZW50ID0gbWF0Y2hlci5nZXRSZWNvcmRNYXRjaGVyKHBhcmVudE9yUm91dGUpO1xuXHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiAhcGFyZW50KSBkaWFnbm9zdGljcy5WVUVfUk9VVEVSX1IwMDAxKHsgbmFtZTogU3RyaW5nKHBhcmVudE9yUm91dGUpIH0pO1xuXHRcdFx0cmVjb3JkID0gcm91dGU7XG5cdFx0fSBlbHNlIHJlY29yZCA9IHBhcmVudE9yUm91dGU7XG5cdFx0Y29uc3QgcmVtb3ZlUm91dGUgPSBtYXRjaGVyLmFkZFJvdXRlKHJlY29yZCwgcGFyZW50KTtcblx0XHRyb3V0ZXNWZXJzaW9uLnZhbHVlKys7XG5cdFx0cmV0dXJuICgpID0+IHtcblx0XHRcdHJlbW92ZVJvdXRlKCk7XG5cdFx0XHRyb3V0ZXNWZXJzaW9uLnZhbHVlKys7XG5cdFx0fTtcblx0fVxuXHRmdW5jdGlvbiByZW1vdmVSb3V0ZShuYW1lKSB7XG5cdFx0Y29uc3QgcmVjb3JkTWF0Y2hlciA9IG1hdGNoZXIuZ2V0UmVjb3JkTWF0Y2hlcihuYW1lKTtcblx0XHRpZiAocmVjb3JkTWF0Y2hlcikge1xuXHRcdFx0bWF0Y2hlci5yZW1vdmVSb3V0ZShyZWNvcmRNYXRjaGVyKTtcblx0XHRcdHJvdXRlc1ZlcnNpb24udmFsdWUrKztcblx0XHR9IGVsc2UgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgZGlhZ25vc3RpY3MuVlVFX1JPVVRFUl9SMDAwMih7IG5hbWU6IFN0cmluZyhuYW1lKSB9KTtcblx0fVxuXHRmdW5jdGlvbiBjbGVhclJvdXRlcygpIHtcblx0XHRtYXRjaGVyLmNsZWFyUm91dGVzKCk7XG5cdFx0cm91dGVzVmVyc2lvbi52YWx1ZSsrO1xuXHR9XG5cdGZ1bmN0aW9uIGdldFJvdXRlcygpIHtcblx0XHRyZXR1cm4gbWF0Y2hlci5nZXRSb3V0ZXMoKS5tYXAoKHJvdXRlTWF0Y2hlcikgPT4gcm91dGVNYXRjaGVyLnJlY29yZCk7XG5cdH1cblx0ZnVuY3Rpb24gaGFzUm91dGUobmFtZSkge1xuXHRcdHJldHVybiAhIW1hdGNoZXIuZ2V0UmVjb3JkTWF0Y2hlcihuYW1lKTtcblx0fVxuXHRmdW5jdGlvbiByZXNvbHZlKHJhd0xvY2F0aW9uLCBjdXJyZW50TG9jYXRpb24pIHtcblx0XHRyb3V0ZXNWZXJzaW9uLnZhbHVlO1xuXHRcdGlmICh0eXBlb2YgcmF3TG9jYXRpb24gPT09IFwic3RyaW5nXCIpIHtcblx0XHRcdGN1cnJlbnRMb2NhdGlvbiA9IGN1cnJlbnRMb2NhdGlvbiB8fCAocmF3TG9jYXRpb24uc3RhcnRzV2l0aChcIi9cIikgPyBTVEFSVF9MT0NBVElPTl9OT1JNQUxJWkVEIDogY3VycmVudFJvdXRlLnZhbHVlKTtcblx0XHRcdGNvbnN0IGxvY2F0aW9uTm9ybWFsaXplZCA9IHBhcnNlVVJMKHBhcnNlUXVlcnkkMSwgcmF3TG9jYXRpb24sIGN1cnJlbnRMb2NhdGlvbi5wYXRoKTtcblx0XHRcdGNvbnN0IG1hdGNoZWRSb3V0ZSA9IG1hdGNoZXIucmVzb2x2ZSh7IHBhdGg6IGxvY2F0aW9uTm9ybWFsaXplZC5wYXRoIH0sIGN1cnJlbnRMb2NhdGlvbik7XG5cdFx0XHRjb25zdCBocmVmID0gcm91dGVySGlzdG9yeS5jcmVhdGVIcmVmKGxvY2F0aW9uTm9ybWFsaXplZC5mdWxsUGF0aCk7XG5cdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG5cdFx0XHRcdGlmIChocmVmLnN0YXJ0c1dpdGgoXCIvL1wiKSkgZGlhZ25vc3RpY3MuVlVFX1JPVVRFUl9SMDAwMyh7XG5cdFx0XHRcdFx0bG9jYXRpb246IHJhd0xvY2F0aW9uLFxuXHRcdFx0XHRcdGhyZWZcblx0XHRcdFx0fSk7XG5cdFx0XHRcdGVsc2UgaWYgKCFtYXRjaGVkUm91dGUubWF0Y2hlZC5sZW5ndGgpIGRpYWdub3N0aWNzLlZVRV9ST1VURVJfUjAwMDQoeyBwYXRoOiByYXdMb2NhdGlvbiB9KTtcblx0XHRcdH1cblx0XHRcdHJldHVybiBhc3NpZ24obG9jYXRpb25Ob3JtYWxpemVkLCBtYXRjaGVkUm91dGUsIHtcblx0XHRcdFx0cGFyYW1zOiBkZWNvZGVQYXJhbXMobWF0Y2hlZFJvdXRlLnBhcmFtcyksXG5cdFx0XHRcdHJlZGlyZWN0ZWRGcm9tOiB2b2lkIDAsXG5cdFx0XHRcdGhyZWZcblx0XHRcdH0pO1xuXHRcdH1cblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmICFpc1JvdXRlTG9jYXRpb24ocmF3TG9jYXRpb24pKSB7XG5cdFx0XHRkaWFnbm9zdGljcy5WVUVfUk9VVEVSX1IwMDA1KHsgcmF3TG9jYXRpb24gfSk7XG5cdFx0XHRyZXR1cm4gcmVzb2x2ZSh7fSk7XG5cdFx0fVxuXHRcdGN1cnJlbnRMb2NhdGlvbiA9IGFzc2lnbih7fSwgY3VycmVudExvY2F0aW9uIHx8IChyYXdMb2NhdGlvbi5wYXRoICE9IG51bGwgJiYgcmF3TG9jYXRpb24ucGF0aC5zdGFydHNXaXRoKFwiL1wiKSAmJiAhKFwibmFtZVwiIGluIHJhd0xvY2F0aW9uICYmIHJhd0xvY2F0aW9uLm5hbWUpID8gU1RBUlRfTE9DQVRJT05fTk9STUFMSVpFRCA6IGN1cnJlbnRSb3V0ZS52YWx1ZSkpO1xuXHRcdGxldCBtYXRjaGVyTG9jYXRpb247XG5cdFx0aWYgKHJhd0xvY2F0aW9uLnBhdGggIT0gbnVsbCkge1xuXHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiBcInBhcmFtc1wiIGluIHJhd0xvY2F0aW9uICYmICEoXCJuYW1lXCIgaW4gcmF3TG9jYXRpb24pICYmIE9iamVjdC5rZXlzKHJhd0xvY2F0aW9uLnBhcmFtcykubGVuZ3RoKSBkaWFnbm9zdGljcy5WVUVfUk9VVEVSX1IwMDA2KHsgcGF0aDogcmF3TG9jYXRpb24ucGF0aCB9KTtcblx0XHRcdG1hdGNoZXJMb2NhdGlvbiA9IGFzc2lnbih7fSwgcmF3TG9jYXRpb24sIHsgcGF0aDogcGFyc2VVUkwocGFyc2VRdWVyeSQxLCByYXdMb2NhdGlvbi5wYXRoLCBjdXJyZW50TG9jYXRpb24ucGF0aCkucGF0aCB9KTtcblx0XHR9IGVsc2Uge1xuXHRcdFx0Y29uc3QgdGFyZ2V0UGFyYW1zID0gYXNzaWduKHt9LCByYXdMb2NhdGlvbi5wYXJhbXMpO1xuXHRcdFx0Zm9yIChjb25zdCBrZXkgaW4gdGFyZ2V0UGFyYW1zKSBpZiAodGFyZ2V0UGFyYW1zW2tleV0gPT0gbnVsbCkgZGVsZXRlIHRhcmdldFBhcmFtc1trZXldO1xuXHRcdFx0bWF0Y2hlckxvY2F0aW9uID0gYXNzaWduKHt9LCByYXdMb2NhdGlvbiwgeyBwYXJhbXM6IGVuY29kZVBhcmFtcyh0YXJnZXRQYXJhbXMpIH0pO1xuXHRcdFx0Y3VycmVudExvY2F0aW9uLnBhcmFtcyA9IGVuY29kZVBhcmFtcyhjdXJyZW50TG9jYXRpb24ucGFyYW1zKTtcblx0XHR9XG5cdFx0Y29uc3QgbWF0Y2hlZFJvdXRlID0gbWF0Y2hlci5yZXNvbHZlKG1hdGNoZXJMb2NhdGlvbiwgY3VycmVudExvY2F0aW9uKTtcblx0XHRjb25zdCBoYXNoID0gcmF3TG9jYXRpb24uaGFzaCB8fCBcIlwiO1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgaGFzaCAmJiAhaGFzaC5zdGFydHNXaXRoKFwiI1wiKSkgZGlhZ25vc3RpY3MuVlVFX1JPVVRFUl9SMDAwNyh7IGhhc2ggfSk7XG5cdFx0bWF0Y2hlZFJvdXRlLnBhcmFtcyA9IG5vcm1hbGl6ZVBhcmFtcyhkZWNvZGVQYXJhbXMobWF0Y2hlZFJvdXRlLnBhcmFtcykpO1xuXHRcdGNvbnN0IGZ1bGxQYXRoID0gc3RyaW5naWZ5VVJMKHN0cmluZ2lmeVF1ZXJ5JDEsIGFzc2lnbih7fSwgcmF3TG9jYXRpb24sIHtcblx0XHRcdGhhc2g6IGVuY29kZUhhc2goaGFzaCksXG5cdFx0XHRwYXRoOiBtYXRjaGVkUm91dGUucGF0aFxuXHRcdH0pKTtcblx0XHRjb25zdCBocmVmID0gcm91dGVySGlzdG9yeS5jcmVhdGVIcmVmKGZ1bGxQYXRoKTtcblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG5cdFx0XHRpZiAoaHJlZi5zdGFydHNXaXRoKFwiLy9cIikpIGRpYWdub3N0aWNzLlZVRV9ST1VURVJfUjAwMDMoe1xuXHRcdFx0XHRsb2NhdGlvbjogcmF3TG9jYXRpb24sXG5cdFx0XHRcdGhyZWZcblx0XHRcdH0pO1xuXHRcdFx0ZWxzZSBpZiAoIW1hdGNoZWRSb3V0ZS5tYXRjaGVkLmxlbmd0aCkgZGlhZ25vc3RpY3MuVlVFX1JPVVRFUl9SMDAwNCh7IHBhdGg6IHJhd0xvY2F0aW9uLnBhdGggIT0gbnVsbCA/IHJhd0xvY2F0aW9uLnBhdGggOiByYXdMb2NhdGlvbiB9KTtcblx0XHR9XG5cdFx0cmV0dXJuIGFzc2lnbih7XG5cdFx0XHRmdWxsUGF0aCxcblx0XHRcdGhhc2gsXG5cdFx0XHRxdWVyeTogc3RyaW5naWZ5UXVlcnkkMSA9PT0gc3RyaW5naWZ5UXVlcnkgPyBub3JtYWxpemVRdWVyeShyYXdMb2NhdGlvbi5xdWVyeSkgOiByYXdMb2NhdGlvbi5xdWVyeSB8fCB7fVxuXHRcdH0sIG1hdGNoZWRSb3V0ZSwge1xuXHRcdFx0cmVkaXJlY3RlZEZyb206IHZvaWQgMCxcblx0XHRcdGhyZWZcblx0XHR9KTtcblx0fVxuXHRmdW5jdGlvbiBsb2NhdGlvbkFzT2JqZWN0KHRvKSB7XG5cdFx0cmV0dXJuIHR5cGVvZiB0byA9PT0gXCJzdHJpbmdcIiA/IHBhcnNlVVJMKHBhcnNlUXVlcnkkMSwgdG8sIGN1cnJlbnRSb3V0ZS52YWx1ZS5wYXRoKSA6IGFzc2lnbih7fSwgdG8pO1xuXHR9XG5cdGZ1bmN0aW9uIGNoZWNrQ2FuY2VsZWROYXZpZ2F0aW9uKHRvLCBmcm9tKSB7XG5cdFx0aWYgKHBlbmRpbmdMb2NhdGlvbiAhPT0gdG8pIHJldHVybiBjcmVhdGVSb3V0ZXJFcnJvcig4LCB7XG5cdFx0XHRmcm9tLFxuXHRcdFx0dG9cblx0XHR9KTtcblx0fVxuXHRmdW5jdGlvbiBwdXNoKHRvKSB7XG5cdFx0cmV0dXJuIHB1c2hXaXRoUmVkaXJlY3QodG8pO1xuXHR9XG5cdGZ1bmN0aW9uIHJlcGxhY2UodG8pIHtcblx0XHRyZXR1cm4gcHVzaChhc3NpZ24obG9jYXRpb25Bc09iamVjdCh0byksIHsgcmVwbGFjZTogdHJ1ZSB9KSk7XG5cdH1cblx0ZnVuY3Rpb24gaGFuZGxlUmVkaXJlY3RSZWNvcmQodG8sIGZyb20pIHtcblx0XHRjb25zdCBsYXN0TWF0Y2hlZCA9IHRvLm1hdGNoZWRbdG8ubWF0Y2hlZC5sZW5ndGggLSAxXTtcblx0XHRpZiAobGFzdE1hdGNoZWQgJiYgbGFzdE1hdGNoZWQucmVkaXJlY3QpIHtcblx0XHRcdGNvbnN0IHsgcmVkaXJlY3QgfSA9IGxhc3RNYXRjaGVkO1xuXHRcdFx0bGV0IG5ld1RhcmdldExvY2F0aW9uID0gdHlwZW9mIHJlZGlyZWN0ID09PSBcImZ1bmN0aW9uXCIgPyByZWRpcmVjdCh0bywgZnJvbSkgOiByZWRpcmVjdDtcblx0XHRcdGlmICh0eXBlb2YgbmV3VGFyZ2V0TG9jYXRpb24gPT09IFwic3RyaW5nXCIpIHtcblx0XHRcdFx0bmV3VGFyZ2V0TG9jYXRpb24gPSBuZXdUYXJnZXRMb2NhdGlvbi5pbmNsdWRlcyhcIj9cIikgfHwgbmV3VGFyZ2V0TG9jYXRpb24uaW5jbHVkZXMoXCIjXCIpID8gbmV3VGFyZ2V0TG9jYXRpb24gPSBsb2NhdGlvbkFzT2JqZWN0KG5ld1RhcmdldExvY2F0aW9uKSA6IHsgcGF0aDogbmV3VGFyZ2V0TG9jYXRpb24gfTtcblx0XHRcdFx0bmV3VGFyZ2V0TG9jYXRpb24ucGFyYW1zID0ge307XG5cdFx0XHR9XG5cdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIG5ld1RhcmdldExvY2F0aW9uLnBhdGggPT0gbnVsbCAmJiAhKFwibmFtZVwiIGluIG5ld1RhcmdldExvY2F0aW9uKSkge1xuXHRcdFx0XHRkaWFnbm9zdGljcy5WVUVfUk9VVEVSX1IwMDA4KHtcblx0XHRcdFx0XHR0YXJnZXQ6IEpTT04uc3RyaW5naWZ5KG5ld1RhcmdldExvY2F0aW9uLCBudWxsLCAyKSxcblx0XHRcdFx0XHR0bzogdG8uZnVsbFBhdGhcblx0XHRcdFx0fSk7XG5cdFx0XHRcdHRocm93IG5ldyBFcnJvcihcIkludmFsaWQgcmVkaXJlY3RcIik7XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gYXNzaWduKHtcblx0XHRcdFx0cXVlcnk6IHRvLnF1ZXJ5LFxuXHRcdFx0XHRoYXNoOiB0by5oYXNoLFxuXHRcdFx0XHRwYXJhbXM6IG5ld1RhcmdldExvY2F0aW9uLnBhdGggIT0gbnVsbCA/IHt9IDogdG8ucGFyYW1zXG5cdFx0XHR9LCBuZXdUYXJnZXRMb2NhdGlvbik7XG5cdFx0fVxuXHR9XG5cdGZ1bmN0aW9uIHB1c2hXaXRoUmVkaXJlY3QodG8sIHJlZGlyZWN0ZWRGcm9tKSB7XG5cdFx0Y29uc3QgdGFyZ2V0TG9jYXRpb24gPSBwZW5kaW5nTG9jYXRpb24gPSByZXNvbHZlKHRvKTtcblx0XHRjb25zdCBmcm9tID0gY3VycmVudFJvdXRlLnZhbHVlO1xuXHRcdGNvbnN0IGRhdGEgPSB0by5zdGF0ZTtcblx0XHRjb25zdCBmb3JjZSA9IHRvLmZvcmNlO1xuXHRcdGNvbnN0IHJlcGxhY2UgPSB0by5yZXBsYWNlID09PSB0cnVlO1xuXHRcdGNvbnN0IHNob3VsZFJlZGlyZWN0ID0gaGFuZGxlUmVkaXJlY3RSZWNvcmQodGFyZ2V0TG9jYXRpb24sIGZyb20pO1xuXHRcdGlmIChzaG91bGRSZWRpcmVjdCkgcmV0dXJuIHB1c2hXaXRoUmVkaXJlY3QoYXNzaWduKGxvY2F0aW9uQXNPYmplY3Qoc2hvdWxkUmVkaXJlY3QpLCB7XG5cdFx0XHRzdGF0ZTogdHlwZW9mIHNob3VsZFJlZGlyZWN0ID09PSBcIm9iamVjdFwiID8gYXNzaWduKHt9LCBkYXRhLCBzaG91bGRSZWRpcmVjdC5zdGF0ZSkgOiBkYXRhLFxuXHRcdFx0Zm9yY2UsXG5cdFx0XHRyZXBsYWNlXG5cdFx0fSksIHJlZGlyZWN0ZWRGcm9tIHx8IHRhcmdldExvY2F0aW9uKTtcblx0XHRjb25zdCB0b0xvY2F0aW9uID0gdGFyZ2V0TG9jYXRpb247XG5cdFx0dG9Mb2NhdGlvbi5yZWRpcmVjdGVkRnJvbSA9IHJlZGlyZWN0ZWRGcm9tO1xuXHRcdGxldCBmYWlsdXJlO1xuXHRcdGlmICghZm9yY2UgJiYgaXNTYW1lUm91dGVMb2NhdGlvbihzdHJpbmdpZnlRdWVyeSQxLCBmcm9tLCB0YXJnZXRMb2NhdGlvbikpIHtcblx0XHRcdGZhaWx1cmUgPSBjcmVhdGVSb3V0ZXJFcnJvcigxNiwge1xuXHRcdFx0XHR0bzogdG9Mb2NhdGlvbixcblx0XHRcdFx0ZnJvbVxuXHRcdFx0fSk7XG5cdFx0XHRoYW5kbGVTY3JvbGwoZnJvbSwgZnJvbSwgdHJ1ZSwgZmFsc2UpO1xuXHRcdH1cblx0XHRyZXR1cm4gKGZhaWx1cmUgPyBQcm9taXNlLnJlc29sdmUoZmFpbHVyZSkgOiBuYXZpZ2F0ZSh0b0xvY2F0aW9uLCBmcm9tKSkuY2F0Y2goKGVycm9yKSA9PiBpc05hdmlnYXRpb25GYWlsdXJlKGVycm9yKSA/IGlzTmF2aWdhdGlvbkZhaWx1cmUoZXJyb3IsIDIpID8gZXJyb3IgOiBtYXJrQXNSZWFkeShlcnJvcikgOiB0cmlnZ2VyRXJyb3IoZXJyb3IsIHRvTG9jYXRpb24sIGZyb20pKS50aGVuKChmYWlsdXJlKSA9PiB7XG5cdFx0XHRpZiAoZmFpbHVyZSkge1xuXHRcdFx0XHRpZiAoaXNOYXZpZ2F0aW9uRmFpbHVyZShmYWlsdXJlLCAyKSkge1xuXHRcdFx0XHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgaXNTYW1lUm91dGVMb2NhdGlvbihzdHJpbmdpZnlRdWVyeSQxLCByZXNvbHZlKGZhaWx1cmUudG8pLCB0b0xvY2F0aW9uKSAmJiByZWRpcmVjdGVkRnJvbSAmJiAocmVkaXJlY3RlZEZyb20uX2NvdW50ID0gcmVkaXJlY3RlZEZyb20uX2NvdW50ID8gcmVkaXJlY3RlZEZyb20uX2NvdW50ICsgMSA6IDEpID4gMzApIHtcblx0XHRcdFx0XHRcdGRpYWdub3N0aWNzLlZVRV9ST1VURVJfUjAwMDkoe1xuXHRcdFx0XHRcdFx0XHRmcm9tOiBmcm9tLmZ1bGxQYXRoLFxuXHRcdFx0XHRcdFx0XHR0bzogdG9Mb2NhdGlvbi5mdWxsUGF0aFxuXHRcdFx0XHRcdFx0fSk7XG5cdFx0XHRcdFx0XHRyZXR1cm4gUHJvbWlzZS5yZWplY3QoLyogQF9fUFVSRV9fICovIG5ldyBFcnJvcihcIkluZmluaXRlIHJlZGlyZWN0IGluIG5hdmlnYXRpb24gZ3VhcmRcIikpO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRyZXR1cm4gcHVzaFdpdGhSZWRpcmVjdChhc3NpZ24oeyByZXBsYWNlIH0sIGxvY2F0aW9uQXNPYmplY3QoZmFpbHVyZS50byksIHtcblx0XHRcdFx0XHRcdHN0YXRlOiB0eXBlb2YgZmFpbHVyZS50byA9PT0gXCJvYmplY3RcIiA/IGFzc2lnbih7fSwgZGF0YSwgZmFpbHVyZS50by5zdGF0ZSkgOiBkYXRhLFxuXHRcdFx0XHRcdFx0Zm9yY2Vcblx0XHRcdFx0XHR9KSwgcmVkaXJlY3RlZEZyb20gfHwgdG9Mb2NhdGlvbik7XG5cdFx0XHRcdH1cblx0XHRcdH0gZWxzZSBmYWlsdXJlID0gZmluYWxpemVOYXZpZ2F0aW9uKHRvTG9jYXRpb24sIGZyb20sIHRydWUsIHJlcGxhY2UsIGRhdGEpO1xuXHRcdFx0dHJpZ2dlckFmdGVyRWFjaCh0b0xvY2F0aW9uLCBmcm9tLCBmYWlsdXJlKTtcblx0XHRcdHJldHVybiBmYWlsdXJlO1xuXHRcdH0pO1xuXHR9XG5cdC8qKlxuXHQqIEhlbHBlciB0byByZWplY3QgYW5kIHNraXAgYWxsIG5hdmlnYXRpb24gZ3VhcmRzIGlmIGEgbmV3IG5hdmlnYXRpb24gaGFwcGVuZWRcblx0KiBAcGFyYW0gdG9cblx0KiBAcGFyYW0gZnJvbVxuXHQqL1xuXHRmdW5jdGlvbiBjaGVja0NhbmNlbGVkTmF2aWdhdGlvbkFuZFJlamVjdCh0bywgZnJvbSkge1xuXHRcdGNvbnN0IGVycm9yID0gY2hlY2tDYW5jZWxlZE5hdmlnYXRpb24odG8sIGZyb20pO1xuXHRcdHJldHVybiBlcnJvciA/IFByb21pc2UucmVqZWN0KGVycm9yKSA6IFByb21pc2UucmVzb2x2ZSgpO1xuXHR9XG5cdGZ1bmN0aW9uIHJ1bldpdGhDb250ZXh0KGZuKSB7XG5cdFx0Y29uc3QgYXBwID0gaW5zdGFsbGVkQXBwcy52YWx1ZXMoKS5uZXh0KCkudmFsdWU7XG5cdFx0cmV0dXJuIGFwcCAmJiB0eXBlb2YgYXBwLnJ1bldpdGhDb250ZXh0ID09PSBcImZ1bmN0aW9uXCIgPyBhcHAucnVuV2l0aENvbnRleHQoZm4pIDogZm4oKTtcblx0fVxuXHRmdW5jdGlvbiBuYXZpZ2F0ZSh0bywgZnJvbSkge1xuXHRcdGxldCBndWFyZHM7XG5cdFx0Y29uc3QgW2xlYXZpbmdSZWNvcmRzLCB1cGRhdGluZ1JlY29yZHMsIGVudGVyaW5nUmVjb3Jkc10gPSBleHRyYWN0Q2hhbmdpbmdSZWNvcmRzKHRvLCBmcm9tKTtcblx0XHRndWFyZHMgPSBleHRyYWN0Q29tcG9uZW50c0d1YXJkcyhsZWF2aW5nUmVjb3Jkcy5yZXZlcnNlKCksIFwiYmVmb3JlUm91dGVMZWF2ZVwiLCB0bywgZnJvbSk7XG5cdFx0Zm9yIChjb25zdCByZWNvcmQgb2YgbGVhdmluZ1JlY29yZHMpIHJlY29yZC5sZWF2ZUd1YXJkcy5mb3JFYWNoKChndWFyZCkgPT4ge1xuXHRcdFx0Z3VhcmRzLnB1c2goZ3VhcmRUb1Byb21pc2VGbihndWFyZCwgdG8sIGZyb20pKTtcblx0XHR9KTtcblx0XHRjb25zdCBjYW5jZWxlZE5hdmlnYXRpb25DaGVjayA9IGNoZWNrQ2FuY2VsZWROYXZpZ2F0aW9uQW5kUmVqZWN0LmJpbmQobnVsbCwgdG8sIGZyb20pO1xuXHRcdGd1YXJkcy5wdXNoKGNhbmNlbGVkTmF2aWdhdGlvbkNoZWNrKTtcblx0XHRyZXR1cm4gcnVuR3VhcmRRdWV1ZShndWFyZHMpLnRoZW4oKCkgPT4ge1xuXHRcdFx0Z3VhcmRzID0gW107XG5cdFx0XHRmb3IgKGNvbnN0IGd1YXJkIG9mIGJlZm9yZUd1YXJkcy5saXN0KCkpIGd1YXJkcy5wdXNoKGd1YXJkVG9Qcm9taXNlRm4oZ3VhcmQsIHRvLCBmcm9tKSk7XG5cdFx0XHRndWFyZHMucHVzaChjYW5jZWxlZE5hdmlnYXRpb25DaGVjayk7XG5cdFx0XHRyZXR1cm4gcnVuR3VhcmRRdWV1ZShndWFyZHMpO1xuXHRcdH0pLnRoZW4oKCkgPT4ge1xuXHRcdFx0Z3VhcmRzID0gZXh0cmFjdENvbXBvbmVudHNHdWFyZHModXBkYXRpbmdSZWNvcmRzLCBcImJlZm9yZVJvdXRlVXBkYXRlXCIsIHRvLCBmcm9tKTtcblx0XHRcdGZvciAoY29uc3QgcmVjb3JkIG9mIHVwZGF0aW5nUmVjb3JkcykgcmVjb3JkLnVwZGF0ZUd1YXJkcy5mb3JFYWNoKChndWFyZCkgPT4ge1xuXHRcdFx0XHRndWFyZHMucHVzaChndWFyZFRvUHJvbWlzZUZuKGd1YXJkLCB0bywgZnJvbSkpO1xuXHRcdFx0fSk7XG5cdFx0XHRndWFyZHMucHVzaChjYW5jZWxlZE5hdmlnYXRpb25DaGVjayk7XG5cdFx0XHRyZXR1cm4gcnVuR3VhcmRRdWV1ZShndWFyZHMpO1xuXHRcdH0pLnRoZW4oKCkgPT4ge1xuXHRcdFx0Z3VhcmRzID0gW107XG5cdFx0XHRmb3IgKGNvbnN0IHJlY29yZCBvZiBlbnRlcmluZ1JlY29yZHMpIGlmIChyZWNvcmQuYmVmb3JlRW50ZXIpIHtcblx0XHRcdFx0aWYgKGlzQXJyYXkocmVjb3JkLmJlZm9yZUVudGVyKSkgZm9yIChjb25zdCBiZWZvcmVFbnRlciBvZiByZWNvcmQuYmVmb3JlRW50ZXIpIGd1YXJkcy5wdXNoKGd1YXJkVG9Qcm9taXNlRm4oYmVmb3JlRW50ZXIsIHRvLCBmcm9tKSk7XG5cdFx0XHRcdGVsc2UgZ3VhcmRzLnB1c2goZ3VhcmRUb1Byb21pc2VGbihyZWNvcmQuYmVmb3JlRW50ZXIsIHRvLCBmcm9tKSk7XG5cdFx0XHR9XG5cdFx0XHRndWFyZHMucHVzaChjYW5jZWxlZE5hdmlnYXRpb25DaGVjayk7XG5cdFx0XHRyZXR1cm4gcnVuR3VhcmRRdWV1ZShndWFyZHMpO1xuXHRcdH0pLnRoZW4oKCkgPT4ge1xuXHRcdFx0dG8ubWF0Y2hlZC5mb3JFYWNoKChyZWNvcmQpID0+IHJlY29yZC5lbnRlckNhbGxiYWNrcyA9IHt9KTtcblx0XHRcdGd1YXJkcyA9IGV4dHJhY3RDb21wb25lbnRzR3VhcmRzKGVudGVyaW5nUmVjb3JkcywgXCJiZWZvcmVSb3V0ZUVudGVyXCIsIHRvLCBmcm9tLCBydW5XaXRoQ29udGV4dCk7XG5cdFx0XHRndWFyZHMucHVzaChjYW5jZWxlZE5hdmlnYXRpb25DaGVjayk7XG5cdFx0XHRyZXR1cm4gcnVuR3VhcmRRdWV1ZShndWFyZHMpO1xuXHRcdH0pLnRoZW4oKCkgPT4ge1xuXHRcdFx0Z3VhcmRzID0gW107XG5cdFx0XHRmb3IgKGNvbnN0IGd1YXJkIG9mIGJlZm9yZVJlc29sdmVHdWFyZHMubGlzdCgpKSBndWFyZHMucHVzaChndWFyZFRvUHJvbWlzZUZuKGd1YXJkLCB0bywgZnJvbSkpO1xuXHRcdFx0Z3VhcmRzLnB1c2goY2FuY2VsZWROYXZpZ2F0aW9uQ2hlY2spO1xuXHRcdFx0cmV0dXJuIHJ1bkd1YXJkUXVldWUoZ3VhcmRzKTtcblx0XHR9KS5jYXRjaCgoZXJyKSA9PiBpc05hdmlnYXRpb25GYWlsdXJlKGVyciwgOCkgPyBlcnIgOiBQcm9taXNlLnJlamVjdChlcnIpKTtcblx0fVxuXHRmdW5jdGlvbiB0cmlnZ2VyQWZ0ZXJFYWNoKHRvLCBmcm9tLCBmYWlsdXJlKSB7XG5cdFx0YWZ0ZXJHdWFyZHMubGlzdCgpLmZvckVhY2goKGd1YXJkKSA9PiBydW5XaXRoQ29udGV4dCgoKSA9PiBndWFyZCh0bywgZnJvbSwgZmFpbHVyZSkpKTtcblx0fVxuXHQvKipcblx0KiAtIENsZWFucyB1cCBhbnkgbmF2aWdhdGlvbiBndWFyZHNcblx0KiAtIENoYW5nZXMgdGhlIHVybCBpZiBuZWNlc3Nhcnlcblx0KiAtIENhbGxzIHRoZSBzY3JvbGxCZWhhdmlvclxuXHQqL1xuXHRmdW5jdGlvbiBmaW5hbGl6ZU5hdmlnYXRpb24odG9Mb2NhdGlvbiwgZnJvbSwgaXNQdXNoLCByZXBsYWNlLCBkYXRhKSB7XG5cdFx0Y29uc3QgZXJyb3IgPSBjaGVja0NhbmNlbGVkTmF2aWdhdGlvbih0b0xvY2F0aW9uLCBmcm9tKTtcblx0XHRpZiAoZXJyb3IpIHJldHVybiBlcnJvcjtcblx0XHRjb25zdCBpc0ZpcnN0TmF2aWdhdGlvbiA9IGZyb20gPT09IFNUQVJUX0xPQ0FUSU9OX05PUk1BTElaRUQ7XG5cdFx0Y29uc3Qgc3RhdGUgPSAhaXNCcm93c2VyID8ge30gOiBoaXN0b3J5LnN0YXRlO1xuXHRcdGlmIChpc1B1c2gpIHtcblx0XHRcdGlmIChyZXBsYWNlIHx8IGlzRmlyc3ROYXZpZ2F0aW9uKSByb3V0ZXJIaXN0b3J5LnJlcGxhY2UodG9Mb2NhdGlvbi5mdWxsUGF0aCwgYXNzaWduKHsgc2Nyb2xsOiBpc0ZpcnN0TmF2aWdhdGlvbiAmJiBzdGF0ZSAmJiBzdGF0ZS5zY3JvbGwgfSwgZGF0YSkpO1xuXHRcdFx0ZWxzZSByb3V0ZXJIaXN0b3J5LnB1c2godG9Mb2NhdGlvbi5mdWxsUGF0aCwgZGF0YSk7XG5cdFx0fVxuXHRcdGN1cnJlbnRSb3V0ZS52YWx1ZSA9IHRvTG9jYXRpb247XG5cdFx0aGFuZGxlU2Nyb2xsKHRvTG9jYXRpb24sIGZyb20sIGlzUHVzaCwgaXNGaXJzdE5hdmlnYXRpb24pO1xuXHRcdG1hcmtBc1JlYWR5KCk7XG5cdH1cblx0bGV0IHJlbW92ZUhpc3RvcnlMaXN0ZW5lcjtcblx0ZnVuY3Rpb24gc2V0dXBMaXN0ZW5lcnMoKSB7XG5cdFx0aWYgKHJlbW92ZUhpc3RvcnlMaXN0ZW5lcikgcmV0dXJuO1xuXHRcdHJlbW92ZUhpc3RvcnlMaXN0ZW5lciA9IHJvdXRlckhpc3RvcnkubGlzdGVuKCh0bywgX2Zyb20sIGluZm8pID0+IHtcblx0XHRcdGlmICghcm91dGVyLmxpc3RlbmluZykgcmV0dXJuO1xuXHRcdFx0Y29uc3QgdG9Mb2NhdGlvbiA9IHJlc29sdmUodG8pO1xuXHRcdFx0Y29uc3Qgc2hvdWxkUmVkaXJlY3QgPSBoYW5kbGVSZWRpcmVjdFJlY29yZCh0b0xvY2F0aW9uLCByb3V0ZXIuY3VycmVudFJvdXRlLnZhbHVlKTtcblx0XHRcdGlmIChzaG91bGRSZWRpcmVjdCkge1xuXHRcdFx0XHRwdXNoV2l0aFJlZGlyZWN0KGFzc2lnbihzaG91bGRSZWRpcmVjdCwge1xuXHRcdFx0XHRcdHJlcGxhY2U6IHRydWUsXG5cdFx0XHRcdFx0Zm9yY2U6IHRydWVcblx0XHRcdFx0fSksIHRvTG9jYXRpb24pLmNhdGNoKG5vb3ApO1xuXHRcdFx0XHRyZXR1cm47XG5cdFx0XHR9XG5cdFx0XHRwZW5kaW5nTG9jYXRpb24gPSB0b0xvY2F0aW9uO1xuXHRcdFx0Y29uc3QgZnJvbSA9IGN1cnJlbnRSb3V0ZS52YWx1ZTtcblx0XHRcdGlmIChpc0Jyb3dzZXIgJiYgaW5mby5kZWx0YSkgc2F2ZVNjcm9sbFBvc2l0aW9uKGdldFNjcm9sbEtleShmcm9tLmZ1bGxQYXRoLCBpbmZvLmRlbHRhKSk7XG5cdFx0XHRuYXZpZ2F0ZSh0b0xvY2F0aW9uLCBmcm9tKS5jYXRjaCgoZXJyb3IpID0+IHtcblx0XHRcdFx0aWYgKGlzTmF2aWdhdGlvbkZhaWx1cmUoZXJyb3IsIDEyKSkgcmV0dXJuIGVycm9yO1xuXHRcdFx0XHRpZiAoaXNOYXZpZ2F0aW9uRmFpbHVyZShlcnJvciwgMikpIHtcblx0XHRcdFx0XHRwdXNoV2l0aFJlZGlyZWN0KGFzc2lnbihsb2NhdGlvbkFzT2JqZWN0KGVycm9yLnRvKSwgeyBmb3JjZTogdHJ1ZSB9KSwgdG9Mb2NhdGlvbikudGhlbigoZmFpbHVyZSkgPT4ge1xuXHRcdFx0XHRcdFx0aWYgKGlzTmF2aWdhdGlvbkZhaWx1cmUoZmFpbHVyZSwgMjApICYmICFpbmZvLmRlbHRhICYmIGluZm8udHlwZSA9PT0gXCJwb3BcIikgcm91dGVySGlzdG9yeS5nbygtMSwgZmFsc2UpO1xuXHRcdFx0XHRcdH0pLmNhdGNoKG5vb3ApO1xuXHRcdFx0XHRcdHJldHVybiBQcm9taXNlLnJlamVjdCgpO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGlmIChpbmZvLmRlbHRhKSByb3V0ZXJIaXN0b3J5LmdvKC1pbmZvLmRlbHRhLCBmYWxzZSk7XG5cdFx0XHRcdHJldHVybiB0cmlnZ2VyRXJyb3IoZXJyb3IsIHRvTG9jYXRpb24sIGZyb20pO1xuXHRcdFx0fSkudGhlbigoZmFpbHVyZSkgPT4ge1xuXHRcdFx0XHRmYWlsdXJlID0gZmFpbHVyZSB8fCBmaW5hbGl6ZU5hdmlnYXRpb24odG9Mb2NhdGlvbiwgZnJvbSwgZmFsc2UpO1xuXHRcdFx0XHRpZiAoZmFpbHVyZSkge1xuXHRcdFx0XHRcdGlmIChpbmZvLmRlbHRhICYmICFpc05hdmlnYXRpb25GYWlsdXJlKGZhaWx1cmUsIDgpKSByb3V0ZXJIaXN0b3J5LmdvKC1pbmZvLmRlbHRhLCBmYWxzZSk7XG5cdFx0XHRcdFx0ZWxzZSBpZiAoaW5mby50eXBlID09PSBcInBvcFwiICYmIGlzTmF2aWdhdGlvbkZhaWx1cmUoZmFpbHVyZSwgMjApKSByb3V0ZXJIaXN0b3J5LmdvKC0xLCBmYWxzZSk7XG5cdFx0XHRcdH1cblx0XHRcdFx0dHJpZ2dlckFmdGVyRWFjaCh0b0xvY2F0aW9uLCBmcm9tLCBmYWlsdXJlKTtcblx0XHRcdH0pLmNhdGNoKG5vb3ApO1xuXHRcdH0pO1xuXHR9XG5cdGxldCByZWFkeUhhbmRsZXJzID0gdXNlQ2FsbGJhY2tzKCk7XG5cdGxldCBlcnJvckxpc3RlbmVycyA9IHVzZUNhbGxiYWNrcygpO1xuXHRsZXQgcmVhZHk7XG5cdC8qKlxuXHQqIFRyaWdnZXIgZXJyb3JMaXN0ZW5lcnMgYWRkZWQgdmlhIG9uRXJyb3IgYW5kIHRocm93cyB0aGUgZXJyb3IgYXMgd2VsbFxuXHQqXG5cdCogQHBhcmFtIGVycm9yIC0gZXJyb3IgdG8gdGhyb3dcblx0KiBAcGFyYW0gdG8gLSBsb2NhdGlvbiB3ZSB3ZXJlIG5hdmlnYXRpbmcgdG8gd2hlbiB0aGUgZXJyb3IgaGFwcGVuZWRcblx0KiBAcGFyYW0gZnJvbSAtIGxvY2F0aW9uIHdlIHdlcmUgbmF2aWdhdGluZyBmcm9tIHdoZW4gdGhlIGVycm9yIGhhcHBlbmVkXG5cdCogQHJldHVybnMgdGhlIGVycm9yIGFzIGEgcmVqZWN0ZWQgcHJvbWlzZVxuXHQqL1xuXHRmdW5jdGlvbiB0cmlnZ2VyRXJyb3IoZXJyb3IsIHRvLCBmcm9tKSB7XG5cdFx0bWFya0FzUmVhZHkoZXJyb3IpO1xuXHRcdGNvbnN0IGxpc3QgPSBlcnJvckxpc3RlbmVycy5saXN0KCk7XG5cdFx0aWYgKGxpc3QubGVuZ3RoKSBsaXN0LmZvckVhY2goKGhhbmRsZXIpID0+IGhhbmRsZXIoZXJyb3IsIHRvLCBmcm9tKSk7XG5cdFx0ZWxzZSB7XG5cdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBkaWFnbm9zdGljcy5WVUVfUk9VVEVSX1IwMDEwKCk7XG5cdFx0XHRjb25zb2xlLmVycm9yKGVycm9yKTtcblx0XHR9XG5cdFx0cmV0dXJuIFByb21pc2UucmVqZWN0KGVycm9yKTtcblx0fVxuXHRmdW5jdGlvbiBpc1JlYWR5KCkge1xuXHRcdGlmIChyZWFkeSAmJiBjdXJyZW50Um91dGUudmFsdWUgIT09IFNUQVJUX0xPQ0FUSU9OX05PUk1BTElaRUQpIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcblx0XHRyZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdFx0cmVhZHlIYW5kbGVycy5hZGQoW3Jlc29sdmUsIHJlamVjdF0pO1xuXHRcdH0pO1xuXHR9XG5cdGZ1bmN0aW9uIG1hcmtBc1JlYWR5KGVycikge1xuXHRcdGlmICghcmVhZHkpIHtcblx0XHRcdHJlYWR5ID0gIWVycjtcblx0XHRcdHNldHVwTGlzdGVuZXJzKCk7XG5cdFx0XHRyZWFkeUhhbmRsZXJzLmxpc3QoKS5mb3JFYWNoKChbcmVzb2x2ZSwgcmVqZWN0XSkgPT4gZXJyID8gcmVqZWN0KGVycikgOiByZXNvbHZlKCkpO1xuXHRcdFx0cmVhZHlIYW5kbGVycy5yZXNldCgpO1xuXHRcdH1cblx0XHRyZXR1cm4gZXJyO1xuXHR9XG5cdGZ1bmN0aW9uIGhhbmRsZVNjcm9sbCh0bywgZnJvbSwgaXNQdXNoLCBpc0ZpcnN0TmF2aWdhdGlvbikge1xuXHRcdGNvbnN0IHsgc2Nyb2xsQmVoYXZpb3IgfSA9IG9wdGlvbnM7XG5cdFx0aWYgKCFpc0Jyb3dzZXIgfHwgIXNjcm9sbEJlaGF2aW9yKSByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG5cdFx0Y29uc3Qgc2Nyb2xsUG9zaXRpb24gPSAhaXNQdXNoICYmIGdldFNhdmVkU2Nyb2xsUG9zaXRpb24oZ2V0U2Nyb2xsS2V5KHRvLmZ1bGxQYXRoLCAwKSkgfHwgKGlzRmlyc3ROYXZpZ2F0aW9uIHx8ICFpc1B1c2gpICYmIGhpc3Rvcnkuc3RhdGUgJiYgaGlzdG9yeS5zdGF0ZS5zY3JvbGwgfHwgbnVsbDtcblx0XHRyZXR1cm4gbmV4dFRpY2soKS50aGVuKCgpID0+IHNjcm9sbEJlaGF2aW9yKHRvLCBmcm9tLCBzY3JvbGxQb3NpdGlvbikpLnRoZW4oKHBvc2l0aW9uKSA9PiB0byA9PT0gY3VycmVudFJvdXRlLnZhbHVlICYmIHBvc2l0aW9uICYmIHNjcm9sbFRvUG9zaXRpb24ocG9zaXRpb24pKS5jYXRjaCgoZXJyKSA9PiB0byA9PT0gY3VycmVudFJvdXRlLnZhbHVlICYmIHRyaWdnZXJFcnJvcihlcnIsIHRvLCBmcm9tKSk7XG5cdH1cblx0Y29uc3QgZ28gPSAoZGVsdGEpID0+IHJvdXRlckhpc3RvcnkuZ28oZGVsdGEpO1xuXHRsZXQgc3RhcnRlZDtcblx0Y29uc3QgaW5zdGFsbGVkQXBwcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG5cdGNvbnN0IHJvdXRlciA9IHtcblx0XHRjdXJyZW50Um91dGUsXG5cdFx0bGlzdGVuaW5nOiB0cnVlLFxuXHRcdGFkZFJvdXRlLFxuXHRcdHJlbW92ZVJvdXRlLFxuXHRcdGNsZWFyUm91dGVzLFxuXHRcdGhhc1JvdXRlLFxuXHRcdGdldFJvdXRlcyxcblx0XHRyZXNvbHZlLFxuXHRcdG9wdGlvbnMsXG5cdFx0cHVzaCxcblx0XHRyZXBsYWNlLFxuXHRcdGdvLFxuXHRcdGJhY2s6ICgpID0+IGdvKC0xKSxcblx0XHRmb3J3YXJkOiAoKSA9PiBnbygxKSxcblx0XHRiZWZvcmVFYWNoOiBiZWZvcmVHdWFyZHMuYWRkLFxuXHRcdGJlZm9yZVJlc29sdmU6IGJlZm9yZVJlc29sdmVHdWFyZHMuYWRkLFxuXHRcdGFmdGVyRWFjaDogYWZ0ZXJHdWFyZHMuYWRkLFxuXHRcdG9uRXJyb3I6IGVycm9yTGlzdGVuZXJzLmFkZCxcblx0XHRpc1JlYWR5LFxuXHRcdGluc3RhbGwoYXBwKSB7XG5cdFx0XHRhcHAuY29tcG9uZW50KFwiUm91dGVyTGlua1wiLCBSb3V0ZXJMaW5rKTtcblx0XHRcdGFwcC5jb21wb25lbnQoXCJSb3V0ZXJWaWV3XCIsIFJvdXRlclZpZXcpO1xuXHRcdFx0YXBwLmNvbmZpZy5nbG9iYWxQcm9wZXJ0aWVzLiRyb3V0ZXIgPSByb3V0ZXI7XG5cdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoYXBwLmNvbmZpZy5nbG9iYWxQcm9wZXJ0aWVzLCBcIiRyb3V0ZVwiLCB7XG5cdFx0XHRcdGVudW1lcmFibGU6IHRydWUsXG5cdFx0XHRcdGdldDogKCkgPT4gdW5yZWYoY3VycmVudFJvdXRlKVxuXHRcdFx0fSk7XG5cdFx0XHRpZiAoaXNCcm93c2VyICYmICFzdGFydGVkICYmIGN1cnJlbnRSb3V0ZS52YWx1ZSA9PT0gU1RBUlRfTE9DQVRJT05fTk9STUFMSVpFRCkge1xuXHRcdFx0XHRzdGFydGVkID0gdHJ1ZTtcblx0XHRcdFx0cHVzaChyb3V0ZXJIaXN0b3J5LmxvY2F0aW9uKS5jYXRjaCgoZXJyKSA9PiB7XG5cdFx0XHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgZGlhZ25vc3RpY3MuVlVFX1JPVVRFUl9SMDAxMSh7IGNhdXNlOiBlcnIgfSk7XG5cdFx0XHRcdH0pO1xuXHRcdFx0fVxuXHRcdFx0Y29uc3QgcmVhY3RpdmVSb3V0ZSA9IHt9O1xuXHRcdFx0Zm9yIChjb25zdCBrZXkgaW4gU1RBUlRfTE9DQVRJT05fTk9STUFMSVpFRCkgT2JqZWN0LmRlZmluZVByb3BlcnR5KHJlYWN0aXZlUm91dGUsIGtleSwge1xuXHRcdFx0XHRnZXQ6ICgpID0+IGN1cnJlbnRSb3V0ZS52YWx1ZVtrZXldLFxuXHRcdFx0XHRlbnVtZXJhYmxlOiB0cnVlXG5cdFx0XHR9KTtcblx0XHRcdGFwcC5wcm92aWRlKHJvdXRlcktleSwgcm91dGVyKTtcblx0XHRcdGFwcC5wcm92aWRlKHJvdXRlTG9jYXRpb25LZXksIHNoYWxsb3dSZWFjdGl2ZShyZWFjdGl2ZVJvdXRlKSk7XG5cdFx0XHRhcHAucHJvdmlkZShyb3V0ZXJWaWV3TG9jYXRpb25LZXksIGN1cnJlbnRSb3V0ZSk7XG5cdFx0XHRjb25zdCB1bm1vdW50QXBwID0gYXBwLnVubW91bnQ7XG5cdFx0XHRpbnN0YWxsZWRBcHBzLmFkZChhcHApO1xuXHRcdFx0YXBwLnVubW91bnQgPSBmdW5jdGlvbigpIHtcblx0XHRcdFx0aW5zdGFsbGVkQXBwcy5kZWxldGUoYXBwKTtcblx0XHRcdFx0aWYgKGluc3RhbGxlZEFwcHMuc2l6ZSA8IDEpIHtcblx0XHRcdFx0XHRwZW5kaW5nTG9jYXRpb24gPSBTVEFSVF9MT0NBVElPTl9OT1JNQUxJWkVEO1xuXHRcdFx0XHRcdHJlbW92ZUhpc3RvcnlMaXN0ZW5lciAmJiByZW1vdmVIaXN0b3J5TGlzdGVuZXIoKTtcblx0XHRcdFx0XHRyZW1vdmVIaXN0b3J5TGlzdGVuZXIgPSBudWxsO1xuXHRcdFx0XHRcdGN1cnJlbnRSb3V0ZS52YWx1ZSA9IFNUQVJUX0xPQ0FUSU9OX05PUk1BTElaRUQ7XG5cdFx0XHRcdFx0c3RhcnRlZCA9IGZhbHNlO1xuXHRcdFx0XHRcdHJlYWR5ID0gZmFsc2U7XG5cdFx0XHRcdH1cblx0XHRcdFx0dW5tb3VudEFwcCgpO1xuXHRcdFx0fTtcblx0XHRcdGlmICgocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiIHx8IF9fVlVFX1BST0RfREVWVE9PTFNfXykgJiYgaXNCcm93c2VyICYmIHRydWUpIGFkZERldnRvb2xzKGFwcCwgcm91dGVyLCBtYXRjaGVyKTtcblx0XHR9XG5cdH07XG5cdGZ1bmN0aW9uIHJ1bkd1YXJkUXVldWUoZ3VhcmRzKSB7XG5cdFx0cmV0dXJuIGd1YXJkcy5yZWR1Y2UoKHByb21pc2UsIGd1YXJkKSA9PiBwcm9taXNlLnRoZW4oKCkgPT4gcnVuV2l0aENvbnRleHQoZ3VhcmQpKSwgUHJvbWlzZS5yZXNvbHZlKCkpO1xuXHR9XG5cdHJldHVybiByb3V0ZXI7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IE5hdmlnYXRpb25GYWlsdXJlVHlwZSwgUm91dGVyTGluaywgUm91dGVyVmlldywgU1RBUlRfTE9DQVRJT05fTk9STUFMSVpFRCBhcyBTVEFSVF9MT0NBVElPTiwgY3JlYXRlTWVtb3J5SGlzdG9yeSwgY3JlYXRlUm91dGVyLCBjcmVhdGVSb3V0ZXJNYXRjaGVyLCBjcmVhdGVXZWJIYXNoSGlzdG9yeSwgY3JlYXRlV2ViSGlzdG9yeSwgaXNOYXZpZ2F0aW9uRmFpbHVyZSwgbG9hZFJvdXRlTG9jYXRpb24sIG1hdGNoZWRSb3V0ZUtleSwgb25CZWZvcmVSb3V0ZUxlYXZlLCBvbkJlZm9yZVJvdXRlVXBkYXRlLCBwYXJzZVF1ZXJ5LCByb3V0ZUxvY2F0aW9uS2V5LCByb3V0ZXJLZXksIHJvdXRlclZpZXdMb2NhdGlvbktleSwgc3RyaW5naWZ5UXVlcnksIHVzZUxpbmssIHVzZVJvdXRlLCB1c2VSb3V0ZXIsIHZpZXdEZXB0aEtleSB9O1xuIl0sImZpbGUiOiJDOi9Vc2Vycy9zaW1vb29uZS9EZXNrdG9wL2Nvc2FzL2ZhY3RvcmlhIGY1L3RyYWJham9zL3Byb2plY3QtcDUtZGlnaXRhbC1hY2FkZW15LXRlYW0zLXJlc3RhdXJhbnQtZnJvbnRlbmQvbm9kZV9tb2R1bGVzLy52aXRlL2RlcHMvdnVlLXJvdXRlci5qcyIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDEsMiwzLDQsNSw2LDcsOF19