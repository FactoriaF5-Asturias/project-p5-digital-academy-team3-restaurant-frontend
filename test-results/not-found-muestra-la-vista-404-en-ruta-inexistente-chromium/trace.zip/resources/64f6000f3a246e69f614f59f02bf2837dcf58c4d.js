import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/NotFoundView.vue");import MainHeader from "/src/components/common/MainHeader.vue";
import notFoundIcon from "/src/assets/notfound.svg?import"

const _sfc_main = {
  __name: 'NotFoundView',
  setup(__props, { expose: __expose }) {
  __expose();


const __returned__ = { MainHeader, get notFoundIcon() { return notFoundIcon } }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { createVNode as _createVNode, createElementVNode as _createElementVNode, createTextVNode as _createTextVNode, resolveComponent as _resolveComponent, withCtx as _withCtx, Fragment as _Fragment, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/node_modules/.vite/deps/vue.js?v=7f2dea69"

const _hoisted_1 = { class: "min-h-[calc(100vh-88px)] flex items-center justify-center px-8" }
const _hoisted_2 = { class: "flex flex-col items-center text-center max-w-3xl gap-5" }
const _hoisted_3 = ["src"]

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_RouterLink = _resolveComponent("RouterLink")

  return (_openBlock(), _createElementBlock(_Fragment, null, [
    _createVNode($setup["MainHeader"]),
    _createElementVNode("main", _hoisted_1, [
      _createElementVNode("section", _hoisted_2, [
        _createElementVNode("img", {
          src: $setup.notFoundIcon,
          alt: "",
          class: "w-20 h-20"
        }, null, 8 /* PROPS */, _hoisted_3),
        _cache[1] || (_cache[1] = _createElementVNode("h1", { class: "font-display text-5xl text-text-brand font-bold" }, " ¡Página no encontrada! ", -1 /* CACHED */)),
        _cache[2] || (_cache[2] = _createElementVNode("p", { class: "text-text-muted text-xl max-w-2xl" }, " Lo sentimos, la página que buscas no existe o ha sido trasladada. Es posible que el enlace esté roto o haya caducado. ", -1 /* CACHED */)),
        _createVNode(_component_RouterLink, {
          to: "/",
          class: "bg-bg-brand text-text-on-brand px-14 py-3 rounded-md font-semibold inline-flex items-center gap-2 transition-colors hover:bg-bg-brand-darker"
        }, {
          default: _withCtx(() => [...(_cache[0] || (_cache[0] = [
            _createTextVNode(" Volver a la página principal ", -1 /* CACHED */),
            _createElementVNode("span", {
              "aria-hidden": "true",
              class: "text-2xl"
            }, "→", -1 /* CACHED */)
          ]))]),
          _: 1 /* STABLE */
        })
      ])
    ])
  ], 64 /* STABLE_FRAGMENT */))
}



_sfc_main.__hmrId = "071430af"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"C:/Users/simooone/Desktop/cosas/factoria f5/trabajos/project-p5-digital-academy-team3-restaurant-frontend/src/views/NotFoundView.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTm90Rm91bmRWaWV3LnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8c2NyaXB0IHNldHVwPlxyXG5pbXBvcnQgTWFpbkhlYWRlciBmcm9tICcuLi9jb21wb25lbnRzL2NvbW1vbi9NYWluSGVhZGVyLnZ1ZSc7XHJcbmltcG9ydCBub3RGb3VuZEljb24gZnJvbSAnLi4vYXNzZXRzL25vdGZvdW5kLnN2ZydcclxuPC9zY3JpcHQ+XHJcblxyXG48dGVtcGxhdGU+XHJcbiAgICA8TWFpbkhlYWRlciAvPlxyXG4gICAgPG1haW4gY2xhc3M9XCJtaW4taC1bY2FsYygxMDB2aC04OHB4KV0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcHgtOFwiPlxyXG4gICAgICAgIDxzZWN0aW9uIGNsYXNzPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgdGV4dC1jZW50ZXIgbWF4LXctM3hsIGdhcC01XCI+XHJcbiAgICAgICAgICAgIDxpbWcgOnNyYz1cIm5vdEZvdW5kSWNvblwiIGFsdD1cIlwiIGNsYXNzPVwidy0yMCBoLTIwXCI+XHJcbiAgICAgICAgICAgIDxoMSBjbGFzcz1cImZvbnQtZGlzcGxheSB0ZXh0LTV4bCB0ZXh0LXRleHQtYnJhbmQgZm9udC1ib2xkXCI+XHJcbiAgICAgICAgICAgICAgICDCoVDDoWdpbmEgbm8gZW5jb250cmFkYSFcclxuICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAgPHAgY2xhc3M9XCJ0ZXh0LXRleHQtbXV0ZWQgdGV4dC14bCBtYXgtdy0yeGxcIj5cclxuICAgICAgICAgICAgICAgIExvIHNlbnRpbW9zLCBsYSBww6FnaW5hIHF1ZSBidXNjYXMgbm8gZXhpc3RlIG8gaGEgc2lkbyB0cmFzbGFkYWRhLiBFcyBwb3NpYmxlIHF1ZSBlbCBlbmxhY2UgZXN0w6kgcm90byBvIGhheWEgY2FkdWNhZG8uXHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPFJvdXRlckxpbmsgdG89XCIvXCIgY2xhc3M9XCJiZy1iZy1icmFuZCB0ZXh0LXRleHQtb24tYnJhbmQgcHgtMTQgcHktMyByb3VuZGVkLW1kIGZvbnQtc2VtaWJvbGQgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRyYW5zaXRpb24tY29sb3JzIGhvdmVyOmJnLWJnLWJyYW5kLWRhcmtlclwiPlxyXG4gICAgICAgICAgICAgICAgVm9sdmVyIGEgbGEgcMOhZ2luYSBwcmluY2lwYWwgPHNwYW4gYXJpYS1oaWRkZW49XCJ0cnVlXCIgY2xhc3M9XCJ0ZXh0LTJ4bFwiPuKGkjwvc3Bhbj5cclxuICAgICAgICAgICAgPC9Sb3V0ZXJMaW5rPlxyXG4gICAgICAgIDwvc2VjdGlvbj5cclxuICAgIDwvbWFpbj5cclxuPC90ZW1wbGF0ZT4iXSwibWFwcGluZ3MiOiJBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7Ozs7O0FBRm5DOzs7Ozs7Ozs7O3FCQU9KLEtBQUssRUFBQyxnRUFBZ0U7cUJBQy9ELEtBQUssRUFBQyx3REFBd0Q7Ozs7Ozs7SUFGM0UsYUFBYztJQUNkLG9CQWFPLFFBYlAsVUFhTztNQVpILG9CQVdVLFdBWFYsVUFXVTtRQVZOLG9CQUFrRDtVQUE1QyxHQUFHLEVBQUUsbUJBQVk7VUFBRSxHQUFHLEVBQUMsRUFBRTtVQUFDLEtBQUssRUFBQyxXQUFXOztrQ0FDakQsb0JBRUssUUFGRCxLQUFLLEVBQUMsaURBQWlELElBQUMsMEJBRTVEO2tDQUNBLG9CQUVJLE9BRkQsS0FBSyxFQUFDLG1DQUFtQyxJQUFDLHlIQUU3QztRQUNBLGFBRWE7VUFGRCxFQUFFLEVBQUMsR0FBRztVQUFDLEtBQUssRUFBQyw4SUFBOEk7OzRCQUFDLENBQ3ZJOzZCQUR1SSxnQ0FDdkk7WUFBQSxvQkFBa0Q7Y0FBNUMsYUFBVyxFQUFDLE1BQU07Y0FBQyxLQUFLLEVBQUMsVUFBVTtlQUFDLEdBQUMiLCJpZ25vcmVMaXN0IjpbXX0=